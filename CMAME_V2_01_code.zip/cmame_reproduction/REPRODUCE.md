# CMAME revision reproducibility

Unzip the code archive and the records archive into the SAME directory.
Both contain `cmame_reproduction/`; their files are complementary.
Python3.9.7 was used. Install requirements in a fresh virtual environment.

```sh
python -m pip install -r requirements.txt
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
python -m pytest cmame_trimmed/tests cmame_trimmed/revision_v2/tests -q
python -m cmame_trimmed.revision_v2.analyze
python -m cmame_trimmed.revision_v2.cost_analyze
python -m cmame_trimmed.figures
python -m cmame_trimmed.revision_v2.figures
python -m cmame_trimmed.revision_v2.cost_figures --timings-finished
python -m cmame_trimmed.revision_v2.audit_figures --timings-finished
python -m cmame_trimmed.revision_v2.elastic_fields --from-records
python -m cmame_trimmed.revision_v2.build_revision
```

The plot commands regenerate figures from included measurements. They do
not rerun timing experiments. `elastic_fields --from-records` plots the
saved spline fields; omitting the flag recomputes their direct-reference
solutions and display surfaces. To repeat timings, make a separate copy
and preserve its entire `cmame_trimmed/revision_v2/results` directory under
a different name before starting with an empty results directory. This
regenerates the manifests and source snapshots for the new environment;
retaining a published manifest would retain its original environment
metadata. Run `python -m cmame_trimmed.revision_v2.campaign all`, followed
serially by `python -m cmame_trimmed.revision_v2.cost_ablation all`.
Record the new processor and memory configuration alongside those results.
Never run timed studies concurrently. Each driver refuses to overwrite its
formal records. Manifests verify frozen source hashes; new experiment code
must get a new manifest, not masquerade as the archived implementation.

Independent audit commands:
`python -m cmame_trimmed.revision_v2.kernel_study`
`python -m cmame_trimmed.revision_v2.active_audit`
`python -m cmame_trimmed.revision_v2.mechanism_audit --mode all`
Run these audits in the same fresh results tree before rebuilding a paper
from newly measured timings. Preserve previous audit records separately.

The original seven-family records and the new 3D records have separate
configurations and timing provenance. Pilots are excluded from paper claims.
The four-policy stopping-rule experiment is a disclosed follow-up study.
It adds measured-cost stopping and deterministic lookahead to the repeated
fixed-power and progressive baselines. The time scopes
exclude warm-start transfer, reference solves, validation and file output.
All unsuccessful attempts are preserved; no failed sequence is a speedup.

For LaTeX, compile the merged manuscript and supplement with a current
TeXLive/MacTeX installation providing elsarticle and its bibliography style:
`latexmk -pdf manuscript.tex` and `latexmk -pdf supplement.tex` in the
submission directory. Each document has one body source file; figures and
BibTeX remain separate. Manuscript preparation does not submit the article.
