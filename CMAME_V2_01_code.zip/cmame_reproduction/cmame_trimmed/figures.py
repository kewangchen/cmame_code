"""Publication figures from recorded data; no synthetic benchmark values."""
import json,csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,TwoSlopeNorm
from matplotlib.patches import FancyBboxPatch,Circle
from cmame_trimmed.src.space import SplineGrid
ROOT=Path(__file__).resolve().parent;R=ROOT/'results';F=ROOT/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'legend.fontsize':7.5,'xtick.labelsize':8,'ytick.labelsize':8,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,'savefig.dpi':300,'figure.facecolor':'white'})
COL={'energy':'#087f8c','fresh':'#26384a','exact_local':'#d99a30','energy_raw':'#b44d61','energy_deterministic':'#8864aa','stale':'#9fadb8','periodic':'#687b42','jacobi':'#4b6baa','cbas':'#9a7348','deflation':'#aa4e22','direct':'#363636'}
LAB={'energy':'Risk-controlled reuse','fresh':'Fresh Schwarz','exact_local':'Exact local refresh','energy_raw':'Raw-anchor reuse','energy_deterministic':'Deterministic reuse','stale':'Transported stale','periodic':'Periodic (5)','jacobi':'Jacobi','cbas':'CbAS','deflation':'Coordinate deflation','direct':'Sparse direct'}
CASES={'moving_hole':'Moving hole','local_plate':'Local plate edit','active_crossing':'Active-space crossing','elastic_plate':'Plane-strain plate','elastic_solid':'Extruded elastic solid','large_plate':'Refined plate','ridge':'Ridge boundary'}
manifest=[]

def read(n):return json.loads((R/(n+'.json')).read_text())
def save(fig,name,source):
    for ext in ('pdf','svg','png'):fig.savefig(F/(name+'.'+ext),bbox_inches='tight',pad_inches=.08)
    plt.close(fig);manifest.append([name,source,'Python/matplotlib','PDF+SVG vector; PNG 300 dpi'])
def panel(ax,letter,title=None):
    ax.text(-.12,1.05,letter,transform=ax.transAxes,fontweight='bold',fontsize=12,va='bottom')
    if title:ax.set_title(title,loc='left',pad=9)
    ax.grid(axis='y',color='#e7ebef',lw=.6,zorder=0)
def legend(ax,**kwargs):return ax.legend(frameon=False,**kwargs)


def mechanism():
    fig=plt.figure(figsize=(7.2,3.6));gs=fig.add_gridspec(2,3,height_ratios=[.65,1],hspace=.55,wspace=.4)
    ax=fig.add_subplot(gs[0,:]);ax.axis('off')
    labels=['Current trimmed system\n'+r'$A_t$ and stable basis IDs','Transport old local factors\n'+r'$C_{i,a}\ \mapsto\ S_{i,t}^{-1}C_{i,a}^{-1}S_{i,t}^{-1}$','Test cumulative energy drift\naccept, or refresh the factor']
    for i,label in enumerate(labels):
        x=.02+i*.33;box=FancyBboxPatch((x,.12),.29,.74,boxstyle='round,pad=.012,rounding_size=.04',edgecolor='#b9c8cf',facecolor=['#eef3f7','#e2f1ef','#fbf0da'][i],transform=ax.transAxes,lw=.8);ax.add_patch(box);ax.text(x+.15,.49,label,ha='center',va='center',transform=ax.transAxes,fontsize=8.5)
        if i<2:ax.annotate('',xy=(x+.33,.49),xytext=(x+.30,.49),xycoords='axes fraction',arrowprops=dict(arrowstyle='->',color='#607481',lw=1.2))
    eps=np.geomspace(1,.001,100);cond=[]
    H=np.array([[1.,1.],[1.,4/3]])
    from scipy.linalg import eigvalsh
    for e in eps:
        A=np.array([[e,e*e],[e*e,4*e**3/3]])
        eig=eigvalsh(A,H);cond.append(eig[-1]/eig[0])
    ax=fig.add_subplot(gs[1,0]);panel(ax,'a','Amplitude drift')
    ax.loglog(eps,cond,color=COL['energy_raw'],label='Raw anchor');ax.loglog(eps,np.ones_like(eps),color=COL['energy'],label='Transported anchor');ax.invert_xaxis();ax.set(xlabel=r'Cut length $\varepsilon$',ylabel='Condition number');legend(ax,loc='upper left')
    ax=fig.add_subplot(gs[1,1]);panel(ax,'b','Cumulative drift')
    t=np.arange(31);ax.semilogy(t,2/.97**t-1,color=COL['energy_raw'],label='Per-step acceptance')
    tau=.2;anchor=0;vals=[]
    for i in t:
        small=.97**i;previous=.97**anchor
        if max(abs(small/previous-1),abs((2-small)/(2-previous)-1))>tau:anchor=i;previous=small
        vals.append(((2-small)/(2-previous))/(small/previous))
    ax.semilogy(t,vals,color=COL['energy'],label='Anchor acceptance');ax.set(xlabel='Query',ylabel='Condition number');legend(ax,loc='upper left')
    ax=fig.add_subplot(gs[1,2]);panel(ax,'c','Anytime risk allocation')
    j=np.arange(1,101);spent=np.cumsum(6/(np.pi**2*j*j));ax.plot(j,spent,color=COL['energy']);ax.axhline(1,color='#8d99a5',ls='--',lw=.8);ax.set(xlabel='Independent check index',ylabel='Cumulative budget / '+r'$\delta$',ylim=(.55,1.03))
    save(fig,'01_mechanism','Analytic formulas in manuscript: homogeneous Gram, cumulative drift, summable risk budget')


def accuracy():
    data=read('accuracy');fig,axs=plt.subplots(1,2,figsize=(7.2,2.7),layout='constrained')
    for p,col in zip((1,2,3,4),('#99a6ad','#45687e','#087f8c','#d99a30')):
        rows=[r for r in data['convergence'] if r['degree']==p];n=np.array([r['n'] for r in rows]);v=[r['H1_seminorm'] for r in rows]
        axs[0].loglog(n,v,'o-',ms=3,color=col,label=f'$p={p}$')
    panel(axs[0],'a','Manufactured-solution convergence');axs[0].set(xlabel='Cells per direction',ylabel=r'$H^1$ seminorm error');axs[0].set_xticks([4,8,16,32],[4,8,16,32]);legend(axs[0],ncol=2)
    rows=data['quadrature'][:-1];axs[1].semilogy([r['order'] for r in rows],[r['matrix_relative_frobenius'] for r in rows],'o-',color=COL['fresh'],ms=4,label='Matrix difference');axs[1].semilogy([r['order'] for r in rows],[r['energy_difference'] for r in rows],'s-',color=COL['energy'],ms=4,label='Solution energy difference');panel(axs[1],'b','Independent quadrature check');axs[1].set(xlabel='Gauss order per subinterval',ylabel='Relative difference to order 24');legend(axs[1])
    save(fig,'02_accuracy','results/accuracy.json')


def cut_study():
    data=read('cut_study');fig,axs=plt.subplots(1,2,figsize=(7.2,2.8),layout='constrained')
    for ax,typ,title in zip(axs,['fixed_domain_sliver','thin_domain'],['Fixed bulk with a vanishing cut strip','Shrinking physical strip']):
        for m in ('jacobi','cbas','deflation','fresh'):
            rows=[r for r in data['rows'] if r['degree']==4 and r['method']==m and r['geometry_type']==typ]
            ax.semilogx([r['cut'] for r in rows],[r['iterations'] for r in rows],'o-',ms=3,color=COL[m],label=LAB[m])
        ax.invert_xaxis();ax.set(xlabel=r'Relative strip thickness $\eta$',ylabel='PCG iterations')
        panel(ax,'a' if typ=='fixed_domain_sliver' else 'b',title)
    legend(axs[0],ncol=2,loc='center left');save(fig,'03_cut_conditioning','results/cut_study.json; degree 4; all active unknowns retained')


def spectral():
    data=read('spectral_audit');rows=data['rows'];fig,axs=plt.subplots(1,2,figsize=(7.2,2.8),layout='constrained')
    t=[r['step'] for r in rows]
    axs[0].fill_between(t,.8,1.2,color='#e2f1ef',label='Theorem interval')
    axs[0].plot(t,[r['lower'] for r in rows],'o-',color=COL['fresh'],ms=3,label='Smallest eigenvalue');axs[0].plot(t,[r['upper'] for r in rows],'s-',color=COL['energy'],ms=3,label='Largest eigenvalue');axs[0].set(xlabel='Query',ylabel=r'Eigenvalues of $(B_r,B_f)$',ylim=(.76,1.24));panel(axs[0],'a','Independent global spectral audit');legend(axs[0],loc='lower right')
    axs[1].plot(t,[r['fresh_condition'] for r in rows],'o-',ms=3,color=COL['fresh'],label='Fresh Schwarz');axs[1].plot(t,[r['reuse_condition'] for r in rows],'s-',ms=3,color=COL['energy'],label='Retained Schwarz');axs[1].set(xlabel='Query',ylabel='Preconditioned condition number');panel(axs[1],'b','Conditioning after accepted changes');legend(axs[1]);save(fig,'04_spectral_audit','results/spectral_audit.json; independently formed dense operators')


def field_data(name):
    files=sorted(R.glob(name+'_state_*.npz'));z=np.load(files[-1]);g=SplineGrid(tuple(z['cells']),int(z['degree']));c=int(z['components']);full=np.zeros(g.size*c);full[z['ids']]=z['solution'];coef=full.reshape(*g.shape,c)
    x=np.linspace(0,1,241);y=np.linspace(0,float(z['top']),241);X,Y=np.meshgrid(x,y,indexing='ij');bx=g.splines[0](x);by=g.splines[1](y)
    if g.dim==3:coef=np.einsum('ijkc,k->ijc',coef,g.splines[2](1.))
    U=np.einsum('xi,ijc,yj->xyc',bx,coef,by,optimize=True)
    mask=np.ones(X.shape,dtype=bool)
    for cx,cy,r in z['holes']:mask&=(X-cx)**2+(Y-cy)**2>=r*r
    if len(z['roof']):mask&=Y<=np.interp(X,z['roof'][:,0],z['roof'][:,1])
    values=U[:,:,0] if c==1 else np.linalg.norm(U,axis=2);values=np.where(mask,values,np.nan)
    return z,X,Y,U,values


def geometries():
    names=['moving_hole','local_plate','active_crossing','elastic_plate']
    fig,axs=plt.subplots(1,4,figsize=(7.2,2.45),layout='constrained')
    cmap=LinearSegmentedColormap.from_list('field',['#f7f3e9','#9fc9c4','#368b9a','#173f5f'])
    for i,(ax,name) in enumerate(zip(axs,names)):
        z,X,Y,U,V=field_data(name);im=ax.pcolormesh(X,Y,V,cmap=cmap,rasterized=True,shading='auto');ax.set_aspect('equal');ax.set(xlim=(0,1),ylim=(0,1));ax.set_xticks([]);ax.set_yticks([]);panel(ax,chr(97+i),CASES[name]);ax.grid(False)
        for cx,cy,r in z['holes']:ax.add_patch(Circle((cx,cy),r,fill=False,color='#637982',lw=.65))
        ax.plot([0,0],[0,float(z['top'])],color='#b44d61',lw=2.5)
        cb=fig.colorbar(im,ax=ax,orientation='horizontal',fraction=.065,pad=.06);cb.ax.tick_params(labelsize=8);cb.set_label(r'$u$' if int(z['components'])==1 else r'$\|\mathbf{u}\|_2$',fontsize=8.5)
    save(fig,'05_fields','results/*_state_*.npz; tensor spline evaluation on current physical domain')


def performance():
    names=[n for n in CASES if (R/('sequence_'+n+'.json')).exists()]
    methods=['fresh','exact_local','energy','energy_deterministic','energy_raw','stale','periodic','jacobi','cbas','deflation','direct']
    table=[];summaries={};failures=[]
    for name in names:
        data=read('sequence_'+name);s={}
        for m in methods:
            rows=[r for r in data['rows'] if r['method']==m]
            if not rows:continue
            reps=sorted(set(r['repeat'] for r in rows));vals={k:[sum(r[k] for r in rows if r['repeat']==rep) for rep in reps] for k in ['linear','total','setup','solve','assembly','iterations']}
            s[m]={k:float(np.median(v)) for k,v in vals.items()};s[m]['linear_min']=min(vals['linear']);s[m]['linear_max']=max(vals['linear']);s[m]['total_min']=min(vals['total']);s[m]['total_max']=max(vals['total']);s[m]['failures']=sum(not r['success'] for r in rows);s[m]['max_energy_error']=max(r['energy_error'] for r in rows);s[m]['max_residual']=max(r['residual'] for r in rows);s[m]['nmin']=min(r['dofs'] for r in rows);s[m]['nmax']=max(r['dofs'] for r in rows);s[m]['factorizations']=float(np.median([sum(r.get('stat_new',0)+r.get('stat_refreshed',0) for r in rows if r['repeat']==rep) for rep in reps]));s[m]['checked']=sum(r.get('stat_randomized_checks',0) for r in rows)
        summaries[name]=s
        for m,v in s.items():
            rr=[r for r in data['rows'] if r['method']==m]
            v['screen_acceptances']=sum(r.get('stat_reused_energy',0) for r in rr)
            v['small_block_refreshes']=sum(r.get('stat_skipped_small_blocks',0) for r in rr)
        for m,v in s.items():table.append(dict(case=name,method=m,**v,speedup_linear=s['fresh']['linear']/v['linear'],speedup_total=s['fresh']['total']/v['total']))
        failures+=data.get('failures',[])
    (R/'summary.json').write_text(json.dumps(dict(cases=summaries,failures=failures),indent=2))
    with open(R/'summary.csv','w') as f:
        w=csv.DictWriter(f,fieldnames=table[0].keys());w.writeheader();w.writerows(table)
    available=[m for m in methods if any(m in s for s in summaries.values())]
    values=np.array([[np.log2(summaries[n][m]['linear']/summaries[n]['fresh']['linear']) if m in summaries[n] else np.nan for n in names] for m in available])
    fig,ax=plt.subplots(figsize=(7.2,4.2),layout='constrained');im=ax.imshow(values,cmap='RdBu_r',vmin=-2,vmax=2,aspect='auto')
    for i,m in enumerate(available):
        for j,n in enumerate(names):
            if m in summaries[n]:ax.text(j,i,f"{2**values[i,j]:.2f}",ha='center',va='center',fontsize=8.5,color='white' if abs(values[i,j])>1.25 else '#1e2a34')
    ax.set_xticks(np.arange(len(names)),[CASES[n] for n in names],rotation=30,ha='right');ax.set_yticks(np.arange(len(available)),[LAB[m] for m in available]);ax.set_title('Sequence linear-algebra time / fresh Schwarz (lower is faster)',loc='left',pad=12)
    ax.tick_params(labelsize=9)
    cb=fig.colorbar(im,ax=ax,shrink=.75);cb.set_ticks([-2,-1,0,1,2],labels=['0.25','0.5','1','2','4']);cb.set_label('Time ratio; colors clipped at 0.25 and 4')
    save(fig,'06_method_comparison','results/sequence_*.json; median complete-sequence sum across repetitions')
    chosen=[n for n in ['moving_hole','active_crossing','elastic_solid'] if n in names]
    fig,axs=plt.subplots(1,len(chosen),figsize=(7.2,2.7),layout='constrained',squeeze=False)
    for i,name in enumerate(chosen):
        ax=axs[0,i];data=read('sequence_'+name)
        for m in ['fresh','exact_local','energy','energy_raw']:
            rows=sorted([r for r in data['rows'] if r['method']==m and r['repeat']==0],key=lambda r:r['step'])
            if rows:ax.plot(np.arange(len(rows)),np.cumsum([r['linear'] for r in rows]),color=COL[m],label=LAB[m],lw=1.4)
        panel(ax,chr(97+i),CASES[name]);ax.set(xlabel='Query',ylabel='Cumulative setup + solve (s)')
    legend(axs[0,0],fontsize=8);save(fig,'07_cumulative_cost','results/sequence_*.json; first recorded repetition, all cold setup included')
    return summaries


def active_history():
    name='active_crossing';data=read('sequence_'+name);rows=sorted([r for r in data['rows'] if r['method']=='energy' and r['repeat']==0],key=lambda r:r['step']);x=np.arange(len(rows));fig,axs=plt.subplots(1,2,figsize=(7.2,2.6),layout='constrained')
    axs[0].plot(x,[r['dofs'] for r in rows],'o-',color=COL['fresh'],ms=3);panel(axs[0],'a','Changing active spline space');axs[0].set(xlabel='Query',ylabel='Active free degrees of freedom')
    fields=['stat_new','stat_refreshed','stat_reused_energy','stat_reused_unchanged','stat_reused_exact'];labels=['New membership','Refreshed','Accepted drift','Unchanged','Identical'];colors=['#26384a','#b44d61','#087f8c','#d0e4e1','#e3e9ee'];bottom=np.zeros(len(rows))
    for f,l,c in zip(fields,labels,colors):
        v=np.array([r.get(f,0) for r in rows]);
        if not np.any(v):continue
        axs[1].bar(x,v,bottom=bottom,color=c,label=l,width=.8);bottom+=v
    panel(axs[1],'b','Local factor decisions');axs[1].set(xlabel='Query',ylabel='Number of unique local blocks',ylim=(0,max(bottom)*1.4));legend(axs[1],ncol=2,fontsize=7.5)
    save(fig,'08_active_space','results/sequence_active_crossing.json; first repetition')


def solid_figure():
    files=sorted(R.glob('elastic_solid_state_*.npz'));z=np.load(files[-1]);g=SplineGrid(tuple(z['cells']),int(z['degree']));c=3
    coeff=np.zeros(g.size*c);coeff[z['ids']]=z['solution'];coeff=coeff.reshape(*g.shape,c)
    def evaluate(points):
        out=[]
        for start in range(0,len(points),300):
            p=points[start:start+300];bs=[s(p[:,a]) for a,s in enumerate(g.splines)]
            out.append(np.einsum('qi,qj,qk,ijkc->qc',*bs,coeff,optimize=True))
        return np.linalg.norm(np.concatenate(out),axis=1)
    v=np.linspace(0,1,70);X,Y=np.meshgrid(v,v);surfaces=[]
    for zz in (0.,1.):
        Z=np.full_like(X,zz);mask=np.ones_like(X,dtype=bool)
        for cx,cy,r in z['holes']:mask&=(X-cx)**2+(Y-cy)**2>=r*r
        surfaces.append((X,Y,Z,mask))
    for a,side in ((0,0.),(0,1.),(1,0.),(1,1.)):
        if a==0:surfaces.append((np.full_like(X,side),X,Y,np.ones_like(X,dtype=bool)))
        else:surfaces.append((X,np.full_like(X,side),Y,np.ones_like(X,dtype=bool)))
    for cx,cy,r in z['holes']:
        th,zz=np.meshgrid(np.linspace(0,2*np.pi,110),v)
        surfaces.append((cx+r*np.cos(th),cy+r*np.sin(th),zz,np.ones_like(th,dtype=bool)))
    values=[evaluate(np.column_stack([a.ravel(),b.ravel(),c.ravel()])).reshape(a.shape) for a,b,c,_ in surfaces]
    vmax=max(float(a.max()) for a in values);norm=plt.Normalize(0,vmax);cmap=plt.get_cmap('viridis')
    fig=plt.figure(figsize=(7.2,3.15));gs=fig.add_gridspec(1,2,width_ratios=[1.05,1],wspace=.32);ax=fig.add_subplot(gs[0],projection='3d')
    for (x,y,zz,mask),value in zip(surfaces,values):
        ax.plot_surface(np.where(mask,x,np.nan),np.where(mask,y,np.nan),np.where(mask,zz,np.nan),facecolors=cmap(norm(value)),rstride=1,cstride=1,linewidth=0,edgecolor='none',antialiased=False,shade=False,rasterized=True)
    ax.view_init(25,-60);ax.set_box_aspect((1,1,1));ax.set_axis_off();ax.text2D(0,1.02,r'$\mathbf{a}$  Extruded elastic solid',transform=ax.transAxes,fontsize=10)
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),ax=ax,location='bottom',fraction=.045,pad=-.02,shrink=.7);cb.set_label(r'Displacement magnitude $\|\mathbf{u}\|_2$')
    ax=fig.add_subplot(gs[1]);data=read('sequence_elastic_solid');methods=['fresh','exact_local','energy_deterministic','energy'];bottom=np.zeros(4)
    for field,label,color in [('stat_factorization_time','Factorization','#26384a'),('stat_randomized_time','Gaussian screen','#087f8c'),('stat_energy_preparation_time','Inverse preparation','#8864aa'),('other','Other setup','#d5dde2')]:
        vals=[]
        for method in methods:
            rr=[r for r in data['rows'] if r['method']==method and r['step']>0]
            if field=='other':v=np.mean([r['setup']-sum(r.get(k,0) or 0 for k in ['stat_factorization_time','stat_randomized_time','stat_energy_preparation_time']) for r in rr])
            else:v=np.mean([r.get(field,0) or 0 for r in rr])
            vals.append(v)
        ax.bar(np.arange(4),vals,bottom=bottom,color=color,label=label,width=.65);bottom+=vals
    panel(ax,'b','Cost of subsequent setup');ax.set_xticks(np.arange(4),['Fresh','Exact local','Deterministic','Risk-controlled'],rotation=20,ha='right');ax.set_ylabel('Mean setup time per query (s)');ax.set_ylim(0,max(bottom)*1.45);legend(ax,fontsize=7.5)
    save(fig,'09_elastic_solid','results/elastic_solid_state_11.npz and sequence_elastic_solid.json; undeformed surface colored by evaluated displacement; setup means exclude initial query')


def sensitivity():
    data=read('update_sensitivity');fig,axs=plt.subplots(1,2,figsize=(7.2,2.8),layout='constrained')
    mult=data['multipliers'];records=data['rows']
    for method in data['methods']:
        med=[];low=[];high=[]
        for a in mult:
            vals=[sum(r['linear'] for r in records if r['multiplier']==a and r['repeat']==rep and r['method']==method) for rep in range(3)]
            med.append(np.median(vals));low.append(min(vals));high.append(max(vals))
        axs[0].plot(mult,med,'o-',ms=3,color=COL[method],label=LAB[method]);axs[0].fill_between(mult,low,high,color=COL[method],alpha=.10)
    axs[0].set_xscale('log');axs[0].set(xlabel='Geometry-step multiplier',ylabel='24-query setup + solve (s)');panel(axs[0],'a','Larger edits and longer sequences');axs[0].set_ylim(0,axs[0].get_ylim()[1]*1.3);legend(axs[0],fontsize=7.5,ncol=2,loc='upper left')
    x=np.arange(len(mult));bottom=np.zeros(len(mult))
    for field,label,color in [('accepted','Accepted screen',COL['energy']),('rejected','Rejected screen',COL['energy_raw']),('small','Direct small-block refresh','#d99a30')]:
        values=[]
        for a in mult:
            rr=[r for r in records if r['multiplier']==a and r['method']=='energy']
            accepted=sum(r.get('stat_reused_energy',0) for r in rr)/3
            checks=sum(r.get('stat_randomized_checks',0) for r in rr)/3
            values.append(accepted if field=='accepted' else checks-accepted if field=='rejected' else sum(r.get('stat_skipped_small_blocks',0) for r in rr)/3)
        axs[1].bar(x,values,bottom=bottom,color=color,label=label,width=.65);bottom+=values
    axs[1].set_xticks(x,[str(v) for v in mult]);axs[1].set(xlabel='Geometry-step multiplier',ylabel='Mean decisions per sequence');panel(axs[1],'b','Cost of changing local blocks');axs[1].set_ylim(0,max(bottom)*1.4);legend(axs[1],fontsize=7.5)
    save(fig,'10_update_sensitivity','results/update_sensitivity.json; median and min-max over three complete sequences; decision counts averaged over repeats')


def polynomial_mechanism():
    data=read('mechanism_audit');r=data['rows'];x=[v['epsilon'] for v in r]
    fig,axs=plt.subplots(1,3,figsize=(7.2,2.6),layout='constrained')
    for field,label,color,style in [('actual_drift','Exact generalized drift',COL['energy'],'-'),('simple_bound','Simple bound',COL['fresh'],'--'),('sharper_bound','Sharper bound',COL['exact_local'],'-.')]:
        axs[0].loglog(x,[v[field] for v in r],style,color=color,label=label)
    panel(axs[0],'a','Nonhomogeneous correction');axs[0].set(xlabel=r'Cut scale $\varepsilon$',ylabel='Relative drift from limit');legend(axs[0],fontsize=6.2)
    for field,label,color in [('raw_condition','Raw physical anchor',COL['energy_raw']),('transported_condition','Transported anchor',COL['energy'])]:
        axs[1].loglog(x,[v[field] for v in r],color=color,label=label)
    panel(axs[1],'b','Fixed anchor at '+r'$10^{-3}$');axs[1].set(xlabel=r'Cut scale $\varepsilon$',ylabel='Preconditioned condition');legend(axs[1],fontsize=6.2)
    bad=data['singular_leading_rows'];x2=np.array([v['epsilon'] for v in bad]);axs[2].loglog(x2,[v['normalized_condition'] for v in bad],color=COL['energy_raw'],label='Singular leading Gram');axs[2].loglog(x2,12/x2**2,'--',color='#9fadb8',label=r'$12\varepsilon^{-2}$')
    panel(axs[2],'c','Changing near dependence');axs[2].set(xlabel=r'Cut scale $\varepsilon$',ylabel='Normalized condition');legend(axs[2],fontsize=6.2)
    save(fig,'11_polynomial_mechanism','results/mechanism_audit.json; exact polynomial integrals and independent generalized eigensolves, not timing data')

if __name__=='__main__':
    mechanism();accuracy();cut_study()
    if (R/'spectral_audit.json').exists():spectral()
    if all(list(R.glob(n+'_state_*.npz')) for n in ['moving_hole','local_plate','active_crossing','elastic_plate']):geometries()
    if (R/'sequence_elastic_solid.json').exists():performance();active_history();solid_figure()
    if (R/'update_sensitivity.json').exists():sensitivity()
    if (R/'mechanism_audit.json').exists():polynomial_mechanism()
    with open(F/'manifest.csv','w') as f:writer=csv.writer(f);writer.writerow(['figure','source','backend','formats']);writer.writerows(manifest)
