"""Create two compact reproduction archives and the author review folder."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parent
DEST=ROOT.parent/'delivery'/'CMAME_Trimmed_Reuse_2026_10_16'


def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if src.is_dir():shutil.copytree(src,dst,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','.DS_Store'))
    else:shutil.copy2(src,dst)


def main():
    assert (ROOT/'paper/manuscript.pdf').exists() and (ROOT/'paper/supplement.pdf').exists()
    assert (ROOT/'results/campaign_complete.json').exists() and (ROOT/'results/ablations_complete.json').exists()
    assert (ROOT/'FINAL_REVIEW_zh.md').exists()
    DEST.mkdir(parents=True,exist_ok=True)
    for n in ['manuscript.pdf','manuscript.tex','supplement.pdf','supplement.tex','references.bib','highlights.txt']:
        copy(ROOT/'paper'/n,DEST/'manuscript'/n)
    for p in (ROOT/'paper/figures').glob('*.pdf'):copy(p,DEST/'manuscript/figures'/p.name)
    for p in (ROOT/'paper').glob('cover_letter*'):copy(p,DEST/'editorial'/p.name)
    for name in ['final_originality_audit.md','final_theory_audit.md','final_code_audit.md','venue_requirements.md']:
        if (ROOT/'docs'/name).exists():copy(ROOT/'docs'/name,DEST/'editorial/audits'/name)
    for n in ['FINAL_REVIEW_zh.md','README_zh.md','author_information.txt']:
        if (ROOT/n).exists():copy(ROOT/n,DEST/n)
    code=DEST/'01_numerical_code';data=DEST/'02_results_and_figures'
    base=code/'cmame_trimmed'
    for p in (ROOT/'src').glob('*.py'):copy(p,base/'src'/p.name)
    for p in (ROOT/'tests').glob('*.py'):copy(p,base/'tests'/p.name)
    for n in ['__init__.py','experiments.py','run_all.py','run_ablations.py','run_static_checks.py','run_mechanism_audit.py','figures.py','build_paper.py','requirements.txt','README.md','references.bib']:
        if (ROOT/n).exists():copy(ROOT/n,base/n)
    for p in (ROOT/'docs').iterdir():
        if p.suffix in ('.tex','.bib'):copy(p,base/'docs'/p.name)
    (code/'prepare_data.py').write_text('''from pathlib import Path
import hashlib,shutil
root=Path(__file__).resolve().parent
source=root.parent/'02_results_and_figures'/'cmame_trimmed'/'results'
target=root/'cmame_trimmed'/'results'
if not source.is_dir():raise SystemExit('Extract 02_results_and_figures.zip beside 01_numerical_code first.')
for path in sorted(source.rglob('*')):
    if not path.is_file():continue
    dest=target/path.relative_to(source)
    if dest.exists():
        if hashlib.sha256(dest.read_bytes()).digest()!=hashlib.sha256(path.read_bytes()).digest():raise SystemExit('Conflicting existing file: '+str(dest))
    else:
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
print('Recorded data prepared in',target)
''')
    copy(ROOT/'README.md',code/'README.md')
    for p in (ROOT/'results').iterdir():
        include=(p.suffix in ('.json','.npz') or p.name in ('benchmark_sources','ablation_sources','static_sources','run_all.log','run_ablations.log','final_tests.log','static_checks.log'))
        if include:copy(p,data/'cmame_trimmed/results'/p.name)
    copy(ROOT/'figures',data/'figures')
    (data/'README.txt').write_text('Recorded primary results, sensitivity studies, source snapshots, reference coefficients and figure exports. Extract this folder beside 01_numerical_code, then run its prepare_data.py. Exploratory timings are excluded.\n')
    archives=[]
    for folder in (code,data):
        target=DEST/(folder.name+'.zip')
        with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p in sorted(folder.rglob('*')):
                if p.is_file():z.write(p,p.relative_to(DEST))
        with zipfile.ZipFile(target) as z:assert z.testzip() is None
        assert target.stat().st_size<100_000_000
        archives.append(dict(file=target.name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
    (DEST/'archive_manifest.json').write_text(json.dumps(archives,indent=2))
    files=[]
    for p in sorted(DEST.rglob('*')):
        if p.is_file() and p.name!='SHA256SUMS.txt':files.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(DEST).as_posix())
    (DEST/'SHA256SUMS.txt').write_text('\n'.join(files)+'\n')
    print(json.dumps(dict(delivery=str(DEST),archives=archives),indent=2))

if __name__=='__main__':main()
