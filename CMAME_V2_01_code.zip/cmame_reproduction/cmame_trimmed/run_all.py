"""One serial process for the complete frozen benchmark campaign."""
import hashlib,json,time,shutil
from pathlib import Path
from cmame_trimmed.experiments import sequence,accuracy,cut_study,spectral_audit,metadata,RESULTS,ROOT
metadata()
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src').glob('*.py'))}
manifest.update({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'experiments.py',ROOT/'run_all.py']})
(RESULTS/'benchmark_source_hashes.json').write_text(json.dumps(manifest,indent=2))
for relative in manifest:
    target=RESULTS/'benchmark_sources'/relative;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/relative,target)
start=time.time()
for case in ['moving_hole','local_plate','active_crossing','elastic_plate','ridge','large_plate','elastic_solid']:
    print('BEGIN',case,flush=True)
    sequence(case,repeats=3,steps=12)
    print('END',case,'elapsed',time.time()-start,flush=True)
spectral_audit()
(RESULTS/'campaign_complete.json').write_text(json.dumps(dict(completed=time.strftime('%Y-%m-%d %H:%M:%S %z'),elapsed_seconds=time.time()-start),indent=2))
