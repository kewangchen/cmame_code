"""Freeze and rerun static validation with the delivered source version."""
import hashlib,shutil,time,runpy
from cmame_trimmed.experiments import ROOT,RESULTS,save,accuracy,cut_study
files=sorted((ROOT/'src').glob('*.py'))+[ROOT/'experiments.py',ROOT/'run_mechanism_audit.py',ROOT/'run_static_checks.py']
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
save('static_source_hashes',manifest)
for relative in manifest:
    target=RESULTS/'static_sources'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/relative,target)
accuracy()
cut_study()
runpy.run_module('cmame_trimmed.run_mechanism_audit',run_name='__main__')
save('static_checks_complete',dict(completed=time.strftime('%Y-%m-%d %H:%M:%S %z')))
