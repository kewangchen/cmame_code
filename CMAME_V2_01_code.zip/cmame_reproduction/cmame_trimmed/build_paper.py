"""Assemble single-file manuscript and supplement from audited prose + data."""
import json,re,shutil
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent;R=ROOT/'results';P=ROOT/'paper';D=ROOT/'docs';P.mkdir(exist_ok=True)
CASES={'moving_hole':'Moving hole','local_plate':'Local plate edit','active_crossing':'Active-space crossing','elastic_plate':'Plane-strain plate','elastic_solid':'Extruded elastic solid','large_plate':'Refined plate','ridge':'Ridge boundary'}
TITLE='Risk-controlled reuse of local Schwarz solvers for evolving trimmed spline discretizations'

def read(name):return json.loads((R/(name+'.json')).read_text())
def sci(value):
    a,b=f'{value:.2e}'.split('e');return a+r'\times10^{'+str(int(b))+'}'
def table(headers,rows,caption,label,align=None):
    align=align or ('l'+'r'*(len(headers)-1))
    return '\\begin{table}[t]\n\\centering\\small\\setlength{\\tabcolsep}{4pt}\n\\caption{'+caption+'}\\label{'+label+'}\n\\begin{tabular}{'+align+'}\\toprule\n'+' & '.join(headers)+r' \\ \midrule'+'\n'+'\n'.join(' & '.join(map(str,r))+r' \\' for r in rows)+'\n\\bottomrule\\end{tabular}\n\\end{table}\n'

def build():
    assert (R/'campaign_complete.json').exists(),'Primary campaign must complete first'
    summary=read('summary')['cases'];names=list(CASES)
    rows=[r for name in names for r in read('sequence_'+name)['rows']]
    assert len(rows)==7*3*12*11,(len(rows),'missing primary solves')
    gm_f=np.exp(np.mean([np.log(summary[n]['fresh']['linear']/summary[n]['energy']['linear']) for n in names]))
    gm_l=np.exp(np.mean([np.log(summary[n]['exact_local']['linear']/summary[n]['energy']['linear']) for n in names]))
    nmax=max(r['dofs'] for r in rows);maxres=max(r['residual'] for r in rows);maxerr=max(r['energy_error'] for r in rows);failed=sum(not r['success'] for r in rows)
    solid=summary['elastic_solid'];ss=solid['fresh']['setup']/solid['energy']['setup'];sf=solid['fresh']['linear']/solid['energy']['linear'];sl=solid['exact_local']['linear']/solid['energy']['linear']
    abstract=r'''Repeated analysis of a trimmed spline model changes both its stiffness matrix and its active basis, making previously computed local factors difficult to reuse reliably. We develop a risk-controlled update policy for additive Schwarz solvers that separates basis-amplitude changes from changes in normalized energy couplings. Current diagonal scales transport cached factors, and Gaussian power actions test their cumulative discrepancy from the current local matrices. A summable probability allocation covers all adaptive decisions in a sequence, including changes in active dimension. In exact arithmetic, with probability at least $1-\delta$, the retained preconditioner inherits the fresh current spectrum within factors $1-\tau$ and $1+\tau$; the resulting condition-number inflation is at most $(1+\tau)/(1-\tau)$. A conditional small-cut limit explains how transport removes amplitude-induced deterioration and identifies the role of leading-gradient independence. Experiments comprise seven evolving-domain families, scalar elliptic and elastic systems, small-cut studies, and independent discretization and spectral checks. Across the seven families, geometric-mean setup-plus-solve speedups are @GF@ relative to full reconstruction and @GL@ relative to exact local refresh. The extruded elastic sequence yields @SS@ faster preconditioner setup. These measurements identify the larger local-factor regime in which screened reuse pays for its decisions, while preserving the current Galerkin system and active unknowns.'''
    abstract=abstract.replace('@GF@',f'{gm_f:.2f}').replace('@GL@',f'{gm_l:.2f}').replace('@SS@',f'{ss:.2f}-fold')
    case_rows=[];time_rows=[]
    for name in names:
        data=read('sequence_'+name);c=data['config'];s=summary[name];v=s['energy']
        case_rows.append([CASES[name],r'$'+'\\times'.join(map(str,c['cells']))+'$',c['degree'],f"{v['nmin']:,}--{v['nmax']:,}",c['width']])
        time_rows.append([CASES[name],f"{s['fresh']['linear']:.3f}",f"{s['exact_local']['linear']:.3f}",f"{v['linear']:.3f}",f"{s['fresh']['total']:.3f}",f"{v['total']:.3f}"])
    ct=table(['Family','Background cells','$p$','Free DOFs','Block width'],case_rows,'Primary sequence configurations. Each family contains 12 geometry queries, repeated three times. Block width counts knot cells before the one-cell overlap.','tab:cases',align='llrrr')
    tt=table(['Family',r'Fresh $T_L$',r'Local $T_L$',r'Reuse $T_L$',r'Fresh $T_A$',r'Reuse $T_A$'],time_rows,r'Median cumulative times in seconds. $T_L$ includes setup and solve; $T_A$ additionally includes assembly. ``Local'' means exact local refresh. The supplementary table includes the observed repetition ranges and all external methods.','tab:times')
    nrebuild=solid['energy']['factorizations'];nfresh=solid['fresh']['factorizations'];red=100*(1-nrebuild/nfresh)
    fastest={n:min(summary[n],key=lambda m:summary[n][m]['linear']) for n in names}
    text=(f'The primary campaign records {len(rows):,} linear solves with {failed} failed solution-accuracy checks. '
          f'The largest physical relative residual is ${sci(maxres)}$ and the largest relative energy difference from the direct reference is ${sci(maxerr)}$. '
          f'The systems contain up to {nmax:,} free unknowns. ')
    text+=r'Table~\ref{tab:times} and Figure~\ref{fig:comparison} distinguish gains from rebuilding every factor from gains over exact local refresh. '
    text+=(f'The geometric-mean setup-plus-solve speedup over seven equally weighted families is {gm_f:.2f} relative to full reconstruction and {gm_l:.2f} relative to exact local refresh. '
           f'For the extruded elastic sequence, setup is {ss:.2f} times faster than a fresh build, while setup plus solve is {sf:.2f} times faster than fresh Schwarz and {sl:.2f} times faster than exact local refresh. '
           f'The median number of new or refreshed local factors falls from {nfresh:.0f} to {nrebuild:.0f}, a reduction of {red:.1f}\\%. ')
    jacwins=sum(v=='jacobi' for v in fastest.values())
    text+=f'Jacobi gives the smallest measured setup-plus-solve time in {jacwins} of the seven families. '
    text+=r'The moving-hole, active-crossing and ridge sequences invoke no Gaussian checks under the size rule and have the same factorization counts as exact local refresh. Their small timing differences reflect run variation and control-path costs, rather than benefits from accepting nonzero energy drift. '
    text+=r'The runtime benefit therefore depends on the cost of the chosen fresh solver. In the local plate edit, exact local refresh already leaves most factors untouched; further retention saves little setup and can require additional PCG iterations. Stale reuse sometimes costs less, but has no energy acceptance criterion. The controlled method trades that unrestricted retention for an explicit bound on spectral deterioration.'
    active=read('sequence_active_crossing')['rows'];ar=[x for x in active if x['method']=='energy' and x['repeat']==0]
    checks=sum(x.get('stat_randomized_checks',0) for x in ar);accepted=sum(x.get('stat_reused_energy',0) for x in ar)
    small=sum(x.get('stat_skipped_small_blocks',0) for x in ar)
    at=f"The active-boundary sequence changes the number of free coefficients from {ar[0]['dofs']} to {ar[-1]['dofs']}. In its first repetition, the size rule directly refreshes {small} small changed blocks. "
    at+=(f"Of {checks} Gaussian checks on eligible larger blocks, {accepted} accept reuse. " if checks else "No changed block is large enough to invoke the Gaussian screen. ")
    at+=r"Figure~\ref{fig:active} exposes these decisions directly. Here the size rule makes the method operate largely as exact local refresh; new memberships remain independent reasons to rebuild."
    sp=read('spectral_audit')['rows'];lo=min(r['lower'] for r in sp);hi=max(r['upper'] for r in sp);drift=max(r['max_exact_drift'] for r in sp);ratio=max(r['reuse_condition']/r['fresh_condition'] for r in sp)
    assert lo>=.8-1e-7 and hi<=1.2+1e-7 and drift<=.2+1e-7,'Spectral audit violated a claimed bound'
    st=f"The observed generalized spectrum lies in $[{lo:.6f},{hi:.6f}]$, compared with the allowed interval $[0.8,1.2]$. The largest independently evaluated local drift is {drift:.6f}, and the largest observed condition-number ratio is {ratio:.6f}, below the bound 1.5."
    ab=ablation_text()
    results=(D/'results_template.tex').read_text().replace('@CASE_TABLE@',ct).replace('@TIME_TABLE@',tt).replace('@NUMERICAL_RESULTS@',text).replace('@ACTIVE_RESULTS@',at).replace('@SPECTRAL_RESULTS@',st).replace('@ABLATION_RESULTS@',ab)
    preamble=r'''\documentclass[final,3p,times]{elsarticle}
\usepackage[T1]{fontenc}
\usepackage{amsmath,amssymb,amsthm,booktabs,graphicx,microtype,placeins,float}
\usepackage[hyphens]{url}
\usepackage[colorlinks=true,linkcolor=teal,citecolor=teal,urlcolor=teal]{hyperref}
\pdfstringdefDisableCommands{\def\corref#1{}}
\renewcommand{\topfraction}{0.9}
\renewcommand{\bottomfraction}{0.8}
\renewcommand{\textfraction}{0.08}
\renewcommand{\floatpagefraction}{0.75}
\graphicspath{{figures/}}
\newtheorem{theorem}{Theorem}[section]
\newtheorem{lemma}[theorem]{Lemma}
\newtheorem{proposition}[theorem]{Proposition}
\newtheorem{corollary}[theorem]{Corollary}
\newtheorem{remark}[theorem]{Remark}
\newtheorem{example}[theorem]{Example}
\journal{Comput. Methods Appl. Mech. Engrg.}
\begin{document}
\begin{frontmatter}
\title{@TITLE@}
\author{Kewang Chen\corref{cor1}}
\address{College of Mathematics and Statistics, Nanjing University of Information Science and Technology, Nanjing, 210044, China}
\ead{kwchen@nuist.edu.cn}
\cortext[cor1]{Corresponding author: Kewang Chen, kwchen@nuist.edu.cn}
\begin{abstract}
@ABSTRACT@
\end{abstract}
\begin{keyword}
Trimmed isogeometric analysis \sep Additive Schwarz \sep Repeated linear solves \sep Preconditioner reuse \sep Randomized energy estimation
\end{keyword}
\end{frontmatter}
'''.replace('@TITLE@',TITLE).replace('@ABSTRACT@',abstract)
    parts=['introduction.tex','model_algorithm.tex','main_theory.tex','experiment_protocol.tex']
    body='\n'.join((D/p).read_text() for p in parts)+results+'\n\\FloatBarrier\n'+(D/'limitations_conclusion.tex').read_text()
    body=body.replace(r'\subsection{A probability budget for adaptive reuse}',(D/'cut_asymptotic_main.tex').read_text()+r'\subsection{A probability budget for adaptive reuse}')
    body=body.replace(r'\begin{figure}[t]',r'\begin{figure}[!htbp]').replace(r'\begin{table}[t]',r'\begin{table}[!htbp]')
    (P/'manuscript.tex').write_text(preamble+body+'\n\\bibliographystyle{elsarticle-num}\n\\bibliography{references}\n\\end{document}\n')
    bib=(ROOT/'references.bib').read_text()+(D/'theory_references.bib').read_text()+(D/'randomized_references.bib').read_text();(P/'references.bib').write_text(bib)
    shutil.copytree(ROOT/'figures',P/'figures',dirs_exist_ok=True)
    (P/'highlights.txt').write_text('\n'.join(['Current diagonal scales transport cached Schwarz factors across trim changes.','Fresh Gaussian energy tests control reuse with a summable risk budget.','Accepted factors inherit an explicit relative-to-fresh spectral bound.','Seven evolving-domain families separate setup savings from total solve costs.'])+'\n')
    supplement(preamble,bib,summary)
    facts=dict(gm_vs_fresh=gm_f,gm_vs_exact_local=gm_l,solid_setup_speedup=ss,solid_linear_vs_fresh=sf,solid_linear_vs_exact=sl,primary_solves=len(rows),failures=failed,max_residual=maxres,max_energy_error=maxerr,max_dofs=nmax,fastest=fastest,spectral_range=[lo,hi],spectral_max_drift=drift,condition_ratio=ratio)
    (R/'paper_facts.json').write_text(json.dumps(facts,indent=2))
    print(json.dumps(facts,indent=2))


def ablation_text():
    data=read('ablation_screening');out=[]
    for key in data['configurations']:
        rows=[r for r in data['rows'] if r['configuration']==key]
        sums=[sum(r['linear'] for r in rows if r['repeat']==rep) for rep in range(data['repeats'])]
        factors=[sum(r.get('stat_new',0)+r.get('stat_refreshed',0) for r in rows if r['repeat']==rep) for rep in range(data['repeats'])]
        out.append([key.replace('_',r'\_'),f'{np.median(sums):.3f}',f'{np.median(factors):.0f}'])
    text=r'''The screening ablation holds the elastic-plate sequence fixed and compares equal triangular-solve workloads, $(q,s)=(1,24),(2,12),(4,6)$, as well as changes in $\tau$ and the risk budget. Table~\ref{tab:ablation} includes the initial factorization and every inconclusive test. Increasing the allowed drift may retain more factors but can increase iteration work; a smaller probability budget increases the multiplier in the Gaussian screen. The block-size experiment separately varies macrocell width over 4, 8, 12 and 16 on the moving-hole sequence. Its complete data are in the supplement, including all three repetitions. These ablations assess computational choices rather than using the theorem as a timing prediction.
'''
    text+=table(['Configuration','Setup + solve (s)','New/refreshed factors'],out,'Screening ablation: median eight-query totals over three repetitions. Unspecified parameters use $q=2$, $s=12$, $\\tau=0.2$, $\\delta=10^{-8}$ and size threshold 288. Configurations tau005/tau05 use $\\tau=0.05/0.5$; risk1e4/risk1e12 use $\\delta=10^{-4}/10^{-12}$; no\\_size\\_guard uses threshold zero.','tab:ablation')
    data=read('update_sensitivity');srows=[]
    for a in data['multipliers']:
        rr=[r for r in data['rows'] if r['multiplier']==a];times={m:float(np.median([sum(r['linear'] for r in rr if r['method']==m and r['repeat']==rep) for rep in range(3)])) for m in data['methods']}
        er=[r for r in rr if r['method']=='energy'];checks=sum(r.get('stat_randomized_checks',0) for r in er);accepted=sum(r.get('stat_reused_energy',0) for r in er)
        srows.append([f'{a:g}',f"{times['fresh']:.3f}",f"{times['exact_local']:.3f}",f"{times['energy']:.3f}",f"{accepted}/{checks}"])
    text+=r'''\subsection{Update magnitude and sequence length}
We extend the plane-strain plate to 24 queries and multiply the first
hole's horizontal increment by 0.25, 1, 5 and 20. The largest net motion
is 0.0552, and the two holes remain disjoint. Each path is repeated three
times using fresh Schwarz, exact local refresh, risk-controlled reuse,
stale reuse and Jacobi; the parameters of the acceptance rule stay fixed.
The experiment adds 1440 solves. Figure~\ref{fig:updates} shows the
complete cost and how changed-block decisions shift with edit size.
The table reports all screened acceptances over the three repetitions.
An increased screening rejection rate is paid for as both a test and a
new factorization; it is part of the update policy's measured cost.
\begin{figure}[t]
\centering\includegraphics[width=\linewidth]{10_update_sensitivity.pdf}
\caption{Update-size sensitivity over 24-query elastic sequences.
Lines show medians and shaded bands the observed minimum--maximum range
over three repetitions. Decision counts are means per sequence.
Unchanged factors and new memberships are omitted from the right panel.}
\label{fig:updates}
\end{figure}
'''
    text+=table(['Step multiplier','Fresh (s)','Exact local (s)','Reuse (s)','Accepted/checks'],srows,'Longer elastic sequences with varied geometry increments. Times include cold setup and every subsequent setup and solve.','tab:updates')
    return text


def supplement(preamble,bib,summary):
    head=preamble[:preamble.index('\\begin{frontmatter}')]+r'''\begin{frontmatter}
\title{Supplementary material: '''+TITLE+r'''}
\author{Kewang Chen}
\address{Nanjing University of Information Science and Technology, China}
\begin{abstract}Additional deterministic bounds, reproducibility details and complete comparison tables.\end{abstract}
\end{frontmatter}
'''
    theory=(D/'theory.tex').read_text();part=theory[:theory.index('\\subsection{Spectral inheritance')]
    # The generic H/Delta notation here is local to this supplementary derivation.
    text=part+r'''
\subsection{Complementary inverse-factor bound}
For an equilibrated anchor $C=LL^T$ and symmetric scaled change $E$, set
$\nu=\|L^{-1}\|_1\|L^{-1}\|_\infty$. Submultiplicativity and
$\|X\|_2^2\leq\|X\|_1\|X\|_\infty$ give
\[
 \|L^{-1}EL^{-T}\|_2\leq\nu\|E\|_2\leq\nu\|E\|_\infty.
\]
The deterministic comparator takes the smaller of this bound and the
inverse-diagonal majorant. The row/column sums for $\nu$ are obtained
from the same inverse-triangular calculation used for the inverse
diagonal. All this preparation is lazy and charged when first needed.
A compressed test is attempted only for support size at most 128.
Normalized support is determined from the full current-minus-anchor
difference, since diagonal transport can change couplings outside the
raw update support.

@CUT_ASYMPTOTIC@

\section{Geometry specifications}
Coordinates lie in the unit square or its unit extrusion. In every
12-query sequence, $t=0,\ldots,11$.
\begin{itemize}
\item Moving hole: center $(0.472+0.0002t,0.51)$, radius $0.183$.
\item Local and refined plates: hole centers $(0.28,0.28)$, $(0.72,0.28)$,
$(0.28,0.72)$, $(0.72,0.72)$; radii $0.12$, except the first radius
$0.12+0.00008t$.
\item Active crossing: upper boundary $y=0.699+0.002t$ and a hole
centered at $(0.46,0.35)$ with radius $0.142$.
\item Plane-strain plate: holes $(0.35+0.00012t,0.48,0.16)$ and
$(0.74,0.6,0.1)$, with triples denoting center and radius.
\item Extruded solid: circular through-hole $(0.47+0.00005t,0.51,0.173)$,
extruded over $0<z<1$.
\item Ridge graph: domain below the polyline
$(0,0.62)$, $(0.3,0.62)$, $(0.42,0.012)$,
$(0.5,0.69+0.0002t)$, $(0.58,0.012)$, $(0.7,0.62)$ and $(1,0.62)$.
\end{itemize}
The primary sequences use order $\max(12,p+6)$ quadrature. The cut study
uses $p+4$ on piecewise-polynomial strip integrals. Manufactured assembly
and error integration use $p+9$ and $p+14$, respectively. The initial
query assembles every cell; later queries reuse exactly matching local
geometry signatures. The complete sparse current matrix is rebuilt
from current and cached element contributions.

\section{Complete method comparison}
The intervals below are the minimum and maximum observed complete-sequence
times over three repetitions. They describe run dispersion, not
confidence intervals. Each baseline uses its own previous successful
solution as a warm start. Linear algebra time excludes assembly.
'''
    for name in CASES:
        rows=[]
        for m,v in summary[name].items():
            rows.append([m.replace('_',r'\_'),f"{v['linear']:.3f}",f"[{v['linear_min']:.3f}, {v['linear_max']:.3f}]",f"{v['setup']:.3f}",f"{v['iterations']:.0f}",v['failures']])
        text+=table(['Method','Median (s)','Range (s)','Setup (s)','Iterations','Failures'],rows,CASES[name]+': complete 12-query totals.','tab:supp-'+name)
    text+=r'\clearpage\section{Block-size ablation}'+'\n'
    data=read('ablation_block_size');rows=[]
    for key in data['configurations']:
        rr=[r for r in data['rows'] if r['configuration']==key];vals=[sum(r['linear'] for r in rr if r['repeat']==rep) for rep in range(3)];its=[sum(r['iterations'] for r in rr if r['repeat']==rep) for rep in range(3)]
        rows.append([key.replace('_',r'\_'),f'{np.median(vals):.3f}',f'[{min(vals):.3f}, {max(vals):.3f}]',f'{np.median(its):.0f}'])
    text+=table(['Configuration','Median (s)','Range (s)','Iterations'],rows,'Eight-query moving-hole sequences with varied macrocell width; three repetitions.','tab:blocks')
    text+=r'\clearpage\section{Complete cut and discretization checks}'+'\n'
    cut=read('cut_study')['rows']
    for p in (2,3,4):
        out=[]
        for geometry in ['fixed_domain_sliver','thin_domain']:
            for eta in [1.,.1,.01,.001,.0001,.00001]:
                rr={r['method']:r for r in cut if r['degree']==p and r['cut']==eta and r['geometry_type']==geometry}
                out.append(['Fixed bulk' if geometry=='fixed_domain_sliver' else 'Thin domain',f'${sci(eta)}$',rr['fresh']['dofs']]+[rr[m]['iterations'] for m in ('jacobi','cbas','deflation','fresh')])
        text+=table(['Geometry',r'$\eta$','DOFs','Jacobi','CbAS','Deflation','Fresh'],out,f'Cut study at degree {p}: PCG iterations for all retained free unknowns. Each listed solve passed the residual and energy checks.','tab:cut'+str(p))
    out=[]
    for r in read('accuracy')['convergence']:
        out.append([r['degree'],r['n'],r['dofs'],f"${sci(r['L2'])}$",f"${sci(r['H1_seminorm'])}$"])
    text+=table(['Degree','Cells/direction','DOFs',r'$L^2$ error',r'$H^1$ seminorm error'],out,'Manufactured scalar solution on the circular-hole domain.','tab:fullaccuracy')
    text+=r'\clearpage\section{Screening decisions}'+'\n'
    out=[]
    for n,v in summary.items():
        s=v['energy'];out.append([CASES[n],s['checked'],s['screen_acceptances'],s['small_block_refreshes'],f"{s['factorizations']:.0f}"])
    text+=table(['Family','Checks','Accepted','Size refreshes','Factors'],out,'Risk-controlled policy. Checks, acceptances and size-rule refreshes are totals over three repetitions. Factors is the median number of new or refreshed factors per repetition.','tab:screencounts')
    text+=r'''\section{Reproduction and numerical checks}
The code package contains the assembly, preconditioners, drivers and tests;
the data package contains raw measurements and saved solution coefficients.
The README gives the environment and exact commands. The test suite checks
partition of unity, affine patch reproduction, elasticity energy contractions,
geometry signatures, independent local eigenvalues, transported covariance,
conditional budget state, anchor drift, repeated-block multiplicities and
safe handling of changed memberships. Post-solve checks use actual residuals
and energy differences. Published probability bounds do not replace these
checks or constitute a floating-point interval proof.

The comparative formulations follow~\cite{dePrenter2019,Voet2026}; the Gaussian norm estimate follows~\cite{Halko2011}. The main campaign records a hash manifest and an exact snapshot of the
executed benchmark sources. Exploratory pilot timings are excluded from
all manuscript tables and figures. Data generation, plotting and manuscript
assembly are separate commands, permitting figure reconstruction without
rerunning timing experiments. Wall times depend on the numerical libraries
and host workload; the stored measurements preserve the original runs.
'''
    extra=(D/'cut_asymptotic_theory.tex').read_text()+r'''
\begin{figure}[t]
\centering\includegraphics[width=\linewidth]{11_polynomial_mechanism.pdf}
\caption{Conditional small-cut mechanism from exact polynomial integrals.
For $\{x+x^2,x^2\}$, normalized drift tends to zero and a transported
anchor controls amplitude variation. For $\{x,x+x^2\}$, the leading
gradient Gram is singular and normalized conditioning deteriorates.
These are local-region mechanism examples, not full spline-block timings.}
\label{fig:poly-mechanism}
\end{figure}
The numerical audit checks both normalized bounds and the anchored bound
at 80 cut scales from $10^{-6}$ to $0.05$. An independent generalized
eigensolve verifies the limiting coefficient $1+2/\sqrt3$ to within
$10^{-4}$ at the smallest scale. All evaluated inequalities hold within
the stated double-precision audit tolerance $10^{-12}$.
'''
    text=text.replace('@CUT_ASYMPTOTIC@',extra)
    text=text.replace(r'\begin{table}[t]',r'\begin{table}[H]').replace(r'\begin{figure}[t]',r'\begin{figure}[!htbp]')
    text=text.replace(r'\clearpage\section',r'\FloatBarrier\section')
    (P/'supplement.tex').write_text(head+text+'\n\\bibliographystyle{elsarticle-num}\n\\bibliography{references}\n\\end{document}\n')

if __name__=='__main__':build()
