# Energy-controlled reuse for evolving trimmed spline systems

Date: 2026-10-16. User selected candidate B and requested a complete CMAME manuscript, rigorous theory, executed comparisons and final audit. Python plotting was already selected. This is a separate research project; existing TOG sources and deliveries remain unchanged.

## Research question and candidate contribution

For repeated SPD systems on a fixed background spline grid with changing active basis functions, can local matrix changes determine which Schwarz solves may be retained while bounding the global loss relative to freshly constructed preconditioning? The target is an energy-controlled update rule, not a new static cut-robustness theorem.

Use the current local matrices A_i=R_i A R_i^T. Each retained block owns a fixed ordered list of background basis IDs, an anchor matrix H_i, a diagonally equilibrated Cholesky factor, and data for relative-energy tests. Compare the current block to its anchor, never only to the preceding query. New, changed-membership and invalid blocks are rebuilt. Disappeared blocks are retired. Changes are identified from assembled element contributions and their complete basis-support closure.

The first test bounds ||H_i^(-1/2)(A_i-H_i)H_i^(-1/2)||_2 by d^T |A_i-H_i| d, where d_j=sqrt((H_i^-1)_jj). A second test uses the actual low-dimensional support K of a nonzero block change: the nonzero perturbation spectrum is that of L_K^T Delta_KK L_K, with L_K L_K^T=(H_i^-1)_KK. Reuse if a chosen bound is <= tau<1. Refresh otherwise. Derive the global Loewner comparison and condition-number inflation, invariance to diagonal basis scaling, cumulative drift control, and rules for active-space changes.

Floating-point tests are implemented numerical bounds, not outward-rounded interval certificates. Compare them with independently computed generalized eigenvalues in audit cases, including anisotropic scaling and small cuts. No claim that finite precision inherits exact-arithmetic inequalities without qualification.

## Baselines and alternatives

1. Fresh and persistent variants of the same overlap/weak-cut Schwarz construction isolate reuse.
2. Exact support-local refresh (zero permitted drift) is a strong reuse baseline; stale blocks and periodic rebuilds are ablations.
3. Jacobi PCG, connectivity-based additive Schwarz (de Prenter et al. 2019), coordinate cut deflation (Voet et al. 2026), and a fresh sparse direct solve compare core numerical methods. Implemented formulations must be identified; do not call a reimplementation author code.
4. A coarse spline correction may be added identically to matched Schwarz policies if h-dependence dominates. Do not infer universal cut or h,p robustness from observed examples.

## Numerical scope

Tensor B-splines in 2D and extruded 3D. SPD Poisson/reaction-diffusion and linear elasticity with outer strong Dirichlet data and natural trimmed boundaries. Analytic line/circle/ridge trimming with cut-aware quadrature that resolves small cells; no background material penalty. Retain every basis with a nonzero physical support and all original unknowns; no hidden basis removal. Separate conditioning from geometry/quadrature error.

Test cut-size sensitivity, h/p refinement, moving-hole sequences, localized multi-hole edits, active-set crossings, and perforated elastic solids. Manufactured solutions establish discretization error; an independently higher quadrature verifies representative cases. Multiple RHS state/adjoint-style queries may be measured but must not be substituted for one-RHS totals. Measure cold setup, updates, solver time, assembly, actual residuals, and energy errors against a scaled direct solution. Failures and timeouts remain in all summaries.

## Deliverables and evidence

English single-file LaTeX manuscript, PDF, numbered references, highlights, supplementary derivations/protocol, reproducibility scripts/data, and Chinese final audit with claim-to-evidence map and unresolved scientific issues. Existing author details may be used. New funding/conflict/exclusivity declarations require separate confirmation rather than inheriting a declaration about the different TOG manuscript. Research tool use is disclosed accurately. Archives should be individually below 100 MB.

## Figure contract

Python/matplotlib only, vector PDF/SVG plus PNG previews, readable type at final width. Geometry/field plates use actual evaluated fields. Quantitative panels cover mechanism, spectra, cut size, error convergence, cumulative cost and ablations. All timing bars derive from recorded repetitions; labels state what is included. No artificial performance values or aesthetic smoothing of measured solution data.

## Pilot-driven refinement (2026-10-16)

Raw physical-coordinate anchor tests refreshed most changing cut blocks in the first pilot. Vanishing basis magnitudes are now separated from correlation changes. Main matched Schwarz policies factor C_t=D_t A_t D_t, D_t=diag(A_t)^(-1/2), and reuse normalized anchors. In physical variables the inverse is transported by the CURRENT D_t. This transport is shared by fresh, exact normalized-local, energy, stale and periodic comparisons. `energy_raw` retains the original physical-anchor policy as an ablation. The actual difference of normalized matrices supplies compressed-test support; raw changed-element support is used only to skip blocks disjoint from all updates.

All sequence solvers receive their own previous converged solution transferred by stable background IDs; new unknowns start at zero. Cold first queries and all preparation costs are charged. Success uses recomputed scaled and physical residuals and energy error, not only the iterative solver return code. Exploratory `pilot*.log` and old provisional sequences are not final evidence. Formal results are regenerated after the audited numerical implementation is frozen.
