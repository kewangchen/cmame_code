# Independent discretization and experiment review

Reviewed 16 October 2026. Scope: `src/geometry.py`, `space.py`, `assembly.py`, `solver.py`, `experiments.py`, with the relevant local-action definitions in `preconditioners.py` and the existing discretization tests. No source or benchmark output was changed by this reviewer. Only small single-cell checks were executed; no timing benchmark was run. The parent agent repaired several findings during this review; verified repairs and unresolved points are distinguished below.

## Overall judgment

The scalar Galerkin form, tensor-product spline ordering, small-strain isotropic elasticity form, stable background-ID indexing, and transformation of the inverse preconditioner into equilibrated coordinates are mathematically consistent. These conclusions follow from algebraic derivations and the limited checks below. They do not establish arbitrary-geometry quadrature accuracy, universal SPD, cut robustness, or benchmark superiority.

The initial experiment code had a result-overwrite defect and a cut-study confound. Both have been corrected in the source inspected during this review. Two geometry integration inconsistencies were also corrected. The parent also added an explicit recomputed-residual/energy success gate, rejected materially negative energy quadratic forms, and saved sequence reference failures. Source inspection verified those changes. Reference-failure accounting in the cut sweep and minor diagnostic/reporting qualifications remain open as detailed below.

## Correctness findings

### Galerkin form and boundary data

For scalar problems, the element matrix is the positive-weight quadrature of grad(N_i) dot grad(N_j), plus reaction times N_i N_j when requested. With unit body load the right-hand side is the quadrature of N_i. Setting the open-knot endpoint coefficients to zero imposes the stated homogeneous boundary condition strongly: x=0 for `bc='left'`, or the outer background box boundary for `bc='outer'`. Trimmed internal boundaries have homogeneous natural conditions for body-load runs.

Manufactured loads instead use f_i=a(u_exact,N_i). This is a valid weak manufactured load, and it includes the exact generally nonzero natural flux/traction on the holes. It is not a test of the unit-body-load problem with zero hole traction. The paper should state this explicitly. The affine patch test uses the same quadrature on both sides and therefore checks algebraic reproduction; it does not independently establish geometric quadrature accuracy.

`Assembler.errors` reports the derivative-only quantity sqrt(integral |grad(u_h−u)|²) under the key `H1`. It is the H1 seminorm, not the full H1 norm. Labels should use `H1 seminorm` or the numerical definition should be changed consistently.

### Elasticity tensor

Let H_abij=integral (partial_a N_i)(partial_b N_j). The code forms

K_(ia,jb) = mu delta_ab sum_c H_ccij + mu H_baij + lambda H_abij.

This equals the bilinear form integral [2 mu epsilon(v):epsilon(u)+lambda div(v)div(u)] for node-major component ordering. The manufactured traction load contracts grad(N_i) with the corresponding stress, consistently with this form.

An independent random-coefficient single-cell energy contraction was compared with c^T K c for degree-two splines on a clipped cell. Relative differences were 1.1994542061941772e−16 in 2D and 3.4308817687019397e−16 in 3D. This check uses the pointwise symmetric gradient rather than reusing the matrix's tensor assembly expression.

The Lamé formula lambda=E nu/((1+nu)(1−2nu)) gives plane strain in 2D. A 'plane stress' description would be incorrect. The current 3D examples extrude the 2D trim through z; they do not test general trimmed surfaces. The default nu=.3 avoids near-incompressibility, and no locking-robustness conclusion follows.

### Spline and active-space indexing

`cell_ids` uses tensor-product ranges e,...,e+p and NumPy row-major flattening. `local` builds basis and gradient columns in the same order. Open knots and the global shape n+p are consistent. The Greville-point affine reproduction test is relevant to this ordering.

Vector unknowns use global ID = scalar_basis_ID * dimension + component. `System.ids` retains these background IDs while the current sparse matrix is restricted to active unconstrained rows. Warm-start transfer uses intersections of these IDs, and therefore does not confuse current row numbers with physical basis identities. Reused block keys use the corresponding ordered stable-ID tuples.

Activity is detected from strictly positive assembled diagonal entries, with no positive threshold and no explicit small-basis removal. This supports the statement that the tested implementation does not deliberately drop small basis functions. It is not a proof that every nonzero physical support survives arbitrary finite-precision underflow or unresolved geometry. SPD additionally requires sufficient boundary constraints on every connected component; a disconnected floating component can have positive diagonals and still be singular. Current benchmark holes/roofs should therefore be kept within the stated connected-domain scope.

### Preconditioner scaling

With D=diag(A_ii^(−1/2)), the solve uses C=D A D, f=D b, and x=D y. If B approximates A^−1, the scaled inverse action must be D^−1 B D^−1. `scaled(v)=(M@(v/d))/d` implements precisely that action, and `x0/d` is the corresponding scaled initial guess. There is no extra Jacobi preconditioner accidentally composed with Schwarz.

The local factor stores its own diagonal scale with its retained raw anchor. Passing the unscaled physical-basis A into `build_schwarz` keeps this anchor convention consistent even though the outer PCG system is freshly equilibrated. The newly added `changed_global_ids=system.changed_ids` shortcut is valid only with complete numerical change support; the cell-level support closure supplies a conservative set because every changed element contributes all its scalar/component basis IDs.

## Geometry findings and repair status

### Repaired: irrelevant holes changed numerical partitions

Initially, `TrimDomain.signature` included only circles intersecting a cell, but `cut_quadrature` built x-breakpoints from every circle. Consequently a remote moved hole could change a fresh quadrature rule on a cell whose cache signature did not change. That breaks exact equality between cached and from-scratch assembled operators even though the true local geometry is unchanged.

The repaired code sets `local_holes=signature[1]`, uses these holes for breakpoints, and chooses the sine map based on `local_holes`. The new regression `test_irrelevant_hole_does_not_change_local_quadrature` was independently executed and passed. During post-repair checks, four selected cells at orders 4 and 8 gave exactly equal local matrices under such a remote change.

### Repaired: missing roof/top intersections

Initially the roof segmentation included intersections with the cell's y boundaries, but not with `geometry.top`. A unit-cell example with roof y=x and top=.3 has exact area .255. The original rule returned .25989787493579847 at order 4, .25392280627109276 at order 8, and .2547712035997307 at order 16. The loss of accuracy comes from integrating across an unsegmented kink in min(top,roof).

The current code includes `geometry.top` in the roof intersection loop. The new regression `test_roof_top_intersection_is_integrated_exactly` was independently executed and passed. This is a real quadrature repair, not a tolerance adjustment.

### Remaining geometry scope

Circular geometry is represented analytically in vertical spans. Finite-order Gauss quadrature after the sine map is nevertheless approximate, not exact circle integration. Existing area and higher-order matrix checks are appropriate numerical evidence; the manuscript should distinguish exact geometry from approximate integration.

Overlapping circles require segmentation where circular span endpoints exchange order. Combined sloping-roof/circle cases require roof–circle intersections. The current breakpoint routine does not explicitly include these intersections. The listed benchmark families use separated circles and a roof-only ridge, so this limitation need not invalidate them. The supported scope should be stated or these intersections should be implemented before adding such mixed cases.

## Experiment findings and repair status

### Repaired: ablation overwrote the formal baseline

The original `ablation()` repeatedly called `sequence('local_plate', methods=['energy'])`, writing every step to `sequence_local_plate.json`, then copied that file to a tolerance-specific name. The final all-method baseline could therefore be replaced by a tau=.7 energy-only run. `sequence` now accepts `output_name`, and ablation writes directly to distinct files. The repair was verified by source inspection.

### Repaired: thin-domain test confused geometry and cut conditioning

The original cut sweep used top=eta/12 throughout, shrinking the whole physical domain into an increasingly thin strip. This changes the PDE geometry and its physical aspect ratio, not only a small cut fraction. The sweep now includes `fixed_domain_sliver` with top=(7+eta)/12 and separately labels the original `thin_domain` family. The first family keeps a substantial physical interior as eta tends to zero. The second is a legitimate stress case but should not be interpreted as an isolated cut-fraction experiment.

### Repaired in sequence; remaining cut-sweep failure accounting

The original runner updated warm-start history using `info==0` alone, although PCG stops on the scaled residual. The repaired `solve` now sets success only if the solution is finite, info is zero, both recomputed relative residuals are at most 1e−8, and reference energy disagreement is at most 1e−6 when available. `sequence` uses this gate for history updates. All rows, including success=false rows, must remain in the final summaries.

`sequence` now records and saves assembly/reference failures before terminating, and its per-method handler catches `RuntimeError`. Its failure-path save omits the configuration object, which should also be retained. The cut sweep still calls `direct_reference` outside a failure-recording guard in the last inspected snapshot; an LU failure there can abort the sweep without a structured record. Preserve that state and the parameter configuration before stopping or continuing. A mathematically singular geometry must remain a reported limitation.

### Repaired main energy-error guard; remaining diagnostic qualifications

The original relative energy-error metric silently used max(0,e^T A e). The repaired solver computes the signed form and rejects values below a scale-aware dot-product roundoff threshold, before clipping residual roundoff. This prevents materially negative forms from being reported as perfect agreement. Recording the raw signed value would further aid auditability, and the reference denominator should be checked for positivity and finiteness. The separate quadrature-comparison metric in `accuracy()` still clips without this guard; it should receive the same treatment if that case exhibits negative forms. These floating-point diagnostics do not constitute outward-rounded error certificates.

### Comparison fairness and reporting limits

Fresh, exact-local, energy, stale, and periodic methods use the same current overlap/weak blocks. This is the correct controlled comparison for a reuse claim. The CbAS and balanced coordinate-correction implementations are independent static competitors with different constructions; their formulation and implementation provenance need explicit labels. A balanced coordinate-correction preconditioner is not literal author code from the Voet paper.

All iterative policies now receive their own previous computed solution transferred by stable IDs, with a zero start at the first query. This is a fair repeated-solve protocol provided the previous solution passed the declared accuracy gate. Report the warm-start policy and do not pool earlier zero-start timings with these runs. The transfer is currently performed outside `solve`'s setup/linear timer; include its time in end-to-end totals or state that the reported total excludes common transfer/bookkeeping overhead.

The reference solve is deliberately outside each method's reported time, and its factorization is repeated by the timed direct baseline. This is defensible: verification overhead is excluded, while the direct method pays for its own factorization. The reference uses the same sparse-LU implementation as the direct baseline, so zero error for that baseline is agreement with itself, not an independent accuracy audit.

Assembly is shared once per query and the measured assembly time is added to each method's total. This compares the same assembly algorithm under each hypothetical solver policy. Explain the accounting; do not describe the sum as a separately measured full process for every policy. Record repetitions and use paired query/repetition totals rather than treating queries as independent timing replicates.

The metadata routine records package versions, platform and thread environment variables. A frozen source hash and the exact command/settings must also accompany formal results, particularly because source changes occurred during this audit. Cases run before these fixes should be treated as pilots and regenerated before inclusion.

## Review evidence and exit conditions

A small active-space crossing check used a degree-two 4-by-4 grid and top=.49 then .51. The dimension changed from 20 to 25, both current blocks were newly built and both old blocks retired at the crossing, and true residuals were 2.24e−15 and 2.93e−15. Relative energy differences to the direct references were 7.11e−16 and 1.92e−15. Both passed the new success gate. This tests index transfer and scaled actions together, without constituting a performance study.

Small checks used `/Users/kewang/Documents/ChatGPT/ACM_tog/.venv/bin/python` with bytecode writing disabled. No source was patched by this reviewer. The independent elasticity energy checks and the analytic roof-cap area expose mathematical properties directly; they are not performance runs.

Before accepting the paper's numerical claims: verify the repaired regression tests, use actual-residual success labels, preserve direct-reference failures, report the H1 seminorm correctly, distinguish plane strain and extruded geometry, and freeze the source used for the measured runs. These checks address concrete implementation and reporting risks. They do not replace the planned formal comparisons or a final review of the generated figures and tables.
