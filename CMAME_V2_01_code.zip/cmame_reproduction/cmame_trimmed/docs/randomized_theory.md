# Gaussian power screen: theory, implementation contract, and audit

Written 2026-10-16. This supplements `theory.tex` and `transport_theory.tex`; it does not replace the deterministic baseline. The complete paper-ready statement and proofs are in `randomized_theory.tex`. This is a numerical implementation of an exact-arithmetic, high-probability energy screen, not a deterministic certificate.

## Definition and one-check guarantee

For a retained normalized anchor C_a=L L^T and current C_t, use the complete cumulative difference Δ=C_t−C_a and symmetric E=L⁻¹ΔL⁻ᵀ. Orthogonal similarity gives η=||E||₂=||C_a⁻¹ᐟ²ΔC_a⁻¹ᐟ²||₂, even when Δ is indefinite.

Before drawing probes, fix positive integers q,s and a risk allocation δ∈(0,1). Draw s independent, unnormalized N(0,I_m) vectors. Set

β = [α max_j ||E^q ω_j||₂]^(1/q),  α = sqrt(2/π) δ^(−1/s).

Then P(β<η)≤δ. Choose a norm-attaining unit eigenvector u of E. For each probe, ||E^qω_j||≥η^q|u^Tω_j|. Underestimation requires every independent standard normal scalar |u^Tω_j|<1/α. The normal density bound gives P(|g|<1/α)≤sqrt(2/π)/α, and multiplication over s probes proves the result. η=0 is immediate. Accept β≤τ; a false acceptance with η>τ is a subset of the underestimation event. A rejection does not prove η>τ.

The default proposed before formal experiments is q=2, s=12, δ_total=10⁻⁸. The q=1,s=24 screen is an equal-work ablation. Positive integer powers are valid because E is symmetric and ||E^q||₂=||E||₂^q. Reusing the same probes for successive applications within E^q is required by this formula and does not violate independence: independence is needed across the s initial columns and between checks and their preceding histories.

## Lifetime risk and adaptive choices

For randomized check i across the entire lifetime, allocate δ_i=6δ_total/(π²i²). Conditional on the complete prior history and the selected current candidate, draw new independent Gaussian probes. Dimension, E_i, τ_i, q_i and s_i must be fixed before those probes. Adaptive geometry, anchors, and active memberships chosen using earlier information are permitted.

The conditional failure probability is at most δ_i. The countable union bound and Σ_i i⁻²=π²/6 give probability at least 1−δ_total that *every* computed β_i upper-bounds η_i, simultaneously over arbitrarily many checks, including an adaptively stopped run. Therefore every accepted local block satisfies its energy contract on the same event.

The counter covers blocks, queries, fresh anchors, and retries. It does not reset per block or time step. Every reroll consumes a new index. A deterministic test can precede the randomized test and does not consume random risk. If current normalized matrices remain unchanged, their existing contract remains valid without another random test; every changed normalized matrix needs a valid current test. New or changed ordered basis-ID memberships rebuild; disappeared blocks retire. A new experimental run can have its own budget, but a claim simultaneous across R runs must sum their budgets. Selection of favorable seeds or parameter settings after inspecting the current probes is outside the one-check theorem.

## Global consequence and transport

On the simultaneous good event, the earlier deterministic proof applies to every current block:

(1−τ) F_t⁻¹ ≼ S_t⁻¹ C_a⁻¹ S_t⁻¹ ≼ (1+τ) F_t⁻¹.

For identical current injections and an identical positive semidefinite auxiliary correction, summing gives (1−τ)B_f≼B_r≼(1+τ)B_f and κ_A(B_r)≤[(1+τ)/(1−τ)]κ_A(B_f), simultaneously for all queries. The changing-dimensional spaces are handled querywise using current membership and coverage. The theorem inherits the fresh method's quality; it gives no additional cut, h, or p robustness. The preconditioner remains fixed inside each PCG solve.

Independent positive diagonal temporal basis rescalings leave each normalized C_t unchanged. Coupling the same Gaussian arrays in the same ordered normalized coordinates therefore leaves the acceptance decisions unchanged. Signed temporal scaling requires the gauge treatment stated in the transport note.

## Computational contract and limitations

Apply E to a probe matrix Y in this order: Z=L⁻ᵀY, W=ΔZ, Y_new=L⁻¹W. Repeat q times, then use column norms and the qth root. Two triangular solves with s right-hand sides and one dense product per power give O(qsm²) work and O(ms) extra working storage. No inverse, inverse diagonal, or explicit E is needed. Both q=2,s=12 and q=1,s=24 use 48 triangular right-hand-side solves and 24 matrix-vector-equivalent products. Small blocks may still favor rebuilding; that is an empirical comparison.

For E=λP with rank-r orthogonal projector P, β/||E||=[α max_j X_j]^(1/q), where X_j are independent χ_r variables. The characteristic rank dependence changes from sqrt(r) at q=1 to r^(1/4) at q=2. More generally E||E^qω||²=||E^q||_F², so a broad cluster of large absolute eigenvalues makes the screen conservative. Powers suppress smaller eigenvalues. There is no universal dominance of q=2,s=12 over q=1,s=24: changing s changes α and the maximum over samples. This explains a mechanism, not an observed performance result.

At i=1 and δ_total=10⁻⁸, δ_1≈6.0792710×10⁻⁹. For q=2,s=12, α≈3.86028263 and α^(1/q)≈1.96476020. For q=1,s=24, α≈1.75500995. At fixed q,s the risk multiplier grows with i as i^(2/(sq)). For rank-one E, the exact underestimation probability is [erf(1/(sqrt(2)α))]^s, at most δ; the q dependence cancels.

Exposed old probes cannot safely be used against candidates selected from their results. For s<m choose a unit u orthogonal to the old probe columns, then E=γuu^T has E^qΩ=0 and arbitrary norm γ. Unit-normalized Gaussian vectors and random-sign probes do not have the small-ball law used above. Using a constant per-check risk gives only the finite union bound Nδ and no fixed infinite-lifetime risk.

Floating-point calculations and pseudorandom Gaussian draws approximate the theorem's exact model. Verified column error bounds ε_j for the complete application of E^q, including factor discrepancy, would permit β_safe=[α max_j(||Yhat_j||+ε_j)]^(1/q). A numerical margin without such bounds does not make a certificate. Record seed, generator, q, s, δ_total and check counter. Nonfinite values trigger a refresh or recorded failure; do not silently accept. Powers can underflow or amplify roundoff. If intermediate vectors are rescaled, retain the accumulated scale. Small empirical audits cannot establish a probability as low as 10⁻⁸.

## Primary precedent and contribution boundary

Halko, Martinsson and Tropp's published Lemma 4.1 gives ||B||≤a sqrt(2/π) max_j||Bω_j|| except with probability a^(−s). Our single-check formula is precisely that result with B=E^q and a=δ^(−1/s). Their Remark 4.1 also discusses power iteration to sharpen estimation. Neither the Gaussian estimate nor the use of powers is a new contribution. The candidate contribution is the integration with transported local inverse reuse, explicit cumulative risk accounting, and changing active-space semantics; useful end-to-end behavior still requires measured evidence. [Published paper and metadata](https://epubs.siam.org/doi/10.1137/090771806); [published full text, Lemma 4.1 on p. 241](https://www.cs.cornell.edu/courses/cs6241/2019sp/readings/Halko-2011-randomness.pdf). Verified BibTeX is in `randomized_references.bib`.

## Independent algebra audit

A small read-only script on 2026-10-16 used NumPy/SciPy, seed 91371, and 24 random SPD normalized anchors of sizes 2, 5, and 11, with symmetric indefinite perturbations. For each matrix it compared factor-only applications at q=1,2,3 against explicitly formed E^q and compared ||E||₂ with independently computed generalized eigenvalues of (Δ,C_a).

- Maximum relative power-application discrepancy: 5.98×10⁻¹⁶.
- Maximum relative energy-norm discrepancy: 7.68×10⁻¹⁶.
- Rank-one exact first-check underestimation probabilities: 5.31893×10⁻⁹ for q=2,s=12; 1.70578×10⁻⁹ for q=1,s=24. Both are below δ_1.
- Moderate-risk rank-one sanity sample: 100,000 draws, s=3, δ=.2; observed underestimation .15184, exact .15434, analytic bound .2. This is an implementation sanity check, not evidence for the tiny lifetime risk.
- Cached-probe counterexample: an 8-dimensional rank-one E of norm 100 annihilated three exposed Gaussian columns to numerical action norm 8.14×10⁻¹⁵.
- TeX environment nesting and unique labels passed; the insert was not compiled standalone.

## Claim-to-evidence map

| Claim | Support | Scope |
|---|---|---|
| One-check underestimation risk at most δ | Lemma proof; HMT 2011 Lemma 4.1 | Exact arithmetic and independent Gaussian draws |
| Any positive integer symmetric power is valid | Norm-attaining eigenvector; ||E^q||=||E||^q | Symmetric E, including indefinite E |
| Lifetime risk at most δ_total | Conditional estimate and countable union bound | Fresh independent probes and cumulative counter |
| Simultaneous global fresh-method comparison | Good event plus existing Loewner proof | Same current Schwarz construction and valid membership |
| No full inverse preprocessing needed | Explicit two-triangular-solve application | Randomized branch; dense O(qsm²) screen |
| Powers reduce projector rank dependence | Exact χ_r expression | Mechanistic model, not universal ordering |
| Positive temporal scaling invariance | Normalized matrices unchanged | Same ordered coordinates and coupled probes |
| Better reuse, speed, or practical robustness | No evidence supplied in this note | Must come from formal recorded experiments |
