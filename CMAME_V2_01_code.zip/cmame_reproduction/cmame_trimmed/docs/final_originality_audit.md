# Final originality and scientific-claim audit

Audit date: 16 October 2026. This final snapshot supersedes the earlier pre-guard assessment. Inspected: `FINAL_REVIEW_zh.md`, `docs/introduction.tex`, `docs/model_algorithm.tex`, `docs/main_theory.tex`, generated `paper/manuscript.tex`, final `results/paper_facts.json`, `summary.json`, all primary/ablation/cut JSON records, verification/source manifests and the recorded test log. No source, benchmark, manuscript prose or experimental data was changed by this audit. The only edited file is this audit. The generated manuscript may subsequently be rebuilt with final figures; this check concerns the scientific text and data available at this snapshot.

## Recommendation

The project now supplies a coherent, reproducible research draft with a specific mathematical maintenance contract, completed comparisons, explicit negative results and an honest internal major-revision recommendation. I agree with **continued scientific revision before CMAME submission**, rather than unconditional submission readiness. The final guarded campaign supports a useful larger-local-factor regime, especially the extruded elasticity example, but the mean benefit over exact normalized local refresh is modest and every primary family favors Jacobi in the measured implementation.

This is a combination/application contribution: current diagonal transport of normalized local anchors, cumulative Gaussian energy screening with a persistent risk budget, active-ID semantics, and a transparent small-block refresh rule. Its value should be stated as maintenance of an existing Schwarz construction with explicit degradation control. The executed evidence does not establish general solver superiority, production engineering scalability or a new universal cut-stability result.

## Independent arithmetic and protocol verification

The headline arithmetic was recomputed from the final summary, and the counts were checked against the row-level records:

| Quantity | Verified final value | Correct interpretation |
|---|---:|---|
| Primary solve records | 2,772 | 7 families × 12 queries × 3 repetitions × 11 methods |
| Additional checked solves | 2,100 | Screening ablation 192 + block-size ablation 288 + update sensitivity 1,440 + static cut study 180 |
| Total checked solve records | 4,872 | All recorded solution-accuracy flags pass; exception lists are empty |
| Geometric mean vs fresh | 1.1629257029 | Equal weight for seven ratios of sequence-median setup+solve times |
| Geometric mean vs exact-local | 1.0346227689 | Same convention; not a ratio of all pooled times |
| 3D setup speedup | 1.7108219518 | Relative to **fresh**, not exact-local; the latter ratio is 1.8243011062 |
| 3D setup+solve vs fresh | 1.2012579791 | Ratio of sequence medians |
| 3D setup+solve vs exact-local | 1.2439628402 | Ratios within paired repetitions: 1.242, 1.219, 1.254 to three decimals |
| 3D fresh/retained factor counts | 228 / 30 | Median per-repetition sequence count; reduction 86.8421% |
| Largest primary free dimension | 8,698 | Moderate model-problem scale |
| Largest primary physical residual | 1.1844741e-9 | Original-system relative residual, separate from scaled stopping rule |
| Largest primary reference energy difference | 3.1207530e-8 | Relative to a scaled sparse-direct reference, not exact continuum error |
| Fastest primary setup+solve method | Jacobi in 7/7 families | Includes all locally implemented comparators |

All three source manifests match the current files: 8 benchmark hashes, 8 ablation hashes and 9 static-experiment hashes. The recorded `final_tests.log` reports 47 tests passed; this audit did not rerun them. The generated manuscript has no unresolved citation keys against its bibliography: 24 used keys, 25 entries. The 14-query spectral audit and the 80-scale mechanism audit are additional checks and are correctly excluded from the 4,872 solve count.

The protocol rotates method order, records three complete repetitions and uses each policy's own preceding successful solution as its warm start. Timers include scaling, block construction, extraction, screening, local factorization and solve. Identifier transfer for warm starts, independent reference construction, post-solve checks and output are excluded. Assembly is common and charged once per query to each method's attributed total. This is an explicitly defined solver/assembly scope, not full application wall-clock time. Medians of setup and solve need not add exactly to the median of their sum; the independent medians shown in the summary are consistent with that convention.

## Final guarded primary results

Times below are medians across three complete 12-query sums, in seconds. They include cold setup. “Checks” counts randomized screens across all three repetitions; it is not a per-repetition median.

| Family | Fresh linear | Exact-local linear | Final linear | Exact/final ratio | Random screens | Random accepts |
|---|---:|---:|---:|---:|---:|---:|
| Moving hole | 0.896223 | 0.804777 | 0.789276 | 1.019639 | 0 | 0 |
| Local plate | 1.864980 | 1.472703 | 1.549365 | 0.950520 | 117 | 96 |
| Active crossing | 0.375677 | 0.306241 | 0.302240 | 1.013240 | 0 | 0 |
| Elastic plate | 1.720856 | 1.591120 | 1.648914 | 0.964950 | 198 | 176 |
| Extruded elastic solid | 19.867146 | 20.573425 | 16.538617 | 1.243963 | 594 | 594 |
| Larger plate | 7.379211 | 6.535666 | 6.563765 | 0.995719 | 243 | 174 |
| Ridge | 0.348411 | 0.313577 | 0.290027 | 1.081196 | 0 | 0 |

**Interpretation of zero-screen cases is essential.** Moving hole, active crossing and ridge invoke no Gaussian screen under the final size rule and retain the same factorization counts as exact-local. Their measured advantages cannot be attributed to accepting nonzero energy drift. In these cases the guarded policy largely reduces to exact-local refresh; timing variation and control-path overhead remain. The geometric means are arithmetically correct, but the small aggregate gain is not independent evidence that randomized reuse accelerates every family.

The three-dimensional case supplies the clearest mechanism/performance evidence: many eligible large blocks pass screening, factorization work falls, and the paired repetition ratios consistently favor the method over exact-local. Two-dimensional local and elastic plates retain additional factors but still lose time relative to exact-local. All of these outcomes belong in the main interpretation. When assembly is included, the 3D exact-local/final ratio is approximately 41.5550/37.4358 = 1.1100; the solver gain is diluted by unchanged assembly work.

The no-size-guard campaign remains preserved separately. It is useful evidence for the cost rule and algorithm development, but its timings must not be mixed with final primary tables. The guarded rule is a leading arithmetic heuristic, not a hardware-optimal threshold proved by the theory.

## Originality and closest literature

| Ingredient | Closest established basis | Defensible current distinction |
|---|---|---|
| Partial Schwarz refresh and mixed-age local factors | Berenguer–Tromeur-Dervout 2015/2016; Svolos et al. 2020 | An explicit normalized energy acceptance contract on changing trimmed active spaces |
| Cut amplitude loss and near dependence | de Prenter et al. 2017/2019/2023; Voet et al. 2026 | Their temporal separation via current diagonal transport, with limited mechanism models |
| Diagonal scaling and inverse congruence | Classical matrix analysis; standard immersed preconditioning | Consistent transport of stored normalized factors through independently changing positive scales |
| Gaussian norm estimates and powers | Halko–Martinsson–Tropp 2011 | Application to cumulative local anchor-energy discrepancies |
| Adaptive sequence risk budget | Conditional probability and a countable union bound | Concrete run-wide state and acceptance policy; the summable allocation is standard |
| Local-to-global spectral inheritance | Xu 1992; Toselli–Widlund 2005; Kolombage et al. 2026 | Direct multiplicative comparison of retained and fresh local inverse sums |
| Matrix-sequence updates | Carr et al. 2021; Bergamaschi 2020; Hager 1989 | Retaining/testing normalized local factors rather than a general mapped or low-rank update |
| Active-space correspondence | Stable coordinate IDs and cache invalidation | Explicit rules for changing trimmed spline memberships and complete support closure |
| Small-block refresh | Classical cost comparison | A measured implementation choice that spends no Gaussian budget on directly rebuilt blocks |

The Introduction and Related Work identify the most relevant sources and avoid unsupported first/universal claims. The refined nonhomogeneous restriction result adds a useful **conditional mechanism statement**: positive-definite leading-gradient Gram and a bounded relative remainder yield an explicit normalized-drift bound and reusable small-scale region. It is not a theorem that these assumptions hold for all actual B-spline Schwarz blocks. Two coordinate bases spanning the same polynomial space can behave differently, as the manuscript explicitly demonstrates.

No contradiction was found in the inspected small-cut derivation. The amplitude powers cancel under normalization; the relative remainder estimate leads to the stated conservative bound; combining current and anchor estimates gives the denominator `1−gamma_anchor`; solving the sufficient condition yields the displayed reusable-region threshold. The `1+2/sqrt(3)` coefficient in the explicit nonhomogeneous two-function example is consistent with the normalized correlation expansion.

Full journal-text access to the 2015 Berenguer and Svolos papers remains incomplete; the descriptions should stay within the accessed abstracts and public proceedings source. The search remains targeted rather than exhaustive. It supports positioning, not a priority proof. Primary sources for CbAS, contemporary deflation, the Gaussian estimate and the 2026 local-defect preprint have been examined through accessible full texts.

## Claims, probability and numerical limitations

The exact-arithmetic proof remains coherent under its explicit assumptions. Each candidate is fixed before fresh conditionally independent Gaussian probes are drawn. A single nonresetting counter allocates summable risks; rebuilding costs no risk. A directly refreshed small block has zero drift, so the size guard preserves the theorem. Accepted local inverse comparisons add to the global Loewner inequality on the current active space. The supplied sharpness example is compatible with unit-diagonal normalization.

The final manuscript correctly qualifies the probability claim with exact arithmetic in the abstract, Introduction and analysis. The guarantee concerns unsafe local acceptance, not all numerical failures. It does not establish outward-rounded certification of floating-point arithmetic or cut/h/p robustness of the fresh base method. The budget `42×1e-8` is the valid simple union bound for two randomized policies × three repetitions × seven primary families. It is not a bound over every exploratory and ablation run; those runs must retain their own stated risk allocations.

Independent small-system spectral measurements agree with the asserted admissible region: observed generalized eigenvalues `[0.9563350042,1.0433454660]`, maximal exact local drift `0.0458848826`, and maximal retained/fresh condition-number ratio `1.0425298726`, versus `[0.8,1.2]` and ratio bound `1.5` for `tau=0.2`. The audit deliberately disables the dimension gate to exercise screening. This is a mechanism/implementation audit, not a statistically powered empirical test of a `1e-8` failure probability.

Two minor wording issues were reported to the parent for correction, rather than edited here:

1. Generated results prose says “0 failed acceptance checks.” The count concerns **solution-accuracy checks**, while inconclusive Gaussian screens are intentionally rejected and rebuilt. Use unambiguous terminology so readers cannot infer that every screen passed.
2. The Chinese review says the leading-Gram condition “常会” fail for general local spline blocks. The supplied mathematics demonstrates that it **can** fail, without establishing a frequency. “可能失效” or an explicit counterexample is more precise.

The strongest remaining scientific gaps are unchanged by successful execution: broad runtime value relative to exact-local is modest; external Jacobi dominates current sizes; the implementation is serial and one-level; the largest primary system has fewer than 9,000 unknowns; three-dimensional geometry is an extrusion; and there is no production multi-patch CAD or mature multilevel comparison. The 24-query and edit-magnitude sensitivity studies strengthen the evidence within the chosen model regime but do not remove these scope limits.

## Final review, author facts and submission distinction

`FINAL_REVIEW_zh.md` is candid and consistent with the final data: it recommends major revision, reports Jacobi's advantage, distinguishes theoretical and numerical claims, discloses access gaps and labels the work an internal tool-assisted audit. It predicts no acceptance probability and does not imply external peer review.

The parent reports direct user confirmation of no funding and no conflicts. The generated manuscript includes those statements, so they are no longer unresolved author facts. Final human scientific approval and submission exclusivity remain distinct matters; neither follows from the earlier TOG manuscript. AI's substantive research/code/writing role is disclosed without falsely asserting completed human review. A local reproducibility archive is accurately described as lacking a public DOI/repository identifier.

Current journal-specific anonymity, abstract/file requirements and graphical-abstract status remain unverified because the official CMAME guide was inaccessible. Official Elsevier general highlights and AI/data policies are recorded in `venue_requirements.md`. This is an upload-preparation gap, separate from the scientific recommendation. The final generated PDF still needs the parent's planned rebuild and visual/compile verification; this audit does not certify a future binary.

**Final assessment:** a complete research artifact suitable for careful human review and reproducibility checks, with supported conditional theory and a measured 3D maintenance benefit. Further scientific revision is justified before CMAME submission, especially a stronger connection between the local mechanism and realistic blocks, and a challenging larger/multilevel mechanics comparison. The current data should be retained as mixed positive and negative evidence rather than reframed as universal acceleration.
