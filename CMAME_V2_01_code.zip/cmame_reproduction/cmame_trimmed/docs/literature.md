# Literature verification and originality map

Verified on 2026-10-16. Audience: CMAME computational mechanics and numerical linear algebra reviewers. The bibliography contains 21 entries in `../references.bib`. This is a targeted predecessor search, not an exhaustive systematic review. A missing search hit is not evidence of novelty. No external baseline code was executed or installed.

## Search and access protocol

Search families covered (i) trimmed/immersed IGA conditioning and Schwarz preconditioning, (ii) preconditioner reuse for matrix sequences, (iii) partial local Schwarz refresh and adaptive updates, and (iv) reduced order analysis of changing trimmed geometries. Searches used publisher pages, arXiv, and institutional author repositories. The academic-search MCP server described by the skill was not installed; public web search/open was used instead. Direct Crossref HTTP access from the shell failed DNS resolution; opening its API through the web tool also failed. Metadata below was therefore checked against accessible publisher or institutional records rather than represented as a successful Crossref lookup. Search-engine crawl dates were not treated as publication dates.

Access labels: **F** = accessible full text with relevant sections inspected; **M** = metadata/abstract/preview checked; this does not mean full text was read. Published-year citations use issue years, not preprint or first-online dates. Full texts remain at their source URLs; this package does not redistribute publisher PDFs.

## Closest predecessors

| Key | Verified primary source and access | Established contribution | Implication for this manuscript |
|---|---|---|---|
| `dePrenter2017` | **F**, [accepted manuscript](https://research.tue.nl/files/143604802/Prenter2017.pdf); [DOI](https://doi.org/10.1016/j.cma.2016.07.006). CMAME 316 (2017), 297–327. | Separates small basis norms from near dependence and introduces SIPIC scaling/orthogonalization. | Small-cut pathology and local algebraic cures are prior work; do not claim them as new. |
| `dePrenter2019` | **F**, [arXiv full text](https://arxiv.org/pdf/1708.03519); [published record](https://repository.tudelft.nl/record/uuid:e6ad1ac9-b7f2-4876-b2e7-d9f4809bc088); [DOI](https://doi.org/10.1016/j.cma.2019.01.030). | Connectivity-based additive Schwarz, including nonsymmetric/mixed flow systems. | CbAS is a required static comparator. Our SPD reuse result does not establish a nonsymmetric extension. |
| `dePrenter2020` | **F**, [publisher full text](https://link.springer.com/article/10.1007/s00466-019-01796-y). Computational Mechanics 65 (2020), 807–838. | Uses Schwarz smoothers in geometric multigrid to address mesh dependence in immersed systems; includes large systems. | Retaining local factors is different from obtaining h scalability. State which coarse correction is shared by matched policies. |
| `Voet2026` | **F**, [arXiv v1 full text](https://arxiv.org/html/2604.12848v1); [metadata](https://arxiv.org/abs/2604.12848). Submitted 14 April 2026; the accessed record identifies v1. | Gives counterexamples to earlier cut-block choices and a coordinate deflation construction, with an optional rank reduction. | Include deflation and adverse ridge/corner configurations. A reuse bound is relative to the chosen fresh preconditioner and cannot cure its block-selection deficiencies. Treat as a preprint, not a published CMAME paper. |
| `Berenguer2015` | **M**, [publisher record](https://www.sciencedirect.com/science/article/pii/S0045793014003946); [DOI](https://doi.org/10.1016/j.compfluid.2014.09.049). Computers & Fluids 110 (2015), 211–218. | Partially updates a frozen RAS preconditioner for nonlinear CFD, including asynchronous implementation. | Selective refresh and mixed-age local factors are not new. Full publisher text was not retrieved. |
| `Berenguer2016` | **F**, [DD22 author/proceedings PDF](https://www.ddm.org/DD22/proceedings/36_berenguer_contrib.pdf); [DOI](https://doi.org/10.1007/978-3-319-18827-0_44). LNCS&E 104 (2016), 437–444. | Section 1 defines lagged RAS and mixed-age local inverses; Section 2 uses cyclic partial LU refresh. Global iteration-count and periodic rebuild triggers are discussed. The conclusion identifies selective update criteria as a research direction. | The candidate distinction is a quantitative anchor-relative energy acceptance test plus active-space semantics, not the act of keeping some old factors. |
| `Carr2021` | **M**, [publisher abstract and metadata](https://epubs.siam.org/doi/abs/10.1137/20M1331123); [NSF full-text location](https://par.nsf.gov/servlets/purl/10311857), whose open request failed in this session. SISC 43(3), A2242–A2267. | Sparse approximate maps transfer an existing preconditioner across matrix sequences. | Compare conceptually to mapped updates: the proposed rule retains/refactors local SPD solves using local energy changes. Do not claim matrix-sequence reuse itself. Cite published author name Carr, not the older preprint name Grim-McNally. |
| `Chasapi2023` | **F**, [publisher article](https://doi.org/10.1016/j.cma.2023.115997); [author manuscript](https://infoscience.epfl.ch/server/api/core/bitstreams/9d0286d5-13e3-4df2-a508-4934eadf2e37/content). CMAME 410, 115997. | Snapshot extension, hyper-reduction and localized reduced bases on parameterized unfitted domains, including Poisson and elasticity. | Repeated geometry queries and background extensions are established. Our method targets full-order iterative solves and does not claim ROM accuracy/cost. |
| `Chasapi2024` | **F**, [publisher full text](https://link.springer.com/article/10.1007/s00366-024-01980-6). Engineering with Computers 40 (2024), 3623–3650. | Local reduced basis analysis of parameterized trimmed multi-patch Kirchhoff–Love shells. | Strong application-side predecessor for repeated trimmed geometry queries; not evidence that the present Poisson/solid code supports shells or multi-patch coupling. |

The DD22 full text is especially consequential: partial RAS updates already combine inverses built at different times. Its cyclic scheduling and global convergence triggers must be distinguished explicitly from an anchor-based local acceptance rule. The present study should cite both the 2015 journal article and the inspected 2016 chapter while specifying which details were read in which source.

## Classical ingredients and limits of the candidate contribution

| Ingredient | Prior basis | Claim permitted here |
|---|---|---|
| Restriction to active background splines; small-cut conditioning | `Hughes2005`, `Marussig2018`, `dePrenter2017`, `dePrenter2023` | State the discretization and its conditioning problem. |
| Additive local inverse sums | `Xu1992`, `Toselli2005`, `dePrenter2019` | Use and cite subspace-correction structure. |
| Spectrally equivalent inexact local solvers | `Xu1992`, `Toselli2005` | Derive the particular comparison; do not present the Loewner summation principle as a new abstract Schwarz theorem. |
| Reuse/partial refresh across systems | `Berenguer2015`, `Berenguer2016`, `Carr2021` | Explain a specific acceptance test and demonstrate when it pays. |
| Low-rank matrix/inverse identities | `Hager1989` | The support-reduced spectrum is a classical AB/BA/congruence reduction specialized to the detected perturbation support. |
| Recycling Krylov information | `Parks2006` | A separate possible acceleration; not implemented unless explicitly reported. |
| Local generalized spectral criteria and coarse modes | `Spillane2014` | Acknowledge that local eigenproblems are established; the test here measures change relative to a stored local inverse rather than selecting a GenEO coarse space. |
| Ghost penalty, aggregation, minimal stabilization, basis removal | `Burman2010`, `Badia2018`, `Buffa2020`, `Elfverson2018` | Explain alternative routes and the scope choice. The reuse scheme does not modify the variational form or discard weak active unknowns. |

The candidate contribution is the combination of (1) anchor-relative, scale-invariant local energy tests, (2) a support-reduced test that exploits the actual algebraic change support, (3) explicit invalidation on changes in ordered background basis IDs, and (4) a matched-fresh global spectral comparison on every current active space. Whether this combination warrants a CMAME methods contribution depends on complete proofs and measured cost savings against strong update policies. Its individual inequalities and matrix identities are classical. No priority claim follows from this targeted search.

Use the following boundary in the paper: “We study when existing local Schwarz solves may be retained as the trimmed active space changes. The analysis bounds the degradation relative to the corresponding freshly assembled preconditioner; it does not supply a new universal cut-independent condition-number bound.”

## Source-specific baseline requirements

**CbAS.** Primary full-text verification: de Prenter et al. (2019), Section 3.1, Eq. (18), printed pp. 8–9 of the arXiv manuscript, explicitly defines CbAS as one block per trimmed element containing all basis functions supported on that element, with singleton diagonal blocks for unknowns appearing in no such block. Thus the implemented cut-element comparator is faithful to this stated construction. For vector problems, Section 3.2 permits an efficient component-separated variant; grouping all components gives the unsplit version in Fig. 4(a). Preserve repeated-block multiplicities when sharing identical factorizations, and disclose the numerical cut-fraction classification. Overlap patches and weak-cut enrichment used by the proposed matched policies are separate block choices. Fresh and reused matched policies must use identical current restrictions and weights.

**Coordinate deflation.** Voet et al. v1 Section 5.3 uses columns of the identity associated with functions supported only on trimmed elements; Section 5.4 gives a further heuristic reduction. State whether all such coordinates or a reduced set are used, which background preconditioner is applied, and whether the deflated operator is solved on its compatible subspace. An SPD balanced/coarse-corrected implementation is an algebraic variant unless its equivalence to the stated deflated PCG algorithm is established. The v1 code-availability section says that code will be available before publication; no author code was downloaded or run in this task.

**Partial updates.** Include exact support-local refresh (all changed blocks rebuilt), whole-preconditioner lagging, periodic refresh, and matched fresh construction. A cyclic partial refresh policy reflects the inspected Berenguer chapter more directly than calling exact support refresh their published algorithm. Iteration-triggered lagged rebuild is an established heuristic and can be included if measured.

**Timing.** Count tests, factor refreshes, failed tests, active-set bookkeeping, assembly, and Krylov work. Saving factorizations does not establish saving time. Report cold and cumulative one-RHS totals, not only repeated-RHS amortization. The relative comparison inherits every deficiency in the fresh block choice.

## Metadata and access ledger for remaining references

| Key | Verified bibliographic record | Access and intended use |
|---|---|---|
| `Hughes2005` | [Publisher](https://doi.org/10.1016/j.cma.2004.10.008), CMAME 194(39–41), 4135–4195 (2005) | **M**, IGA background. |
| `Marussig2018` | [Publisher full text](https://link.springer.com/article/10.1007/s11831-017-9220-9), Archives 25, 1059–1127 (2018) | **F**, trimming challenges. Online 2017 is not the cited issue year. |
| `dePrenter2023` | [Publisher full text](https://link.springer.com/article/10.1007/s11831-023-09913-0), Archives 30, 3617–3656 (2023) | **F**, distinguishes stability, conditioning, quadrature and remedies. |
| `Xu1992` | [Publisher](https://epubs.siam.org/doi/abs/10.1137/1034116), SIAM Review 34(4), 581–613 (1992) | **M**, abstract/metadata; classical subspace-correction framework. |
| `Toselli2005` | [Publisher](https://link.springer.com/book/10.1007/b137868), Springer Series in Computational Mathematics 34 (2005) | **M**, contents/metadata; abstract Schwarz and two-level framework. |
| `Parks2006` | [Publisher](https://epubs.siam.org/doi/abs/10.1137/040607277), SISC 28(5), 1651–1674 (2006) | **M**, Krylov recycling. |
| `Hager1989` | [Publisher](https://epubs.siam.org/doi/abs/10.1137/1031049), SIAM Review 31(2), 221–239 (1989) | **M**, update identities and Schur-complement context. |
| `Burman2010` | [Official full text](https://comptes-rendus.academie-sciences.fr/mathematique/item/10.1016/j.crma.2010.10.006.pdf), C. R. Math. 348, 1217–1220 (2010) | **F**, matrix conditioning through ghost penalty. |
| `Badia2018` | [Institutional publication record](https://research.vu.nl/en/publications/the-aggregated-unfitted-finite-element-method-for-elliptic-proble/), CMAME 336, 533–553 (2018), DOI 10.1016/j.cma.2018.03.022 | **M**, aggregation changes the approximation space. |
| `Buffa2020` | [Publisher](https://epubs.siam.org/doi/10.1137/19M1244718), SINUM 58(5), 2711–2735 (2020) | **M**, variational stabilization for trimmed Dirichlet treatment. |
| `Elfverson2018` | [Author institutional record](https://umu.diva-portal.org/smash/person.jsf?pid=authority-person:68083), AMSES 5, article 6 (2018), DOI 10.1186/s40323-018-0099-2; [preprint](https://arxiv.org/abs/1801.00673) | **M**, basis removal with retained convergence order under stated conditions. |
| `Spillane2014` | [Author institutional record](https://researchportal.bath.ac.uk/en/publications/abstract-robust-coarse-spaces-for-systems-of-pdes-via-generalized/), Numer. Math. 126(4), 741–770 (2014), DOI 10.1007/s00211-013-0576-y | **M**, generalized eigenproblem coarse spaces. |

## Remaining search limitations

Full publisher access was intermittent, including the CMAME guide and several ScienceDirect pages. The closest reuse predecessor was therefore examined through its lawful public proceedings manuscript. No exhaustive forward-citation search or independent expert priority assessment was completed. Before claiming publication readiness, human authors should inspect the currently metadata-only closest source (`Berenguer2015`), assess implementation equivalence for the baselines, and review new work appearing after this search. This access limitation does not invalidate the self-contained algebraic proof, but it limits any assertion of priority.
