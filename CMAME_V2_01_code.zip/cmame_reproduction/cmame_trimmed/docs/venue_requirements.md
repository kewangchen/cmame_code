# CMAME submission preparation: verified rules and open checks

Checked on 2026-10-16. This file distinguishes publisher-wide rules verified from official sources from journal-specific items that could not be verified. It does not certify submission readiness.

## Official source access

The [current CMAME Guide for Authors](https://www.sciencedirect.com/journal/computer-methods-in-applied-mechanics-and-engineering/publish/guide-for-authors) returned a web-tool retrieval error. The [journal aims and scope](https://www.sciencedirect.com/journal/computer-methods-in-applied-mechanics-and-engineering/about/aims-and-scope) and [older Elsevier guide URL](https://www.elsevier.com/journals/computer-methods-in-applied-mechanics-and-engineering/0045-7825/guide-for-authors) returned 403. The attempted official legacy PDF location was also inaccessible. No claim below depends on a third-party guide or on the lookalike domain `sciencedirectelsevier.com`.

| Item | Verified status | Preparation decision |
|---|---|---|
| Single versus double anonymized review | **Unverified for current CMAME.** No accessible official source established the current review model. | Keep editable title-page metadata separate conceptually; verify the live portal/guide before choosing submission anonymization. Do not describe a named draft as an officially required single-anonymized format. |
| Abstract word limit | **Unverified for current CMAME.** A 250-word limit appeared in third-party summaries, which are not authority. | Prepare a concise abstract of at most 250 words as a conservative authoring choice, not a verified current journal rule. |
| Highlights | **Official Elsevier general guidance verified:** 3–5 bullets, each at most 85 characters including spaces; separate Highlights file. | Deliver a separate text file containing 3–5 measured, result-based bullets; count characters mechanically. Whether mandatory for current CMAME still requires the live guide. |
| Graphical abstract | **Current CMAME requirement/optional status unverified.** | An explanatory mechanism figure may be supplied as a useful artifact; do not label it mandatory or assert a pixel rule without checking the guide. |
| Reference style / LaTeX class / layout | **Current CMAME details unverified.** | Use numbered citations and an editable single-source manuscript as the project convention. Keep the BibTeX file and source so final publisher formatting remains straightforward. |
| Data/code availability | **Official Elsevier general policy verified:** research data can include code, algorithms and models; journals vary in their data-statement requirements. **Current CMAME policy option unverified.** | Include an accurate data/code statement naming the delivered local archive and reproduction commands. A local archive is not a public repository or DOI deposit. Do not invent a URL, accession or license choice. |
| AI use | **Official Elsevier journal policy verified:** disclose manuscript preparation use in a separate declaration before references; describe research-process use in Methods. Humans remain accountable and AI is not an author. | Describe actual drafting, source search, mathematical assistance, code generation and analysis roles. Do not imply completed human review before it has occurred. |
| Funding, conflicts, contributions, author approval | Project facts require author confirmation. | Do not transfer declarations from the unrelated TOG article. Keep unresolved facts explicit in preparation notes; obtain author confirmation before submission. |
| Cover letter and submission declarations | Journal/portal-specific required fields unverified. | A draft cover letter can explain the method and evidence, but exclusivity, all-author approval and conflict assertions remain for authors to confirm. |

Highlights source: [Elsevier Publishing Support, “How do I include Highlights with my manuscript?”](https://www.elsevier.support/publishing/answer/how-do-i-include-highlights-with-my-manuscript). Data scope and statements source: [Elsevier, “Sharing research data for journal authors”](https://www.elsevier.com/researcher/author/tools-and-resources/research-data). AI source: [Elsevier, “Generative AI policies for journals”](https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals).

## AI disclosure preparation

The current project uses Codex for substantive scientific and computational assistance, so an “English grammar only” declaration would be inaccurate. The following is an honest working statement, to be replaced by a human-approved declaration after review:

> Codex, an OpenAI AI-assisted research and coding tool, was used to assist with literature discovery and verification, research design, mathematical derivations, implementation, experiment execution, figure preparation, manuscript drafting and consistency checks. The delivered manuscript, code and results require review and approval by the named human authors before submission.

After authors actually perform that review, they can add a factual statement that they checked and edited the material and take responsibility for the article. Keep a Methods description of research/code assistance and the reproducibility audit in addition to the separate manuscript-preparation declaration. Preserve tool records and measured data. This project uses programmatically plotted measured results; do not describe them as generated experimental observations or images.

## Scientific readiness gates

These are the project's evidence standards, not claims about unpublished editorial rules.

1. Every headline saving is traceable to executed measurements and includes the appropriate assembly/update/solve scope and a fresh matched comparator.
2. The main theorem states exact SPD and block-identity assumptions and bounds degradation relative to the fresh method. Numerical inequalities are not advertised as outward-rounded certificates.
3. The closest partial-update RAS predecessors and the 2026 deflation preprint are discussed. A targeted search is not a priority proof.
4. Active-set crossings, missed block support changes, cumulative drift, adverse cut configurations and finite-precision failures remain visible in the evidence.
5. Manufactured-solution checks and independent quadrature checks distinguish discretization error from linear-solver error. Direct comparisons use a scaled system and report residual limitations.
6. Data/code availability describes the archive actually delivered. Publication, repository deposition and journal submission have not been performed by preparing these files.

Before upload, the corresponding author must re-open the official journal guide or portal to resolve the review model, abstract limit, graphical-abstract status, declaration fields, required file types and data-policy option. This is a concrete access gap, not a reason to stop the authorized research/drafting work.
