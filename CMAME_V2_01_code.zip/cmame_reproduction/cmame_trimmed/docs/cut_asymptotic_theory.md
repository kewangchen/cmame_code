# Conditional asymptotic mechanism for shrinking local restrictions

Date: 2026-10-16. New independent derivation; existing publication inserts were not edited. No tests, benchmarks, or numerical experiments were run while the timed campaign was active. `cut_asymptotic_theory.tex` contains the complete statements and proofs.

## What the result adds

Exact homogeneity is sufficient but unnecessary for diagonal transport to remain useful. If independently scaled leading gradient fields have an SPD Gram, then nonhomogeneous corrections induce an O(ε) normalized energy change. There is a nonempty interval (0,ε_max] on which every pair of current and anchor scales satisfies a prescribed energy tolerance, regardless of their amplitude ratio. The estimate explicitly separates shrinking amplitudes from the conditioning of the leading normalized Gram.

This is a conditional application of standard perturbation tools. It supplies a mechanism and an identified failure condition; it does not make the general Schwarz comparison or Gaussian norm estimate more novel, and it does not prove universal robustness for trimmed B-spline blocks.

## Assumptions and exact Gram expansion

Let Ω⊂R^d be bounded with positive measure and Ω_ε=x₀+εΩ. Assume, as vector fields on the fixed Ω,

∇φ_i(x₀+εy)=ε^(k_i)[g_i(y)+ε w_(i,ε)(y)].

Define Vz=Σ_i z_i g_i and W_εz=Σ_i z_i w_(i,ε) as maps to L²(Ω;R^d). The crucial assumptions are G₀=V*V≻0 and a uniform bound ||W_εG₀⁻¹ᐟ²||≤b. Uniform individual remainder bounds ||w_(i,ε)||≤M_i suffice with b=(Σ_i M_i²)^(1/2)/sqrt(λ_min(G₀)). The Gram assumption is independence of the *leading gradient fields*, which is stronger than independence of the original functions.

For the local stiffness Gram, Q_ε=diag(ε^(d/2+k_i)) gives

F_ε=Q_ε(G₀+E_ε)Q_ε,

||G₀⁻¹ᐟ²E_εG₀⁻¹ᐟ²||≤r_ε=2bε+b²ε².

The proof expands (V+εW_ε)*(V+εW_ε), using that VG₀⁻¹ᐟ² is an isometry. On a prescribed interval ε≤ε_bar, the simpler bound r_ε≤cε holds with c=2b+b²ε_bar. Positivity follows whenever r_ε<1. These formulas concern a pure first-gradient Gram with constant coefficients; other forms need their own expansion.

## Normalization bound, including a sharper alternative

Set D₀=sqrt(diag G₀), C₀=D₀⁻¹G₀D₀⁻¹ and κ₀=κ₂(C₀). Let C_ε be the unit-diagonal normalization of F_ε. The diagonal Q_ε cancels exactly, so C_ε is also the normalization of G₀+E_ε. Thus the amplitude exponents k_i disappear from the bound.

The proposed estimate is valid:

γ_ε=||C₀⁻¹ᐟ²(C_ε−C₀)C₀⁻¹ᐟ²||≤2r_εκ₀/(1−r_ε).

A second bound improves the leading condition-number dependence. Define

a(r)=sqrt(κ₀)[(1−r)^(−1/2)−1],

Γ(r;κ₀)=min{2rκ₀/(1−r), (1+r)[1+a(r)]²−1}.

Then γ_ε≤Γ(r_ε;κ₀), with Γ(r;κ₀)=(1+sqrt(κ₀))r+O(r²) for fixed κ₀. The original bound has first-order coefficient 2κ₀. The improvement matters when C₀ is moderately ill-conditioned, although both estimates can be conservative.

To verify the constants, let Ē=D₀⁻¹E_εD₀⁻¹ and d_i=E_(ε,ii)/G_(0,ii). Relative Gram control gives |d_i|≤r and −rC₀≼Ē≼rC₀. With Z=diag((1+d_i)^(−1/2)),

C_ε=Z(C₀+Ē)Z.

The two ordinary-norm terms ZĒZ and ZC₀Z−C₀ each have norm at most r||C₀||/(1−r), proving the first bound after division by λ_min(C₀). For the sharper version, set U=C₀¹ᐟ²ZC₀⁻¹ᐟ² and B=C₀⁻¹ᐟ²ĒC₀⁻¹ᐟ². Then ||U−I||≤a(r), ||B||≤r, and the relative normalized matrix equals Uᵀ(I+B)U. Its deviation from identity is bounded by r(1+a)²+2a+a²=(1+r)(1+a)²−1.

## Anchored drift and uniform safe interval

Write γ_ε for either proved upper bound. If γ_a<1, then

η(C_a,C_ε−C_a)≤(γ_ε+γ_a)/(1−γ_a).

This follows directly from |xᵀ(C_ε−C_a)x|≤(γ_ε+γ_a)xᵀC₀x and xᵀC_ax≥(1−γ_a)xᵀC₀x. It has the requested anchor direction: the denominator uses the anchor's lower comparison with C₀.

Both expressions in Γ increase with r. Therefore every ε,ε_a∈(0,ε_max] satisfies η≤τ if

Γ(r_(ε_max);κ₀)≤τ/(2+τ).

A simpler explicit sufficient condition is

r_(ε_max)≤r*=τ/[2κ₀(2+τ)+τ].

For b>0 this holds whenever ε_max≤[sqrt(1+r*)−1]/b, together with ε_max≤ε_bar. For b=0, transport is exact throughout the assumed family. Because ε_max is positive for fixed finite b,κ₀ and τ>0, the statement gives a genuine nonempty asymptotic regime. It permits nonmonotone visits to that interval and arbitrarily large ratios ε/ε_a; no factor depending directly on the amplitude exponents appears.

“Safe” means the underlying exact relative-energy contract holds. A conservative majorant or Gaussian screen can still reject a safe pair. No acceptance-rate or speed guarantee follows from this theorem. A uniform local contract can feed the existing global Schwarz comparison only when it holds for every retained block.

## Concrete nonhomogeneous example

Take φ₁=x+x² and φ₂=x² on (0,ε). On the reference interval (0,1), their gradients are 1+2εy and ε(2y). Hence k₁=0, k₂=1, g₁=1, g₂=2y, and

G₀=[[1,1],[1,4/3]],  det G₀=1/3>0.

With Q_ε=diag(ε^(1/2),ε^(3/2)), direct polynomial integration gives

Q_ε⁻¹F_εQ_ε⁻¹ = [[1+2ε+4ε²/3, 1+4ε/3], [1+4ε/3, 4/3]].

Here Wz=2z₁y. Consequently ||WG₀⁻¹ᐟ²||²=(4/3)(G₀⁻¹)₁₁=16/3, so b=4/sqrt(3) is an explicit admissible constant. The limiting normalized correlation is sqrt(3)/2 and κ₀=7+4sqrt(3). The current correlation is

ρ_ε=(1+4ε/3)/sqrt[(4/3)(1+2ε+4ε²/3)].

Its derivative at zero is sqrt(3)/6. Since the two-by-two correlation matrices share their eigenvectors,

η(C₀,C_ε−C₀)=(1+2/sqrt(3))ε+O(ε²).

Thus the normalized matrices are not constant, but converge in relative energy at first order. The polynomial correction is higher degree and lower asymptotic amplitude. This is a strict extension of the homogeneous example, without relying on numerical evidence.

## Where the hypothesis fails

For {x,x+x²}, both leading gradients are the constant 1. G₀ is singular, although every finite-ε stiffness Gram is SPD. The normalized correlation tends to one, κ₂(C_ε)∼12ε⁻², and the drift against any fixed positive-scale normalized anchor has limit inferior at least one. No tolerance τ<1 permits indefinite reuse of that anchor as ε→0. The successful and unsuccessful examples span the same polynomial space in different bases: the property concerns the coordinates used by diagonal transport, not only the approximation space.

Within one fixed knot cell, each polynomial B-spline piece has a Taylor expansion of the required form. However, at a generic interior point, each nonzero gradient has a constant vector as its leading term. More than d such gradients must be dependent, so the SPD-leading hypothesis often fails for a larger local block. Expansions across knots require a fixed scaled partition and verified uniform remainder bounds. It is not enough to assert that a B-spline is smooth everywhere.

The analyzed matrix integrates only x₀+εΩ. A Schwarz principal matrix ordinarily integrates all physical supports of its basis functions, including contributions outside that region. Such a matrix requires a separate expansion before this theorem can be applied. Multiple small regions, changing shapes, variable coefficients, exterior contributions, or a changing block membership are not automatically covered. Nor are the constants uniform in degree, mesh size or the condition number of the leading Gram.

## Verification plan after timed runs

No verification computations were executed for this note. An inexpensive later audit can be limited to small matrices and should proceed as follows:

1. Use the displayed two-function example with several ε values and exact polynomial-integral formulas. Compute C_ε, the true generalized-eigenvalue drift against C₀ and a fixed positive anchor, r_ε, both Γ bounds, and the anchor bound. Check all inequalities and the limiting coefficient 1+2/sqrt(3). This is a mathematical mechanism check, not a timing experiment.
2. Repeat with {x,x+x²}; confirm singularity of the leading Gram and the normalized condition asymptotic. Do not regularize the leading Gram or discard a basis function to force the assumption.
3. For a proposed B-spline application, identify a fixed cell or fixed scaled piecewise partition and obtain the leading gradient coefficients analytically from the polynomial pieces. Inspect G₀ before applying any theorem. If it is singular, report that the sufficient condition fails rather than inferring robustness from finite-ε positivity.
4. If G₀ is SPD, bound the Taylor remainder over the fixed reference domain and compare actual normalized drift with Γ for a small ε grid. Use higher precision if the leading Gram or physical amplitudes are ill-conditioned. A floating-point eigenvalue check illustrates the theorem but does not certify its exact inequalities.
5. Distinguish this local-region audit from the current full-support Schwarz block. Do not claim that the former validates the latter without establishing its matrix expansion.

## Claim-to-evidence map

| Claim | Evidence | Limitation |
|---|---|---|
| Nonhomogeneous Gram is relative-O(ε) after amplitude removal | Operator expansion and explicit remainder constant | SPD leading gradient Gram; uniform remainder |
| Proposed 2rκ₀/(1−r) normalized bound | Two-term norm estimate | Conservative; κ₀-dependent |
| Sharper first-order 1+sqrt(κ₀) coefficient | Congruence Uᵀ(I+B)U | Fixed κ₀ as r→0 |
| Uniform anchored drift bound | Rayleigh quotient relative to C₀ | Anchor γ_a<1 |
| Arbitrarily different amplitudes can share a valid anchor | Cancellation of Q_ε and uniform interval condition | Contract validity, not screen acceptance |
| A nonhomogeneous example satisfies the assumptions | Exact polynomial integrals | One-dimensional mechanism example |
| General B-spline robustness | Not established | Leading Gram can be singular; full block may not be a shrinking-region Gram |

The result is scientifically useful as a concise conditional explanation and a falsifiable diagnostic. It should not be marketed as the principal novelty of the paper or used to convert empirical cut sensitivity into a general robustness theorem.
