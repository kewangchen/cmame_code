# Independent publication-theory audit

Status update: the final section records the follow-up review after exception recovery, condition-number wording, probability scope, timing scope, and the dimension guard were revised. The numbered findings below preserve the original inspection history.

Date: 2026-10-16. Scope: `docs/main_theory.tex`, `docs/model_algorithm.tex`, and `docs/introduction.tex`, checked against `src/solver.py`, `src/preconditioners.py`, and root-level `experiments.py`; `src/assembly.py` was read to verify block construction and update-support semantics. This was a read-only mathematical and control-flow audit during the formal campaign. No benchmarks or tests were run and no source code was changed. Findings refer to the text at the time of inspection; revisions may shift line numbers.

**Assessment:** the transport inequality, Gaussian constants, adaptive lifetime proof, global comparison, normalized cumulative example, and active-space argument are mathematically sound under the stated exact-arithmetic assumptions. Publication is not unconditionally cleared: one exception-recovery code path breaks the update-support contract, two condition-number statements need correction, and the scope of probabilities and timings needs precise labeling. The code defect does not affect a sequence with no caught method exceptions.

## Findings requiring action

### 1. A caught method exception can leave a stale update-support baseline

**Priority: high for failure recovery.** `experiments.py:62–67` catches a method exception, records it, and proceeds without clearing that method's cache. A cache is replaced only after `solve` returns. At the next geometry query, `solver.py:33` supplies the immediately preceding step's `system.changed_ids`, while the surviving cache may represent an earlier query. `preconditioners.py:316–317` then skips any block disjoint from this latest support and trusts its previous bound.

For a concrete control-flow counterexample, let a previously accepted two-coordinate block change from the identity to [[1,.5],[.5,1]] at a query where a later factorization or solve raises an exception. The caller retains the preceding cache. Suppose the next query changes only coordinates outside that block. Its latest change support is disjoint from the block, so the old identity action is reused as unchanged despite drift .5, violating τ=.2. The full algorithm does not have to fail in the offending block: any caught exception before returning the updated cache suffices.

**Required correction:** on a method exception, clear that method's cache, or retain the last successfully processed geometry and accumulate every missed change support until the method next completes setup. Preserve the probability budget rather than resetting it. The previously converged solution can remain a warm-start source. A returned unsuccessful iteration with a current returned cache is a different case: its setup state is current and does not have this defect.

**Effect on existing evidence:** inspect every formal result's `failures` list. Failure-free runs are unaffected. A run containing a caught method exception needs a recovery-aware analysis or rerun; later results for that method cannot automatically inherit the theorem. This was reported to the parent immediately.

### 2. The shrinking example mixes spectral and singular-value condition numbers

**Priority: medium, mathematical notation.** `main_theory.tex:70` states κ(F₁⁻¹F_ε)∼16ε⁻². The product is generally nonsymmetric. The stated constant is correct for its positive eigenvalue ratio, equivalently κ_{F_ε}(F₁⁻¹), but not for its Euclidean singular-value condition number.

Here F₁⁻¹=[[4,−3],[−3,3]], so F₁⁻¹F_ε has trace 4ε−6ε²+4ε³ and determinant ε⁴. Its eigenvalue ratio is asymptotic to 16ε⁻². Its leading matrix is ε[[4,0],[−3,0]], whose largest singular value is 5ε; the determinant then gives κ₂(F₁⁻¹F_ε)∼25ε⁻².

**Required correction:** write κ_{F_ε}(F₁⁻¹) and define this spectral preconditioned condition number before its first use, or explicitly write the generalized eigenvalue ratio. Use the same interpretation in the analytic figure caption.

### 3. The sharpness proof names the wrong object with condition number one

**Priority: medium, wording with mathematical meaning.** `main_theory.tex:171–172` says “the fresh inverse has condition number one.” For C=[[1,τ],[τ,1]], C⁻¹ has condition number (1+τ)/(1−τ). The freshly preconditioned operator has condition number one.

**Required correction:** state κ_C(C⁻¹)=1 and κ_C(I)=(1+τ)/(1−τ). The unit-diagonal construction is correct and demonstrates sharpness of the local-contract comparison. It does not assert that a continuous randomized screen accepts the boundary case η=τ with positive probability on its upper-bound event; sharpness is a property of the comparison class, or can be understood as a supremum approached with η<τ.

### 4. The risk budget is per method, case, and repeat

**Priority: medium, claim scope.** `experiments.py:44` creates separate budgets for `energy` and `energy_raw` at the start of each repetition. Each counter persists across its blocks and geometry queries. This correctly implements a lifetime budget for one method's one sequence. It does not provide a single δ=10⁻⁸ guarantee for the entire campaign.

For seven cases, three repeats and two probabilistic policies, the direct union bound is 42δ=4.2×10⁻⁷. For the proposed transported policy alone it is 21δ. No independence across these runs is required for that union bound; using corresponding seeds in separate policies does not invalidate their marginal claims. Additional spectral audits and ablations have additional budgets.

**Required clarification:** define “run” as one method's one case/repeat sequence. Keep the theorem at that scope, or explicitly sum budgets for any wider simultaneous claim. Do not describe three seed repetitions as an empirical validation of a 10⁻⁸ failure rate.

### 5. “Complete sequence costs” overstates the timing boundary

**Priority: medium, comparison interpretation.** `introduction.tex:68` says complete sequence costs. `solver.py:23–46` times normalization, block construction, preconditioner setup, and linear solution. `total` adds current assembly time. The warm-start stable-ID transfer in `experiments.py:57–61`, direct validation reference, residual and reference-energy validation after `solver.py:46`, and output/plotting are outside these timers.

The current boundary is useful and fair when labeled. All matched policies pay their own normalization, extraction, screening and factorization; the same assembly cost is charged to each method's hypothetical standalone sequence. Excluding a separate validation reference is appropriate. The issue is claiming full wall time rather than the measured computational stages.

**Required clarification:** use “assembly, setup, and linear-solution time” and state the exclusions. If claiming full end-to-end wall time, the missing stages must be timed. Existing data do not permit reconstructing transfer time exactly.

## Verified mathematical statements

### Transport and shrinking models

The direction of inversion is correct: (1−τ)H≼C≼(1+τ)H implies (1−τ)C⁻¹≼H⁻¹≼(1+τ)C⁻¹. The current-scale congruence therefore gives the reported local inverse bounds. Positive diagonal temporal rescaling cancels exactly in normalized coordinates; the signed-coordinate caveat is appropriate.

The homogeneous stiffness scaling exponent d+r_i+r_j−2 is correct for the unweighted scalar stiffness form used in the model, or a fixed constant coefficient tensor. The SPD assumption excludes constant-gradient null directions and any dependent derivative fields. The proposition should be read for this stiffness Gram, not arbitrary variable coefficients or mixed-order forms. The two one-dimensional matrices and the 12ε⁻² normalized condition asymptotic for {x,x+x²} are correct. These models explain mechanisms; they do not prove universal B-spline cut robustness.

### New normalized cumulative example

Set a=1−e and t=0,1,…. F_t has eigenvalues λ₊(t)=2−a^t and λ₋(t)=a^t. The preceding-step relative change has eigenvalues

- −e in the minus mode;
- e a^(t−1)/(2−a^(t−1)) in the plus mode, whose magnitude is at most e for t≥1.

Its norm is therefore exactly e at every step, while F₀=I and κ₂(F_t)=(2−a^t)/a^t=2a⁻ᵗ−1. The diagonal remains [1,1]. The example establishes both failure of a diagonal-only indicator and failure of individually small preceding-step contracts to control a fixed retained anchor. The cumulative anchor drift is ρ_t→1 and eventually exceeds every fixed τ<1. Explicitly specifying t=0,1,… would make initialization unambiguous.

### Gaussian powers and lifetime constants

For symmetric K, including indefinite K, ||K^q||₂=||K||₂^q for every positive integer q. The norm-attaining eigenvector argument bounds underestimation by [sqrt(2/π)/α]^s. The displayed α_j=sqrt(2/π)δ_j^(−1/s) and δ_j=6δ/(π²j²) therefore give the exact intended allocation. α need not exceed one in the lemma; when the displayed upper bound exceeds one it is merely uninformative, not false.

Conditioning on all earlier information and the fixed current candidate makes the one-check bound applicable. Taking expectations and the countable union bound proves the arbitrary-lifetime result. The code's `EnergyBudget.draw` uses the same logarithmic formula, advances one persistent counter per randomized check, and draws fresh standard normal columns. Its immutable configuration prevents unnoticed changes of q,s,δ. The budget token prevents skipped unchanged blocks from being treated as probabilistically certified under an unrelated budget object. Exact equality and fresh anchors are deterministic and need no allocation.

The implementation applies L⁻ᵀ first, then Δ, then L⁻¹. Per-column normalization after each power retains the accumulated Euclidean norm in logarithms, so it represents the stated unnormalized-Gaussian formula in exact arithmetic. It does not substitute normalized initial Gaussian probes. Both default q=2,s=12 and q=1,s=24 use 48 triangular right-hand-side solves. The rank-projector χ_r expression is correct; a universal dominance claim between the two parameter choices would not follow from it. The text's qualification that acceptance rates and other costs can differ is appropriate.

The main section explicitly assumes exact arithmetic. The supplemental finite-precision qualifications should be retained: floating-point screening and a seeded pseudorandom generator are not an outward-rounded deterministic certificate, and a finite audit cannot substantiate a 10⁻⁸ failure frequency experimentally.

### Global and changing-space theorem

Current principal matrices, matching current injections and coverage suffice to sum the local Loewner inequalities with no new overlap constant. The same PSD coarse term is admissible. The generalized condition-number factor (1+τ)/(1−τ) and the PCG energy-error bound have the correct direction. The theorem does not transfer absolute cut, h, or p robustness from nowhere; it explicitly retains all dependence of the fresh method.

Ordered stable IDs identify the same local basis functions across active-row renumbering. `build_schwarz` uses those ordered tuples as keys, rebuilds new memberships, retires absent ones, and preserves repeated-block multiplicities. `assembly.System.blocks` supplies coverage and the same blocks to each matched policy. The construction and theorem are querywise, so no map between the entire old and new vector spaces is needed. The unchanged-support shortcut is sound only when support is complete relative to the last matrix actually processed by that cache; finding 1 identifies the exceptional path where that premise fails.

## Code-to-text alignment

| Item | Finding |
|---|---|
| Scalar and elasticity models | Match assembly; plane-strain Lamé parameterization is stated correctly; 3D is extrusion |
| Matched block construction | Overlapping macro-cell supports, one-cell extension, weak-component enrichment, singleton coverage match the text |
| Main transported policies | `solver` passes globally normalized C; local principal matrices are normalized blocks in exact arithmetic |
| Raw-anchor ablation | Builds on physical A and wraps the inverse by D⁻¹ on both sides for the scaled solve; correct |
| Current inverse action | The factor and its local anchor scaling remain fixed during PCG; no probes occur in application |
| Deterministic comparator | Inverse-diagonal and inverse-factor bounds followed by support compression match described supplemental design |
| Exact local comparator | Equality is tested in current normalized coordinates, consistent with shared transport |
| Warm starts | Each method uses its own last converged solution, transferred by stable IDs; first solve starts at zero |
| Stopping and acceptance | CG uses scaled relative tolerance 10⁻⁹; success additionally requires actual scaled and physical residuals ≤10⁻⁸ and reference energy error ≤10⁻⁶ |
| Independent spectra | `spectral_audit` computes generalized operator and local-drift eigenvalues independently of random estimates; it is an audit, not timed main setup |
| Failed screens | Rebuilds are charged to setup; exceptions are reported, but subsequent cache recovery needs finding 1's correction |

## Scientific significance for CMAME

The manuscript now attributes partial Schwarz reuse, Jacobi/SIPIC scaling, Gaussian norm estimation and powers, the union bound, and Schwarz spectral comparison to established foundations. That is the correct novelty boundary. The exact-arithmetic proofs are short and sound, but they do not on their own constitute a substantial new numerical-analysis result.

The credible contribution is a specific practical combination: update the physical amplitude scaling immediately, retain normalized local factors only under cumulative energy control, implement a factor-only probabilistic screen with an explicit sequence budget, and maintain its assumptions through active-space changes. The homogeneous and cumulative examples explain why each part matters. A CMAME case requires measured, reproducible utility of that combination over the strong exact-local-refresh baseline and the practical external solvers, including all screening costs and rejected tests.

The current seven-case suite addresses scalar, elastic, active-crossing and extruded geometries, but most geometric motions are small. For example, the 16-query moving-hole sequence moves its center by .003 over a 48-cell direction (about .144 cells), and local-plate radii change by .0012. These are legitimate slowly evolving workloads, not evidence for arbitrary geometry edits or topology change. The text should state that scope. All 3D examples are extruded; they do not establish performance for general 3D trimming. Three repeats provide timing variation and seed variation, not strong evidence about rare randomized failures.

A defensible final conclusion may be positive, mixed, or negative depending on the frozen measurements. If the method wins only when block factors are large, changes are localized, and correlations drift slowly, that is a useful conditional result when the crossover and unfavorable cases are visible. If exact local refresh or fresh direct solves remain faster throughout, the current theory does not justify claiming a broadly effective solver advance. No journal-readiness approval should precede the measured comparison and failure audit.

## Inspected snapshot hashes

SHA-256 values recorded immediately after the read-only inspection:

```text
f57e72b944aa1ccc2e605176a9f8e6c416b6958990e94dc39450a8b9f58afa19  docs/main_theory.tex
9d1322215b7dc360d67ad7c595440468f552c7981b947f559de4e087c0d35b45  docs/model_algorithm.tex
ab11b04d21d2416dc3a221ec98305c6825a3b125c4f1dd760fc747a27671518e  docs/introduction.tex
9d8f42e7efa995769cec544c4afa3346aa887e112e36d4b5d37745e26c29a96c  src/solver.py
c3401c68291f5fc7c3e9b1ac969ba176601d6e72821db281e6a524bd7d85e73b  src/preconditioners.py
d2df23483af1a7412fef36caa58dab3f001fa1eb23be4b8e83a32caf91a11304  experiments.py
```


## Resolution review after the dimension guard

Follow-up date: 2026-10-16, while the final serial campaign was running. Sources and publication inserts were read again; `experiment_protocol.tex` and `limitations_conclusion.tex` were also inspected for the scope clarifications. No tests, benchmarks, or source/prose edits were performed. Only this audit was updated.

### Resolved findings

1. **Exception-recovery defect: resolved in the inspected source.** The caught method-exception handler now removes both `caches[method]` and `previous[method]`. It leaves the existing `EnergyBudget` object and counter intact. The next query therefore constructs current fresh factors and cannot invoke an unchanged-support shortcut against an unprocessed intermediate query. This is the correct recovery action. The probability budget continues to account for all random checks performed before the exception.

2. **Shrinking-model condition-number meaning: corrected.** The example now uses κ_{F_ε}(F₁⁻¹), so the coefficient 16 denotes the intended spectral preconditioned condition number. One presentation issue remains: the notation is still first used near line 70 and defined only near line 144. Move its definition before the example, preferably to the opening paragraph of the spectral-analysis section. This is a definition-order issue, not a remaining incorrect asymptotic.

3. **Sharpness object: resolved.** The text now correctly says the freshly preconditioned operator is the identity. The unit-diagonal example and the sharp comparison factor remain valid.

4. **Risk scope: resolved in the protocol.** The experimental protocol now specifies separate budgets for each probabilistic policy and complete repetition, and states the 42δ union bound for the seven-case, three-repeat, two-policy campaign. This matches the source. The policy's theorem is a per-sequence statement, while the wider campaign statement sums its budgets.

5. **Timing scope: resolved in the protocol and introduction.** The introduction now names cumulative assembly, setup and solver costs. The protocol explicitly excludes warm-start identifier transfer, independent reference computation, post-solve validation and output. The measured quantities are now described accurately.

### Dimension guard: algebra and implementation agree

The sequence constructor uses `EnergyBudget(min_dimension=288)` for both `energy` and `energy_raw`. The exact execution order in `build_schwarz` is:

1. Reuse a previously justified unchanged block when the current support and state permit it.
2. Extract a changed candidate and reuse it if it equals its anchor exactly.
3. For a changed, unequal retained block with m≤288, skip the randomized screen and build a fresh factor.
4. For a changed, unequal retained block with m>288, draw probes and apply the probabilistic screen.
5. New memberships receive fresh factors without screening.

The guard branch increments `skipped_small_blocks`, leaves `retain` false and falls through to fresh factorization. It does not call `EnergyBudget.draw`, so it spends no probability and the check index still counts actual randomized tests. A fresh block has zero relative drift. The lifetime union bound and the global fresh-Schwarz comparison therefore apply without modification. Selecting this fixed dimension threshold before drawing current probes also preserves conditional independence. The exact threshold is inclusive on refresh: screening starts at dimension 289, not 288.

The dense spectral audit creates `EnergyBudget()` with its default `min_dimension=0` and records that value explicitly. Since block sizes are positive, it deliberately exercises the unguarded screen. This is a legitimate mechanism audit of the screen and spectral theorem. It is not the identical trajectory of the guarded production policy, and should be labeled accordingly in the manuscript and figure captions.

### Gaussian threshold and current normalization rechecked

The tested threshold is β≤τ with τ=.2; α remains sqrt(2/π)δ_j^(−1/s), and the code takes the qth root after applying α to the maximum action norm through the equivalent logarithmic expression. The dimension guard does not alter that formula. Initial probes are standard Gaussian; intermediate unit-column rescaling retains all magnitudes and hence computes the same powered action in exact arithmetic.

The main solver still passes C=D_t A_t D_t with current D_t=diag(A_t)⁻¹ᐟ² into the retained-factor construction. Its principal matrices are exactly the current normalized local matrices in exact arithmetic. Applied in physical coordinates, the normalized inverse becomes S_t⁻¹H⁻¹S_t⁻¹. The additional internal equilibration of a stored factor is an algebraically equivalent representation of its anchor inverse, not an inadvertent replacement of current transport by an old physical scaling. The raw-anchor policy still builds from physical A and wraps the action with D_t⁻¹ on both sides for the scaled solve. No new scaling defect was found.

### Remaining publication edits and interpretation limits

- **Define κ_A(B) before first use.** The shrinking example still precedes the definition in `main_theory.tex`.
- **Describe the actual dimension guard.** `model_algorithm.tex` currently omits the 288 threshold, the fact that exact/unchanged reuse is tried first, and the absence of a risk charge for direct refresh. Add these details to the algorithm description. State that the spectral audit deliberately sets the threshold to zero.
- **Treat 288 as an empirical cost policy.** O(m³) versus O(qsm²) motivates a threshold but does not prove that 288 is a universal crossover. Record that the final threshold was fixed from exploratory work before the final campaign, and avoid hardware-independent optimality claims.
- **Qualify the deterministic comparison.** The guard applies to both probabilistic policies, but `energy_deterministic` does not have the same small-block refresh branch. Their timing comparison therefore combines estimator choice and the guard. The introduction's statement that these comparators “isolate” inexpensive screening is too strong unless a matched guard comparison is also supplied. Describe them as complete policy comparisons, or report the guard separately.
- **Expose how much screening is actually used.** The saved `skipped_small_blocks`, `randomized_checks`, `reused_energy`, and refresh statistics distinguish cheap direct refresh from successful nonzero-drift reuse. If a case mostly stays below the threshold, its agreement with exact local refresh is expected and should not be presented as evidence of a useful Gaussian screen. This requires reporting existing records, not a new computation-heavy test.
- **Keep the final empirical conclusion conditional until the campaign completes.** The conclusion currently states that the clearest benefit occurs in larger elastic blocks. This is a provisional empirical statement until the final guarded records and their failures have been analyzed. The theorem alone does not establish it.

The protocol now specifies 12 queries per final sequence. Earlier examples in this audit used the 16-query function default to describe the workload family, not the final run length. Over 12 moving-hole queries, the center moves .0022, or about .1056 cells on the 48-cell grid; the qualification that the experiments study slowly evolving trims remains applicable.

### Decisive assessment

The previously identified recovery-path correctness defect is fixed, and the mathematical core remains sound for exact arithmetic. The dimension guard is a valid conservative algorithmic choice and creates no new probability or active-space defect. The remaining issues are reproducibility details, definition order, comparison attribution and empirical interpretation, rather than an unresolved sign, constant or spectral-proof error.

This supports proceeding with analysis of the frozen campaign. It does not support unconditional CMAME submission clearance. The scientific case must come from the guarded policy's measured benefit over exact local refresh and the practical external methods, with unfavorable cases and the cost of all screens retained. The Gaussian estimate, power refinement, summable union bound and Schwarz comparison remain established ingredients; the contribution is their specified integration with transport and changing-space factor maintenance.

Follow-up source snapshot SHA-256 values:

```text
f57e72b944aa1ccc2e605176a9f8e6c416b6958990e94dc39450a8b9f58afa19  docs/main_theory.tex
9d1322215b7dc360d67ad7c595440468f552c7981b947f559de4e087c0d35b45  docs/model_algorithm.tex
bf405f4a09f31a9f3b816304e59ab2e1d254915ee3402bef5c100837d9880f45  docs/introduction.tex
9d8f42e7efa995769cec544c4afa3346aa887e112e36d4b5d37745e26c29a96c  src/solver.py
0d436c9d4233fd00cd0fe68ee4fc99379725a2bcfb628d4e2d9c52bd8bd10ca8  src/preconditioners.py
276712aec9fd9d71613f5e1a872f7146a3bc471f04a367a7a337ef379756bdcf  experiments.py
```
