# Novelty and theory audit

Audit date: 16 October 2026. Audience: computational mechanics and numerical linear algebra. This is an assessment of the proposed contribution, not evidence of publication priority. Primary sources were checked for the claims below; access limitations are stated where relevant.

## Assessment

Selective reuse of local Schwarz factorizations is established practice. Perturbation arguments that transfer a fresh preconditioner's spectral bounds to approximate local solvers are also established. Cauchy–Schwarz, Loewner-order inversion, congruence, and nonzero-spectrum compression are classical linear algebra. Presenting any one of them as a new theorem of general preconditioning would overstate originality.

The defensible contribution is a specific implementable contract for evolving trimmed discretizations: retain local factors only while the full cumulative matrix change remains small in their own anchor energy; evaluate that contract by an inverse-diagonal majorant and, where economical, an exact coordinate-support compression; preserve the correspondence through stable basis IDs as the active spline space changes. The resulting guarantee is relative to the current fresh version of the same additive Schwarz method. Its scientific value depends on whether the full system pays less for this policy than for exact support-local refresh, fresh assembly of the preconditioner, and established static competitors.

This is a method/application contribution supported by exact algebraic guarantees. The inspected sources do not establish that this precise combination already appears elsewhere, but the search does not justify a first-of-kind claim.

## Closest primary sources

**Berenguer and Tromeur-Dervout, partial RAS updates.** Their [DD22 proceedings manuscript](https://www.ddm.org/DD22/proceedings/36_berenguer_contrib.pdf), *Partially Updated Restricted Additive Schwarz Preconditioner*, explicitly retains some subdomain LU factors while replacing others in sequences of nonlinear solves. Section 1 discusses lagged RAS, iteration-count and periodic global refreshes; Section 2 studies asynchronous local updates and cyclic scheduling. The related journal article is *Asynchronous partial update of the Restricted Additive Schwarz preconditioner to solve nonlinear CFD problems*, Computers & Fluids 110 (2015), 211–218, [DOI:10.1016/j.compfluid.2014.09.049](https://doi.org/10.1016/j.compfluid.2014.09.049). The proceedings full text was inspected; the journal publisher endpoint did not provide a readable full text. The present distinction is an SPD energy acceptance criterion with a quantitative relative-to-fresh bound and changing active-ID handling, rather than partial updates themselves.

**Svolos, Berger-Vergiat and Waisman (2020).** *Updating strategy of a domain decomposition preconditioner for parallel solution of dynamic fracture problems*, Journal of Computational Physics 422, 109746, [DOI:10.1016/j.jcp.2020.109746](https://doi.org/10.1016/j.jcp.2020.109746). The [publisher abstract](https://www.sciencedirect.com/science/article/pii/S0021999120305209) describes a localized region rebuilt at each nonlinear iteration and a complementary region whose LU solve is selectively updated using performance-based optimization. This is a close computational-mechanics precedent for maintaining Schwarz factors under localized physical changes. The proposed trimmed-domain method differs in its algebraic energy contract and active-space bookkeeping. This comparison is based on the publisher abstract; it should not be expanded into claims about details of their algorithm without reading the full article.

**Kolombage, Målqvist and Verfürth (2026).** *Subspace decomposition with defect diffusion coefficient*, [arXiv:2603.09924](https://arxiv.org/abs/2603.09924), with [full text](https://arxiv.org/html/2603.09924v2). The authors precompute a dictionary of local reference solves and combine them online for diffusion operators with localized random defects. Their Theorem 4.5 bounds the perturbed spectrum by [C1−eta,C2+eta], and Proposition 4.8 controls the global perturbation through local indicators and overlap. This is the closest inspected analytical precedent. Our bounds compare individual retained inverses to fresh local inverses and therefore sum directly to a multiplicative Loewner comparison, without an extra overlap constant. The current proposal stores a temporal anchor per block, rather than combining a precomputed defect dictionary; it also treats changes in active coordinate lists. Generic spectral inheritance and local error monitoring are shared ideas and should be acknowledged explicitly.

**Bergamaschi (2020), and Carr, de Sturler and Gugercin (2021).** Bergamaschi's *A survey of low-rank updates of preconditioners for sequences of symmetric linear systems*, Algorithms 13(4), 100, [DOI:10.3390/a13040100](https://doi.org/10.3390/a13040100), is verified through the [author institution record](https://www.research.unipd.it/handle/11577/3347248?mode=complete). Carr et al.'s *Preconditioning Parametrized Linear Systems*, [DOI:10.1137/20M1331123](https://doi.org/10.1137/20M1331123), is described in the [SIAM issue record](https://epubs.siam.org/toc/sjoce3/43/3). These works establish the broader setting of updated/recycled preconditioners; Carr et al. construct maps from a new matrix to a previous matrix. Our support compression evaluates an acceptance test; it does not update an inverse by a low-rank correction. The survey should frame the field, while direct comparisons should emphasize the closest local Schwarz methods.

**de Prenter, Verhoosel and van Brummelen (2019).** *Preconditioning immersed isogeometric finite element methods with application to flow problems*, CMAME 348, 604–631, [DOI:10.1016/j.cma.2019.01.030](https://doi.org/10.1016/j.cma.2019.01.030), verified at the [author institution record](https://research.tue.nl/en/publications/preconditioning-immersed-isogeometric-finite-element-methods-with/). Their additive Schwarz construction addresses ill-conditioning in immersed discretizations. It is a base-method precedent and a numerical comparator, not evidence for the new reuse policy. Its existence rules out presenting local inverse blocks for cut splines as the present invention.

**Voet, Möller, Antolin and Vuik (2026).** *Deflation-based preconditioning for immersed finite element methods and immersogeometric analysis*, [arXiv:2604.12848](https://arxiv.org/abs/2604.12848), [inspected full text](https://arxiv.org/html/2604.12848v1). They identify failures in some established Schwarz block-selection strategies and propose cut-focused deflation. This prevents treating a familiar overlap construction as automatically cut robust. Their method must be represented as a distinct static solver comparator. Our result neither supersedes their failure analysis nor proves cut-independent conditioning; it controls reuse relative to whichever fresh base method is actually implemented.

## Additional close software artifact

The author-hosted [Deepsleepinger/JSR repository](https://github.com/Deepsleepinger/JSR), inspected on the audit date, describes *Stateful Selective Maintenance of Two-Level Schwarz Preconditioners for Evolving Sparse Linear Systems*. Its README uses an accumulated normalized diagonal-change proxy, threshold refreshes, and current coarse-operator updates. The visible repository does not establish peer review, a stable archival publication, or priority of all its contents. Treat it as related software, not as a verified journal paper; record a commit if citing it in the manuscript.

Its diagonal proxy differs mathematically from the full-energy contract here. For H=I and F=[[1,rho],[rho,1]], the diagonal variation is zero while the full relative-energy change is rho. This counterexample is our direct calculation and shows why a guarantee cannot follow from diagonal variation alone. The repository also makes clear that cumulative state and threshold resets are not, by themselves, sufficiently distinctive novelty claims.

## Recommended manuscript positioning

Suggested contribution language:

> We develop an anchor-controlled reuse policy for local additive Schwarz solvers in sequences of trimmed spline systems. An inverse-diagonal majorant and a support-compressed generalized energy test determine whether a retained factor remains spectrally equivalent to the current local inverse. These blockwise contracts imply a sharp, explicit bound on deterioration relative to the fresh current preconditioner. Stable basis identifiers extend the policy across active-space changes. Numerical experiments assess whether the work saved by retaining factors exceeds the cost of the acceptance tests.

This paragraph states an actual algorithmic contribution and separates it from the classical tools used to prove it. Add observed performance only after the recorded experiments support it.

## Strengthening the paper without changing its claim

1. Compare with exact support-local refresh, not only rebuilding everything. This reveals the value of tolerating nonzero matrix drift beyond merely recognizing unchanged blocks.
2. Report the first-stage acceptance rate, exact-test rescue rate, support fractions k/m, number of refreshed blocks, and screening/setup/solve costs. These connect the claimed mechanism to measured savings.
3. Include the diagonal-only and per-step counterexamples in the theory or supplement; they explain why the chosen state is needed. Do not describe these elementary examples as new physical failure modes.
4. Use the same current blocks, weights, and coarse term in fresh versus retained comparisons. Any block-design improvement otherwise confounds the reuse result.
5. Include at least one case where the base preconditioner is difficult and one where screening fails to pay for itself. Preserve timeouts and numerical failures. This defines the method's useful operating range.
6. Test active-set crossings with original global basis IDs and independently audit cumulative changed-support closure. This is the application-specific feature absent from the strongest inspected analytical precedent.
7. State whether the factor's stored equilibration remains fixed, or is transformed consistently. Changing current diagonal scales without transforming retained factors invalidates the comparison even if basis IDs match.
8. Use 'energy-controlled' or 'numerically evaluated bound' for the floating-point algorithm. Reserve 'certified' for exact-arithmetic statements or an implemented outward-rounded computation.

## Claim audit

| Proposed claim | Assessment | Evidence needed before submission |
|---|---|---|
| Partial Schwarz factor reuse is new | Reject | Established DD22/2015 and JCP 2020 precedents |
| Local perturbation bounds imply global spectral quality | Classical principle | Cite 2026 defect-subspace work and standard Schwarz foundations |
| The particular two-stage anchor test is useful | Plausible method contribution | Full implementation, rescue rates, cost breakdown, adversarial audits |
| Active-space-safe reuse on evolving trimmed splines | Concrete application contribution | Stable-ID crossing tests, membership rebuild counts, support audits |
| Relative-to-fresh inflation is at most (1+tau)/(1−tau) | Proved, sharp in exact arithmetic | Theorem and 2x2 equality example in theory.tex |
| No additional overlap factor occurs in this comparison | Proved | Sum of local Loewner inequalities; do not remove overlap dependence from fresh bounds |
| The method is cut robust | Unsupported as a general theorem | Independent base-method result with applicable hypotheses |
| The method is faster | Unresolved until experiments | End-to-end repeated measurements against exact local refresh and static alternatives |
| Standard floating-point tests are rigorous certificates | Reject | Outward error bounds or intervals would be needed |
| This is the first such reuse method | Unsupported | Do not claim priority from this bounded search |

The theory can support a sound manuscript, but it cannot alone establish a major algorithmic advance. CMAME-level strength rests on the evolving-trimmed-domain formulation, difficult geometry and mechanics examples, practical savings over a strong reuse baseline, and a reproducible explanation of when the policy is worthwhile.
