# Preconditioner implementation and numerical audit

The implementation is `src/preconditioners.py`. Only principal block matrices
and coordinate coarse matrices become dense; the global sparse matrix is never
converted to a dense array. The assembly and block-construction routines supply
the current sparse matrix, overlapping current-row blocks, and stable background
DOF IDs. An ID identifies a scalar unknown, including its component for vector
problems. Block order is part of the cache identity.

## Public interface

```python
M, cache, stats = build_schwarz(
    A_csr, blocks, global_ids, mode="energy", cache=cache,
    tau=0.2, step=step, period=5, diagnostics=False,
    changed_global_ids=None, spectral_cap=32,
    probability_state=None,
)
```

`M` is a symmetric `scipy.sparse.linalg.LinearOperator` applying the additive
inverse sum. The caller passes it as the inverse preconditioner to PCG. The
returned cache is a dictionary keyed by `tuple(global_ids[block])`. Each
`LocalFactor` retains its raw anchor matrix, diagonal scales, Cholesky factor,
and lazily prepared inverse information. Every call returns a dictionary
containing only current blocks. A surviving factor can be shared with an older
cache dictionary; preparation may populate its optional diagnostic caches.
An already returned operator retains its original block/factor actions.
An energy-accepted cache entry also retains the bound accepted at its previous
query. Updating that bound creates a new metadata entry sharing the original
anchor/factor arrays; it does not overwrite the older cache's bound.

Policies are:

- `fresh`: factor every current block; never prepare inverse diagonals.
- `exact_local`: retain only blocks exactly equal to their anchors under
  `numpy.array_equal`.
- `energy`: retain exact blocks immediately; screen each changed block against
  its retained anchor and refresh when neither permitted test accepts it.
- `prob_energy`: screen changed blocks using fresh Gaussian power actions and
  an explicit sequential failure budget; refresh directly if the test does
  not accept. This is a high-probability policy in exact arithmetic.
- `stale`: retain every surviving block without a drift guarantee.
- `periodic`: refresh changed blocks when `step % period == 0`; at other steps
  retain surviving blocks. Exactly equal blocks can always be retained.

New ordered memberships always create new anchors. Missing previous memberships
are retired. Uncovered current rows receive singleton diagonal blocks; their
number is reported by `uncovered_rows` and `diagonal_fallback`. A nonpositive
diagonal or a failed Cholesky factorization is an explicit exception. Duplicate
rows within a block and duplicate stable IDs are errors. Repeated ordered
blocks are permitted: each unique membership is factored once and its inverse
is multiplied by the number of occurrences. This preserves the per-element
block multiplicity required by the CbAS baseline, including identical active
row sets associated with distinct cut elements.

All singleton numerical extractions and scales are batched. Singleton cache
entries retain individual identities and statistics but do not invoke separate
Cholesky factorizations. Their inverse actions are combined into one vector
of diagonal weights. Adding these weights to larger-block actions preserves
the exact additive sum where singleton and larger blocks overlap.

`changed_global_ids` is an optional complete support closure of numerical
changes since the preceding system in the caller's specified matrix coordinates.
It is a caller contract, rather than a heuristic inferred from block geometry.
`None` disables the shortcut; an empty list asserts no numerical changes.
Surviving blocks disjoint from this closure skip numerical extraction and
increment `reused_unchanged`. Their previous anchor certificates remain valid
even when the preceding query accepted nonzero anchor drift. The shortcut
checks the stored bound against the current `tau`; an uncertified stale anchor
or a stricter tolerance requiring a new check cannot pass it. Exact-refresh
policies require actual stored anchor equality, and a due periodic refresh
cannot skip an uncertified stale block. Membership changes still extract and
factor normally. Stable background IDs make this rule independent of current
row permutations. The main solver stores diagonally transported, unit-diagonal
local anchors from C_t = D_t A_t D_t. Its complete physical-matrix change
closure is sufficient for this shortcut: a block disjoint from that closure
has unchanged entries and unchanged diagonal scaling. The raw-energy ablation
instead stores physical-matrix anchors. A caller must not change coordinate
scaling on an allegedly untouched block without including the affected IDs.

## Factor arithmetic

For a raw anchor H, let S = diag(sqrt(diag(H))). The implementation factors
C = S^-1 H S^-1 and applies H^-1 b as S^-1 C^-1 S^-1 b. Divisions are performed
sequentially to avoid forming products of very large or small diagonal scales.
This scaling does not add a diagonal shift or discard a basis function.

The global matrix is checked for finite entries and symmetry. The equilibrated
local symmetry discrepancy must be at most 64 machine eps times its infinity
norm (with unit lower reference). Roundoff-sized asymmetry is averaged before
Cholesky and measured in `max_symmetry_error`. Larger discrepancies are rejected.
With `diagnostics=True`, `max_factor_residual` is the relative infinity-norm
reconstruction residual of the equilibrated Cholesky factor. Dense diagnostic
matrix products are omitted by default and this statistic is then `None`.
No eigenvalue is clipped and no system matrix is stabilized.

For energy policies only, the inverse diagonal is obtained from a triangular
inverse of the equilibrated factor **lazily at the first nonzero-drift test**.
New, refreshed, and exactly unchanged anchors do not pay this cost. The scalar
case uses its reciprocal directly. The same triangular inverse also provides
`inverse_factor_norm_bound` from its absolute column and row sums, without any
extra linear solve. This preparation is included in `energy_preparation_time`.
`max_inverse_residual` is the backward
residual of this triangular inverse, normalized by
1 + norm(L, infinity) norm(L^-1, infinity). Unrepresentable inverse-diagonal
data and nonfinite screening arithmetic raise explicit floating-point errors.
It is computed only with `diagnostics=True` and only when inverse information
has actually been prepared; otherwise it is `None`. Audit diagnostics for
already cached factors can be requested on a later call. The minimum and
maximum equilibration scales are also recorded. These
diagnostics are numerical observations, not interval guarantees.

## Screening rules

Write Delta = A_local - H, always comparing to the retained anchor. Let
q_j = sqrt((C^-1)_jj). The coordinate bound is evaluated as

```text
q^T abs(S^-1 Delta S^-1) q
    = d^T abs(Delta) d,  d_j = sqrt((H^-1)_jj).
```

The equilibrated evaluation is algebraically identical and remains stable
under severe diagonal changes of basis. A complementary cheap bound uses
the already computed inverse triangular factor T = L^-1, where C = L L^T:

```text
nu = norm(T, 1) norm(T, infinity),
eta_operator = nu norm(E, infinity),  E = S^-1 Delta S^-1.
```

This is the classical induced-norm bound: norm(C^-1, 2) = norm(T, 2)^2
<= norm(T, 1) norm(T, infinity), while symmetric E satisfies
norm(E, 2) <= norm(E, infinity). Submultiplicativity therefore bounds the
relative energy norm by eta_operator. Both quantities need only absolute
row/column sums after the existing triangular inverse is available. No new
solve or matrix product is needed for this complementary bound. Its value
and the coordinate bound remain invariant under diagonal basis rescaling in
exact arithmetic, including diagonal sign changes.

The minimum of these two numerical bounds is compared with `tau`. If it is
at most `tau`, the anchor is retained. Otherwise, K is the union of nonzero rows and columns of
the actual raw Delta. If its size exceeds `spectral_cap` (default 32), the block is refreshed; a failed
first bound is never treated as proof that the true norm exceeds the threshold.

For support size at most `spectral_cap`, the implementation computes G = (C^-1)_KK through
selected inverse columns, factors G = Lc Lc^T, and computes all eigenvalues of

```text
Lc^T (S^-1 Delta S^-1)_KK Lc.
```

This is precisely Lh^T Delta_KK Lh for
Lh = S_K^-1 Lc and Lh Lh^T = (H^-1)_KK. Its spectral radius equals the norm
of the full symmetric relative perturbation. G and Lc are cached by ordered
support. Small roundoff asymmetry in inverse data and reduced matrices is
averaged before the symmetric eigensolve; reduced-matrix asymmetry is included
in `max_symmetry_error`. Eigenvalues retain both signs, so a large contraction
cannot pass a one-sided expansion test. Accepted blocks keep the original
anchor; repeated small changes cannot accumulate unchecked drift.

These comparisons implement exact-arithmetic bounds using ordinary floating
point. They do not outward round a certificate. Near-threshold decisions may
reflect rounding. Independent generalized eigensolves in the unit tests audit
the support-compressed calculation.

## Sequential high-probability power screening

The `prob_energy` policy avoids deterministic inverse preparation. Construct
one explicit state for the whole adaptive run and pass the same object to
every call:

```python
from cmame_trimmed.src.preconditioners import EnergyBudget, build_schwarz

budget = EnergyBudget(seed=20261016, delta_total=1e-8, probes=12, power=2,
                      min_dimension=0)
M, cache, stats = build_schwarz(
    C_current, blocks, global_ids, mode="prob_energy", cache=cache,
    probability_state=budget, tau=0.2,
)
```

The state owns its NumPy generator, cumulative `count`, and
`spent_failure_budget`. Configuration is immutable. There is no implicit RNG
creation/reset within the policy. A new or refreshed anchor is exact and
spends no randomized check. Neither does an exactly equal anchor comparison
or a valid unchanged-support skip. Each changed surviving unique block draws
fresh independent Gaussian columns before any inverse preparation. Duplicate
block occurrences share the same test and retain their original multiplicity.

`min_dimension` is an optional nonnegative integer cost-policy threshold with
backward-compatible default zero. After exact/unchanged reuse is attempted,
a changed block of dimension m <= min_dimension refreshes directly, without
Gaussian probes or inverse preparation. `skipped_small_blocks` counts these
unique blocks. The leading-operation comparison m^3/3 for Cholesky versus
4 q s m^2 for the power screen motivates a threshold 12 q s (288 at q=2,
s=12). This is a cost heuristic rather than a measured performance guarantee.
It leaves the probability theorem unchanged: the bypass creates an exact
anchor with zero drift and spends no randomized failure budget.

Let K = L^-1 E L^-T for the equilibrated anchor C = L L^T and symmetric
change E. At sequential check j >= 1 allocate delta_j =
6 delta_total/(pi^2 j^2). With s probes and power q, compute

```text
Omega[:, k] independently ~ N(0, I),
alpha_j = sqrt(2/pi) delta_j^(-1/s),
beta_j = (alpha_j max_k norm(K^q Omega[:, k], 2))^(1/q).
```

One K action uses two triangular solves around the multiplication by E:
Y = L^-T Omega and Z = L^-1(E Y). Columns are normalized after every action
and their magnitudes accumulated logarithmically. This is algebraically the
same power bound and avoids forming tiny/large powers explicitly. Nonfinite
action arithmetic raises an explicit error. Default q = 2 and s = 12 require
48 triangular right-hand-side solves, the same count as q = 1 and s = 24.
`power=1` is supported as an ablation.

The exact-arithmetic small-ball argument is conditional on previous history:
for a fixed current symmetric K and a top-magnitude eigenvector v,
norm(K^q omega, 2) >= norm(K, 2)^q abs(v^T omega). Independent standard
Gaussian projections satisfy P(abs(v^T omega) < t) <= sqrt(2/pi) t.
Consequently P(beta_j < norm(K, 2) | history) <= delta_j. The summable
allocation gives a total failure probability at most delta_total across all
checks sharing the state, including history-dependent matrix/anchor choices
made before the fresh current probes. This is a **high-probability
exact-arithmetic guarantee**, rather than a deterministic certificate.
Ordinary floating-point arithmetic and pseudorandom Gaussian generation are
used in the implementation; no outward rounding is claimed.

If beta_j <= tau, retain the anchor and its accepted bound. Otherwise refresh
immediately: there is no deterministic inverse-diagonal preparation or
support-compressed fallback. This keeps a changed-block screening action at
O(m^2 s q) work. A retained probabilistic certificate records the originating
state token. Unchanged-support reuse is valid only with that same state and
an adequate current threshold; another state or the deterministic energy
policy must screen again. Exact anchors remain universally reusable. No
randomness is used when the resulting operator is applied during CG.

`randomized_checks`, `randomized_time`, and `max_randomized_bound` describe
new power tests in the current call. All sampling and power-action work is
included in `randomized_time` and total setup. `cumulative_checks` and
`spent_failure_budget` report the complete supplied state. Acceptance also
increments `reused_energy`; the mode identifies whether that acceptance was
deterministic or probabilistic. `max_accepted_bound` includes a certificate
carried through an unchanged-support skip. Dense tests independently reproduce
both power formulas, inspect the sequential budget sum, replay fixed seeds,
audit positive/signed basis scaling and temporal diagonal transport, check
tiny-power underflow avoidance, enforce state provenance, and verify that CG
application does not advance the generator.

## Baselines

`jacobi(A)` applies the inverse diagonal and rejects nonpositive entries.
`coordinate_deflation(A, weak_ids)` accepts **current row indices**, with stable
ID mapping performed by the caller. It implements the balanced SPD operator

```text
Q + (I - Q A) D^-1 (I - A Q),
Q = Z (Z^T A Z)^-1 Z^T,
```

where Z contains the selected coordinate columns and D is the diagonal of A.
The coordinate coarse matrix uses the same equilibrated factor arithmetic.
An empty selection returns Jacobi. This is a balanced implementation related
to the weak-cut coordinate-deflation approach discussed in the research design;
it is not presented as literal author code from Voet et al. (2026).

## Statistics and verification

Per-call counters are `new`, `refreshed`, `reused_exact`, `reused_energy`,
`reused_stale`, `reused_unchanged`, `first_checks`, `spectral_checks`, `retired`,
`active_blocks`, `singleton_blocks`, `unique_singleton_blocks`, `unique_blocks`,
and `blocks`. `blocks` and `singleton_blocks` count input occurrences (including
added fallback blocks), whereas `unique_blocks`, `active_blocks`, and all
factor/reuse counters count unique cache keys. Repeated inverse actions carry
their original multiplicity. `peak_rank` is the largest changed-support dimension encountered
after a failed first test, including dimensions above the compressed-test cap;
it is an upper bound on perturbation rank. `peak_blocks` is the maximum of
incoming and outgoing cache sizes, not the transient count of simultaneously
allocated factor objects. `first_coordinate_bound` and `first_operator_bound`
record the largest observed values of the two cheap bounds in the call.
`max_first_bound` records the largest observed minimum; the minimum of the
two per-call maxima need not equal this quantity across multiple blocks.
`operator_only_accepts` counts blocks whose coordinate bound exceeds `tau`
but whose operator bound permits immediate reuse. Bounds are also recorded in
`max_spectral_norm`, and `max_accepted_bound`. The last includes certificates
reused through the unchanged-support shortcut.

`setup_time` measures the entire build call. Its component timers are
`extraction_time`, `factorization_time`, `energy_preparation_time`,
`first_check_time`, and `spectral_check_time`. Untimed validation, comparisons,
dictionary management, and operator construction remain part of total setup.
With `changed_global_ids=None`, every policy extracts all current local
matrices. Otherwise only blocks requiring extraction are read; the caller
supplies the complete previous-step closure. Scalar diagonal extraction,
scales, and action reciprocals are batched and included in extraction or
factorization timing. Lazy inverse-diagonal preparation, including audits,
remains included in `energy_preparation_time`. The fresh baseline pays no
inverse preparation cost. These timers are instrumentation; benchmark repetitions and
serialized timing runs are the caller's responsibility.

The dense test suite covers the additive inverse action and SPD property,
Loewner comparison and condition-number inflation, severe signed diagonal
basis scaling, independent generalized eigenvalues, membership retirement,
anchor-based accumulated drift, large contractions, conservative large-support
refreshes with a configurable cap, stale/periodic ablations, missing-row
fallback, balanced deflation, and explicit numerical failures. Dense
generalized-eigenvalue oracles audit both cheap bounds, their inverse-factor
norm estimate, severe signed basis scaling, and broad-change acceptance by
the operator bound. Further tests
check singleton overlap without individual solves, lazy inverse preparation,
optional diagnostics, extraction-free unchanged reuse after accepted anchor
drift, stricter tolerances, stale-policy transitions, and row permutations.
Execute from the repository root with:

```sh
.venv/bin/python -W error -m pytest cmame_trimmed/tests
```
