# Final implementation and protocol consistency audit

Static, read-only review of the current `src` implementation,
`experiments.py`, `run_all.py`, and `run_ablations.py` against
`docs/model_algorithm.tex`, `docs/main_theory.tex`, and
`docs/experiment_protocol.tex`. No tests, benchmarks, solver executions, or
changes to executed source were made during this review.

## Material findings

1. **Ablation-group exception retention is incomplete.**
   `run_ablations.py:12-29` has no exception handler or failure ledger in
   `run_group`. A method, assembly, or reference exception terminates that
   group and the driver; its last saved JSON covers only the preceding fully
   completed query. Rows completed earlier in the interrupted query have not
   yet been saved. This differs from `sequence` and `update_sensitivity`,
   which record caught method exceptions and continue. The protocol's
   retention statement is therefore implemented for returned unsuccessful
   solves, but is not implemented for exceptions in these screening/block-size
   ablation groups. An aborted group must be identified as incomplete.

2. **Exception ledgers do not contain elapsed failure costs.**
   The handlers in `experiments.py:66-70` and
   `run_ablations.py:54-56` save identifiers and exception text, but not the
   setup/solve/total time spent before the exception. Returned rows with
   `success=False` do retain their measured costs. Thus exception records
   preserve the existence of a failure, not a complete timed observation;
   sequence comparisons involving an exception cannot obtain its full
   failed-attempt cost from these ledgers. Failed/incomplete runs must not be
   represented as completed sequence sums with the failed work omitted.

## Verified implementation facts

- **Size rule and probability state match the main protocol.**
  `sequence` constructs separate `energy` and `energy_raw` budgets once per
  repetition, with `min_dimension=288`, default power 2, 12 probes, and risk
  `1e-8`. In `preconditioners.py:344-384`, unchanged-support and exact-anchor
  reuse precede the small-block bypass; changed blocks with at most 288 scalar
  or vector DOFs refresh without probes or inverse preparation. Larger
  candidates draw fresh probes only after their current matrix is extracted.
  The state counter advances before the sampled action is evaluated and is
  not reset after an exception. Accepted anchors are not advanced. Rebuilt
  memberships are exact and spend no check.

- **The API default is intentionally different from the campaign preset.**
  `EnergyBudget.min_dimension` defaults to zero; 288 is supplied explicitly by
  the timed campaign. The independent dense spectral audit also uses zero
  and records that fact. Likewise, the public sequence/CLI default is 16
  queries, but `run_all.py` explicitly runs the seven primary families with
  12 queries and three repetitions. Reproduction must use that driver or
  supply the documented 12-query argument. The deterministic comparator uses
  the solver wrapper's support-test cap of 128, rather than the lower-level
  builder's default cap of 32.

- **PCG solves the current operator with a fixed inverse action.**
  `solver.py:23-45` builds the current scaled matrix `C = D A D`, creates the
  preconditioner once, and passes these fixed operators to SciPy CG. The
  transported policies build their anchors from current `C`; `energy_raw`
  builds physical anchors from `A` and applies the correct scaled congruence
  `D^-1 B_raw D^-1`. Sampling occurs only during setup. Applied factors retain
  their anchor scales/Cholesky arrays; metadata and diagnostic caches do not
  alter the factor action during CG. Independent physical/scaled residuals
  and reference-energy checks use the current `A` after the solve.

- **Cache recovery and warm starts are consistent where recovery exists.**
  Main-sequence and update-sensitivity exception handlers remove the affected
  method's factor cache and preceding solution while leaving its probability
  budget intact. This prevents a cache older than one query from misusing
  the next one-step changed-support closure. A returned unsuccessful solve
  keeps its valid current setup cache but does not replace the method's most
  recent successful warm start. Identifier transfer is method-specific and
  initializes newly active coordinates to zero. Assembly's change list
  includes the complete basis/component IDs of every changed element,
  including cells that become empty. Untouched blocks therefore also have
  untouched diagonal scales in the normalized system. New memberships are
  rebuilt and absent memberships retired.

- **Certificate transitions preserve the stated policy scopes.**
  A probabilistic retained decision records its originating budget token.
  Unchanged reuse requires that token and a bound satisfying the current
  tolerance. A different budget or the deterministic energy policy screens
  again; exact anchors can be reused universally. The stored drift is always
  relative to the retained anchor. Duplicate block occurrences share a
  factor/test and retain their multiplicity in the applied inverse.

- **Comparator semantics match their qualified descriptions.**
  CbAS takes a block per numerically classified cut cell, expands vector
  components, preserves repeated memberships, and completes uncovered rows
  with singleton terms (`assembly.py:28-54`). Its near-full-cell classification
  uses the explicit fraction threshold `fraction < 1 - 1e-10`. Matched overlap
  policies share the same current unique overlap/enrichment blocks. Coordinate
  deflation uses the balanced formula in the protocol and selects current
  weak rows with no fully interior support cell; it is not literal author
  software. The transported stale policy retains surviving changed anchors;
  periodic refresh is due at zero-based steps 0, 5, 10, and so forth, while
  exact anchors need no redundant factorization even on a due step.

- **The longer sensitivity paths keep the two holes nonoverlapping.**
  The driver uses 24 queries, three repetitions, and multipliers
  `{0.25, 1, 5, 20}`. At the largest multiplier and final query, the moving
  center is `(0.4052, 0.48)` with radius `0.16`; its rightmost point is
  `0.5652`. The fixed hole centered at `(0.74, 0.6)` with radius `0.1` starts
  at x = `0.64`. Their x intervals remain disjoint throughout every path,
  avoiding the unsupported overlapping-circle integration case. Both holes
  stay inside the unit square. Each multiplier/repetition creates a fresh
  assembler, independent per-method caches/warm starts, and one persistent
  energy budget; method order rotates at every query. Saved configuration,
  multiplier, repetition, and row step identify the geometry and run state.

- **Risk counts and extra experiments have separate scopes.**
  The stated `42 * 1e-8` union bound counts two probabilistic policies across
  seven main cases and three repetitions, which agrees with the primary
  driver. It does not include the dense spectral audit, screening ablations,
  block-size ablations, or 12 sensitivity paths. Screening/block-size groups
  use eight queries and seed base `20262016`; sensitivity paths use 24 queries
  and seed base `20263016`. Screening configurations also include risks
  `1e-4` and `1e-12`. Their settings and probability scopes need their own
  supplementary protocol if those results are reported; the main 12-query
  description and 42-sequence bound alone do not describe them.

- **Timer scopes support the two reported totals.**
  The outer `solve.setup` timer begins before current scaling and covers block
  construction, local extraction, screening, and required factors. The solve
  timer covers the scaled linear solve; the raw-anchor wrapper is created
  within that timer. Physical solution recovery and independent validation
  occur afterward. Driver identifier transfer, independent direct-reference
  computation, and output are outside both timers. `linear` is setup plus
  solve; `total` adds the shared current assembly cost once per method.
  Preconditioner component timers are nested diagnostics, not exhaustive
  substitutes for outer setup: they omit outer normalization, block creation,
  validation, and some bookkeeping. Their residual belongs in “other setup.”
  Dense residual diagnostic products remain disabled in timed builds.

No source-level inconsistency was found between the main size-guarded
randomized algorithm and the stated exact-arithmetic theorem assumptions.
This static audit does not assert that ongoing runs have completed, establish
a measured speedup, or turn floating-point screens into interval certificates.
