# Diagonal transport of cached Schwarz inverses

This note extends `theory.md` without changing its raw-anchor statements. The stored anchor is now a normalized local matrix. Its expensive factor is retained; inexpensive current diagonal amplitudes are always updated. The distinction matters near vanishing cut supports, where a local matrix may change substantially in amplitude while its normalized correlations change little.

## Definition and local guarantee

At a current query, let F_t be an SPD local matrix and define S_t=diag(sqrt((F_t)_jj)) and C_t=S_t^(-1) F_t S_t^(-1). Then diag(C_t)=1. At its last refresh a, store the normalized anchor C_a and a factor of C_a. The transported local action is

T_t = S_t^(-1) C_a^(-1) S_t^(-1).

Equivalently, T_t=H_t^(-1) for the query-dependent physical anchor

H_t=S_t C_a S_t=S_t S_a^(-1) F_a S_a^(-1) S_t.

This differs from applying the old physical inverse F_a^(-1). It still acts on the original current unknowns and changes neither the discretization nor the solution of F_t x=b.

Define eta_t=||C_a^(-1/2)(C_t−C_a)C_a^(-1/2)||_2. The exact generalized Rayleigh quotient shows

eta_t=||H_t^(-1/2)(F_t−H_t)H_t^(-1/2)||_2.

Thus eta_t<=tau<1 gives

(1−tau)F_t^(-1) <= T_t <= (1+tau)F_t^(-1).

The proof is precisely the raw-anchor inverse comparison after the common current congruence by S_t^(-1). The anchor in the acceptance test remains C_a until factor refresh; replacing it by C_(t−1) would again allow cumulative normalized drift.

The existing two tests apply with H=C_a and Delta=C_t−C_a. In particular d_j=sqrt((C_a^(-1))_jj), the first majorant is d^T|Delta|d, and the exact compressed matrix is L^T Delta_KK L for LL^T=(C_a^(-1))_KK. K must contain the complete support of the normalized anchor difference. Raw-matrix support need not suffice: a change in one raw diagonal changes its normalized off-diagonal couplings, and the resulting nonzero row/column union can span the whole block.

## Global fresh comparison

For current injections P_i and an identical PSD coarse term C_0, form

B_f=C_0+sum_i P_i F_(i,t)^(-1) P_i^T,
B_tr=C_0+sum_i P_i T_(i,t) P_i^T.

Assume current coverage C_0+sum_i P_i P_i^T is SPD. If every reused normalized anchor meets eta_(i,t)<=tau<1 and every new/changed-membership block is refreshed, then

(1−tau)B_f <= B_tr <= (1+tau)B_f,
kappa_A(B_tr) <= ((1+tau)/(1−tau)) kappa_A(B_f).

A rebuilt normalized block gives T=F^(-1) exactly. Summing the local inequalities proves the result; no new assumption about cut robustness is introduced. The bound is sharp even under unit-diagonal normalization: take one full block, C_a=I_2 and F_t=[[1,tau],[tau,1]], so S_t=I_2 and the transported condition number is (1+tau)/(1−tau), while the fresh inverse has condition number one.

Current S_t, block membership and injections are held fixed during the PCG solve. They may change between queries. Stable-ID membership rules remain unchanged.

## Invariance to temporal rescaling

Let Q_t be any positive diagonal matrix, allowed to change independently at every query, and replace F_t by F'_t=Q_t F_t Q_t. Its current scale is S'_t=Q_t S_t, hence C'_t=C_t. The normalized anchor, both acceptance indicators, and all accept/refresh decisions are therefore unchanged in exact arithmetic. The applied action transforms as T'_t=Q_t^(-1) T_t Q_t^(-1), as required for the inverse in the rescaled coordinates. This invariance is stronger than the common-basis scaling property of the raw-anchor indicator: here the anchor and current matrices may undergo different positive diagonal scalings.

For arbitrary signed diagonal Q_t, write Q_t=J_t |Q_t|. Then C'_t=J_t C_t J_t. Independent time-varying signs are not invisible unless they are explicitly aligned: a transformed anchor stored at a must be conjugated by J_t J_a before comparison and use. With that alignment, the test spectrum and entrywise majorant are invariant, and the action is covariant. With fixed signs over time, alignment is automatic. B-spline amplitude scalings are positive, so the primary proposition uses positive Q_t.

A global diagonal rescaling transforms all local coordinate restrictions consistently. For unweighted coordinate injections, or diagonal symmetric weights that commute with the scaling, the entire preconditioner has the analogous covariance. A coarse term must be transformed consistently as well. This covariance claim is separate from the fresh comparison, which permits any common current injections.

## Exact homothetic model

Let Omega_0 be a bounded open set of positive measure in R^d, let Omega_epsilon=epsilon Omega_0, and fix homogeneous polynomials p_i of degrees r_i. Consider a constant-coefficient Gram form of a common derivative order s, either s=0 for a mass Gram or s=1 for a gradient Gram. Write D^s p_i for the value or the vector of first derivatives, and let W be a constant SPD matrix acting on those components. Assume the functions D^s p_i are linearly independent in L2(Omega_0), so the Gram matrix G_1 is SPD. For s=1 this excludes a nonzero combination that is constant; ordinary polynomial independence alone would not exclude the gradient nullspace.

Changing variables x=epsilon y gives

(G_epsilon)_ij = epsilon^(d+r_i+r_j−2s) (G_1)_ij.

For monomials p_i=x^(alpha_i), r_i=|alpha_i|. The mass exponent is d+|alpha_i|+|alpha_j|, and the stiffness exponent subtracts two. Let D_epsilon=diag(epsilon^(r_i+(d−2s)/2)); then G_epsilon=D_epsilon G_1 D_epsilon. Since its diagonal scale is S_epsilon=D_epsilon S_1, the normalized matrix is exactly constant:

C_epsilon=S_1^(-1)G_1 S_1^(-1).

Consequently one normalized factor provides the exact current local inverse at every epsilon>0. The transported drift is zero, not merely bounded by tau. This conclusion applies to the stated Gram family; it does not assert that an arbitrary assembled spline principal block is a homogeneous Gram matrix.

For an untransported anchor G_a at epsilon_a, let r=epsilon/epsilon_a and beta_i=d+2r_i−2s. Coordinate Rayleigh quotients give

eta(G_a,G_epsilon−G_a) >= max_i |r^(beta_i)−1|.

In the mass case beta_i>0, and in the gradient case with nonconstant homogeneous polynomials beta_i>=d>0. Any fixed tau<1 therefore eventually forces a raw-anchor rejection as r tends to zero; as r tends to infinity, the lower bound diverges. This statement concerns the acceptance criterion. A common scalar change can trigger a raw-anchor rejection even though it leaves the preconditioned condition number unchanged.

## Two explicit stiffness examples

**Exact amplitude transport.** On (0,epsilon), choose p_1(x)=x and p_2(x)=x², which satisfy homogeneous Dirichlet data at x=0. Their derivative Gram is

G_epsilon = [[epsilon,epsilon²],[epsilon²,(4/3)epsilon³]],
C_epsilon = [[1,sqrt(3)/2],[sqrt(3)/2,1]].

Both are SPD for epsilon>0. Reusing the normalized factor is exactly the fresh inverse for every epsilon. For the raw anchor G_1, the eigenvalues of G_1^(-1)G_epsilon have product epsilon^4 and sum 4epsilon−6epsilon²+4epsilon³. Hence the raw retained condition number is asymptotic to 16epsilon^(-2) as epsilon tends to zero. The normalized factor remains of fixed condition number (1+sqrt(3)/2)/(1−sqrt(3)/2).

**Correlation changes remain.** On the same interval, take p_1(x)=x and p_2(x)=x+x². The normalized off-diagonal is

rho_epsilon=(1+epsilon)/sqrt(1+2epsilon+(4/3)epsilon²).

Here 1−rho_epsilon²=epsilon²/[3(1+2epsilon+(4/3)epsilon²)], and kappa(C_epsilon) is asymptotic to 12epsilon^(-2). Diagonal transport cannot remove this near dependence. Relative to any fixed normalized anchor, the small-mode ratio tends to zero and the anchor-energy drift tends to at least one, forcing refresh for every tau<1. A refreshed exact local inverse can still remove this local ill-conditioning; normalization alone cannot.

A general B-spline segment contains several polynomial degrees. Its support may change shape rather than shrink homothetically, several cells may contribute to a principal block, and stiffness may mix derivative and mass terms. None of these situations satisfies the simple scaling law automatically. The model explains why updating amplitudes can save refactorizations; it does not prove a uniform cut-independent normalized drift bound for B-splines.

## Relation to prior methods and experimental contract

Diagonal normalization and the separation of small-amplitude and near-dependent basis functions are established in Jacobi scaling and SIPIC. De Prenter et al.'s [2017 CMAME article](https://doi.org/10.1016/j.cma.2016.07.006) combines scaling with local orthonormalization; its [author-hosted full text](https://pure.tue.nl/ws/portalfiles/portal/143604802/Prenter2017.pdf) explains these two mechanisms. The proposed contribution is transporting a cached local inverse with current amplitudes while controlling the remaining cumulative correlation drift by an exact-arithmetic energy test. The scaling law and diagonal normalization themselves should not be claimed as new.

All main reuse policies must share current diagonal transport: fresh, exact-normalized reuse, energy-controlled normalized reuse, transported stale, and transported periodic. Fresh is still the same mathematical Schwarz inverse. The exact-local policy now means equality of normalized local matrices, not equality of raw physical matrices. A raw-energy ablation must retain and test the raw physical anchor to isolate the value of transport. Do not mix pilot timings from the earlier raw-anchor policy with transported runs.

In exact arithmetic singleton blocks have C=[1], so transport updates their diagonal inverse exactly without any refactorization or nonzero drift. Report this simple mechanism separately if singleton blocks dominate a result. Normalized matrix extraction, current diagonal updates, support tests and any coordinate transformations belong in measured setup/application costs.

Standard floating-point evaluation can perturb unit diagonals, normalization and small correlation eigenvalues. The inherited theorem remains an exact-arithmetic statement, with the same conditional approximate-action qualification as the earlier theory. Include temporally varying diagonal-scale cases in the algebra audit; no new numerical-certification claim follows from transport.

## Independent algebra audit

A read-only NumPy/SciPy audit, independent of the preconditioner implementation, used RNG seed 7241 and the project Python environment. It generated normalized SPD anchors of sizes 2, 5 and 9, imposed symmetric zero-diagonal perturbations with prescribed anchor norm .15, assigned different positive physical scales to anchor and current matrices, and then applied independent additional temporal scalings. Across 36 cases, the maximum normalized-matrix discrepancy was 4.44e−16, the largest relative inverse-action covariance discrepancy was 7.97e−16, and the largest discrepancy against the explicitly inverted transported physical anchor was 3.55e−15. All local inverse comparisons satisfied [0.85,1.15].

Fifteen additional overlapping two-block systems of dimension 8 compared transported and freshly assembled inverse sums. The observed generalized eigenvalues ranged from .9091382093 to 1.1111092551, within the required [.7,1.3] interval for tau=.3. These are correctness checks, not performance measurements.

The explicit stiffness model was evaluated at epsilon=1,.1,.01,.001,1e−8. The normalized matrix agreed with its constant analytic value to 2.23e−16. The product of the raw-anchor condition number and epsilon² was respectively 1, 11.81359154, 15.52655216, 15.95206595, and 15.99999952, confirming the asymptotic constant 16. The tiny-epsilon eigenvalue ratio was evaluated stably from the analytic trace and determinant, not by subtracting nearly equal eigenvalue expressions.

The audit also verified that a raw one-coordinate diagonal change can create full normalized support, and that changing one basis sign without aligning the anchor changes the normalized drift. LaTeX environment nesting was checked separately. The insert still requires compilation in the parent manuscript.
