# Exact-arithmetic theory of anchor-controlled Schwarz reuse

This note supplies the mathematical contract for the implementation and the manuscript. All matrices are real. `theory.tex` contains self-contained statements and proofs ready for inclusion in a paper. A preconditioner is the inverse action B, so the relevant condition number is that of A^(1/2) B A^(1/2), equivalently the ratio of positive eigenvalues of BA. It is not the Euclidean singular-value condition number of the generally nonsymmetric product BA.

## 1. Local acceptance contract

A stored block contains a fixed ordered list of global basis IDs, an SPD anchor H, a factor of H, and inverse-energy data. At the current query its matrix is F=H+Delta. The anchor is the matrix actually represented by the retained factor, not the preceding query matrix. Define

- eta(H,Delta) = ||H^(-1/2) Delta H^(-1/2)||_2;
- d_j = sqrt((H^(-1))_jj);
- b(H,Delta) = d^T |Delta| d, with entrywise absolute value.

For any vector x, |x_j| <= d_j sqrt(x^T H x), by Cauchy–Schwarz applied to H^(-1/2)e_j and H^(1/2)x. Therefore |x^T Delta x| <= b x^T H x and eta <= b. Acceptance at eta <= tau<1 gives (1−tau)H <= F <= (1+tau)H. Inverting this inequality correctly yields (1−tau)F^(-1) <= H^(-1) <= (1+tau)F^(-1).

The majorant is invariant under every nonsingular diagonal basis rescaling: H'=DHD, Delta'=D Delta D, d'=|D|^(-1)d imply b'=b. The exact eta is invariant under any invertible congruence, whereas the entrywise majorant need not be invariant under a general change of basis. Equilibration can thus improve numerical arithmetic without changing the exact acceptance test.

The majorant is exact for a one-coordinate perturbation Delta=c e_j e_j^T. It can be pessimistic by a factor m even for an m-dimensional diagonal anchor: Delta=alpha H gives eta=|alpha| but b=m|alpha|. A rejection by b means only that the cheap sufficient test was inconclusive.

## 2. Exact support compression

Suppose the complete cumulative difference satisfies Delta=R_K^T Delta_KK R_K, where R_K selects k coordinates and includes every nonzero row and column of Delta. Set G=R_K H^(-1) R_K^T and use the lower Cholesky factor G=LL^T. Then

eta(H,Delta) = max |lambda(L^T Delta_KK L)|.

Proof: Q=H^(-1/2)R_K^T L^(-T) has orthonormal columns and H^(-1/2)Delta H^(-1/2)=Q(L^T Delta_KK L)Q^T. The omitted eigenvalues are zero. For signed extremal-eigenvalue bounds, include the additional zero eigenvalues when k<m. This proof also establishes the correct multiplication order; L Delta_KK L^T is generally wrong for lower triangular L.

If K is empty, eta=0. The support need not be minimal: any certified superset is valid. It is the support of the anchor-to-current change. A mask covering only the latest geometry movement is insufficient after previous accepted changes. A full recomputation of Delta permits cancellation and safely shrinks K. Alternatively, accumulate the union of changed supports since refresh, together with all signed matrix increments.

G is a principal block of H^(-1), not the inverse of H_KK. The two differ when anchor coordinates in K couple to its complement. With H=[[1,rho],[rho,1]] and Delta=alpha e_1 e_1^T, eta=|alpha|/(1−rho^2); replacing G by (H_KK)^(-1)=1 underestimates it by an unbounded factor as rho tends to 1.

## 3. Current-query global theorem

At one query, let A be SPD, R_i select the current block coordinates, F_i=R_i A R_i^T, and P_i be the current injections. Standard unweighted Schwarz uses P_i=R_i^T. Symmetric weighting may use P_i=R_i^T W_i. Define

B_f = C + sum_i P_i F_i^(-1) P_i^T,
B_r = C + sum_i P_i H_i^(-1) P_i^T,

where C is an identical positive semidefinite current coarse or auxiliary term in both policies. Assume C+sum_i P_i P_i^T is positive definite, ensuring coverage, and eta(H_i,F_i−H_i)<=tau<1 for every block. A rebuilt block has H_i=F_i and eta=0. Then

(1−tau) B_f <= B_r <= (1+tau) B_f,

and each ordered eigenvalue obeys

(1−tau) lambda_j(A^(1/2)B_f A^(1/2)) <= lambda_j(A^(1/2)B_r A^(1/2)) <= (1+tau) lambda_j(A^(1/2)B_f A^(1/2)).

Thus kappa_A(B_r) <= ((1+tau)/(1−tau)) kappa_A(B_f). Congruence by P_i and addition prove the first statement; congruence by A^(1/2) and the min–max principle prove the second. The factor is sharp: one full block with H=I_2, A=diag(1−tau,1+tau) has fresh condition number 1 and retained condition number (1+tau)/(1−tau).

An exact compressed spectrum also supplies signed bounds ell_i<=lambda(E_i)<=u_i. If ell_i>−1, set a=min(1,min_i(1+ell_i)) and b=max(1,max_i(1+u_i)); then a B_f <= B_r <= b B_f. The factors 1 can be omitted when C=0. This refinement is useful for monotone domain additions/removals and common positive rescaling. It is optional; the implemented symmetric tau test remains the primary contract.

This is a relative-to-fresh theorem. It adds no overlap factor, mesh factor, polynomial-degree factor, or cut-fraction factor to those already present in the fresh method. It does not establish their absence from the fresh method. An identical exact coarse term is allowed; a changed or reused coarse solve requires its own equivalence bound. The result applies to symmetric additive constructions, not nonsymmetric RAS or multiplicative Schwarz without a separate argument.

## 4. Active-space and cache semantics

The theorem is applied separately at every current query, so the global dimension may change between queries. No comparison between matrices of different dimensions is required. Stable basis IDs provide the correspondence:

1. Construct the current block family and ensure coverage of current unknowns.
2. Reuse only a block with the same ordered basis-ID list, the same local mathematical operator convention, and the same coordinate system as its anchor. A known permutation can be applied to the anchor/factor consistently; merely matching block size is insufficient.
3. Test each retained block against its own anchor. Current weights and injections must be identical in the fresh and retained comparators; they may be recomputed for the current query.
4. Rebuild a new or changed-membership block. Retire disappeared blocks. Rebuilt means current local factorization, inverse data refresh, and cumulative-support reset.
5. Keep the resulting B fixed throughout ordinary PCG for the query.

An implementation that equilibrates every current matrix must either retain the old block coordinate transformation with the stored factor, transform the stored action consistently into the new coordinates, or rebuild. Otherwise the matrix being certified differs from the matrix actually applied.

For a change A_new−A_old=sum_{e in E_changed} T_e^T D_e T_e, every affected basis index belongs to the union of supports of the changed element contributions. The bound applies to a block whenever the local restriction intersects this support. Geometry cells alone are not basis support: spline basis functions span several cells. Include all changes in material terms, stabilization, boundary terms, constraints and coordinate transformations when these are part of the operator. With active-space changes, use an ambient basis-ID indexing only for change bookkeeping; the active SPD matrices used by the theorem remain current matrices.

## 5. Failure examples and limitations

**Per-step acceptance can fail arbitrarily badly.** Set H=I_2 and F_t=diag((1+epsilon)^t,(1−epsilon)^t), 0<epsilon<tau. The previous-step relative-energy change is exactly epsilon forever. If those checks retain H indefinitely, kappa(F_t)=((1+epsilon)/(1−epsilon))^t tends to infinity, whereas one fresh full-block inverse gives condition number 1. The cumulative anchor test necessarily rejects. A bound on the sum of increments measured in the fixed anchor energy is sufficient but more conservative than testing their signed sum; cancellation can return the current operator to its anchor.

**Diagonal-only variation misses loss of conditioning.** H=I_2 and F_rho=[[1,rho],[rho,1]], 0<rho<1, have identical diagonals. Every diagonal-only difference proxy is zero, but eta=rho and the retained full-block condition number (1+rho)/(1−rho) diverges. Monitoring all stiffness entries in the anchor energy is essential for a worst-case guarantee.

**Incomplete support creates false acceptance.** With H=I_2 and Delta=alpha[[1,−1],[−1,1]], the exact eta=2alpha. Using K={1} instead of {1,2} incorrectly reports alpha. For alpha=0.4 and tau=0.5 this produces false acceptance (0.4 instead of 0.8). F remains SPD; the error is in the certificate, not the PDE.

**Replacing inverse diagonal by reciprocal diagonal is unsafe.** In the correlated anchor H=[[1,rho],[rho,1]], Delta=alpha e_1 e_1^T has eta=alpha/(1−rho^2). Substituting sqrt(1/H_jj) for d_j reports alpha. Those two expressions coincide only for special anchors such as diagonal ones.

**Membership errors are unbounded.** A cached scalar matrix for global basis ID a with entry 1 cannot be attached to a new ID b with current entry epsilon merely because both blocks have dimension one. Combined with another unchanged unit block, the reused inverse leads to condition number 1/epsilon, whereas fresh diagonal inverses give 1. The ID change must invalidate the cache.

**No static robustness follows from perfect reuse.** Let A_epsilon=[[1,1−epsilon],[1−epsilon,1]], and use the two singleton blocks. Even tau=0 gives B_r=B_f=I and kappa_A(B_f)=(2−epsilon)/epsilon. The reuse guarantee is exact while the base preconditioner is arbitrarily poor.

**No wall-clock result follows from the theorem.** Exact inverse diagonals cost work at refresh. For dense block size m and support size k, a stored full inverse gives G in O(k^2), while obtaining it from a Cholesky factor generally costs O(m^2 k); the compressed dense test costs O(k^3). A dense first-stage test costs O(m^2), or work proportional to the nonzeros of Delta if available. When k≈m, the exact test can cost as much as a refresh. Store/report inverse-data setup, screening, refresh, and application separately. A tau=0 support-local refresh policy is a necessary strong baseline.

## 6. Finite precision

The acceptance inequalities are exact-arithmetic results. The implementation evaluates them after diagonal equilibration, rejects nonfinite quantities or factorization failures, and uses a margin below tau. Numerical comparisons against independent generalized eigensolves audit reliability but do not provide outward-rounded certificates.

A precise extension is available if the applied fixed symmetric block action S_i has independently justified bounds (1−theta)H_i^(-1) <= S_i <= (1+theta)H_i^(-1), theta<1. Then (1−theta)(1−tau)B_f <= C+sum_i P_i S_i P_i^T <= (1+theta)(1+tau)B_f, and the condition-number inflation multiplies by (1+theta)/(1−theta). This statement isolates the numerical requirement without assuming that a successful Cholesky call proves it. If the certificate refers to a perturbed anchor represented exactly by a computed factor, the stored difference and inverse data must refer to that same perturbed anchor. Ordinary floating-point triangular solves do not automatically constitute an exact fixed linear operator with known theta.

## 7. Claim-to-evidence map

| Claim | Evidence | Required implementation/experiment check |
|---|---|---|
| Energy majorant dominates exact relative drift | Coordinate Cauchy–Schwarz proof | Compare with generalized eigenvalues; test correlated anchors |
| Invariance under diagonal basis scaling | Entrywise cancellation proof | Rescale both current and anchor matrices, with full consistency |
| Support compression is exact | Orthonormal embedding proof | Validate full cumulative support, Cholesky orientation, inverse principal block |
| Retained Schwarz is within a prescribed factor of fresh | Inverse Loewner order, congruence, addition | Same current blocks, injections, weights and coarse term; all blocks covered |
| Bound is sharp | Two-dimensional diagonal example | Algebraic audit, not a PDE performance claim |
| Active-space changes are admissible | Querywise theorem plus stable-ID invariant | New/changed IDs rebuild, retired blocks removed |
| Per-step or diagonal-only proxies are insufficient | Explicit 2x2 counterexamples | Include these as adversarial policy audits |
| Runtime decreases | Not implied mathematically | Matched repeated timings including test overhead and cold setup |
| Cut/h/p robustness | Not proved here | Requires an independent theorem for the base method or qualified numerical evidence |
| Finite-precision certification | Not established by standard floating-point evaluation | Report numerical-bound terminology and audit errors |

No theorem in this note depends on a numerical benchmark outcome. The application-specific contribution must be established by the complete method and its measured behavior; the inequalities are classical tools assembled into a useful update contract.
