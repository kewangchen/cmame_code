"""Tensor-product open B-splines with stable background basis identifiers."""
import itertools
import numpy as np
from scipy.interpolate import BSpline


class SplineGrid:
    def __init__(self,cells,degree):
        self.cells=tuple(map(int,cells));self.dim=len(self.cells)
        if self.dim not in (2,3):raise ValueError('two or three dimensions required')
        self.degrees=(int(degree),)*self.dim if np.isscalar(degree) else tuple(degree)
        self.degree=max(self.degrees)
        self.shape=tuple(n+p for n,p in zip(self.cells,self.degrees))
        self.size=int(np.prod(self.shape))
        self.knots=[np.r_[np.zeros(p),np.linspace(0,1,n+1),np.ones(p)] for n,p in zip(self.cells,self.degrees)]
        self.splines=[BSpline(t,np.eye(s),p,extrapolate=False) for t,s,p in zip(self.knots,self.shape,self.degrees)]
        self.cell_indices=list(itertools.product(*[range(n) for n in self.cells]))

    def bounds(self,cell):
        return tuple(v for e,n in zip(cell,self.cells) for v in (e/n,(e+1)/n))

    def cell_ids(self,cell):
        ranges=[np.arange(e,e+p+1) for e,p in zip(cell,self.degrees)]
        mesh=np.meshgrid(*ranges,indexing='ij')
        return np.ravel_multi_index(tuple(mesh),self.shape).ravel()

    def local(self,cell,points):
        points=np.asarray(points);nq=len(points)
        B=[];D=[]
        for a,(e,p,s) in enumerate(zip(cell,self.degrees,self.splines)):
            B.append(s(points[:,a])[:,e:e+p+1]);D.append(s(points[:,a],nu=1)[:,e:e+p+1])
        def product(factors):
            out=factors[0]
            for factor in factors[1:]:out=(out[:,:,None]*factor[:,None,:]).reshape(nq,-1)
            return out
        N=product(B);G=np.stack([product([D[b] if a==b else B[b] for b in range(self.dim)]) for a in range(self.dim)],axis=-1)
        return self.cell_ids(cell),N,G

    def greville(self):
        coordinates=[np.array([np.mean(t[i+1:i+p+1]) for i in range(s)]) for t,s,p in zip(self.knots,self.shape,self.degrees)]
        return np.stack(np.meshgrid(*coordinates,indexing='ij'),axis=-1).reshape(-1,self.dim)
