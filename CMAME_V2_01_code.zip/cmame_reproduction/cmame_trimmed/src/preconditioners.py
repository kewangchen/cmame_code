"""SPD additive Schwarz reuse and balanced coordinate-deflation baselines.

Only local principal submatrices are dense.  Energy decisions are numerical
floating-point tests against a retained anchor, not interval certificates.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from math import exp, log, pi
from time import perf_counter
from typing import Dict, Optional, Tuple

import numpy as np
from scipy import linalg, sparse
from scipy.sparse.linalg import LinearOperator


@dataclass(frozen=True)
class EnergyBudget:
    """Explicit sequential high-probability budget and independent probe RNG.

    Keep one instance for a whole adaptive run. Configuration is immutable;
    ``draw`` advances its generator/count and spends the next summable budget.
    The probability statement is exact-arithmetic, not an interval certificate.
    """
    seed: int = 20261016
    delta_total: float = 1e-8
    probes: int = 12
    power: int = 2
    min_dimension: int = 0
    count: int = field(default=0, init=False)
    spent_failure_budget: float = field(default=0., init=False)
    rng: np.random.Generator = field(init=False, repr=False, compare=False)
    token: object = field(default_factory=object, init=False, repr=False, compare=False)

    def __post_init__(self):
        if not isinstance(self.seed, (int, np.integer)) or isinstance(self.seed, (bool, np.bool_)) or self.seed < 0:
            raise ValueError('seed must be a nonnegative integer')
        if not np.isfinite(self.delta_total) or not 0 < self.delta_total < 1:
            raise ValueError('delta_total must be finite and in (0, 1)')
        for name in ('probes', 'power'):
            value = getattr(self, name)
            if not isinstance(value, (int, np.integer)) or isinstance(value, (bool, np.bool_)) or value < 1:
                raise ValueError(name+' must be a positive integer')
        if (not isinstance(self.min_dimension, (int, np.integer))
                or isinstance(self.min_dimension, (bool, np.bool_)) or self.min_dimension < 0):
            raise ValueError('min_dimension must be a nonnegative integer')
        object.__setattr__(self, 'rng', np.random.default_rng(self.seed))

    def draw(self, dimension):
        """Draw fresh columns and return their log small-ball multiplier."""
        if not isinstance(dimension, (int, np.integer)) or dimension < 1:
            raise ValueError('probe dimension must be a positive integer')
        check = self.count+1
        log_allocation = log(6.)+log(self.delta_total)-2*log(pi)-2*log(check)
        log_alpha = .5*log(2/pi)-log_allocation/self.probes
        omega = self.rng.standard_normal((dimension, self.probes))
        object.__setattr__(self, 'count', check)
        object.__setattr__(self, 'spent_failure_budget', self.spent_failure_budget+exp(log_allocation))
        return omega, log_alpha


def _matrix(a):
    if not sparse.issparse(a):
        raise TypeError('A must be a sparse matrix')
    a = sparse.csr_matrix(a, dtype=float)
    if a.shape[0] != a.shape[1] or not np.all(np.isfinite(a.data)):
        raise ValueError('A must be square and finite')
    difference = a - a.T
    error = np.max(np.abs(difference.data), initial=0.)
    magnitude = np.max(np.abs(a.data), initial=0.)
    if error > 64*np.finfo(float).eps*magnitude:
        raise ValueError('A is not symmetric to floating-point tolerance')
    return a


@dataclass
class LocalFactor:
    """An immutable anchor with lazily prepared energy-screening data.

    ``scale`` is sqrt(diag(H)); ``cholesky`` factors its equilibrated matrix.
    The small accepted roundoff symmetry discrepancy is measured explicitly.
    """
    anchor: np.ndarray
    scale: np.ndarray
    cholesky: np.ndarray
    factor_residual: Optional[float]
    symmetry_error: float
    inverse_diagonal: Optional[np.ndarray] = None
    normalized_inverse_diagonal_sqrt: Optional[np.ndarray] = None
    inverse_residual: Optional[float] = None
    inverse_submatrices: Dict[Tuple[int, ...], tuple] = field(default_factory=dict)
    # Bound for the previous numerical local matrix relative to this anchor.
    # None means a stale policy retained a matrix without a valid certificate.
    last_accepted_bound: Optional[float] = 0.
    last_is_exact: bool = True
    inverse_factor_norm_bound: Optional[float] = None
    certificate_kind: str = 'exact'
    probability_token: Optional[object] = field(default=None, repr=False, compare=False)

    @classmethod
    def factor(cls, h, diagnostics=False):
        h = np.asarray(h, dtype=float).copy()
        diag = np.diag(h)
        if not np.all(np.isfinite(h)) or np.any(diag <= 0):
            raise np.linalg.LinAlgError('Local anchor has nonpositive diagonal or nonfinite entries')
        scale = np.sqrt(diag)
        c = h / scale[:, None] / scale[None, :]
        symmetry_error = float(np.linalg.norm(c-c.T, ord=np.inf))
        if symmetry_error > 64*np.finfo(float).eps*max(1., np.linalg.norm(c, ord=np.inf)):
            raise ValueError('Local anchor is not symmetric after equilibration')
        # Average only measured, roundoff-sized asymmetry; never shift or clip.
        cs = .5*c + .5*c.T
        chol = linalg.cholesky(cs, lower=True, check_finite=True)
        residual = (float(np.linalg.norm(c-chol@chol.T, ord=np.inf) / np.linalg.norm(c, ord=np.inf))
                    if diagnostics else None)
        return cls(h, scale, chol, residual, symmetry_error)

    def audit_factor(self):
        if self.factor_residual is None:
            c = self.anchor/self.scale[:, None]/self.scale[None, :]
            self.factor_residual = float(np.linalg.norm(c-self.cholesky@self.cholesky.T, ord=np.inf)
                                         / np.linalg.norm(c, ord=np.inf))

    def solve(self, b):
        b = np.asarray(b, dtype=float)
        s = self.scale if b.ndim == 1 else self.scale[:, None]
        out = linalg.cho_solve((self.cholesky, True), b/s, check_finite=False)/s
        if not np.all(np.isfinite(out)):
            raise FloatingPointError('Local inverse action overflowed; no stabilization was applied')
        return out

    def prepare_energy(self, diagnostics=False):
        if (self.inverse_diagonal is None or self.inverse_factor_norm_bound is None
                or (diagnostics and self.inverse_residual is None)):
            if len(self.scale) == 1:
                with np.errstate(over='raise', invalid='raise', divide='raise'):
                    self.inverse_diagonal = 1./self.anchor.reshape(-1)
                self.normalized_inverse_diagonal_sqrt = np.ones(1)
                self.inverse_factor_norm_bound = 1.
                if diagnostics:
                    self.inverse_residual = 0.
                return
            identity = np.eye(len(self.scale))
            inverse_l = linalg.solve_triangular(self.cholesky, identity, lower=True, check_finite=False)
            with np.errstate(over='raise', invalid='raise'):
                q = np.sqrt(np.sum(inverse_l*inverse_l, axis=0))
                d = q/self.scale
                self.inverse_diagonal = d*d
                absolute_inverse_l = np.abs(inverse_l)
                self.inverse_factor_norm_bound = float(absolute_inverse_l.sum(axis=0).max()
                                                       * absolute_inverse_l.sum(axis=1).max())
            if not np.all(np.isfinite(self.inverse_diagonal)) or np.any(self.inverse_diagonal <= 0):
                raise FloatingPointError('Inverse diagonal is not representable in finite precision')
            if not np.isfinite(self.inverse_factor_norm_bound):
                raise FloatingPointError('Inverse-factor norm bound is not representable')
            self.normalized_inverse_diagonal_sqrt = q
            if diagnostics:
                self.inverse_residual = float(np.linalg.norm(self.cholesky@inverse_l-identity, ord=np.inf)
                                              / (1.+np.linalg.norm(self.cholesky, ord=np.inf)
                                                 * np.linalg.norm(inverse_l, ord=np.inf)))

    def support_inverse(self, support):
        """Cache (H^-1)_KK in equilibrated coordinates and its Cholesky.

        Raw H^-1_KK = diag(1/scale[K]) G diag(1/scale[K]).  Factoring G
        avoids squaring the basis-scaling condition number in the screen.
        """
        key = tuple(int(k) for k in support)
        if key not in self.inverse_submatrices:
            rhs = np.eye(len(self.scale))[:, support]
            inv_columns = linalg.cho_solve((self.cholesky, True), rhs, check_finite=False)
            g = inv_columns[support, :]
            # Roundoff symmetry averaging is measured by the factor diagnostics
            # for H; G is an inverse principal submatrix, not a regularization.
            g = .5*g + .5*g.T
            self.inverse_submatrices[key] = (g, linalg.cholesky(g, lower=True, check_finite=True))
        return self.inverse_submatrices[key]


def _indices(values, n, label):
    v = np.asarray(values)
    if v.ndim != 1 or not np.issubdtype(v.dtype, np.integer):
        # An empty Python list has float dtype, but is a valid empty set.
        if v.ndim != 1 or v.size:
            raise ValueError(label+' must be a one-dimensional integer array')
    v = v.astype(np.intp)
    if np.any(v < 0) or np.any(v >= n) or len(np.unique(v)) != len(v):
        raise ValueError(label+' contains duplicate or out-of-range rows')
    return v


def _probabilistic_bound(factor, change, state):
    """Fresh Gaussian power action; no inverse/factor preparation or CG RNG.

    K = L^-1 change L^-T is symmetric. Column normalization between power
    actions, with logarithmic scale accumulation, avoids naive power underflow.
    """
    vectors, log_alpha = state.draw(len(factor.scale))
    log_magnitudes = np.zeros(state.probes)
    with np.errstate(over='raise', invalid='raise', divide='raise'):
        for _ in range(state.power):
            if len(factor.scale) == 1:
                action = change@vectors
            else:
                y = linalg.solve_triangular(factor.cholesky, vectors, lower=True, trans='T', check_finite=False)
                action = linalg.solve_triangular(factor.cholesky, change@y, lower=True, check_finite=False)
            if not np.all(np.isfinite(action)):
                raise FloatingPointError('Nonfinite randomized energy action')
            scales = np.max(np.abs(action), axis=0)
            live = scales != 0
            vectors = np.zeros_like(action)
            vectors[:, live] = action[:, live]/scales[live]
            lengths = np.sqrt(np.sum(vectors[:, live]*vectors[:, live], axis=0))
            vectors[:, live] /= lengths
            log_magnitudes[live] += np.log(scales[live])+np.log(lengths)
            log_magnitudes[~live] = -np.inf
        log_bound = (log_alpha+float(np.max(log_magnitudes)))/state.power
    if log_bound == -np.inf:
        return 0.
    try:
        bound = exp(log_bound)
    except OverflowError as exc:
        raise FloatingPointError('Randomized energy bound overflowed') from exc
    if not np.isfinite(bound):
        raise FloatingPointError('Nonfinite randomized energy bound')
    return bound


def build_schwarz(A_csr, blocks, global_ids, mode='fresh', cache=None,
                  tau=.2, step=0, period=5, diagnostics=False,
                  changed_global_ids=None, spectral_cap=32,
                  probability_state=None):
    """Return an additive inverse operator, current anchor cache, and setup stats.

    Keys are ordered tuples of stable background DOF IDs.  Missing rows receive
    singleton blocks and are reported.  ``periodic`` refreshes at step % period
    == 0; ``stale`` retains all surviving anchors.  Neither policy is certified.
    The supplied cache dictionary is not replaced in place.
    ``changed_global_ids`` optionally supplies complete previous-step change
    support in fixed physical basis coordinates. Its correctness is a caller
    contract. Previous accepted anchor bounds remain valid on untouched blocks.
    """
    start = perf_counter()
    if mode not in ('fresh', 'exact_local', 'energy', 'prob_energy', 'stale', 'periodic'):
        raise ValueError('Unknown Schwarz policy: '+str(mode))
    if mode == 'prob_energy' and probability_state is None:
        raise ValueError('prob_energy requires an explicit EnergyBudget for the whole run')
    if probability_state is not None and not isinstance(probability_state, EnergyBudget):
        raise TypeError('probability_state must be an EnergyBudget')
    if not np.isfinite(tau) or not 0 <= tau < 1:
        raise ValueError('tau must be finite and in [0, 1)')
    if not isinstance(period, (int, np.integer)) or period < 1:
        raise ValueError('period must be a positive integer')
    if not isinstance(spectral_cap, (int, np.integer)) or spectral_cap < 0:
        raise ValueError('spectral_cap must be a nonnegative integer')
    a = _matrix(A_csr)
    n = a.shape[0]
    gids = np.asarray(global_ids)
    if gids.ndim != 1 or len(gids) != n or len(set(gids.tolist())) != n:
        raise ValueError('global_ids must contain one unique stable ID per current row')
    local_blocks = [_indices(b, n, 'block') for b in blocks]
    if any(len(b) == 0 for b in local_blocks):
        raise ValueError('Schwarz blocks must be nonempty')
    covered = np.zeros(n, dtype=bool)
    for b in local_blocks:
        covered[b] = True
    missing = np.flatnonzero(~covered)
    local_blocks.extend(np.array([i], dtype=np.intp) for i in missing)
    old = {} if cache is None else cache
    changed = None if changed_global_ids is None else set(np.asarray(changed_global_ids).tolist())
    current = {}
    actions = []
    singleton_actions = []
    stats = {k: 0 for k in ('new', 'refreshed', 'reused_exact', 'reused_energy',
                            'reused_stale', 'reused_unchanged', 'operator_only_accepts',
                            'first_checks', 'spectral_checks', 'randomized_checks', 'skipped_small_blocks',
                            'peak_rank', 'retired')}
    stats.update({k: 0. for k in ('extraction_time', 'factorization_time',
                                  'energy_preparation_time', 'first_check_time',
                                  'spectral_check_time', 'max_first_bound',
                                  'first_coordinate_bound', 'first_operator_bound',
                                  'randomized_time', 'max_randomized_bound',
                                  'max_spectral_norm', 'max_accepted_bound',
                                  'max_factor_residual', 'max_inverse_residual',
                                  'max_symmetry_error')})
    stats.update(mode=mode, tau=float(tau), blocks=len(local_blocks),
                 uncovered_rows=len(missing), diagonal_fallback=len(missing),
                 diagnostics=bool(diagnostics), spectral_cap=int(spectral_cap))
    stats['max_factor_residual'] = 0. if diagnostics else None
    stats['max_inverse_residual'] = None
    # Singleton numerical extraction/scaling is batched; each cache key still
    # owns its own anchor and metadata. There are no scalar Cholesky calls.
    plan = []
    singleton_extract_rows = []
    multiplicities = {}
    for b in local_blocks:
        key = tuple(gids[b].tolist())
        if key in multiplicities:
            multiplicities[key] += 1
            continue
        multiplicities[key] = 1
        factor = old.get(key)
        previous_bound = factor.last_accepted_bound if factor is not None else None
        deterministic_certified = (factor is not None and (factor.last_is_exact
                                    or factor.certificate_kind == 'deterministic'))
        same_probability_state = (factor is not None and probability_state is not None
                                  and factor.probability_token is probability_state.token)
        randomized_certified = (factor is not None and (factor.last_is_exact
                                  or (factor.certificate_kind == 'probabilistic'
                                      and same_probability_state)))
        policy_certified = ((mode == 'energy' and deterministic_certified
                             and previous_bound is not None and previous_bound <= tau)
                            or (mode == 'prob_energy' and randomized_certified
                                and previous_bound is not None and previous_bound <= tau)
                            or (mode == 'exact_local' and factor is not None and factor.last_is_exact)
                            or mode == 'stale'
                            or (mode == 'periodic' and (step % period != 0
                                or (factor is not None and factor.last_is_exact))))
        skip = (factor is not None and mode != 'fresh' and changed is not None
                and changed.isdisjoint(key) and policy_certified)
        scalar_index = None
        if len(b) == 1 and not skip:
            scalar_index = len(singleton_extract_rows)
            singleton_extract_rows.append(b[0])
        plan.append((b, key, factor, skip, scalar_index))
    singleton_rows = np.array(singleton_extract_rows, dtype=np.intp)
    tick = perf_counter()
    singleton_values = (np.asarray(a[singleton_rows, singleton_rows]).reshape(-1)
                        if len(singleton_rows) else np.empty(0))
    stats['extraction_time'] += perf_counter()-tick
    if not np.all(np.isfinite(singleton_values)) or np.any(singleton_values <= 0):
        raise np.linalg.LinAlgError('Singleton anchor has nonpositive or nonfinite diagonal')
    tick = perf_counter()
    singleton_scales = np.sqrt(singleton_values)
    stats['factorization_time'] += perf_counter()-tick
    scalar_unit = np.ones((1, 1))
    for b, key, factor, skip, scalar_index in plan:
        retain = False
        h = None
        # A previous nonzero energy certificate remains valid if the numerical
        # block has not changed, but does not imply equality to its anchor.
        previous_bound = factor.last_accepted_bound if factor is not None else None
        if skip:
            retain = True
            stats['reused_unchanged'] += 1
            if mode in ('energy', 'prob_energy'):
                stats['max_accepted_bound'] = max(stats['max_accepted_bound'], previous_bound)
        else:
            tick = perf_counter()
            h = (singleton_values[scalar_index:scalar_index+1].reshape(1, 1)
                 if scalar_index is not None else a[b, :][:, b].toarray())
            stats['extraction_time'] += perf_counter()-tick
        if factor is not None and mode != 'fresh' and not retain:
            if np.array_equal(h, factor.anchor):
                retain = True
                stats['reused_exact'] += 1
                if factor.last_accepted_bound != 0. or not factor.last_is_exact:
                    factor = replace(factor, last_accepted_bound=0., last_is_exact=True,
                                     certificate_kind='exact', probability_token=None)
            elif mode == 'stale' or (mode == 'periodic' and step % period != 0):
                retain = True
                stats['reused_stale'] += 1
                factor = replace(factor, last_accepted_bound=None, last_is_exact=False,
                                 certificate_kind='stale', probability_token=None)
            elif mode == 'prob_energy' and len(b) <= probability_state.min_dimension:
                # Exact/unchanged reuse has already been attempted. A fresh
                # factor is cheaper by the caller's dimension cost policy and
                # has zero drift without spending any probability budget.
                stats['skipped_small_blocks'] += 1
            elif mode == 'prob_energy':
                tick = perf_counter()
                with np.errstate(over='raise', invalid='raise', divide='raise'):
                    change = (h-factor.anchor)/factor.scale[:, None]/factor.scale[None, :]
                bound = _probabilistic_bound(factor, change, probability_state)
                stats['randomized_checks'] += 1
                stats['randomized_time'] += perf_counter()-tick
                stats['max_randomized_bound'] = max(stats['max_randomized_bound'], bound)
                if bound <= tau:
                    retain = True
                    stats['reused_energy'] += 1
                    stats['max_accepted_bound'] = max(stats['max_accepted_bound'], bound)
                    factor = replace(factor, last_accepted_bound=bound, last_is_exact=False,
                                     certificate_kind='probabilistic', probability_token=probability_state.token)
            elif mode == 'energy':
                tick = perf_counter()
                factor.prepare_energy(diagnostics=diagnostics)
                stats['energy_preparation_time'] += perf_counter()-tick
                tick = perf_counter()
                with np.errstate(over='raise', invalid='raise', divide='raise'):
                    delta = h-factor.anchor
                    change = delta/factor.scale[:, None]/factor.scale[None, :]
                    q = (np.ones(1) if scalar_index is not None
                         else factor.normalized_inverse_diagonal_sqrt)
                    absolute_change = np.abs(change)
                    coordinate_bound = float(q @ absolute_change @ q)
                    operator_bound = float(factor.inverse_factor_norm_bound
                                           * absolute_change.sum(axis=1).max())
                    bound = min(coordinate_bound, operator_bound)
                if not np.isfinite(bound):
                    raise FloatingPointError('Nonfinite first energy-screening bound')
                stats['first_checks'] += 1
                stats['first_coordinate_bound'] = max(stats['first_coordinate_bound'], coordinate_bound)
                stats['first_operator_bound'] = max(stats['first_operator_bound'], operator_bound)
                stats['max_first_bound'] = max(stats['max_first_bound'], bound)
                stats['first_check_time'] += perf_counter()-tick
                if bound <= tau:
                    retain = True
                    if coordinate_bound > tau and operator_bound <= tau:
                        stats['operator_only_accepts'] += 1
                else:
                    support = np.flatnonzero(np.any(delta != 0, axis=0) | np.any(delta != 0, axis=1))
                    stats['peak_rank'] = max(stats['peak_rank'], len(support))
                    if len(support) <= spectral_cap:
                        tick = perf_counter()
                        if scalar_index is not None:
                            reduced = change
                        else:
                            _, lower = factor.support_inverse(support)
                            reduced = lower.T @ change[np.ix_(support, support)] @ lower
                        symmetry_error = float(np.linalg.norm(reduced-reduced.T, ord=np.inf))
                        stats['max_symmetry_error'] = max(stats['max_symmetry_error'], symmetry_error)
                        eigenvalues = (reduced.reshape(-1) if scalar_index is not None else
                                       linalg.eigvalsh(.5*reduced+.5*reduced.T, check_finite=True))
                        bound = float(np.max(np.abs(eigenvalues), initial=0.))
                        stats['spectral_checks'] += 1
                        stats['max_spectral_norm'] = max(stats['max_spectral_norm'], bound)
                        stats['spectral_check_time'] += perf_counter()-tick
                        retain = bound <= tau
                if retain:
                    stats['reused_energy'] += 1
                    stats['max_accepted_bound'] = max(stats['max_accepted_bound'], bound)
                    factor = replace(factor, last_accepted_bound=bound, last_is_exact=False,
                                     certificate_kind='deterministic', probability_token=None)
        if not retain:
            tick = perf_counter()
            if scalar_index is not None:
                factor = LocalFactor(h.copy(), singleton_scales[scalar_index:scalar_index+1],
                                     scalar_unit, None, 0.)
            else:
                factor = LocalFactor.factor(h, diagnostics=diagnostics)
            stats['factorization_time'] += perf_counter()-tick
            stats['new' if key not in old else 'refreshed'] += 1
        if mode == 'energy' and diagnostics and factor.inverse_diagonal is not None and factor.inverse_residual is None:
            tick = perf_counter()
            factor.prepare_energy(diagnostics=diagnostics)
            stats['energy_preparation_time'] += perf_counter()-tick
        current[key] = factor
        if len(b) == 1:
            singleton_actions.append((int(b[0]), factor, multiplicities[key]))
        else:
            actions.append((b, factor, multiplicities[key]))
        if diagnostics:
            tick = perf_counter()
            factor.audit_factor()
            stats['factorization_time'] += perf_counter()-tick
            stats['max_factor_residual'] = max(stats['max_factor_residual'], factor.factor_residual)
        if diagnostics and factor.inverse_residual is not None:
            stats['max_inverse_residual'] = max(stats['max_inverse_residual'] or 0., factor.inverse_residual)
        stats['max_symmetry_error'] = max(stats['max_symmetry_error'], factor.symmetry_error)

    # One vector reciprocal prepares all scalar inverse actions, including
    # retained stale anchors. Scatter-add preserves overlap with larger blocks.
    tick = perf_counter()
    scalar_rows = np.array([r for r, f, m in singleton_actions], dtype=np.intp)
    scalar_anchor = np.array([f.anchor[0, 0] for r, f, m in singleton_actions])
    scalar_multiplicity = np.array([m for r, f, m in singleton_actions])
    with np.errstate(over='raise', invalid='raise', divide='raise'):
        scalar_inverse = 1./scalar_anchor
    if not np.all(np.isfinite(scalar_inverse)):
        raise FloatingPointError('Singleton inverse action is not representable')
    scalar_weights = np.bincount(scalar_rows, weights=scalar_inverse*scalar_multiplicity, minlength=n)
    stats['factorization_time'] += perf_counter()-tick
    stats['singleton_blocks'] = int(scalar_multiplicity.sum())
    stats['unique_singleton_blocks'] = len(singleton_actions)

    def apply(x):
        x = np.asarray(x, dtype=float)
        out = scalar_weights*x if x.ndim == 1 else scalar_weights[:, None]*x
        for rows, factor, multiplicity in actions:
            out[rows] += multiplicity*factor.solve(x[rows])
        return out

    op = LinearOperator((n, n), matvec=apply, rmatvec=apply, matmat=apply, dtype=float)
    stats['retired'] = len(set(old)-set(current))
    stats['peak_blocks'] = max(len(old), len(current))
    stats['active_blocks'] = len(current)
    stats['unique_blocks'] = len(current)
    stats['min_equilibration_scale'] = min((f.scale.min() for f in current.values()), default=1.)
    stats['max_equilibration_scale'] = max((f.scale.max() for f in current.values()), default=1.)
    stats['cumulative_checks'] = probability_state.count if probability_state is not None else 0
    stats['spent_failure_budget'] = probability_state.spent_failure_budget if probability_state is not None else 0.
    stats['setup_time'] = perf_counter()-start
    return op, current, stats


def jacobi(A_csr):
    """Inverse diagonal SPD baseline; reject invalid entries explicitly."""
    a = _matrix(A_csr)
    diag = a.diagonal()
    if np.any(diag <= 0):
        raise ValueError('Jacobi requires a positive diagonal')
    inv = 1./diag
    if not np.all(np.isfinite(inv)):
        raise FloatingPointError('Jacobi inverse diagonal overflowed')

    def apply(x):
        x = np.asarray(x)
        return inv*x if x.ndim == 1 else inv[:, None]*x

    return LinearOperator(a.shape, matvec=apply, rmatvec=apply, matmat=apply, dtype=float)


def coordinate_deflation(A_csr, weak_ids):
    """Balanced coordinate correction with ``weak_ids`` as CURRENT ROW indices.

    B = Q + (I-Q A) D^-1 (I-A Q), Q=Z (Z^T A Z)^-1 Z^T.
    Related to weak-cut coordinate deflation; this is a balanced implementation,
    not literal code from Voet et al. 2026.
    """
    a = _matrix(A_csr)
    rows = _indices(weak_ids, a.shape[0], 'weak_ids')
    diagonal = jacobi(a)
    if not len(rows):
        return diagonal
    factor = LocalFactor.factor(a[rows, :][:, rows].toarray())

    def coarse(x):
        out = np.zeros_like(x, dtype=float)
        out[rows] = factor.solve(x[rows])
        return out

    def apply(x):
        x = np.asarray(x, dtype=float)
        qx = coarse(x)
        y = diagonal @ (x-a@qx)
        return qx+y-coarse(a@y)

    return LinearOperator(a.shape, matvec=apply, rmatvec=apply, matmat=apply, dtype=float)
