"""Analytic trims and cut-aware positive quadrature on Cartesian knot cells."""
from dataclasses import dataclass
from functools import lru_cache
import numpy as np
from numpy.polynomial.legendre import leggauss


@lru_cache(None)
def gauss(order):
    return leggauss(int(order))


@dataclass(frozen=True)
class TrimDomain:
    holes: tuple = ()
    top: float = 1.0
    roof: tuple = ()  # Piecewise-linear (x,y) vertices; graph domain below roof.

    def height(self,x):
        if self.roof:
            r=np.asarray(self.roof)
            return np.minimum(self.top,np.interp(x,r[:,0],r[:,1]))
        return np.full_like(np.asarray(x,dtype=float),self.top)

    def signature(self,bounds):
        x0,x1,y0,y1=bounds
        samples=[x0,x1]+[x for x,y in self.roof if x0<x<x1]
        heights=self.height(samples)
        if max(heights)<=y0:return ('empty',)
        relevant=[]
        corners=np.array([[x0,y0],[x0,y1],[x1,y0],[x1,y1]])
        for cx,cy,r in self.holes:
            if np.max((corners[:,0]-cx)**2+(corners[:,1]-cy)**2)<=r*r:
                return ('empty',)
            dx=max(x0-cx,0.,cx-x1);dy=max(y0-cy,0.,cy-y1)
            if dx*dx+dy*dy<r*r:relevant.append((cx,cy,r))
        if min(heights)>=y1 and not relevant:return ('full',)
        return ('cut',tuple(relevant),self.top if min(heights)<y1 else None,
                self.roof if min(heights)<y1 else ())

    def intervals(self,x,y0,y1):
        hi=min(y1,float(self.height([x])[0]))
        if hi<=y0:return []
        spans=[(y0,hi)]
        for cx,cy,r in self.holes:
            v=r*r-(x-cx)**2
            if v<=0:continue
            dy=np.sqrt(v);a,b=cy-dy,cy+dy
            new=[]
            for lo,up in spans:
                if b<=lo or a>=up:new.append((lo,up));continue
                if lo<a:new.append((lo,min(a,up)))
                if b<up:new.append((max(lo,b),up))
            spans=new
        return spans


def cut_quadrature(bounds,geometry,order):
    x0,x1,y0,y1=map(float,bounds)
    signature=geometry.signature(bounds)
    if signature[0]=='empty':return np.empty((0,2)),np.empty(0)
    z,w=gauss(order)
    if signature[0]=='full':
        x=x0+(z+1)*(x1-x0)/2;y=y0+(z+1)*(y1-y0)/2
        points=np.stack(np.meshgrid(x,y,indexing='ij'),axis=-1).reshape(-1,2)
        return points,(np.outer(w,w)*(x1-x0)*(y1-y0)/4).ravel()
    breaks=[x0,x1]
    local_holes=signature[1]
    for cx,cy,r in local_holes:
        breaks.extend([cx-r,cx+r])
        for y in (y0,y1,min(y1,geometry.top)):
            v=r*r-(y-cy)**2
            if v>0:
                dx=np.sqrt(v);breaks.extend([cx-dx,cx+dx])
    if geometry.roof:
        for (xa,ya),(xb,yb) in zip(geometry.roof[:-1],geometry.roof[1:]):
            breaks.extend([xa,xb])
            if yb!=ya:
                for y in (y0,y1,geometry.top):
                    t=(y-ya)/(yb-ya)
                    if 0<t<1:breaks.append(xa+t*(xb-xa))
    breaks=np.unique([x0]+[x for x in breaks if x0<x<x1]+[x1])
    points=[];weights=[]
    for a,b in zip(breaks[:-1],breaks[1:]):
        # Sine mapping gives zero endpoint derivative and regularizes circular
        # square-root endpoints without altering the analytic trimming curve.
        if local_holes:
            theta=np.pi*z/2
            xs=(a+b)/2+(b-a)*np.sin(theta)/2
            wx=w*(b-a)*np.pi*np.cos(theta)/4
        else:
            xs=(a+b)/2+(b-a)*z/2
            wx=w*(b-a)/2
        for x,vx in zip(xs,wx):
            for lo,hi in geometry.intervals(float(x),y0,y1):
                ys=lo+(z+1)*(hi-lo)/2
                points.append(np.column_stack((np.full(len(z),x),ys)))
                weights.append(vx*w*(hi-lo)/2)
    if not points:return np.empty((0,2)),np.empty(0)
    return np.concatenate(points),np.concatenate(weights)
