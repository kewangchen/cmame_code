"""Equilibrated PCG, current-matrix residuals, and independent direct references."""
from time import perf_counter
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import cg, splu, LinearOperator
from .preconditioners import build_schwarz, jacobi, coordinate_deflation


def equilibrate(A,b):
    d=1/np.sqrt(A.diagonal())
    C=(sparse.diags(d)@A@sparse.diags(d)).tocsr()
    return C,d*b,d


def direct_reference(system):
    C,f,d=equilibrate(system.A,system.b)
    start=perf_counter();lu=splu(C.tocsc());setup=perf_counter()-start
    start=perf_counter();x=d*lu.solve(f);solve=perf_counter()-start
    return x,dict(setup=setup,solve=solve,linear=setup+solve)


def solve(system,method,cache=None,step=0,tau=.2,width=6,reference=None,maxiter=1500,history=False,x0=None,spectral_cap=128,probability_state=None):
    start=perf_counter();stats={};A=system.A;b=system.b
    C,f,d=equilibrate(A,b)
    if method=='direct':
        lu=splu(C.tocsc());M=None
    elif method=='jacobi':M=jacobi(C)
    elif method=='deflation':M=coordinate_deflation(C,system.weak_rows)
    else:
        kind='cbas' if method=='cbas' else 'overlap'
        policy={'cbas':'fresh','energy':'prob_energy','energy_raw':'prob_energy','energy_deterministic':'energy'}.get(method,method)
        blocks=system.blocks(kind,width=width)
        M,cache,stats=build_schwarz(A if method=='energy_raw' else C,blocks,system.ids,mode=policy,cache=cache,tau=tau,step=step,changed_global_ids=system.changed_ids,spectral_cap=spectral_cap,probability_state=probability_state)
    setup=perf_counter()-start;residuals=[];its=[0]
    def callback(y):
        its[0]+=1
        if history:residuals.append(float(np.linalg.norm(C@y-f)/np.linalg.norm(f)))
    start=perf_counter()
    if method=='direct':y=lu.solve(f);info=0
    else:
        if method=='energy_raw':
            def scaled(v):return (M@(v/d))/d
            scaled_M=LinearOperator(A.shape,matvec=scaled,rmatvec=scaled,dtype=float)
        else:scaled_M=M
        y,info=cg(C,f,x0=None if x0 is None else x0/d,M=scaled_M,rtol=1e-9,atol=0,maxiter=maxiter,callback=callback)
    elapsed=perf_counter()-start;x=d*y
    r=b-A@x
    result=dict(method=method,step=step,setup=setup,solve=elapsed,linear=setup+elapsed,
                assembly=system.assembly_seconds,total=system.assembly_seconds+setup+elapsed,
                iterations=its[0],info=int(info),scaled_residual=float(np.linalg.norm(d*r)/np.linalg.norm(d*b)),
                residual=float(np.linalg.norm(r)/np.linalg.norm(b)),dofs=len(b),
                changed_cells=system.changed_cells,cached_cells=system.cached_cells,
                weak=len(system.weak_rows),minimum_fraction=float(system.fractions[system.fractions>0].min()),
                measure=system.measure,tau=tau,width=width,warm_start=x0 is not None,**{('stat_'+k):v for k,v in stats.items()})
    if reference is not None:
        e=x-reference
        ae=A@e;value=float(e@ae);roundoff=64*np.finfo(float).eps*float(np.abs(e)@np.abs(ae))
        if value < -roundoff:raise FloatingPointError('Substantively negative energy error quadratic form')
        result['energy_error']=float(np.sqrt(max(0.,value)/(reference@(A@reference))))
    result['success']=bool(info==0 and np.isfinite(x).all() and result['scaled_residual']<=1e-8 and result['residual']<=1e-8 and result.get('energy_error',0)<=1e-6)
    if history:result['history']=residuals
    return x,cache,result
