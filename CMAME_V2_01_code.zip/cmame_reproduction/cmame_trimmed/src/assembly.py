"""Galerkin matrices on analytic trimmed domains; no fictitious material."""
from dataclasses import dataclass
from time import perf_counter
import itertools
import numpy as np
from scipy import sparse
from scipy.sparse.csgraph import connected_components
from .geometry import cut_quadrature, gauss


@dataclass
class System:
    A: object
    b: np.ndarray
    ids: np.ndarray
    A_full: object
    geometry: object
    measure: float
    fractions: np.ndarray
    changed_ids: np.ndarray
    changed_cells: int
    cached_cells: int
    assembly_seconds: float
    weak_rows: np.ndarray
    grid: object
    components: int

    def blocks(self,kind='overlap',width=4,overlap=1,weak_enrichment=True):
        lookup=np.full(self.grid.size*self.components,-1,dtype=int);lookup[self.ids]=np.arange(len(self.ids))
        blocks=[]
        if kind=='cbas':
            groups=[self.grid.cell_ids(cell) for cell,frac in zip(self.grid.cell_indices,self.fractions) if 0<frac<1-1e-10]
        elif kind=='overlap':
            groups=[]
            for macro in itertools.product(*[range(0,n,width) for n in self.grid.cells]):
                ranges=[np.arange(max(0,m-overlap),min(n,m+width+overlap)+p) for m,n,p in zip(macro,self.grid.cells,self.grid.degrees)]
                meshes=np.meshgrid(*ranges,indexing='ij')
                groups.append(np.ravel_multi_index(tuple(meshes),self.grid.shape).ravel())
        else:raise ValueError(kind)
        for scalar_ids in groups:
            bg=(scalar_ids[:,None]*self.components+np.arange(self.components)).ravel()
            rows=lookup[bg];rows=rows[rows>=0]
            if len(rows):blocks.append(rows)
        if weak_enrichment and kind=='overlap' and len(self.weak_rows):
            weak=self.weak_rows;graph=self.A[weak,:][:,weak].copy();graph.data[:]=1
            n,label=connected_components(graph,directed=False)
            blocks.extend(weak[label==i] for i in range(n))
        # Remove duplicate blocks; complete the cover with singleton Jacobi terms.
        if kind!='cbas':blocks=list({tuple(x):x for x in blocks}.values())
        covered=np.zeros(len(self.ids),dtype=bool)
        for x in blocks:covered[x]=True
        blocks.extend(np.array([i]) for i in np.flatnonzero(~covered))
        return blocks


class Assembler:
    def __init__(self,grid,physics='poisson',quadrature=None,load='body',bc='left',reaction=0.,young=1.,poisson=.3):
        self.grid=grid;self.physics=physics;self.components=grid.dim if physics=='elasticity' else 1
        self.quadrature_order=quadrature or grid.degree+4;self.load=load;self.bc=bc;self.reaction=float(reaction)
        self.mu=young/(2*(1+poisson));self.lam=young*poisson/((1+poisson)*(1-2*poisson))
        self.cache={};self.previous=None
        idx=np.array(np.unravel_index(np.arange(grid.size),grid.shape)).T
        self.fixed_scalar=(idx[:,0]==0) if bc=='left' else np.any((idx==0)|(idx==np.array(grid.shape)-1),axis=1)
        self.fixed=np.repeat(self.fixed_scalar,self.components)

    def exact(self,points):
        d=self.grid.dim;x=points
        if self.load=='affine':
            scalar=x[:,0];grad=np.zeros_like(x);grad[:,0]=1
        else:
            sine=np.sin(np.pi*x);cosine=np.cos(np.pi*x)
            scalar=np.prod(sine,axis=1)
            grad=np.stack([np.pi*cosine[:,a]*np.prod(np.delete(sine,a,axis=1),axis=1) for a in range(d)],axis=1)
            if self.bc=='left':scalar=x[:,0]+.1*scalar;grad=.1*grad;grad[:,0]+=1
        if self.components==1:return scalar,grad
        coefficients=np.array([1.,.2,.1][:d])
        return scalar[:,None]*coefficients,np.einsum('a,qb->qab',coefficients,grad)

    def quadrature(self,cell,geometry,order):
        bounds=self.grid.bounds(cell)
        points,w=cut_quadrature(bounds[:4],geometry,order)
        if self.grid.dim==2 or not len(w):return points,w
        z,wz=gauss(order);lo,hi=bounds[4:]
        z=lo+(z+1)*(hi-lo)/2;wz=wz*(hi-lo)/2
        q=np.column_stack((np.repeat(points,len(z),axis=0),np.tile(z,len(points))))
        return q,(w[:,None]*wz).ravel()

    def local_matrix(self,cell,geometry,order):
        points,w=self.quadrature(cell,geometry,order)
        scalar_ids=self.grid.cell_ids(cell);ids=(scalar_ids[:,None]*self.components+np.arange(self.components)).ravel()
        if not len(w):return ids,None,None,0.
        _,N,G=self.grid.local(cell,points)
        if self.components==1:
            K=np.einsum('qia,qja,q->ij',G,G,w,optimize=True)
            if self.reaction:K+=self.reaction*(N.T@(w[:,None]*N))
            if self.load=='body':f=N.T@w
            else:
                u,du=self.exact(points)
                f=np.einsum('qia,qa,q->i',G,du,w,optimize=True)+self.reaction*(N.T@(w*u))
        else:
            d=self.grid.dim
            H=np.einsum('qia,qjb,q->abij',G,G,w,optimize=True)
            K=self.mu*np.einsum('ab,ij->iajb',np.eye(d),np.einsum('aaij->ij',H))
            K+=self.mu*np.einsum('baij->iajb',H)+self.lam*np.einsum('abij->iajb',H)
            K=K.reshape(len(ids),len(ids))
            if self.load=='body':
                force=np.zeros(d);force[-1]=-1
                f=((N.T@w)[:,None]*force).ravel()
            else:
                u,du=self.exact(points);strain=(du+du.swapaxes(1,2))/2
                stress=2*self.mu*strain+self.lam*np.trace(strain,axis1=1,axis2=2)[:,None,None]*np.eye(d)
                f=np.einsum('qib,qab,q->ia',G,stress,w,optimize=True).ravel()
        return ids,(K+K.T)/2,f,float(w.sum())

    def assemble(self,geometry):
        start=perf_counter();rows=[];cols=[];values=[];rhs=np.zeros(self.grid.size*self.components)
        fractions=[];changed=[];changed_count=0;cached=0;measure=0.;strong=np.zeros(self.grid.size,dtype=bool)
        full_measure=1/np.prod(self.grid.cells)
        for cell in self.grid.cell_indices:
            signature=geometry.signature(self.grid.bounds(cell)[:4])
            previous=self.cache.get(cell)
            if previous is not None and signature==previous[0]:
                record=previous[1];cached+=1
            else:
                record=self.local_matrix(cell,geometry,self.quadrature_order)
                self.cache[cell]=(signature,record);changed_count+=1;changed.extend(record[0])
            ids,K,f,volume=record;measure+=volume
            fraction=volume/full_measure;fractions.append(fraction)
            if signature[0]=='full':strong[self.grid.cell_ids(cell)]=True
            if K is None:continue
            rows.append(np.repeat(ids,len(ids)));cols.append(np.tile(ids,len(ids)));values.append(K.ravel())
            rhs[ids]+=f
        n=len(rhs)
        A=sparse.coo_matrix((np.concatenate(values),(np.concatenate(rows),np.concatenate(cols))),shape=(n,n)).tocsr()
        A.sum_duplicates();A.eliminate_zeros()
        diag=A.diagonal();active=diag>0
        if np.any(diag<0):raise ArithmeticError('negative assembled diagonal')
        free=np.flatnonzero(active&~self.fixed)
        weak=np.flatnonzero(~np.repeat(strong,self.components)[free])
        result=System(A[free,:][:,free].tocsr(),rhs[free],free,A,geometry,measure,np.asarray(fractions),np.unique(changed),changed_count,cached,perf_counter()-start,weak,self.grid,self.components)
        self.previous=result
        return result

    def errors(self,system,coefficients,quadrature=None):
        full=np.zeros(self.grid.size*self.components);full[system.ids]=coefficients
        l2=h1=exact_l2=exact_h1=0.
        for cell in self.grid.cell_indices:
            points,w=self.quadrature(cell,system.geometry,quadrature or self.quadrature_order+4)
            if not len(w):continue
            ids,N,G=self.grid.local(cell,points);u,du=self.exact(points)
            if self.components==1:
                c=full[ids];uh=N@c;duh=np.einsum('qia,i->qa',G,c)
                l2+=w@((uh-u)**2);h1+=w@np.sum((duh-du)**2,axis=1)
                exact_l2+=w@(u*u);exact_h1+=w@np.sum(du*du,axis=1)
            else:
                c=full.reshape(-1,self.components)[ids];uh=N@c;duh=np.einsum('qib,ia->qab',G,c)
                l2+=w@np.sum((uh-u)**2,axis=1);h1+=w@np.sum((duh-du)**2,axis=(1,2))
                exact_l2+=w@np.sum(u*u,axis=1);exact_h1+=w@np.sum(du*du,axis=(1,2))
        return dict(L2=float(np.sqrt(l2)),H1_seminorm=float(np.sqrt(h1)),relative_L2=float(np.sqrt(l2/exact_l2)),relative_H1_seminorm=float(np.sqrt(h1/exact_h1)))
