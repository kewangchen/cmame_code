"""Geometry, Galerkin assembly, and solver kernels."""
