"""Evidence-based Chinese audit and editorial draft for author review."""
from pathlib import Path
import json,statistics,hashlib,re
ROOT=Path(__file__).resolve().parent;R=ROOT/'results';P=ROOT/'paper'
facts=json.loads((R/'paper_facts.json').read_text());summary=json.loads((R/'summary.json').read_text())['cases']
names={'moving_hole':'移动圆孔','local_plate':'四孔板局部修改','active_crossing':'活动空间跨结点变化','elastic_plate':'平面应变板','elastic_solid':'三维挤出弹性体','large_plate':'加密四孔板','ridge':'折线裁剪边界'}
source_checks={}
for name in ['benchmark_source_hashes','ablation_source_hashes','static_source_hashes']:
    manifest=json.loads((R/(name+'.json')).read_text())
    source_checks[name]=all(hashlib.sha256((ROOT/k).read_bytes()).hexdigest()==v for k,v in manifest.items())
    assert source_checks[name]
counts={};failed={};exceptions={}
for n in ['sequence_'+n for n in names]+['ablation_screening','ablation_block_size','update_sensitivity','cut_study']:
    d=json.loads((R/(n+'.json')).read_text());counts[n]=len(d['rows']);failed[n]=sum(not x['success'] for x in d['rows']);exceptions[n]=len(d.get('failures',[]))
assert all(counts['sequence_'+n]==396 for n in names)
assert counts['ablation_screening']==192 and counts['ablation_block_size']==288 and counts['update_sensitivity']==1440 and counts['cut_study']==180
assert sum(failed.values())==0 and sum(exceptions.values())==0
v=dict(source_hashes_match=source_checks,solve_counts=counts,total_checked_solves=sum(counts.values()),failed_solution_accuracy_checks=failed,exceptions=exceptions)
(R/'verification.json').write_text(json.dumps(v,indent=2))
rows=[]
for n,label in names.items():
    x=summary[n];e=x['energy'];best=min(x,key=lambda k:x[k]['linear'])
    rows.append(f"| {label} | {e['nmin']:,}–{e['nmax']:,} | {x['fresh']['linear']:.3f} | {x['exact_local']['linear']:.3f} | {e['linear']:.3f} | {x['exact_local']['linear']/e['linear']:.3f} | {best}: {x[best]['linear']:.3f} |")
solid=json.loads((R/'sequence_elastic_solid.json').read_text())['rows'];paired=[]
for rep in range(3):
    t={m:sum(r['linear'] for r in solid if r['method']==m and r['repeat']==rep) for m in ['energy','exact_local','fresh']}
    paired.append(t['exact_local']/t['energy'])
text=f'''# 最终稿件审核：变化裁剪域的 Schwarz 因子复用

本审核属于工具辅助的内部理论、实现、数据和稿件检查，不是编辑部或外部专家的正式审稿意见。

版本日期：2026-10-16。最终方法采用尺度传输、高斯累计能量检测与 288 维成本门槛。以下全部时间来自最终重跑，不混入无门槛探索数据。

## 审核结论

**已经形成可审阅、可复现的完整研究稿；当前建议继续大修，不建议仅凭本轮结果直接向 CMAME 投稿。** 数学分析在明确假设下成立，已运行的数值解满足精度检查，稿件与代码可以交由作者逐项审核。主要不足是：相对于最强匹配基线“精确局部更新”，跨案例平均收益仍较小；外部更便宜的求解器在当前规模占优势；工程级规模、多块 CAD 和多层求解尚未验证。

本轮工作的意义在于给出“旧局部因子还能用到什么程度”的可计算能量准则，并把当前尺度、历史锚点、活动基函数和整条序列的风险预算一致地组织起来。它支持受控维护既有 Schwarz 求解器这一定位，不能据此宣称普遍最快或解决了任意裁剪 IGA 的稳健求解问题。

## 主要结果

七个主序列家族共 2772 次求解，均为 12 个几何查询、3 次完整重复、11 种方法。加上更新幅度、较长序列、筛查参数、分块尺寸和静态小裁剪实验，共 **{sum(counts.values()):,} 次带残差和参考能量检查的求解**，失败检查 {sum(failed.values())} 次、捕获异常 {sum(exceptions.values())} 次。最大主序列自由度 {facts['max_dofs']:,}；主序列最大物理相对残差 {facts['max_residual']:.3e}，最大相对能量差 {facts['max_energy_error']:.3e}。

时间单位为秒，取三次“全序列累计 setup+solve”之中位数。最后一列保留全部方法中实际最快者。加速比大于 1 才表示优于精确局部更新。

| 案例 | 自由度 | 每步全重建 | 精确局部更新 | 本文方法 | 对精确局部更新加速比 | 最快方法及时间 |
|---|---:|---:|---:|---:|---:|---|
'''+ '\n'.join(rows)+f'''

七家族等权几何平均加速：对全重建 **{facts['gm_vs_fresh']:.3f} 倍**，对精确局部更新 **{facts['gm_vs_exact_local']:.3f} 倍**。三维挤出弹性例的 setup 加速为 **{facts['solid_setup_speedup']:.3f} 倍**，setup+solve 对精确局部更新为 **{facts['solid_linear_vs_exact']:.3f} 倍**；三次配对重复分别为 {', '.join(f'{x:.3f}' for x in paired)} 倍。小的百分比差异只作为测量结果，不作显著性或普遍优势判断。

移动圆孔、活动空间跨结点和折线边界三类未触发随机检测，因子分解次数也与精确局部更新相同；它们的小幅计时差异不能作为接受非零漂移带来加速的证据。

这些时间包含缩放、分块、抽取、检测、因子分解和当前求解；另有含装配的表格。初值标识传输、独立验证参考解、解后验证和文件输出不在计时内。本文未把这些计时称为完整应用墙钟时间。范围条表示观测重复区间，不是置信区间。

## 创新与既有方法的边界

| 可成立的贡献 | 理论或实现证据 | 不能扩大为 |
|---|---|---|
| 当前对角尺度传输归一化局部因子，剥离时间变化中的幅值效应 | 正对角重标定不变性、齐次 Gram 及非齐次局部极限推导 | 对角缩放本身的新发现；任意基下的不变性 |
| 对历史锚点的累计能量检测，配合整条运行的风险预算 | 高斯幂估计、条件概率与可求和并集界；计数器不按查询重置 | 新的高斯集中不等式；双精度下所有错误的概率证书 |
| 活动空间变化下相对于当前 fresh 求解器的谱继承 | 局部逆 Loewner 比较求和，条件数膨胀至多 (1+τ)/(1−τ) | 自动获得 cut/h/p 无关稳健性；通用最优解法 |
| 小块直接重建，大块检测；完整记录拒绝检测费用 | 12qs=288 的领先算术成本规则及无门槛消融 | 已证明的硬件最优阈值 |
| 非齐次局部限制的条件渐近结果 | 首项梯度 Gram 正定时归一化漂移 O(ε)，给出统一可复用区域和反例 | 任意 B-spline Schwarz 块均满足首项正定条件 |

部分 Schwarz 更新、对角平衡、高斯范数估计及局部谱比较各有前人基础，正文已讨论 Berenguer、Svolos、de Prenter、Halko、Kolombage 等相关工作。贡献应表述为具体维护算法、机制分析与完整成本验证。定向文献检索不是优先权证明；部分近邻论文仅取得摘要或公开会议版本，仍值得作者核对完整原文。

## 理论、实现和图表核对

- 主定理针对精确 SPD 矩阵和精确算术。δ 仅控制错误保留局部因子的高斯低估事件，不包括积分误差、舍入误差或全部求解故障。
- τ=0.2 的理论谱区间为 [0.8,1.2]，独立稠密谱审计实测 [{facts['spectral_range'][0]:.6f},{facts['spectral_range'][1]:.6f}]；最大局部真实漂移 {facts['spectral_max_drift']:.6f}，最大条件数比 {facts['condition_ratio']:.6f}，上界为 1.5。小型谱审计明确关闭尺寸门槛，以实际触发检测。
- 47 项测试覆盖离散与代数实现；渐近机制另用 80 个尺度验证显式不等式。测试通过不等于已经验证 10⁻⁸ 级事件概率。
- 已修复异常后缓存滞留造成的支撑闭包失配；失败后清除该方法缓存，保留风险计数器。此前谱条件数记号、fresh 预条件后算子与其逆的区别、每条序列概率口径和计时范围均已修正。
- 所有基准都求解当前相同的 Galerkin 系统，不删除非零支撑基函数、不加隐藏对角正则。2D 弹性为平面应变，3D 为挤出域。裁剪边界使用自然条件，左边界强制约束。
- CbAS 与坐标消去使用本地重实现；坐标消去是明确写出的平衡变体，并非作者原始软件的完整复现。原始锚点、确定性能量、陈旧/周期更新都保留在比较中。
- 图形由 Python 绘制。几何场图来自保存的参考 B-spline 系数，且所有方法均接受相应能量精度检查；三维图显示未形变几何上的单位载荷响应，没有人为修饰计算位移。
- 主序列和消融的执行源快照、哈希、种子、线程数与原始数据一并交付。最终源文件逐项通过哈希一致性检查。

## 阻止“立即投稿”的主要科学问题

1. **相对最强匹配基线的价值。** 当前总体增益尚小，局部案例也会变慢。较大局部因子的三维收益构成有效现象，但尚不足以证明广泛工程收益。
2. **外部求解器与基础方法。** 当前规模下，Jacobi 或其他低设置成本方法更快；一层大块 Schwarz 的应用成本和 Python 实现开销仍明显。需要成熟多层/域分解实现与较大工程系统，才能区分维护策略收益和基础实现选择。
3. **工程覆盖与规模。** 算例包括解析圆孔、折线边界及挤出体，最大约 8700 自由度；未包含真实多块 CAD、任意三维裁剪、非线性材料或并行扩展。24 查询敏感性试验拓展了时间与编辑幅度，但不能替代这些验证。
4. **理论贡献深度。** 已有推导自洽且具体，主要使用标准概率和矩阵比较工具；条件渐近命题增加了机制解释，但其首项正定假设可能在一般局部样条块上失效。若要增强 CMAME 定位，应将该条件与真实局部分块或多层结构建立可验证联系。

建议下一轮优先完成一个真正困难、可重复的大型三维或多块工程问题，并用经过验证的成熟求解器作强基线；再决定是否扩展多层理论与实现。继续增加相似小型例子的数量，对弥补上述问题帮助有限。

## 作者与投稿事实

已填入 Kewang Chen、南京信息工程大学数学与统计学院、地址及通讯邮箱。作者已确认本稿无基金资助、无利益冲突，正文已注明。作者最终审核和新稿独家投稿声明仍需确认，不能继承此前另一篇 TOG 稿件的声明。AI 在检索、推导、代码和写作中的实质参与已如实披露。

当前 CMAME 官方作者指南未能成功读取，匿名方式等期刊专属要求尚未核实。本包采用 Elsevier elsarticle、编号引文和单文件正文；Highlights 为四条且每条不超过 85 字符。实际上传前应在[官方作者指南](https://www.sciencedirect.com/journal/computer-methods-in-applied-mechanics-and-engineering/publish/guide-for-authors)或投稿系统核对要求。本轮完成的是论文准备和审核，没有执行投稿或对外发布。
'''
(ROOT/'FINAL_REVIEW_zh.md').write_text(text)
readme=f'''# CMAME 研究稿与最终审核交付

题目：Risk-controlled reuse of local Schwarz solvers for evolving trimmed spline discretizations
作者：Kewang Chen

请先阅读 `FINAL_REVIEW_zh.md`。本次交付包含完整稿件和可复现实验，但审核建议继续大修后再投 CMAME；当前对最强匹配基线的总体收益约为 {facts['gm_vs_exact_local']:.3f} 倍，尚未形成广泛工程优势。

- `manuscript/manuscript.pdf`：英文主文。
- `manuscript/manuscript.tex`：所有章节合并后的单文件 LaTeX。
- `manuscript/supplement.pdf` 与 `.tex`：完整附加推导、参数、方法比较、逐度数小裁剪表和复现细节。
- `manuscript/figures/`：正式矢量 PDF 图稿。
- `manuscript/highlights.txt`：四条贡献摘要。
- `editorial/cover_letter_draft.txt`：供作者审阅的投稿附信草稿，未代填未确认声明。
- `01_numerical_code.zip`：代码、测试、绘图与论文重建脚本。
- `02_results_and_figures.zip`：原始 JSON、解系数、源快照、图稿及验证记录。
- `archive_manifest.json` 与 `SHA256SUMS.txt`：归档大小及完整性校验。

两个压缩包各自可独立解压，解压后让两个目录并列放置。进入 `01_numerical_code`，执行 `python prepare_data.py`，即可把数据准备到代码需要的位置。随后按该目录的 README 创建 Python 环境、运行测试或重建图表。

数值比较以真实执行数据为依据，共 {sum(counts.values()):,} 次带精度检查的求解。时间表包含三次完整重复；作者可以查看原始逐次计时，不必只依赖摘要加速比。源代码中没有下载外部数据或上传数据的步骤，也不打包 Python 虚拟环境。

当前文件是作者审核版本。无基金资助和无利益冲突已由作者确认并写入正文；新稿独家投稿与作者最终批准仍待核实；当前 CMAME 专属上传要求须在官方入口确认。
'''
(ROOT/'README_zh.md').write_text(readme)
letter=f'''DRAFT FOR AUTHOR REVIEW

Dear Editor,

Please consider the manuscript "Risk-controlled reuse of local Schwarz solvers for evolving trimmed spline discretizations" by Kewang Chen for Computer Methods in Applied Mechanics and Engineering.

Repeated analysis after trimming changes creates a practical tension between maintaining useful local factorizations and preserving the quality of the current preconditioner. This manuscript develops a quantitative maintenance policy for additive Schwarz solvers. Current diagonal scales transport normalized factors, and fresh Gaussian power actions test their cumulative energy discrepancy from stored anchors. A persistent summable risk budget connects adaptive local decisions to a simultaneous relative-to-fresh spectral bound, including changes in the active spline space.

The analysis separates basis-amplitude deterioration from changing near dependence. It includes a conditional nonhomogeneous small-cut limit, an explicit reusable region, a cumulative-drift counterexample and a sharp global comparison. The implementation rebuilds small changed blocks directly and includes all screening and failed-screen costs in the measured setup time.

The numerical study includes seven evolving-domain families, Poisson and linear elastic models, changing active sets, cut-size and discretization checks, parameter and block-size ablations, and longer paths with varied edit magnitudes. The primary geometric-mean setup-plus-solve gains are {facts['gm_vs_fresh']:.2f}-fold over full reconstruction and {facts['gm_vs_exact_local']:.2f}-fold over exact local refresh. The extruded elastic example gives a {facts['solid_setup_speedup']:.2f}-fold setup improvement. Comparisons with Jacobi, connectivity-based Schwarz, coordinate deflation and sparse direct solution identify the costs and the applicable regime of local-factor maintenance.

The accompanying supplementary material contains additional proofs and complete tables. The numerical source, recorded measurements, source hashes and plotting scripts are supplied in two compact archives. The manuscript discloses AI-assisted research and writing.

Corresponding author:
Kewang Chen
College of Mathematics and Statistics
Nanjing University of Information Science and Technology
Nanjing, 210044, China
kwchen@nuist.edu.cn

[Author review note: confirm submission exclusivity and author approval for this manuscript before using this letter. The author has confirmed no external funding and no competing interests. These declarations have not been inferred from the separate TOG manuscript.]
'''
(P/'cover_letter_draft.txt').write_text(letter)
print(json.dumps(v,indent=2))
