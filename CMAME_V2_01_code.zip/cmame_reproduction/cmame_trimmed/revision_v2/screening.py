"""Progressive Gaussian energy screening; the original implementation is frozen.

All powers of one fixed local drift use one fresh Gaussian block and ONE
small-ball event. Early acceptance therefore spends no extra failure budget.
Early rejection uses a deterministic induced-norm lower bound. Statements are
in exact arithmetic; numerical results remain floating-point diagnostics.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from math import exp
from types import FunctionType

import numpy as np
from scipy import linalg

from cmame_trimmed.src import preconditioners as baseline


@dataclass(frozen=True)
class ProgressiveEnergyBudget(baseline.EnergyBudget):
    """One independent, sequential budget for an entire adaptive sequence.

    ``power`` is the maximum power, with stopping possible at every power.
    ``min_dimension`` retains the original strict skip rule: changed blocks of
    dimension <= min_dimension are refreshed without drawing any probes.
    ``dimension_cost_cap`` caps actions at min(power, max(1, m//(12*s)))
    from an approximate dense-action/factorization flop comparison. It is a
    workload heuristic and does not affect the common-event probability bound.
    Counters count work even when a screen fails or subsequently refreshes.
    """
    dimension_cost_cap: bool = False
    cost_capped_checks: int = field(default=0, init=False)
    cost_cap_avoided_action_batches: int = field(default=0, init=False)
    last_effective_power: int = field(default=0, init=False)
    effective_power_histogram: dict = field(default_factory=dict, init=False, repr=False, compare=False)
    action_batches: int = field(default=0, init=False)
    column_actions: int = field(default=0, init=False)
    early_accepts: int = field(default=0, init=False)
    early_rejections: int = field(default=0, init=False)
    lower_bound_rejections: int = field(default=0, init=False)
    avoided_action_batches: int = field(default=0, init=False)
    power_histogram: dict = field(default_factory=dict, init=False, repr=False, compare=False)
    last_lower_bound: float = field(default=0., init=False)

    def __post_init__(self):
        if type(self.dimension_cost_cap) is not bool:
            raise ValueError('dimension_cost_cap must be a bool')
        super().__post_init__()

    def effective_power(self, dimension):
        """Maximum actions allowed by the optional dense-flop cost heuristic."""
        if (not isinstance(dimension, (int, np.integer))
                or isinstance(dimension, (bool, np.bool_)) or dimension < 1):
            raise ValueError('dimension must be a positive integer')
        if not self.dimension_cost_cap:
            return self.power
        return min(self.power, max(1, dimension//(12*self.probes)))

    def _increment(self, name, amount=1):
        object.__setattr__(self, name, getattr(self, name)+amount)

    def _finish(self, power, accepted, lower_rejection, effective_power):
        self.power_histogram[power] = self.power_histogram.get(power, 0)+1
        self._increment('avoided_action_batches', effective_power-power)
        if accepted and power < effective_power:
            self._increment('early_accepts')
        if lower_rejection:
            self._increment('lower_bound_rejections')
            if power < effective_power:
                self._increment('early_rejections')


def _normalize_columns(action):
    """Stable Euclidean norms and unit columns; zero columns remain zero."""
    scales = np.max(np.abs(action), axis=0)
    live = scales != 0
    vectors = np.zeros_like(action)
    vectors[:, live] = action[:, live]/scales[live]
    lengths = np.sqrt(np.sum(vectors[:, live]*vectors[:, live], axis=0))
    vectors[:, live] /= lengths
    log_lengths = np.full(action.shape[1], -np.inf)
    log_lengths[live] = np.log(scales[live])+np.log(lengths)
    return vectors, log_lengths


def _finite_exp(log_value, label):
    if log_value == -np.inf:
        return 0.
    try:
        value = exp(log_value)
    except OverflowError as exc:
        raise FloatingPointError(label+' overflowed') from exc
    if not np.isfinite(value):
        raise FloatingPointError('Nonfinite '+label)
    return value


def progressive_bound(factor, change, state, tau=.2, validate=True):
    """Return a progressive upper estimate for ||L^-1 change L^-T||_2.

    ``change`` is the drift already divided by the anchor diagonal scales.
    The candidate/factor must be fixed before the fresh block is drawn. At
    power q the estimate is (alpha max_j ||K^q omega_j||)^(1/q). On a single
    event of probability >= 1-delta_j all these estimates are upper bounds.
    Return at the first accepted estimate, a deterministic lower rejection,
    or the maximum power. A returned value > tau means refresh, not reuse.
    ``validate=False`` is reserved for the builder callback, whose sparse
    matrix and anchor have already been checked; finite actions are always
    checked. Public direct calls validate by default.
    """
    dimension = len(factor.scale)
    if validate:
        if not isinstance(state, ProgressiveEnergyBudget):
            raise TypeError('state must be a ProgressiveEnergyBudget')
        if not np.isfinite(tau) or not 0 <= tau < 1:
            raise ValueError('tau must be finite and in [0, 1)')
        change = np.asarray(change, dtype=float)
        if change.shape != (dimension, dimension) or not np.all(np.isfinite(change)):
            raise ValueError('change must be a finite square matrix matching the factor')
        symmetry = np.max(np.abs(change-change.T), initial=0.)
        if symmetry > 64*np.finfo(float).eps*max(1., np.max(np.abs(change), initial=0.)):
            raise ValueError('change must be symmetric to floating-point tolerance')

    effective_power = state.effective_power(dimension)
    vectors, log_alpha = state.draw(dimension)
    object.__setattr__(state, 'last_effective_power', effective_power)
    state.effective_power_histogram[effective_power] = state.effective_power_histogram.get(effective_power, 0)+1
    if effective_power < state.power:
        state._increment('cost_capped_checks')
        state._increment('cost_cap_avoided_action_batches', state.power-effective_power)
    # Keep the first action identical to the frozen baseline. The input norm is
    # only needed for deterministic rejection and need not normalize the probe.
    _, log_initial_lengths = _normalize_columns(vectors)
    log_magnitudes = np.zeros(state.probes)
    with np.errstate(over='raise', invalid='raise', divide='raise'):
        for power in range(1, effective_power+1):
            state._increment('action_batches')
            state._increment('column_actions', state.probes)
            if dimension == 1:
                action = change@vectors
            else:
                intermediate = linalg.solve_triangular(factor.cholesky, vectors, lower=True,
                                                       trans='T', check_finite=False)
                action = linalg.solve_triangular(factor.cholesky, change@intermediate,
                                                lower=True, check_finite=False)
            if not np.all(np.isfinite(action)):
                raise FloatingPointError('Nonfinite progressive energy action')
            vectors, log_lengths = _normalize_columns(action)
            log_magnitudes += log_lengths
            # Both lower bounds are deterministic: the current induced action
            # ratio and the q-th root of the accumulated induced action ratio.
            input_lengths = log_initial_lengths if power == 1 else np.zeros(state.probes)
            log_local_lower = float(np.max(log_lengths-input_lengths))
            log_power_lower = float(np.max(log_magnitudes-log_initial_lengths))/power
            lower = _finite_exp(max(log_local_lower, log_power_lower), 'energy lower bound')
            object.__setattr__(state, 'last_lower_bound', lower)
            bound = _finite_exp((log_alpha+float(np.max(log_magnitudes)))/power,
                                'progressive energy bound')
            lower_rejection = lower > tau
            accepted = bound <= tau and not lower_rejection
            if accepted or lower_rejection or power == effective_power:
                state._finish(power, accepted, lower_rejection, effective_power)
                # On the overwhelmingly likely common event bound >= lower.
                # Fail closed even if that event fails and the lower bound
                # proves that an apparently accepted upper estimate is false.
                return max(bound, lower) if lower_rejection else bound
    raise AssertionError('positive maximum power must terminate')


_COUNTERS = ('action_batches', 'column_actions', 'early_accepts', 'early_rejections',
             'lower_bound_rejections', 'avoided_action_batches',
             'cost_capped_checks', 'cost_cap_avoided_action_batches')


def build_progressive_schwarz(A_csr, blocks, global_ids, mode='prob_energy', cache=None,
                              tau=.2, step=0, period=5, diagnostics=False,
                              changed_global_ids=None, spectral_cap=32,
                              probability_state=None):
    """Frozen Schwarz builder with only its private bound callback replaced.

    A new function object reuses the original bytecode with a private globals
    dictionary. This does not patch the original module or share callbacks
    between calls. All extraction, cache/provenance, factor, and solve behavior
    therefore comes from the exact original builder. Each call adds work
    counters prefixed ``screen_`` and cumulative state counters.
    """
    if mode == 'prob_energy' and not isinstance(probability_state, ProgressiveEnergyBudget):
        raise TypeError('prob_energy requires a ProgressiveEnergyBudget')
    state = probability_state
    before = {name: getattr(state, name, 0) for name in _COUNTERS}
    histogram_before = dict(state.power_histogram) if isinstance(state, ProgressiveEnergyBudget) else {}
    effective_before = dict(state.effective_power_histogram) if isinstance(state, ProgressiveEnergyBudget) else {}
    max_lower = [0.]

    def callback(factor, change, budget):
        bound = progressive_bound(factor, change, budget, tau=tau, validate=False)
        max_lower[0] = max(max_lower[0], budget.last_lower_bound)
        return bound

    namespace = dict(baseline.build_schwarz.__globals__)
    namespace['_probabilistic_bound'] = callback
    builder = FunctionType(baseline.build_schwarz.__code__, namespace,
                           'build_progressive_schwarz_core', baseline.build_schwarz.__defaults__,
                           baseline.build_schwarz.__closure__)
    op, current, stats = builder(A_csr, blocks, global_ids, mode=mode, cache=cache,
                                tau=tau, step=step, period=period, diagnostics=diagnostics,
                                changed_global_ids=changed_global_ids, spectral_cap=spectral_cap,
                                probability_state=state)
    for name in _COUNTERS:
        after = getattr(state, name, 0)
        stats['screen_'+name] = after-before[name]
        stats['cumulative_screen_'+name] = after
    stats['screen_power_histogram'] = ({str(q): count-histogram_before.get(q, 0)
                                      for q, count in state.power_histogram.items()
                                      if count != histogram_before.get(q, 0)}
                                     if isinstance(state, ProgressiveEnergyBudget) else {})
    stats['screen_effective_power_histogram'] = (
        {str(q): count-effective_before.get(q, 0)
         for q, count in state.effective_power_histogram.items()
         if count != effective_before.get(q, 0)}
        if isinstance(state, ProgressiveEnergyBudget) else {})
    stats['screen_dimension_cost_cap'] = getattr(state, 'dimension_cost_cap', False)
    stats['screen_max_lower_bound'] = max_lower[0]
    stats['screen_kind'] = 'progressive_same_probe'
    return op, current, stats
