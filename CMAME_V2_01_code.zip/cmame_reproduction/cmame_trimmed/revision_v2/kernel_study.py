"""Local-factor crossover using principal blocks of actual 3D IGA matrices."""
from pathlib import Path
from time import perf_counter
import json,gc
import numpy as np
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.geometry import TrimDomain
from cmame_trimmed.src.solver import equilibrate
from cmame_trimmed.src.preconditioners import EnergyBudget,LocalFactor,_probabilistic_bound
from .tensor_assembly import TensorAssembler
from .screening import ProgressiveEnergyBudget,progressive_bound
from scipy import linalg
ROOT=Path(__file__).resolve().parent

def run():
 from .campaign import freeze
 manifest=freeze()
 assert not (ROOT/'results/kernel_formal.json').exists(), 'Formal file already exists'
 a=TensorAssembler(SplineGrid((12,12,6),3),physics='elasticity',quadrature=12)
 systems=[a.assemble(TrimDomain(holes=((.47+dt,.51,.173),))) for dt in [0.,.00005,.0005,.005]]
 common=set.intersection(*[set(s.ids.tolist()) for s in systems]);blocks=systems[0].blocks(width=6)
 bg=max([s0.ids[b] for b in blocks if len(b)>288 for s0 in systems[:1]],key=len)
 bg=np.array([x for x in bg if x in common]);matrices=[]
 for s in systems:
  C,_,_=equilibrate(s.A,s.b);idx=np.searchsorted(s.ids,bg);matrices.append(C[idx,:][:,idx].toarray())
 rows=[];configs={'fixed12x2':(12,2,False),'adaptive8x3':(8,3,True),'adaptive4x6':(4,6,True),'adaptive12x2':(12,2,True),'progressive':(12,6,True)}
 for size in [64,128,256,512,1024,1536,2048,len(bg)]:
  select=np.unique(np.linspace(0,len(bg)-1,size,dtype=int));H=matrices[0][np.ix_(select,select)];factor=LocalFactor.factor(H)
  for k,dt in enumerate([.00005,.0005,.005],1):
   current=matrices[k][np.ix_(select,select)]
   # Independent dense oracle outside every timed section.
   delta=(current-H)/factor.scale[:,None]/factor.scale[None,:]
   K=linalg.solve_triangular(factor.cholesky,delta,lower=True)
   K=linalg.solve_triangular(factor.cholesky,K.T,lower=True).T
   spectrum=linalg.eigvalsh(.5*(K+K.T));exact_drift=float(max(abs(spectrum[0]),abs(spectrum[-1])))
   for rep in range(5):
    methods=['fresh']+list(configs);methods=methods[rep%len(methods):]+methods[:rep%len(methods)]
    for method in methods:
     start=perf_counter();power=columns=0;bound=None;accepted=False;screen=0.
     if method=='fresh':new=LocalFactor.factor(current)
     else:
      probes,maxpower,progressive=configs[method];cls=ProgressiveEnergyBudget if progressive else EnergyBudget
      state=cls(seed=202610160+rep,probes=probes,power=maxpower,**({'dimension_cost_cap':True} if method=='progressive' else {}))
      # A prescribed later check index stresses the summable multiplier.
      object.__setattr__(state,'count',999)
      delta=(current-H)/factor.scale[:,None]/factor.scale[None,:]
      bound=progressive_bound(factor,delta,state,tau=.2,validate=False) if progressive else _probabilistic_bound(factor,delta,state)
      screen=perf_counter()-start;accepted=bool(bound<=.2)
      power=state.action_batches if progressive else maxpower;columns=power*probes
      if not accepted:new=LocalFactor.factor(current)
     elapsed=perf_counter()-start
     rows.append(dict(exact_drift=exact_drift,size=len(select),increment=dt,repeat=rep,method=method,seconds=elapsed,screen_seconds=screen,accepted=accepted,bound=bound,powers=power,column_actions=columns))
   print('kernel',len(select),dt,flush=True)
   (ROOT/'results/kernel_formal.json').write_text(json.dumps(dict(source_hashes=manifest['source_hashes'],config=dict(cells=[12,12,6],degree=3,width=6,physics='elasticity',quadrature=12,check_index=1000,tau=.2,repeats=5,sizes=[64,128,256,512,1024,1536,2048,len(bg)],increments=[.00005,.0005,.005]),rows=rows),indent=2,allow_nan=False))
 del systems,matrices;a=None;gc.collect()
if __name__=='__main__':run()
