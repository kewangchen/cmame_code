# 最终摘要与引言静态审读

审读日期：2026-10-16。读取当前 `abstract_template.tex`、`introduction.tex`，对照 `locality_rank_main.tex`、`locality_rank_supp.tex`、独立代数审读和 JSR 条目。未修改被审文件，未导入数值库、构建、编译或运行实验。前瞻计时尚未完成，本记录不作最终速度判断。

当前主线已经清楚：对角传输与真实累计 anchor 差异 → 同事件渐进筛查 → 变化活动空间上的整序列谱比较 → 保持 capped 决策的 lookahead。JSR 被准确定位为公开代码，未伪装成已发表 CMAME 文献；没有发现 first、unique、普遍 cut/degree 独立性之类排他或过度创新宣称。无需再次整体重写。建议完成以下三项必要澄清。

## 1. rank/locality 的概述须保留固定成员与物理支撑假设

**位置：** `introduction.tex:105–109`。

“a change confined to a fixed set of coefficients” 没有明确是同一有序成员上的 physical current-minus-anchor 矩阵支撑。紧邻前面的变化活动空间定理，读者可能误以为新增/删除成员也直接适用这个 rank 比较。“ambient probe dimension” 还可能被误读成探针列数 `s`；这里替换的是高斯向量/局部块维度 `m`。

建议将这五行替换为：

```tex
For a block with unchanged ordered membership, suppose the physical
current-minus-anchor matrix is supported on $Z\times Z$. The rank of
the normalized, whitened discrepancy is then at most
$\min\{m,2|Z|\}$. A projected Gaussian estimate uses this rank in place
of the ambient block dimension to refine the sufficient power count.
Here $Z$ covers the full coefficient support of all changes since the
anchor. This refinement concerns the work analysis; the implementation
retains dense actions and the ambient-dimension cap.
```

前一段已有严格漂移余量、足够 cap、未截断等条件，不必在这段重复。`Z` 的累计 support closure 和 same membership 不能删；rank 小也不能单独推出漂移小。最后一句只需这一处，避免反复声明“没有实现低秩算法”。

## 2. 摘要中的工作界宜明确为 per-candidate 的条件分析

**位置：** `abstract_template.tex:12–13`。

“A strict drift margin gives a sufficient work bound, refined by the rank induced by localized changes” 把 rank 所指对象留得过宽，容易被理解为 physical update rank，或把前面的整序列概率保证延伸成整序列工作界。实际 rank 是 normalized discrepancy rank；其结构上界取决于累计系数支撑，且工作尾参数与安全预算分开。摘要无需列公式和全部假设，改为：

```tex
A conditional, rank-sensitive bound relates per-candidate screening
work to the drift margin and cumulative locality.
```

若希望更具体而不增加字数，可用：

```tex
A conditional work bound uses the normalized discrepancy rank to
relate per-candidate screening effort to cumulative local changes.
```

这两种写法任选一种。正文已有严格余量和预算区分，不应在摘要增列第二个概率参数，也不应说实现按 rank 降低 action 成本或调整 cap。

## 3. 摘要中的 operator 与独立检查用语再精确一步

**位置：** `abstract_template.tex:9–10, 20–21`。

“retained additive inverse” 并非错误，但摘要尚未定义 additive inverse；“maintained additive preconditioner” 更直接地表明被比较的是 Schwarz 预条件算子，而不是当前刚度的逆误差。建议保留现有概率、因子与共同粗修正，仅改主语：

```tex
with probability at least $1-\delta$, the maintained additive
preconditioner lies between $(1-\tau)$ and $(1+\tau)$ times its
current fresh counterpart, including a common current coarse correction.
```

独立离散化/谱/活动空间检查属于实际有限问题的核对，不是对全部计算和程序的形式验证。将 “checks verify the computed systems” 改为 “checks assess discretization and solver accuracy”，与引言末句统一即可：

```tex
Independent discretization, spectral and active-space checks assess
discretization and solver accuracy; matched stopping-rule comparisons
and local-factor timings identify the costs governing effective reuse.
```

该句没有预写 lookahead 提速，也没有把实证核对替代精确算术定理。

## 应保留的限定与无需修改处

- 摘要和引言中 **in exact arithmetic** 分别限定概率谱比较与 lookahead 决策等价，作用不同，属于必要限定；不宜为去重复而删除。
- JSR 段的 **without further operator assumptions** 是准确的比较边界，不是防御性写作。所述对角 proxy 不控制固定对角下的耦合变化，有独立代数反例支持；当前表述没有声称未取得的 JSR 全文不存在其他谱定理。
- 小裁剪末句说明有限矩阵保证不依赖 leading-Gram 假设，直接回应假设边界，应保留；无需再增一个免责声明段。
- 引言的 elapsed-cost 与 lookahead 两段准确区分“改变 retention”与“精确算术下保留 capped 决策”；不是仅因词语 whereas 就应删的对照。
- 现摘要没有宣称 `rank(F-F_a)` 的两倍普遍界；引言的 twice affected coefficients 与已证明的 `2|Z|` 一致。
- 数值范围准确给出四个 extruded 3D elasticity 家族、次数三到五、两条 50 查询与三重复，没有把所有家族说成长序列或任意 CAD。摘要目前只写 three-dimensional，正文已明确 extruded；若需摘要独立呈现范围，可把 “three-dimensional elasticity families” 改成 “extruded three-dimensional elasticity families”，不必加负面句。

性能插槽仍须等实际记录后填入。正式 progressive 与同批 lookahead 的比值必须分别标明分母及测量批次；不得用 rank/locality 分析解释尚未测得的加速，也不得由查询末缓存一致推断浮点实现的全部中间决定一致。本次未要求添加任何最终速度句。

修订落实记录（主编辑）：上述三项澄清已纳入模板与引言；摘要同时写明 extruded three-dimensional，保留精确算术条件。最终速度仍待完整记录生成，并未根据这份静态审读预写数值。
