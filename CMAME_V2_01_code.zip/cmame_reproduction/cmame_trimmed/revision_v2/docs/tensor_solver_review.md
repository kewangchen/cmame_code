# Independent tensor-assembly and two-level review

Reviewed `revision_v2/tensor_assembly.py`, `twolevel.py`, and their two test
modules against the frozen `src/assembly.py`, `src/space.py`, `src/geometry.py`,
and `src/solver.py`. No implementation or test source was edited during this
review. The review concerns numerical correctness and scope; no timing campaign
or performance assertion was performed.

## Assessment and finding

The stated three-dimensional, body-load, left-face Dirichlet path is
mathematically consistent with the original assembly and solver. No error was
found in its tensor contractions, component ordering, full-cell sharing,
changed-support accounting, prolongation scaling, or additive coarse action.

One concrete scope defect was found in the reviewed version: `TensorAssembler`
accepts the original `bc='outer'` option, whereas `build_coarse` removes only the
coarse left-face boundary columns. A small supported input then produces a
singular coarse operator: degree 2, `(2,2,2)` cells, `bc='outer'`, untrimmed domain,
and ratio 2 causes Cholesky to raise `LinAlgError: 3-th leading minor ... is not
positive definite`. The parent was notified promptly and chose to reject
`bc!='left'` explicitly in this revision rather than extend the coarse-boundary
logic. The parent added that guard, and a subsequent constructor-level check verified
that `bc='outer'` raises the stated left-face-only ValueError before assembly.
This finding is closed for the declared revision scope. All planned comparisons
use the reviewed left-face path.

Minor hardening opportunities, without an observed failure in the declared
campaign: require a positive integer batching threshold and a positive integer
coarsening ratio; verify the refined knot vector against the fine knot vector,
not merely its length. Knot insertion and `linspace` represent the same exact
rational knots with possible last-bit differences in floating point, so
"exact nested" refers to the underlying spline construction, subject to
floating-point evaluation.

## Tensor contraction audit

Let M be the plane mass matrix, H_ab the plane gradient-product matrices, and
B_a the plane derivative/value products. The Z arrays are respectively mass,
derivative/derivative, and derivative/value products. With the original tensor
ordering (z index varies fastest), the implementation forms

- H3_ab = kron(H_ab, Z) for a,b in x,y;
- H3_a,z = kron(B_a, BZ.T), and H3_z,a = kron(B_a.T, BZ);
- H3_z,z = kron(M, DZ).

The transpose placement is correct: the z derivative belongs to the trial
factor in the first cross term and the test factor in its transpose. Summing
the diagonal spatial contractions gives the scalar stiffness; adding reaction
mass and separating the constant load are correct. The elasticity contractions
match the original mu/lambda expression and the interleaved scalar/component
coefficient ordering. The constant downward body force and volume
`area / number_of_z_cells` agree with extrusion.

The z separation is exact for the discrete product quadrature used by the
original assembler. It does not remove the XY trimming-quadrature error or
justify a lower cut quadrature order. The same assembler and quadrature must
be used for every compared retention policy, as the revision driver intends.

## Sharing, incremental support, and memory

On this fixed, uniform, open-knot tensor grid, a cell's local basis shape is
identified by its distances from both endpoints, clipped at the degree. Thus
the per-axis pair `(min(e,p), min(n-1-e,p))` distinguishes every boundary shape
and identifies translation-equivalent interior shapes. The assembler instance
fixes degrees, cell sizes, material coefficients, and load. Including all three
axis types plus quadrature order is therefore sufficient for full-cell sharing;
including z type and order suffices for the z integral cache. This argument
would need revision for nonuniform knots or changing coefficients. Those are
outside this implementation's scope.

The XY cache additionally uses the exact cell index and the geometry signature,
so cut integrals are not improperly shared between different cuts. The
per-element cache reuses exactly the same record when the signature is
unchanged. When it changes, every background ID in that fixed element support
is recorded, including a cell that becomes empty. Summing such supports is
conservative and contains both rows and columns of every changed matrix entry.
The same support remains sufficient after current diagonal equilibration:
changes of a diagonal scale in that support can change only entries with at
least one supported endpoint, while blocks disjoint from that support retain
unchanged principal submatrices.

The subsequently revised assembler now updates the global sparse matrix by
replacing an affected principal block. Let Z be the union of all background
supports of signature-changed cells and let D select Z. Because each changed
cell contributes only inside Z x Z, the matrix difference is supported there.
The implementation keeps `A_old - D A_old D` outside that block and rebuilds
the whole current `A_ZZ` from **all** current incident cells, including unchanged
cells. Restricting both local matrix endpoints to Z is therefore correct; the
cross entries outside Z x Z remain unchanged. The RHS entries on Z are zeroed
and likewise recomputed from all current incident loads. This avoids the
cancellation of large old element energies against new tiny cut energies that
caused the negative ghost diagonal in the earlier delta-update version.
Multiplication by the Boolean diagonal selector extracts the same stored
entries, so their subtraction zeros them before current reassembly. A vanished
basis receives an exact zero diagonal if no current contribution remains; no
threshold or clipping is applied. No matrix factor is incrementally updated.

The COO temporary is flushed after crossing the threshold, so its entry count
is bounded by the threshold plus at most one element matrix. This
is a bounded-batch implementation, not a strict byte-memory cap. The accumulated
CSR matrix, a new batch CSR, concatenation buffers, and element caches still
contribute to memory. Sparse addition changes summation order and can introduce
roundoff differences from the original one-shot COO assembly, which the
matrix-comparison tests accommodate.

## Nested coarse space and SPD action

Univariate knot insertion maps coarse coefficients to the fine open-knot spline
basis. Kronecker products preserve the documented tensor ordering, and a final
Kronecker product with the component identity gives the correct vector map.
Removing the first coarse x index imposes exactly the intended homogeneous
left-face boundary. Selecting current active fine IDs and dropping all-zero
coarse columns removes unsupported coarse functions.

For the matching left-face boundary and exact open-volume trimming problem,
there is also a rank argument stronger than arbitrary matrix column filtering.
If a combination of retained coarse columns vanishes on every active fine row,
the corresponding coarse spline has only physically inactive fine basis
coefficients and hence vanishes on the physical open domain. On each coarse
cell intersecting that domain in an open set, polynomial uniqueness and local
linear independence of tensor B-splines force all locally active coarse
coefficients to vanish. Nonnegative knot-insertion coefficients link each
retained column to a physically active fine basis. Consequently every retained
coarse coefficient vanishes and the restricted prolongation has full column
rank in this exact setting. This argument assumes matching essential boundary
conditions, genuine positive-volume support, and adequate quadrature. It does
not establish a uniform lower eigenvalue under arbitrarily small cuts.
Numerical underflow or severe conditioning can still cause the actual Cholesky
to fail; there is no hidden shift or regularization, and such failures must stay
in the campaign ledger.

The fine solver uses x = D y with C = D A D. Therefore a physical coefficient
prolongation P0 transforms to P = D^-1 P0, exactly as implemented by dividing by
d. Its Galerkin matrix is P.T C P = P0.T A P0. The extra diagonal equilibration
of that coarse matrix is undone in its solve, so the action is precisely
P (P.T C P)^-1 P.T. It is symmetric positive semidefinite; adding it to the SPD
local inverse retains SPD. It is rebuilt from the current matrix and added by
the same code path for all iterative policies. It is not part of the retained
local-factor maintenance gain. Direct solves omit the preconditioner.

The current equilibration, reference solve, warm-start transformation, residual
checks and energy-error computation agree with the original solver. The
preconditioner is fixed during each CG call. Nonconvergence or a failed coarse
factorization must be reported, not used to remove an unfavorable row.

## Verification performed

With one BLAS thread and warnings treated as errors, the existing tensor and
two-level tests passed: **8 tests in 2.37 seconds**. They compare local tensor
matrices for both physics and degrees 2/3 against independent original product
quadrature, compare incremental global systems and supports, verify spline
collocation under prolongation, check the coarse action on its range, and check
solutions against direct references for fresh, exact-local, progressive, stale,
and Jacobi policies.

An additional small independent probe deliberately exercised actual full-cell
sharing, which the boundary-heavy local test alone does not guarantee. On an
`(8,8,8)` grid with anisotropic degrees `(2,3,2)`, four interior cells all mapped
to a single full-cache entry. Against the original quadrature, maximum absolute
matrix discrepancies were `1.74e-17` for Poisson with reaction 0.7 and `1.31e-17`
for elasticity. A tiny-top left-face test also retained a positive coarse
spectrum in the specific checked case; this is a case check, not a universal
conditioning claim.

No numerical process was left running. No original source, benchmark records,
or reviewed implementation files were changed by this review.

## Follow-up review of principal replacement

Read the recorded `results/revision_tests.log` reporting 26 tests passed in
5.01 seconds and inspected the earlier shrinking failure log. The revised
principal-block replacement was checked against the support argument above;
no new correctness defect was found. In an additional lightweight independent
check, a degree-2 `(3,3,2)` grid followed tops `[.91,.24,.81,.81]`, covering
shrinkage, re-expansion, and an unchanged final query. Each query was compared
with a newly constructed original product-quadrature assembler, for both
Poisson and elasticity, including the full background matrix, active IDs and
current RHS. Maximum relative full-matrix errors were `3.35e-16` (Poisson) and
`3.13e-16` (elasticity); maximum relative RHS error was `1.78e-16`. The final
unchanged query reported zero changed cells. This supplements the revision's
crossing-path and disappearing-support tests without making a timing claim.
