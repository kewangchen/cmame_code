# Mechanism and high-order quadrature audit protocol

These are two separate audits implemented in `revision_v2/mechanism_audit.py`. The driver and its correctness tests were prepared without executing them while the formal timing campaign was active. Run them serially after that campaign finishes. Neither output establishes a new speedup, a probability estimate, or interval certification.

## Serial commands

From the repository root, first run the small correctness tests:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 MKL_NUM_THREADS=1 \
  .venv/bin/python -W error -m unittest \
  cmame_trimmed.revision_v2.tests.test_mechanism_audit -q
```

Then run the audits separately, or use `--mode all` to run mechanism followed by quadrature in one process:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 MKL_NUM_THREADS=1 \
  .venv/bin/python -m cmame_trimmed.revision_v2.mechanism_audit --mode mechanism

OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 MKL_NUM_THREADS=1 \
  .venv/bin/python -m cmame_trimmed.revision_v2.mechanism_audit --mode quadrature
```

The default outputs are `revision_v2/results/mechanism_audit.json` and `revision_v2/results/quadrature_audit.json`, with separate `*_audit_sources/` snapshots. Existing JSON is not overwritten. A rerun requires a new `--output-dir`; a failed or incomplete original record is retained. Each snapshot copies exactly the bytes whose SHA-256 hashes appear in the JSON. Source consistency is checked again at completion. The protocol, driver, correctness tests, tensor assembler, campaign specification and frozen source modules are included.

The quadrature driver checks that the four thread settings are one, assigning one only when a setting is absent. It imports the numerical libraries afterwards. This control applies to CLI execution; calling its function from a process that has already initialized numerical libraries does not reconfigure those libraries. Prefer the commands above.

## Exact spline formulas and stable evaluation

The mechanism audit evaluates actual quadratic open one-span B-splines on `(0,epsilon)` with 80-digit Decimal arithmetic. The grid contains eleven scales from `1e-1` to `1e-6`. The fixed anchor is `epsilon_a=1e-4`, and the displayed contract tolerance is `tau=0.2`. Every real-valued result includes a full Decimal string and, where useful for plotting, a binary64 numerical field. The results are high-precision evaluations of exact formulas, not claims that irrational values have finite exact decimal representations.

For the independent positive pair

- `B_1^2(x)=2x(1-x)`;
- `B_2^2(x)=x^2`,

define `h(e)=1-2e+4e^2/3`. Its stiffness entries are

```text
F11 = 4 e h(e)
F12 = 2 e^2 (1-4e/3)
F22 = 4 e^3/3
 det(F) = 4 e^4/3
 det(C) = 1/[4 h(e)]
 rho(e) = (sqrt(3)/2) (1-4e/3)/sqrt(h(e)).
```

The scaled leading gradients are `2` and `2y`, giving `G0=[[4,2],[2,4/3]]`, determinant `4/3`, limiting correlation `sqrt(3)/2`, and limiting normalized condition number `kappa0=7+4sqrt(3)`. The gradient remainder map is `W z=-4 z1 y`, while `(G0^-1)11=1`; hence `||W G0^-1/2||^2=16/3` and the explicit constant is `b=4/sqrt(3)`.

For the counterexample pair

- `B_0^2(x)=(1-x)^2`;
- `B_1^2(x)=2x(1-x)`,

use

```text
a(e) = 1-e+e^2/3
b(e) = 1-2e+4e^2/3
c(e) = 1-3e/2+2e^2/3
F = 4e [[a,-c],[-c,b]]
a*b-c^2 = e^2/12
 det(F) = 4 e^4/3
 det(C) = e^2/[12 a b]
 rho(e) = -c/sqrt(a*b).
```

The exact stiffness Gram is SPD at every positive scale, but the leading gradients `-2` and `2` are dependent. Its normalized correlation tends to `-1`, and `e^2*kappa(C_e)` tends to 48. A relative energy norm against this singular limiting matrix is undefined: the JSON leaves `limit_relative_drift` and `small_cut_upper_bound` null and sets `small_cut_theorem_applicable=false` for this family.

For either normalized 2-by-2 matrix, the program computes

```text
lambda_max = 1+abs(rho)
lambda_min = det(C)/lambda_max
kappa(C) = lambda_max/lambda_min.
```

It never forms the small eigenvalue by subtracting `abs(rho)` from one. At `epsilon=1e-6`, that subtraction would magnify floating-point cancellation for the negative pair. The determinant formulas avoid it. Because all the normalized 2-by-2 matrices have the same eigenvectors, their exact anchor-relative drift is

```text
eta(e;ea) = abs(rho(e)-rho(ea))/lambda_min(C_ea).
```

The output reports both this drift and the absolute normalized-coupling change from the limiting correlation. For the negative pair, the latter equals the stable `lambda_min` expression. The positive limiting relative drift is also reported, using the nonsingular `C0`.

## Checking the sufficient small-cut theorem without overstating it

For the positive pair only, the driver evaluates

```text
r(e) = 2 b e+b^2 e^2
gamma(e) = 2 kappa0 r(e)/(1-r(e))
U(e;ea) = [gamma(e)+gamma(ea)]/[1-gamma(ea)]
```

when the stated denominators and hypotheses hold. It records the sufficient radius obtained from

```text
r_max = tau/[2 kappa0 (2+tau)+tau]
epsilon_max = r_max/[b*(sqrt(1+r_max)+1)].
```

The last expression is a cancellation-free evaluation of `(sqrt(1+r_max)-1)/b`. Rows with both the current scale and anchor within that radius are checked against `eta<=tau`. All available theoretical upper estimates are checked against the exact-formula drift. Scales outside that sufficient region are not labelled unsafe merely because the sufficient theorem is inconclusive. No randomized screen is run, so the output makes no claim that every contract-valid pair would be accepted by a conservative screen.

The driver also constructs the endpoint-vanishing Bernstein sets of degrees 2, 3 and 5. With `a_i=i*binomial(p,i)`, their leading Gram is `G_ij=a_i*a_j/(i+j-1)`. Rational arithmetic produces the complete Gram and all leading principal determinants. Positive determinants verify these finite selected families; they provide no uniform bound in degree or knot geometry. The analytic independence statement follows from the distinct leading powers, not from the numerical audit alone.

The reported counterexample asymptotic check uses the explicit criterion `abs(e_min^2*kappa-48)<=200*e_min` at the smallest supplied scale. This is a finite consistency check with the stated expansion, not an asymptotic proof. The determinant identity and analytic expansion supply the proof.

## High-order three-dimensional quadrature sensitivity

The configured case matches the formal quintic sequence's initial geometry:

- tensor-product cells `(6,6,4)`, degree 5;
- isotropic three-dimensional elasticity with the original material defaults;
- hole centre `(0.47,0.51)`, radius `0.173`, extruded over the third coordinate;
- fixed left face and original negative-last-direction body load;
- fresh nonincremental `TensorAssembler` instances at quadrature orders 24, 12, 16 and 20.

The order-24 matrix and `direct_reference` solution are retained as a numerical reference. Each other order is assembled independently from a fresh cache. The tensor assembler evaluates the z contractions and caches reusable planar/full-cell quantities within that assembly; a separate large 3D tensor-point quadrature loop is not introduced. Local assembly caches are released before the next order to reduce retained memory. This is a quadrature-order sensitivity audit using the same implementation, not an independent quadrature implementation or a continuum discretization-error estimate.

Active IDs must agree exactly; a mismatch is an explicit failed row. The metrics are

```text
||A_q-A_24||_F / ||A_24||_F
||b_q-b_24||_2 / ||b_24||_2
sqrt[(x_q-x_24)^T A_24 (x_q-x_24)/(x_24^T A_24 x_24)]
||x_q-x_24||_2 / ||x_24||_2,
```

plus the current unscaled and diagonally scaled algebraic residuals. The sparse matrices are compared in physical coordinates, and the solution error uses the order-24 energy. Small negative quadratic forms are clipped only within an explicitly computed roundoff bound; a substantively negative value fails. Nonfinite metrics fail. The unscaled and scaled residuals also distinguish integration differences from an inaccurate direct algebraic solve.

Default predeclared diagnostic thresholds are `1e-8` for relative matrix Frobenius error, `1e-6` for relative reference-energy solution difference, and `1e-8` for each algebraic residual. CLI overrides are recorded in the JSON and must be chosen before examining results; they do not replace raw metrics. An order that misses a threshold remains in the output with `passed=false`. No monotone convergence assertion is imposed because roundoff and quadrature errors can interact. Order 24 is not claimed to be exact integration or an upper error bound.

Each completed order is checkpointed. Exceptions remain as failed rows, reference-stage failures remain as incomplete failed output, and the driver exits nonzero when recorded checks fail. Assembly and solve times are diagnostic fields for accounting and are excluded from formal policy speedup claims. No execution result is asserted by this protocol until the serial audit has actually run.
