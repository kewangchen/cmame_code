# Secant lookahead implementation

New module: `lookahead_screening.py`. APIs: `LookaheadEnergyBudget`,
`lookahead_bound`, `build_lookahead_schwarz`. The builder uses an isolated copy
of the frozen builder's globals, replacing only the private bound callback.
No frozen source or cost-policy module is changed.

For one fixed symmetric energy drift K and initial probe column omega_l, define
`f_l(q)=log(||K^q omega_l||)`. Its spectral representation is one half the log
of a sum of nonnegative exponentials, so f is convex wherever the norm is
nonzero. Equivalently, the squared norms are log-convex spectral moments.
For every integer p>q,

`f_l(p) >= f_l(q)+(p-q)*(f_l(q)-f_l(q-1))`.

The implementation keeps the previous accumulated log norm, including the
original Gaussian norm at q=0. After the existing acceptance, deterministic
lower rejection and final-cap checks, it evaluates this predictor for **every**
remaining integer power through the same effective dimension cap. If at each
future power at least one column predicts `log_alpha+f_l(p)>p*log(tau)`, every
remaining Gaussian upper estimate must exceed tau. It rebuilds immediately,
returning the CURRENT Gaussian upper estimate. The predictor is a lower
predictor of a future upper estimate; it is not an upper bound to substitute
into the acceptance test.

A zero current power column remains zero and is omitted. Ambiguous/nonfinite
live secants defer to the original recurrence. All-zero actions and tau=0 are
handled by the original mathematical acceptance/rejection checks, without
calling log(0) in the lookahead helper. Signed eigenvalues are allowed because
the squared spectral representation uses absolute eigenvalues.

The strict comparison has a per-column margin of

`1e-10 * [1+|log_alpha|+|f_q|+(p-q)(|f_q|+|f_(q-1)|)+|p log(tau)|]`.

This avoids pruning on fragile scalar arithmetic and exposes margin/nonfinite
deferral counters. It is **not** a rigorous forward-error bound for the
Cholesky/triangular actions. Exact capped acceptance/refresh decisions and
anchors coincide with unpruned progressive screening in exact arithmetic, for
the same prescribed sequence, caps and probes. In floating point, equivalence
is a testable numerical property, not a universal interval-certified claim.
The new rule only triggers rebuilding; acceptance still uses the original
Gaussian estimate and sequence allocation. Timing-dependent external inputs
need not remain identical after acceleration, so no wall-clock-history
replay claim is made.

A lookahead rebuild does not establish an energy violation. Even a drift below
tau can have no accepting Gaussian estimate by the cap. Consequently these
stops increment `lookahead_rejections`, not `lower_bound_rejections`. They are
separate from dimension caps and mathematical early stopping. Per-build rows
record `stat_screen_lookahead_rejections`,
`stat_screen_lookahead_avoided_action_batches`,
`stat_screen_lookahead_evaluations`, margin/nonfinite deferrals, and
`stat_screen_lookahead_power_histogram`. Stopping/effective-cap histograms and
all original work/budget fields remain. With maximum power Q, completed checks
satisfy

`Q*checks-actions = dimension_cap_avoided + mathematical_early_avoided + lookahead_avoided`.

`stat_screen_kind` is `progressive_secant_lookahead` and
`stat_screen_lookahead_log_margin` records the configured margin. The default
margin is immutable and must be finite and positive. The default inherited
power/cap settings remain configurable; the planned follow-up explicitly uses
12 probes, maximum power 6, dimension cap enabled and guard 288.

The authored tests compare fixed-stream outcomes with unpruned progressive
screening for symmetric diagonal, negative, mixed-sign and rotated matrices;
check independent generalized spectra on accepted matrices; demonstrate a
below-tau matrix pruned before an otherwise inconclusive cap; cover a matrix
that must continue then accept; and verify zero/dead-column handling, margins,
nonfinite behavior, action/budget accounting and complete cache/anchor replay.
They have not been executed while the formal timing process is active. Only
AST syntax checks have run. No performance improvement is asserted.
