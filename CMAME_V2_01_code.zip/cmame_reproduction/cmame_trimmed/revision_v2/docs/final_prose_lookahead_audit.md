# Lookahead 版本静态文字终审

审读范围：`docs/abstract_template.tex`、`docs/introduction.tex`、`docs/cover_letter.tex`、`docs/highlights.txt`，以及 `build_revision.py` 中生成摘要、结果、讨论、结论和投稿信的文字。仅阅读源码；未导入或执行分析、绘图和构建。以下仅列需要修改的问题。行号以本次读取版本为准；root 正在修改的文件未改动。

## 1. 摘要须明确比较对象，并呈现 lookahead 的同批实测结果

**位置：** `build_revision.py:293`、`docs/abstract_template.tex:22`。

本次最初读取时，生成句把正式实验中 `baseline/progressive` 的几何均值称作 “speedups”，既未明确分母，也未呈现摘要刚突出介绍的 lookahead。Root 随后已加入 “For progressive screening” 明确方法；仍须按实际结果决定是否加入独立的 lookahead 句并控制总字数。若某比值低于 1，统一写 “speedups” 会误导。不要用正式实验的 fresh/exact 时间除以后续实验的 lookahead 时间。

建议保留两层证据，但每层至多一句：

> In the six-method comparison, baseline/progressive geometric-mean time ratios are {fresh_L} against fresh factors and {exact_L} against exact local refresh ({fresh_A} and {exact_A} including assembly). In the separate matched comparison, the progressive/lookahead ratios are {LA_L} and {LA_A} for the same two time scopes.

数值分别来自 `summary.geometric_mean` 和 `cost_summary.geometric_mean_lookahead.progressive`；第二句必须标明 separate matched comparison。如填入两句使摘要过长，应缩减测试清单，不能删除精确算术或分母限定。若比较不可用，说明失败状态，不能静默抹去结果或补零。

## 2. 摘要的工作量界缺少条件，“retained inverse” 指代也不够明确

**位置：** `docs/abstract_template.tex:12–18`。

“A drift-margin estimate bounds the number” 容易被读成所有调用均有该接受工作量界；实际需要严格漂移余量、足够幂数上限且未提前重建。摘要可写 conditional，不必把所有假设逐条展开。“retained inverse” 宜明确为 additive preconditioner，避免误读为当前刚度矩阵的近似逆误差定理。下列为可整体替换的紧凑摘要底稿；`@PERF@` 沿用实际结果插槽：

```tex
Repeated mechanical analysis on trimmed spline domains requires local
factors to be maintained as stiffness couplings and active coefficients
change. We develop energy-controlled reuse for additive Schwarz
preconditioners on these evolving spaces. Current diagonal scales
transport stored inverse actions, while cumulative discrepancies are
measured against their factorization anchors. A progressive Gaussian
screen reuses one probe block under an event valid for every power of a
fixed candidate. Log-convexity of power norms identifies checks that
cannot accept before the cap, removing further matrix actions while
preserving capped decisions in exact arithmetic. A summable risk
allocation gives a simultaneous comparison with the current fresh
preconditioner throughout the adaptive sequence: in exact arithmetic,
with probability at least $1-\delta$, the retained operator lies between
$(1-\tau)$ and $(1+\tau)$ times its fresh counterpart. The comparison
also holds with a common current coarse correction. A conditional
action-count bound relates screening work to the drift margin; actual
spline restrictions establish the scope of the small-cut explanation.
Tests on four families of extruded three-dimensional elasticity problems
cover spline degrees three to five and moving cutouts. @PERF@
Component timings identify when avoided factorizations recover the cost
of screening and when additional powers increase total work.
```

这是结构建议，不是已验证结果。原文中的独立离散化、谱和活动空间核对可在引言末段保留。摘要不必同时逐项列出所有审计类别、重复数、两条 50 查询、两个谱常数及所有辅助分析，核心论点才有足够空间。

## 3. 引言须更早连接整序列质量保证与两个不同的工作减少机制

**位置：** `docs/introduction.tex:62–106`。

目前渐进幂数、探针数、成本策略、概率界、工作量界分散成若干功能介绍，核心贡献容易读成一串规则。建议把第 62–85 行压成下面两段，并把现有整序列定理段（87–98 行）紧接其后。12 探针、2/6 幂的配置留给方法或实验协议。

```tex
The progressive screen uses a single Gaussian event that controls every
positive integer power of a fixed candidate. Successive powers can
therefore share the same probes and risk allocation. A norm upper bound
permits retention, a deterministic lower bound permits rejection, and
an unresolved candidate is rebuilt at a dimension-based cap. From the
log-convexity of symmetric power norms, we derive a lookahead test that
identifies candidates for which no remaining allowed power can accept.
It removes the remaining matrix actions without changing the capped
retain-or-rebuild decision in exact arithmetic and requires no new
random draw.

A separate rule limits inconclusive testing by comparing elapsed screen
time with the recorded cost of constructing the anchor. Unlike
lookahead, this rule can rebuild a candidate that further powers would
accept. Both retain the energy acceptance criterion and sequence-wide
risk allocation. Their computational roles differ: lookahead removes
provably futile actions, whereas elapsed-cost stopping trades possible
factor retention for immediate rebuilding.
```

“Unlike” 在此表达必要的科学区分，不是泛泛的防御性对照；需要保留。不要把 lookahead 称为证明真实漂移超阈值的 rejection certificate。

现有第 100–106 行建议替换为：

```tex
A sufficient action-count bound connects the energy test to its cost.
For a fixed drift margin below the tolerance, Gaussian probe norms bound
the powers required for acceptance, provided the effective cap is large
enough and no rebuild rule truncates the test. At fixed dimension and
probe count, the summable risk allocation contributes logarithmically
in the check index. The resulting operation count motivates the
comparison with refactorization; timings determine the actual crossover.
```

这保留了必要假设，也避免把领先运算量比较写成实测运行时间结论。

## 4. 引言末段须覆盖实际作为贡献提出的 lookahead 对照

**位置：** `docs/introduction.tex:133–143`。

当前数值路线只列六方法实验，完全没有四策略匹配比较；摘要、理论与实验路线因而不一致。“Analytic extrusions isolate ... effects” 还暗示严格单因素识别，而四家族同时改变次数、网格和块宽度。建议将末段改为：

```tex
The numerical study measures cumulative maintenance costs on four
families of extruded three-dimensional elasticity problems, spanning
cubic to quintic splines, different resolutions and moving cutouts.
Two paths contain 50 queries, and each family has three complete
repetitions. Fresh factors, exact local refresh, fixed and progressive
screening, stale factors and Jacobi solve the same current systems.
A separate matched comparison evaluates lookahead and elapsed-cost
stopping alongside rerun fixed and progressive baselines. Local-kernel
timings locate the observed factor-size and edit-size crossover.
Independent discretization, quadrature, spectral and active-space
checks assess the finite systems and solver accuracy.
```

无需在引言再逐项复述全部计时分项和概率预算。当前粗层成本与完整 scope 由方法和协议明确交代即可。

## 5. 投稿信须以科学问题和主要结果组织，性能插槽须与实际生成内容一致

**位置：** `docs/cover_letter.tex:34–57`、`build_revision.py:327–329`。

贡献段目前过长且按功能依次列举；生成器又只填 fresh/exact 的正式 progressive 比值，未兑现插槽要求的 fixed-power 比较，也没有 lookahead 的实测证据。末尾追加 “full numerical comparison ... all unsuccessful attempts” 是记录说明，不足以替代主要发现。

建议贡献段替换为：

```tex
The central result is a simultaneous spectral comparison with fresh
Schwarz preconditioning throughout an adaptive sequence, including
changes in active basis functions and a common current coarse
correction. A progressive test shares one Gaussian event across all
powers of each candidate. Log-convex power norms then identify checks
that cannot accept before the cap, allowing their remaining matrix
actions to be omitted without changing capped decisions in exact
arithmetic. An explicit quadratic B-spline pair also establishes where
the leading-gradient assumption of the small-cut explanation fails;
the maintenance guarantee uses the finite matrices and remains
independent of that assumption.
```

性能段最多保留两句：正式 progressive 对 exact/fixed 的实际完整序列比值；同批 progressive/lookahead 的实际比值及含装配口径。若存在不利家族，简短说明其范围；没有实际数据时保留具名占位符。不要在投稿信堆出与表格同样长的四家族数字序列。

作者、单位、邮箱、无基金/无利益冲突以及 Codex 的实质研究参与披露应保留。无需新增未确认的独家投稿或作者批准声明。

## 6. Highlights 的工作量界需要限定，lookahead 应强调等价决策

**位置：** `docs/highlights.txt:4–5`。

现有四、五行都少于 85 字符，但第四行存在同第 2 项相同的无条件工作量界问题；第五行只说无新增动作，没有突出等价决策。建议仅替换这两行：

```text
A conditional drift-margin bound quantifies Gaussian screening work.
In exact arithmetic, lookahead skips actions while preserving capped decisions.
```

保留前三行即可形成五条。这里 “conditional” 与 “In exact arithmetic” 是必要范围限定。

## 7. 生成结果与结论须由主要发现组织，避免逐条报表与单调的正面结尾

**位置：** `build_revision.py:27–54, 238–247, 267–286`。

结果段连续生成五句几何均值、四句家族比值和七个审计计数，接近实验日志。数值留在表图；正文保留主比较、变化范围及一个有科学解释的例外。浮点一致性若全部为零可压成：

> All {available} available query-end pairs had matching current anchor hashes, coefficient arrays, RNG states, draw counts and factor-decision counts; {checks-available} pairs were unavailable. These untimed checks concern the tested floating-point sequences.

若有不一致，保留具体类别和次数，不能套用上述句子。比值段以主结论开头：

> In the matched follow-up, lookahead changes the work spent on candidates that the capped screen cannot accept. Its progressive/lookahead geometric-mean time ratio is {LA_L}, or {LA_A} including assembly. Table ... gives the family-level variation and repetition ranges.

再根据实际诊断解释筛查减少是否抵消标量预测成本、是否改变因子和迭代工作。不要在数据出来前预写 “reduces total time”。四个家族的 paired ranges 和保留的 baseline/cost 比值仍应完整出现在表图或补充材料。

讨论和结论目前尚未吸收 lookahead，最后仍是泛称 “these savings”。建议在结论中整序列保证段之后增加这两句，删除重复的泛称收益句：

```tex
Log-convexity adds a distinct computational result: checks that cannot
accept before the prescribed cap can be terminated without changing
the exact-arithmetic anchor sequence. The matched timings quantify the
benefit and overhead of this prediction separately from elapsed-cost
stopping, which can change factor retention.
```

随后接实际同批比值与必要的适用范围；不要把正式 progressive 和后续 lookahead 的时间拼成 fresh/lookahead 加速。

**同处生成分支：已由 root 修复。** 原 第 49 行用 `'progressive' in case['ratios']` 判断后，读取 `case['lookahead_ratios']['progressive']`。应检查实际读取的集合：`if 'progressive' in case['lookahead_ratios']:`。否则 cost 成功、lookahead 失败时会触发 KeyError，反向情况会漏报有效结果。Root 随后已确认 guard 改为 `lookahead_ratios`；本审读未改生成器。
