# Independent algebraic audit of the locality-sensitive rank refinement

Reviewed `locality_rank_main.tex` and `locality_rank_supp.tex` using their stated definitions and algebra only. No numerical module was imported, and no test, benchmark, or compilation was run. Neither the reviewed notes nor experimental sources were edited.

No mathematical correction is required. The conclusions hold under the conditions stated below; these conditions are already present in the two notes.

## Projected probes and work probability

For real symmetric K, range(K) is the orthogonal complement of ker(K). Its orthogonal projector P commutes with K, and K^q = K^q P for every integer q >= 1. Thus

`||K^q omega_l|| <= eta^q ||P omega_l||`.

With an orthonormal range basis U, U^T omega_l is a standard Gaussian vector in r_K dimensions. Its squared norm has moment-generating value `E exp(||P omega_l||^2/4) = 2^(r_K/2)`. The stated choice `u_r^2 = 2 r log(2) + 4 log(s/epsilon)` consequently gives

`s 2^(r/2) exp(-u_r^2/4) = epsilon`.

The same event `max_l ||P omega_l|| <= u_r` controls every positive power, so no union bound over powers is missing. Taking a larger, pre-draw integer rank bound only enlarges u_r and preserves the probability estimate. For rank zero, symmetry is unnecessary: rank zero means K = 0, and the first mathematical action has zero upper estimate.

For eta < tau, the power-count formula is sufficient. If alpha*u_r > 1, its ceiling ensures `(alpha*u_r)^(1/q_r) <= tau/eta`. If alpha*u_r <= 1, q_r = 1 already gives an upper bound at most eta. Equality at the threshold permits acceptance because the screen uses `<= tau`.

The action-tail argument is also valid: continuing past q requires beta_q > tau, which, by the projected-norm upper bound, requires `max_l ||P omega_l|| > (tau/eta)^q / alpha`. Markov's inequality yields exactly the displayed tail. Any additional early rebuild reduces the event of performing more than q actions, although it can destroy the separate guarantee of acceptance by q_r.

Here epsilon describes a per-candidate work event. It does not recalibrate alpha or consume the safety allocation delta_j. A future claim that the work event holds throughout an adaptive lifetime would need its own summable work-tail allocations or a stated finite-check union bound. The present notes make no such lifetime work claim. Conditional on the pre-draw history, K, P, alpha and the proposed rank bound must be fixed; the measurability formula for P in the supplement is valid eigenvalue by eigenvalue.

## Support, normalization and anchor history

The physical support assumption is the strong principal-support condition `F-F_a` supported on Z x Z. It implies identical diagonal scales outside Z and hence an exactly zero Z-complement principal block of C-H. It does not imply that the normalized difference remains supported on Z x Z: scaling changed rows creates cross entries against unchanged coordinates.

After permutation, `C-H = [[E,T],[T^T,0]]`. Its first |Z| columns span at most |Z| dimensions; every other column lies in the |Z|-dimensional coordinate subspace on Z. Therefore its rank is at most min(m, 2|Z|). Cholesky whitening is an invertible congruence and preserves this rank. The SPD example with a single diagonal physical update and nonzero correlation c produces a nonzero off-diagonal normalized difference, whose determinant is negative and whose rank is two. Disjoint copies establish the asserted sharpness when m >= 2|Z|.

The proved structural bound is in terms of |Z|. It should not be read as a general bound of twice `rank(F-F_a)`; the notes do not assert that stronger statement. The example proves that rank doubling can occur.

The matrices must share the same ordered local coordinates and be compared with the actual retained anchor. Telescoping intervening physical increments justifies taking the union of all their affected coefficient sets. Every changed element contribution requires its complete coefficient support, including coefficients extending outside the changed geometric cells. Membership changes require a new anchor or an explicitly verified coordinate correspondence. A preceding-step change set alone does not establish the cumulative hypothesis.

## Compatibility with lookahead and dense work accounting

On the projected-norm event, beta_(q_r) <= tau whenever the effective cap includes q_r. A valid exact-arithmetic lookahead can prune only when a lower predictor exceeds tau at every remaining power. If a proposed pruning step precedes q_r, the predictor at q_r is at most beta_(q_r) <= tau, so that pruning predicate is false. No deterministic induced-norm lower test can reject when eta < tau. These facts preserve acceptance by q_r for the ordinary progressive and exact lookahead policies. A separate timing cutoff need not preserve it and is correctly excluded.

This compatibility is an exact-arithmetic statement. The implemented logarithmic margin is a numerical precaution, not a rigorous rounding-error certificate. The notes do not turn it into one.

The operation-count interpretation also retains the correct ambient dimension. Dense actions still cost approximately 4*s*m^2 per power, so comparison with m^3/3 gives `12*s*q_r <= m`. Rank improves a sufficient power count, not the dense action cost, implemented cap, measured performance, or uniform dependence on cut geometry and degree. The explicit implementation disclaimer is appropriate.
