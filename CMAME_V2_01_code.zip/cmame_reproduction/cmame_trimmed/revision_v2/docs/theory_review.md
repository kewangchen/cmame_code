# V2 theory review

Scope: self-contained mathematical derivations for the revision, with the frozen manuscript and implementation inspected. This note makes no runtime or empirical acceptance claim. The academic-writing skill guided the research prose. No prior-work priority claim is made.

## Main justified enhancement

**Shared probes give a simultaneous bound across every power with one allocation.** For fixed symmetric `K`, choose a maximal-magnitude eigenvector `v`. The event `max_l |v^T omega_l| >= 1/alpha` implies the upper estimate for every positive integer power. Its complement is bounded by `delta_j`. Consequently the existing Gaussian multiplier supports adaptive early acceptance at q=1, then q=2 or q=3 on exactly the same initial probes, without splitting the budget between powers. A separate union bound over powers would be valid but unnecessarily conservative. The proof also covers a running minimum over computed bounds.

This is a stronger statement than separately applying the one-power lemma. It is a direct consequence of the same Gaussian projection argument, and should be presented as an adaptive use of that argument rather than a new general norm-estimation principle.

The source file `theory_extensions.tex` gives a conditional filtration theorem with predictable parameters, random allocations whose sum is bounded pathwise, unbounded checks, changing active dimensions, budget identity, unchanged-decision inheritance and rebuilding. The current `EnergyBudget` counter and token support the stated lifetime rules. The theorem describes ideal Gaussian randomness; a fixed recorded implementation seed is reproducibility information, not a proof of independence in an adversarial deterministic experiment.

## Implementation consequences

- Freeze candidate K, anchor, coordinates, s and allocation before drawing the initial Gaussian block. Previous probes may influence a new candidate only when its acceptance uses fresh independent probes.
- Keep the same candidate and initial block while progressing through powers. Column normalization with cumulative logarithmic magnitudes represents the same powers and does not spend another allocation.
- Accept when a valid bound is at most tau; reject or rebuild at any point. At each action, `norm(K z)/norm(z)>tau` for nonzero z proves rejection in exact arithmetic.
- Use one draw counter increment for all powers of that block. Fresh retries increment it again. Carry an old probabilistic decision only under its original lifetime budget identity, or include the inherited failure allocation in a larger valid overall budget.
- Adaptive probe counts need an additional argument. A preallocated union bound over probe prefixes is valid; the common-power event alone does not justify selecting a prefix with the same unsplit allocation at every size.
- Floating-point comparisons remain numerical tests, not interval certificates. Include measured action and spectral checks in the numerical validation.

For q in {1,2,3}, the expected number of power actions is `2 - P(Q=1) + P(Q=3)`. It is less than two exactly when exits at q=1 outnumber continuations to q=3 in expectation. This is only an action-count comparison. Refactorization avoided or incurred, failed screens, normalization and PCG cost still enter the measured total.

## Optional alternatives, not required by the implementation

1. Replace the density-bound multiplier with the exact Gaussian lower quantile, `t = Phi^{-1}((1 + delta_j^(1/s))/2)` and divide the observed maximum by t before taking the qth root. This weakly sharpens the same guarantee at unchanged matrix-action cost.
2. Use the aggregate Frobenius action divided by the square root of the lower `chi-square_s` quantile. Its own common event covers all powers at the same action cost. Neither observed statistic uniformly dominates the other. Taking their minimum requires a shared-event proof or splitting the allocation between their two events; the supplied derivation uses a split.
3. If an actual hard cap N on probe blocks is enforced, uniform allocation `delta/N` is valid. Do not use this option with a horizon estimate that may be exceeded.
4. Fresh small probe blocks can be staged with conditional error spending. Reusing powers of a single block avoids redoing previous matrix actions; prefix expansion can be compared empirically only with its own simultaneous calibration.

## Spline applicability resolved with actual basis functions

At a generic interior point where every selected gradient is nonzero, leading gradients are constant vectors and have rank at most d. Thus m>d makes the leading Gram singular for that family. More generally, homogeneous gradient orders must be checked separately. For order k, the space has dimension at most `binomial(d+k,k+1)`; dimension counting is necessary but the coefficient matrix decides independence.

The positive example uses an actual open one-span degree-p B-spline basis, which is Bernstein. On `(0,epsilon)`, the endpoint-vanishing functions `B_i^p`, i=1,...,p, have distinct leading gradient powers `a_i y^(i-1)`. Their Gram is `G_ij=a_i*a_j/(i+j-1)` and is SPD even for p>1. For p=2 it is `[[4,2],[2,4/3]]` with determinant 4/3.

The counterexample uses the actual pair `B_0^2=(1-x)^2`, `B_1^2=2x(1-x)`. Their leading gradients are -2 and 2, so the leading Gram has rank one. The exact stiffness Gram is SPD for every epsilon>0, but its normalized condition number is asymptotic to `48/epsilon^2`. This shows failure within a spline coordinate family without substituting unrelated polynomial coordinates.

In d dimensions, tensor-product Bernstein functions with indices in `{0,...,p}^d` except the zero multi-index have independent leading gradients `a_i grad(y^i)`. A vanishing linear combination would integrate to a constant polynomial with zero constant term. Thus m=`(p+1)^d-1` may greatly exceed d without violating independence. This is a corner restriction with differing vanishing orders, not a generic interior-point limit. A concrete quadratic 2D subfamily of size five is spelled out in the TeX insert.

These are exact statements about selected local restrictions on a shrinking physical domain. Full Schwarz blocks can include exterior contributions and require their own expansion. No uniform bound in spline degree, knot geometry, or cut position follows from independence alone.

## Integration instructions

- Replace or expand the adaptive probability subsection with the common-event proposition and filtration theorem; retain the existing diagonal-transport and global-inheritance results.
- The first paragraph distinguishes normalized transported candidates from the frozen raw-anchor policy. Ensure the manuscript uses the matrix actually tested by each implementation variant.
- Place the progressive schedule and cost identity in the algorithm/theory interface; report actual exits and failed screens in experiments.
- Use the short univariate example and generic rank obstruction in the main text; place the tensor-product proof, counterexample calculation and optional quantile alternatives in the supplement if space is limited.
- State explicitly that the leading-Gram assumption is sufficient for the small-cut explanation only. It is not an assumption of the energy-screen theorem or relative-to-fresh global bound.
- The TeX insert uses theorem/proposition/example/proof environments. Its labels have a `v2-` prefix. It contains no bibliography additions because the new claims are proved in place; the existing Gaussian argument's primary reference can remain in the surrounding manuscript.

## Checks performed

The insert has 13 unique labels, balanced braces and 18 correctly nested theorem/proof/equation environments. The identity `ab-c^2=epsilon^2/12` was checked with exact rational polynomial arithmetic; direct numerical evaluations approach the stated condition-number coefficient 48. The concrete 2D coefficient matrix has rank five. The progressive-screen code and implementation note were inspected: the shared multiplier, normalized recurrence, deterministic immediate-action rejection, accumulated-power rejection, and persistent budget agree with the theorem. Manuscript compilation is left to the integrating agent; structural checks are not a claim that the merged document has compiled.

## Final independent theory-to-code audit

**Finding: no blocking mathematical defect identified in the current progressive screen or its integration.** This audit inspected the current `screening.py`, inherited `EnergyBudget` and `build_schwarz` logic, and `twolevel.py`; it did not modify any source file.

### Primary-path normalization and global inheritance

`solve_revised` calls `equilibrate(A,b)` and passes the resulting current matrix C to either the frozen builder or `build_progressive_schwarz`. It solves in those scaled coordinates and returns `x=d*y`, with `d=diag(A)^(-1/2)`. Therefore the revision's primary path uses normalized anchors, and the physical preconditioner is the congruence `diag(d) M diag(d)`. This is exactly the current physical diagonal transport in the theorem. The earlier generic warning about calling the builder directly on a raw physical matrix does **not** indicate a mismatch in this integrated path.

`build_coarse` uses the same current coarse correction for the matched fresh and reused policies. Its SPD coarse factor defines a PSD additive action. Adding this same action preserves the inequalities with factors `1-tau` and `1+tau`; congruence back to physical coordinates preserves them again. The raw-anchor variant remains a different API usage, not the primary revision policy.

The inherited unchanged-block shortcut assumes complete changed-ID support. This remains a sufficient caller contract after global diagonal equilibration: if a block contains none of the changed physical coordinates, its principal entries and its selected diagonal scales are unchanged. Current identifiers and ordered membership tuples then preserve the coordinate correspondence. This logic does not license incomplete change metadata.

### Mapping of every accepted estimate

One `state.draw(dimension)` call precedes all power actions. Its allocation is `6*delta_total/(pi^2*j^2)`, and its log multiplier is unchanged across the loop. The first action uses the original Gaussian columns. Subsequent live columns are divided by their Euclidean lengths; accumulating the logarithms of those lengths recovers `log ||K^q omega_l||`. The computed upper estimate is consequently the common-event theorem's expression at the stopping power, including q=3. Zero output columns keep log magnitude minus infinity and cannot increase that maximum.

The matrix and anchor are fixed for this call. Its power-dependent stopping decision therefore does not choose a new candidate from the probes. Returning early spends one allocation, and reaching the maximum power also spends one. Selecting eight probes and a maximum of three powers changes the multiplier and work relative to twelve probes and two powers, but does not change the validity of the theorem. Their relative acceptance rates and total times need measurements.

### Lower bounds and zero/nonfinite behavior

At q=1 the code subtracts the initial Gaussian log length, giving `||K omega||/||omega||`. At later powers each live input has norm one, so the immediate action norm gives the same induced-norm lower bound. The accumulated expression gives `(||K^q omega||/||omega||)^(1/q)`. Both are at most `||K||` for arbitrary nonzero inputs; symmetry is not needed for these lower bounds. Taking their maximum is valid. If it exceeds tau, the returned value is forced above tau even when the probabilistic upper estimate happens to underestimate. This can only prevent acceptance, so it does not enlarge the unsafe-acceptance probability.

A zero action column produces log length minus infinity and remains zero at later powers. For ordinary nonzero Gaussian input columns the lower-bound calculations remain defined, and an entirely zero action returns zero and accepts. If a nonzero K annihilates the sampled block, that acceptance lies within the exceptional event already covered by the Gaussian argument. A synthetic exactly zero initial Gaussian column would create an undefined zero-over-zero ratio and raise under the guarded arithmetic; it does not silently authorize reuse. Such an initial column has probability zero in the ideal Gaussian model.

Direct calls validate finite symmetric input before drawing. The internal callback uses `validate=False` only after the inherited sparse-input, parameter and factor validations; change construction is guarded, and action finiteness is checked on every power regardless of this flag. A nonfinite action raises after the draw and attempted action have been recorded, so it cannot return an accepted decision. The budget remains spent. The caller must record a failed build rather than discard it from a timing campaign.

The implementation tolerates measured roundoff-sized asymmetry, averages anchor asymmetry during Cholesky preparation, and uses floating-point triangular solves, norms and exponentials. Log scaling avoids naive repeated-power underflow but cannot make every matrix action or threshold comparison exact. In particular, representational underflow in a very small action is still possible. Thus the mathematical guarantee remains explicitly in exact arithmetic; tests and residual/spectral diagnostics establish numerical consistency, not an interval certificate.

### Provenance and retained decisions

The wrapper copies the builder's globals into a new function object and replaces only its local bound callback. It preserves the original module and all cache-provenance checks. The inherited gate allows a previous probabilistic unchanged decision only when `factor.probability_token is probability_state.token` and the previous accepted bound satisfies the current tolerance. A different budget object causes a changed, nonexact candidate to be rechecked even when its IDs are reported unchanged. Exact equality with the anchor needs no random budget, while new and rebuilt anchors have zero drift.

Token identity is an operational safeguard, not a replacement for conditional independence. Replaying a previous random stream on a candidate chosen from that same stream is outside the theorem, even if a new token is manufactured. The declared campaign must retain its budget state within each run; independent-run or reproduced-seed reporting should remain distinct from a single lifetime claim.

### Lightweight validation executed for this audit

Eight focused existing unit tests passed with warnings promoted to errors and all BLAS thread counts set to one: budget replay/spending, final-power baseline agreement, unchanged/token/dimension behavior, zero actions, invalid finite/asymmetric input, nonfinite-action accounting, validated builder callback, and global spectral comparison with preservation of the original function. The reported unit-test duration was 0.072 seconds; it is not a performance benchmark.

A separate eight-dimensional signed-diagonal oracle reconstructed the Gaussian block and directly formed the stopped matrix powers. For drift magnitudes 0.001, 0.04, 0.08 and 0.3, the implementation stopped at powers 1, 2, 3 and 1 respectively and matched the direct formula in every case. Each call consumed one allocation. This covers early acceptance, intermediate acceptance, maximum-power rejection and deterministic early rejection without a heavy assembly or timing job.

## Read-only review of the optional measured-cost stopping policy

The separate `cost_screening.py` was reviewed without importing, compiling or running it while the formal timing campaign was active. No blocking mathematical mapping issue was identified. The manuscript insert `measured_cost_note.tex` supplies the corresponding two-paragraph argument and cost limitation; this review is not a runtime validation.

`cost_progressive_bound` fixes the candidate, anchor, probe count, allocation and dimension cap before drawing one Gaussian block. It preserves the same log multiplier, normalized power recurrence and deterministic lower estimates as the reviewed progressive implementation. Reading elapsed time changes only the selected stopping power. The common-event theorem is pathwise over all powers, so elapsed time may depend on probe values or earlier actions without requiring a separate independence assumption or another probability allocation.

Acceptance and deterministic rejection are checked before timing, and the configured final power is also handled first. The timing branch is reached only with an inconclusive upper estimate strictly above tau, no deterministic lower rejection, and power below the effective cap. It returns that nonaccepting estimate, prompting rebuilding in the inherited builder. Thus timing introduces no new acceptance rule. The timing floor is `min(2,q_eff)` for inconclusive screens; valid acceptance or conclusive rejection can still stop at the first power.

`TimedLocalFactor.factor` calls the inherited classmethod with the subclass type, so the resulting anchor is a `TimedLocalFactor`. Its additional `factor_seconds` dataclass field survives inherited `dataclasses.replace` calls when probability metadata changes. The wrapper requires a separate timed-factor cache, keeps the existing probability-token gate, and installs both the timed-factor class and callback only in a private copied function namespace. Batched singleton factors have zero individual allowance; that does not invalidate the spectral argument, and the inconclusive-screen floor still controls their timing cutoff when a caller permits their screening.

The elapsed counter starts before the probe draw and includes that draw and action/normalization checks, while extraction and earlier validation remain outside it. Final accounting includes additional decision/return work. Nonfinite actions and invalid elapsed times fail rather than authorize reuse. The measured allowance is based on historical anchor-construction time, not a bound on present factorization cost or all setup work. Timing can overshoot between checks, and the compulsory minimum powers can cause additional excess if the threshold was crossed before the floor. These facts rule out a hard runtime limit or guaranteed saving. Timing truncations are separately counted, so they should not be described as deterministic spectral rejections.

The implementing agent is adding execution tests. No passing-test, measured-speed or formal-campaign result is asserted by this read-only review.
