# Deterministic lookahead: pre-execution extension

Recorded on 16 October 2026, before the matched stopping-rule study was
frozen or executed. The six-method formal campaign remains unchanged.

The progressive policy can spend additional matrix actions on a candidate
whose Gaussian upper estimates will not meet the tolerance within its
remaining power allowance. Log-convexity of symmetric-matrix power norms
provides a deterministic lower predictor for every future estimate. If all
remaining estimates are predicted strictly above the acceptance threshold,
the factor can be rebuilt immediately. This predicts capped nonacceptance;
it does not assert that the true energy drift exceeds the tolerance.

The proposed implementation retains the original probe block, probability
allocation, effective cap and acceptance/rejection precedence. It checks
the remaining powers using logged action norms, with a conservative
floating-point margin. In exact arithmetic, the capped retain/rebuild
decisions and subsequent anchors agree with the unpruned progressive
policy for a common input sequence and random stream. Floating-point
decision equivalence will also be checked; the safety argument does not
depend on it because lookahead adds only rebuilds.

The follow-up compares four independently maintained policies: fixed
two-power screening, progressive screening, measured-cost stopping and
lookahead screening. It retains all four formal configurations, the same
three full repetitions, seeds 2026101700--2026101702 and current direct
references. The 1,488 solve attempts are measured serially. Four methods
with three repetitions give only partial order rotation. Each of the 48
randomized sequences has risk budget 1e-8; the union bound is 4.8e-7.

Local action savings, inclusive screening, factorization, setup, solve,
assembly-inclusive totals, iteration counts and accuracy failures will be
reported. No speedup is assumed. The new comparison must use its own
concurrently collected baselines rather than combining timings from the
earlier campaign.
