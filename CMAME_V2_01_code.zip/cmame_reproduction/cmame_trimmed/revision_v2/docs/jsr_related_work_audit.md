# DC-JSR 近邻工作核查

核查日期：2026-10-16。仅阅读公开网页和源码文本，未克隆、安装、导入或运行仓库，未执行数值计算，也未修改稿件、参考文献或实验。采用 academic-writing 与 nature-academic-search 的引文核查流程；本环境没有可调用的学术检索 MCP，使用公开主来源网页核查。

## 可确认的信息与访问缺口

| 项目 | 核查结果与来源 |
|---|---|
| 公开仓库 | [Deepsleepinger/JSR](https://github.com/Deepsleepinger/JSR) 可公开读取；README 当前索引标题为 *Defect-Constrained Stateful Schwarz Preconditioner Maintenance (DC-JSR)*。 |
| 所述稿件 | README 列出 *Stateful Selective Maintenance of Two-Level Schwarz Preconditioners for Evolving Sparse Linear Systems*。这是仓库所述稿名，未核实为正式发表题名。[README](https://github.com/Deepsleepinger/JSR) |
| 作者 | README 引用示例给出团体作者 **JSR Research Group**；[`jsr/__init__.py`](https://raw.githubusercontent.com/Deepsleepinger/JSR/main/jsr/__init__.py) 的 `__author__` 为 **Stateful Schwarz JSR Research Group**。没有取得可核对的个人作者、单位和 ORCID。不得据账号名称推定个人作者。 |
| 年份与日期 | README 自给引用年份为 **2026**。无法取得仓库创建/推送日期、精确主文日期或 commit SHA。`results/dc_jsr_validation_summary_2026-10-03.json` 的文件名仅是文件名，不能当作发表或投稿日期。[仓库目录说明](https://github.com/Deepsleepinger/JSR) |
| 投稿状态 | README 自称 **Under Review**，并在引用示例填入 CMAME。该说法仅是作者/仓库声明；未取得出版社接收、发表、DOI 或独立在审记录。不得按已发表 CMAME 论文引用。[README citation section](https://github.com/Deepsleepinger/JSR#-citation) |
| 主文 | README 指向 [`docs/main.tex`](https://github.com/Deepsleepinger/JSR/blob/main/docs/main.tex)，但本次 GitHub blob、raw、refs/heads raw 与 `?raw=1` 均失败或 cache miss；[`submission_package`](https://github.com/Deepsleepinger/JSR/tree/main/submission_package) 也未能列出。**未取得、未读完公开主文；不能确认主文作者栏或全部定理。** |
| 代码 | 可读到 [`run_dc_jsr_shadow_prototype.py`](https://raw.githubusercontent.com/Deepsleepinger/JSR/main/benchmarks/run_dc_jsr_shadow_prototype.py)、[`backend_mumps.py`](https://raw.githubusercontent.com/Deepsleepinger/JSR/main/jsr/backend_mumps.py)、`jsr/__init__.py`。它们足以核对控制量及局部/粗层作用；没有逐文件审计全部生产驱动。 |
| 版本稳定性 | 根页面与 `blob/main/README.md` 返回不同的索引快照；后者还描述较早的 Frobenius/age/mass95 控制。应明确区分 DC-JSR 对角 proxy 与较早控制器，不能拼成一个已核实版本。没有 SHA 时，本核查只对列明的可读文本负责。[较早索引快照](https://github.com/Deepsleepinger/JSR/blob/main/README.md) |

网络访问限制：web 工具能读取部分索引源码，但 GitHub commit/API 与主文多路径未能读取；轻量标准库 HTTP 请求因 DNS 不可达失败；内置浏览器不可用。没有为绕过限制申请权限、下载程序或启动仓库实验。

## 指标与实现的实际含义

可读原型 `DC_JSR_Controller.update_and_decide`（源码 23–96 行）在默认 `metric_type="path"` 下累积

\[
 v_i(t)=\frac{\|\operatorname{diag}A_i(t)-\operatorname{diag}A_i(t-1)\|_2}
 {\max\{\|\operatorname{diag}A_i(t)\|_2,10^{-14}\}},\qquad
 V_i^-(t)=V_i(t-1)+v_i(t).
\]

它按剩余 proxy 的最大值或和选择重建集合，并在重建后清零状态。默认最大值模式对应 README 的超阈值集合；原型也有 endpoint 变体。不要把这些变体泛化为实际全部生产路径的同一规则。[公开控制器源码](https://raw.githubusercontent.com/Deepsleepinger/JSR/main/benchmarks/run_dc_jsr_shadow_prototype.py)

后端保留局部 MUMPS 因子并选择性更新；局部作用为分区加权的 Schwarz 求和，粗矩阵为固定分区粗基上的当前 Galerkin 算子。源码 `apply_weighted` 中的对角权重用于限制/延拓的 partition weighting，**不是**随当前刚度对角变化而传输旧因子的 diagonal transport。[后端源码，102–115、191–247 行](https://raw.githubusercontent.com/Deepsleepinger/JSR/main/jsr/backend_mumps.py)

README 所述 minimum-cardinality optimality 是给定 proxy 约束下的集合选择命题；其残差核对是已求得解的准确性诊断。它们分别不等价于相对当前 fresh preconditioner 的乘性 Loewner 比较，也不等价于整个自适应序列上所有错误保留事件的概率界。由于未取得主文，不能断言整篇稿件绝无其他条件谱结果；能确认的是**可见 diagonal proxy 本身不提供这种保证**。

## 一个无需计算的反例：对角累计 proxy 不能单独控制谱漂移

以下是本次核查的独立代数推导，不是对仓库进行的新数值实验。取单个 SPD 块、\(0<r<1\)，令

\[
 A_a=\begin{pmatrix}1&-r\\-r&1\end{pmatrix},\qquad
 A_t=\begin{pmatrix}1&r\\r&1\end{pmatrix}.
\]

两者均 SPD，对角完全相同；任意只读对角的 path 或 endpoint proxy 都为零。当前对角传输在这个例子中也是恒等变换，因而不能独自解决变化。但沿 \((1,1)^T\) 的 anchor-relative 能量变化为

\[
 \frac{x^T(A_t-A_a)x}{x^TA_ax}=\frac{2r}{1-r},
 \qquad
 \|A_a^{-1/2}(A_t-A_a)A_a^{-1/2}\|_2
 =\frac{2r}{1-r}\longrightarrow\infty.
\]

因此，若没有额外的结构假设，零 diagonal proxy 仍允许任意大的相对谱漂移。这一例子也说明我们的区别不能只写成“用了对角信息”：**当前 diagonal transport 消除幅值变化之后，仍需检验完整 signed anchor-relative discrepancy。** Gaussian power actions 对这一完整矩阵提供上界事件，而不是把对角 proxy 重新命名为谱误差。

## 与本稿的可信定位

| 维度 | 可访问 DC-JSR 材料支持的描述 | 本稿对应结果与必要限定 |
|---|---|---|
| 相同问题意识 | 局部因子作为持久状态、根据累计变化选择更新；当前粗算子参与两层求解。 | 不把 stateful/selective reuse 或每步当前粗层作为独占新意。 |
| 累计量 | 沿未重建区间累计对角变化的 path proxy；另有对角 endpoint 原型。 | 当前标准化矩阵直接与真实保留 anchor 比较，控制累计 endpoint 能量差。 |
| 对角的作用 | 对角变化触发选择；后端另有分区加权。 | 当前基能量尺度传输旧逆作用；完整相关性/耦合变化仍进入 discrepancy。 |
| 约束含义 | 给定 proxy 容差下选择重建集合。 | 在当前 SPD 局部块上以实际能量容差验收，并逐当前活动空间求和。 |
| 随机与时间范围 | 已读代码不含与本稿对应的同探针 all-power 事件或可求和条件历史证明；主文未取得。 | 候选确定后新抽样；同一事件控制全部幂；持久可求和预算给精确算术整序列概率比较。 |
| 活动空间 | 已读后端初始化固定 `n_dofs`、`local_indices` 与粗分区；不能据此断言整个仓库不支持其他适应性。 | 稳定背景标识控制新增、删除、退休与可继承成员；保证在每个当前空间成立。 |
| 已有实证范围 | 仓库报告热/扩散问题及 MPI/PETSc/MUMPS 测量；本次未复现。 | 本稿是串行 trimmed spline 力学研究；不据不同平台/系统的自报时间宣称快于 DC-JSR。 |

建议把本稿的定位写成 **energy-certified maintenance with simultaneous adaptive-sequence control on changing active spline spaces**，并具体说明精确算术概率性质。避免 “the first stateful Schwarz maintenance method”“first cumulative criterion”“first two-level update”。lookahead 的有限幂 nonacceptance 预测及其精确算术决策等价可独立叙述，但也不依靠否定近邻工作的成熟度来支撑。

## 原创相关工作段落建议

适宜接在 Berenguer/Svolos 之后、进入本稿 acceptance criterion 之前；未直接改稿。只引用已核实的公开研究代码，不写“发表于 CMAME”：

```tex
Public DC-JSR research code also treats Schwarz factors as persistent
state and selects local refreshes using accumulated normalized diagonal
variation, together with current Galerkin coarse updates
\cite{JSR2026ResearchCode}. This criterion constrains a diagonal-change
proxy; without additional operator assumptions, that proxy does not
bound the anchor-relative energy discrepancy. Our maintenance test
combines current diagonal transport with a Gaussian bound for the full
normalized discrepancy. A summable allocation then controls all
retention decisions over an adaptive sequence, including changes in the
active spline space.
```

这里的区别由可读控制器和上面的代数反例支持，不以未取得的全文为依据。若未来取得主文且其另有谱定理，应按其确切假设补充比较，不能把本段扩写成“该工作没有任何理论”。

## 可安全加入的 BibTeX：公开代码而非已发表文章

建议仅使用下面这一项；其团体署名照录 README，自给年份为 2026，URL 为确实可见的仓库。缺少 commit SHA 时不编造版本号，也不把包内 `1.0.0` 自动当作归档发布版本。

```bibtex
@misc{JSR2026ResearchCode,
  author       = {{JSR Research Group}},
  title        = {Defect-Constrained Stateful {Schwarz} Preconditioner
                  Maintenance ({DC-JSR}): Public Research Code},
  year         = {2026},
  howpublished = {GitHub repository},
  url          = {https://github.com/Deepsleepinger/JSR},
  note         = {Accessed 16 October 2026. Accompanies an unpublished
                  manuscript titled ``Stateful Selective Maintenance of
                  Two-Level Schwarz Preconditioners for Evolving Sparse
                  Linear Systems''}
}
```

不要照抄 README 的 `@article` 加 `journal={Computer Methods in Applied Mechanics and Engineering}`，因为数据库/读者容易把它当作已发表记录。如确需另列稿件，可在核实主文作者与日期后用 `@unpublished`；当前不提供伪装完整的稿件条目。Under Review 仅在审读备注中保留为仓库自述，不赋予出版社验证含义。

## Svolos 2020：已经引用，原始出版信息正确

当前 `docs/introduction.tex` 第 38–40 行已引 `Svolos2020`，表述为 localization 加 performance model 的 selective factor updates。`cmame_trimmed/paper/references.bib` 第 154 行起已有完整条目；V2 构建器继承该参考文献，因此不需要另造键或重复加入。

出版主来源确认三位作者、题名、JCP 422、109746 和 DOI；摘要说明把局部失效区域与其余健康区域分开，健康区 LU 选择性更新，决策利用理想化性能优化及在线执行时间。[Elsevier 出版页面](https://www.sciencedirect.com/science/article/pii/S0021999120305209)

```bibtex
@article{Svolos2020,
  author  = {Svolos, Lampros and Berger-Vergiat, Luc and Waisman, Haim},
  title   = {Updating strategy of a domain decomposition preconditioner
             for parallel solution of dynamic fracture problems},
  journal = {Journal of Computational Physics},
  year    = {2020},
  volume  = {422},
  pages   = {109746},
  doi     = {10.1016/j.jcp.2020.109746},
  url     = {https://doi.org/10.1016/j.jcp.2020.109746}
}
```

现稿引述准确，不建议采用 JSR README 对 Svolos 的绝对说法（如 “inapplicable outside fracture”）作为文献结论。其论文应用于动态断裂，不等于已证明思想不能用于其他问题。

最终分类：Svolos2020 为 **verified**；JSR 公开代码与 README 自述为 **verified as repository material**；JSR 主文个人作者/精确日期/commit 与期刊状态为 **manual verification still needed**。这不是对未发表工作的真实性或质量作负面推定。
