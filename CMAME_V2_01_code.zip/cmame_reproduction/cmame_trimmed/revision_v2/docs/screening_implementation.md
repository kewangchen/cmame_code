# Progressive Gaussian screen implementation

The frozen `src/preconditioners.py` remains the baseline. The new module
`revision_v2/screening.py` exports `ProgressiveEnergyBudget`,
`progressive_bound`, and `build_progressive_schwarz`. A budget inherits the
original `seed`, `delta_total`, `probes`, `power`, and `min_dimension` options;
`power` now sets the maximum number of actions. The optional immutable
`dimension_cost_cap` flag defaults to `False` and accepts a built-in Boolean
only (integers and strings are rejected). Keep one budget instance for
the entire adaptive sequence, including rejected screens and refreshed anchors.

```python
from cmame_trimmed.revision_v2.screening import (
    ProgressiveEnergyBudget, build_progressive_schwarz,
)
state = ProgressiveEnergyBudget(seed=123, probes=12, power=2)
operator, cache, stats = build_progressive_schwarz(
    A, blocks, global_ids, cache=previous_cache,
    probability_state=state, tau=.2,
)
```

The default mode is `prob_energy`; other modes are passed to the original
builder. Pass a progressive budget for probabilistic mode. The dimension guard
has exactly the original rule: changed blocks of dimension at most
`min_dimension` are factored without drawing probes. The guard is an explicitly
configured policy, not a claim that a given dimension is a universal crossover.

## Optional dimension-based power cap

With `dimension_cost_cap=True`, a block of dimension m and s probes uses

`q_eff = min(power, max(1, floor(m/(12*s))))`.

This compares the leading dense estimates `4*q*s*m^2` for q screen actions and
`m^3/3` for a fresh Cholesky. It is an operation-count heuristic, not a measured
time guarantee; memory traffic, BLAS kernels, extraction, and early stopping
can change the actual crossover. The minimum of one action does not satisfy
the comparison for m < 12*s. Use `min_dimension` separately to skip blocks
where screening is unwanted. For example, 12 probes, maximum power 6,
`min_dimension=288`, and the cap enabled will start screening at dimension 289
with q_eff=2, and permit all six powers from dimension 864 onward. The first
and second power estimates are exactly the same as in an uncapped 12-probe
screen; extra powers are evaluated only if neither prior acceptance nor a
deterministic rejection stopped the screen.

The cap depends on the block dimension and immutable configuration before the
fresh draw, so it leaves the common-event theorem unchanged. A single call to
`state.effective_power(m)` exposes the deterministic cap for inspection. Budget
spending still counts candidates, not actions or powers.

## Probability and spectral contract

At candidate j, the current anchor, local drift K and dimension must be
measurable with respect to the prior history, before a fresh Gaussian block
Omega is drawn. The original summable allocation is

`delta_j = 6 delta_total / (pi^2 j^2)` and
`alpha_j = sqrt(2/pi) delta_j^(-1/s)`.

Fix a unit eigenvector u of the symmetric K for an eigenvalue of maximum
absolute value rho. For every positive integer q and every column omega_l,

`||K^q omega_l|| >= rho^q |u^T omega_l|`.

The common event `max_l |u^T omega_l| >= 1/alpha_j` therefore implies
simultaneously, for **every** q,

`rho <= beta_q = (alpha_j max_l ||K^q omega_l||)^(1/q)`.

The Gaussian small-ball inequality bounds the complement of that one event by
`(sqrt(2/pi)/alpha_j)^s = delta_j`. The event is common to all powers of this
same K and same probe block, so looking after each power does not require
splitting delta_j. This argument would not justify extra acceptance decisions
for changed candidates using the same probes. Conditioning on the history and
summing delta_j gives the same sequence-wide `1-delta_total` guarantee as the
original algorithm. Powers and probes may be configured before a run; this
implementation keeps them immutable within a budget instance.

At each action, the algorithm also computes induced-norm lower bounds
`||K v||/||v||` and `(||K^q omega||/||omega||)^(1/q)`. Either exceeding tau
proves rejection in exact arithmetic, allowing the remaining powers to be
skipped. Zero action columns are ignored. Early acceptance is allowed when
`beta_q <= tau` and no deterministic lower bound rejects. If no early stop
occurs, the final-power estimate uses exactly the original multiplier and the
same Gaussian block. It agrees numerically with the original implementation;
there is no final-power conservatism penalty from repeated looks.

All decisions remain floating-point tests. The probability theorem is about
exact arithmetic, not an interval certificate. The normalized recurrence and
logarithmic scales prevent naive power underflow. Nonfinite input is rejected
before a draw; nonfinite actions fail closed after recording the spent draw and
attempted work. No diagonal shift, clipping, inverse construction, or additional
factorization is used by the screen. The public direct-call API validates the
local drift by default. Its `validate=False` option is reserved for the builder
callback, which receives a drift from the original builder after that builder
has checked the external sparse matrix, validated its anchors, and constructed
the drift under overflow/invalid/division guards. The callback avoids redundant
full-matrix finiteness and symmetry scans. Finite-action checks remain active
at every power. External input validation is not skipped.

On the common sequence event, every accepted anchor obeys the original local
relative-energy condition. The unchanged Schwarz assembly and scatter sum give
the same global Loewner comparison to the corresponding freshly factored
additive inverse, with factors `1-tau` and `1+tau`.

## Original-builder reuse

The wrapper creates an isolated Python `FunctionType` from the original
builder's bytecode and a shallow copy of its globals dictionary. It replaces
only the private `_probabilistic_bound` name in that copy with a local callback.
This permits early decisions without editing the frozen source, duplicating
its long cache builder, or monkeypatching process-global state. Extraction,
stable identifiers, certificate-token provenance, unchanged-block skips,
factorization, and operator application are therefore inherited directly.
The copied namespace is per call and no callback persists in the original
module. This deliberate adapter depends on the original private callback name;
if the original builder is changed in a future revision, the wrapper must be
reviewed and the regression tests rerun.

## Work accounting and validation

Every build adds these per-call fields, with corresponding cumulative fields
prefixed `cumulative_screen_`:

- `screen_action_batches`: actual K actions on a block of s columns, including
  screens that fail and cause factorization;
- `screen_column_actions`: the preceding quantity times s;
- `screen_early_accepts`, `screen_early_rejections`;
- `screen_lower_bound_rejections`: all deterministic rejections, including the
  final power;
- `screen_avoided_action_batches`: remaining actions below the effective cap
  skipped because of early acceptance/rejection;
- `screen_cost_capped_checks`: attempted screens whose effective cap is below
  the configured maximum;
- `screen_cost_cap_avoided_action_batches`: configured maximum minus effective
  cap, summed over attempted screens.

`screen_power_histogram` records completed screens by their stopping power.
`screen_effective_power_histogram` records attempted screens by their effective
cap; `screen_dimension_cost_cap` records the configuration flag. An acceptance
or rejection at q_eff is a final decision, not an early decision, even when
q_eff is less than the configured maximum. This keeps early-stopping savings
separate from budget reductions imposed by the cost cap.
`screen_max_lower_bound` records the largest lower diagnostic during this
build. The original randomized timing, factor timing, counters, failure-budget
spending and accepted-bound metadata remain available. `max_randomized_bound`
includes values from failed screens and may be large; it is not an accepted
certificate summary. Failed nonfinite actions consume their probability budget
and attempted action count, then raise; they do not produce a completed-build
record. Callers running sequences must log such exceptions as failures rather
than silently dropping the candidate.

The tests use independent generalized eigensolvers on synthetic SPD blocks and
an actually assembled small extruded spline system; they compare the global
additive inverses, check exact final-power baseline agreement, reproduce the
Gaussian draw and sequence spending, and cover early decisions, final rejection,
unchanged/provenance rules, dimension skips, zero/tiny actions and nonfinite
failure. These tests establish implementation consistency, not empirical
probability estimates or speedups. Timing campaigns belong in separate serial
runs; no elapsed-time assertion is made here.

Validation command (from repository root):

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  .venv/bin/python -W error -m unittest \
  cmame_trimmed.revision_v2.tests.test_screening -q
```

The initial exploratory implementation, which redundantly scanned each drift
in the callback, is preserved as `results/pilot_sources/screening_initial.py`.
Exploratory measurements using that version must retain that source association.
