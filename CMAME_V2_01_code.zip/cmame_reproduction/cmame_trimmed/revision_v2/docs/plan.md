# CMAME revision and acceleration plan — 2026-10-16

User-authorized scope: improve the existing manuscript following the supplied review, including actual acceleration, 3D long sequences, break-even measurements, adaptive theory, leading-Gram applicability and CMAME prose. The review is a proposal/evaluation, not evidence of performance or novelty. Original delivery and benchmark data stay unchanged.

Architecture: keep existing `cmame_trimmed/src` and primary records frozen. Add a revision package for accelerated screening and efficient extruded-IGA assembly, independent tests, drivers, results and manuscript build. The final package includes old and new evidence with separate provenance. No submission or external messaging.

Tasks:
- [x] Verify named 2019/2026 CMAME papers from primary sources; extract original structural patterns, distinguish maintenance from solver construction. Full Chu text remains unavailable; only verified metadata and accessible abstract are used.
- [x] Analyze adaptive Gaussian screening with reduced work. One conditional Gaussian event bounds all powers of a fixed candidate, including timing-dependent stopping. Pilots use actual local matrices; old policy remains a matched baseline.
- [x] Derive leading-gradient rank/failure examples for actual spline restrictions. The finite-matrix local test and global inheritance do not require the explanatory asymptotic hypothesis.
- [x] Implement/test tensor-product assembly for extruded 3D splines, compare independent old product-quadrature matrices and solutions, and test disappearing/reappearing active rows. Use the same assembly for all policies. Higher-order quadrature audit is pending.
- [ ] Execute serial 3D high-order/mesh-size pilot, then predeclare a finite campaign of 50-query sequences, plus factor-size/update-size break-even tests with repeated timings and identical precision.
- [ ] Audit results, failures, paired repetition variation, setup/screen/factor/solve/assembly breakdown. No cherry-picked headline or universal speed claim.
- [ ] Rewrite title/abstract/introduction/discussion around actual numerical-analysis contribution and observed operating regime. Retain negative baselines and applicability limits concisely.
- [ ] Plot Python vector figures, compile merged LaTeX main/supp, independently audit math/claims/code, render all pages.
- [ ] Deliver dated V2 folder, revised audit and two small, extracted-and-tested archives.

Figure contract: evidence chain = actual 3D geometry/response -> costs vs local block dimension -> sequence-wide paired timings -> spectral/accuracy checks. Python only, PDF/SVG/PNG; observed ranges and denominators explicit. No illustrative data used as measurements.

Alternatives considered: prose-only reframing would not address the review; many small planar examples would not resolve cost scalability; chosen approach combines a cheaper validated screen with larger 3D factor workloads and honest crossover analysis. User explicitly asked for this substantive revision, so execute without another approval round.

Follow-up disclosed before execution: the first complete cubic repetition showed that six-power screening saved factors but increased total time relative to the two-power baseline. A separate matched experiment will compare fixed, progressive and historical-cost stopping on all four original configurations and all three repetitions. This experiment is an outcome-motivated follow-up, not part of the original frozen campaign. Original measurements and sources remain intact.
