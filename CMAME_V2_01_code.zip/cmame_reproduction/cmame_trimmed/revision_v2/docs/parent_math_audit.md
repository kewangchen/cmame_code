# Independent algebra review by the integrating agent

Scope: static review of the revised main and supplementary mathematical text;
this is separate from numerical validation and from the authoring agent's review.

1. Local comparison: `(1-tau)H <= C <= (1+tau)H` gives
   `(1-tau)C^-1 <= H^-1 <= (1+tau)C^-1`. Congruence by the current
   positive diagonal scale gives the stated inverse-action inequalities.
2. The all-powers event is valid for a fixed symmetric signed discrepancy:
   a maximal-absolute-eigenvalue component is amplified by `eta^q` for every
   integer power. Gaussian small-ball integration gives the stated multiplier.
3. Conditional fresh probes, the tower property and the countable union bound
   justify the adaptive lifetime statement. Dimensions may change between
   checks; the comparison at each query uses only its current restrictions.
4. Summing local positive-semidefinite inequalities introduces no extra
   overlap factor in the relative-to-fresh comparison. A common current
   positive-semidefinite coarse correction preserves the same constants.
   Fresh-method mesh, degree and cut dependence is not thereby removed.
5. In the small-cut proposition, the normalized perturbation is the sum of
   a scaled Gram perturbation and a diagonal-normalization perturbation.
   Each has Euclidean norm at most `r ||C0||/(1-r)`, yielding the stated
   `2 kappa0 r/(1-r)` relative bound. The radius condition follows by
   solving `2 gamma/(1-gamma) <= tau`. Added the explicit restriction
   `epsilon_max <= bar_epsilon`, where the uniform remainder hypothesis holds.
6. The negative quadratic Bernstein example gives
   `ab-c^2=epsilon^2/12`; its unit-diagonal correlation therefore yields
   `epsilon^2 kappa(C_epsilon) -> 48`. The positive pair has determinant
   `4/3` and normalized limit condition number `7+4 sqrt(3)`.
7. For the tensor-product corner family, a vanishing linear combination of
   leading gradients would make a polynomial with no constant monomial
   constant. Polynomial independence proves the claimed leading-Gram rank.
8. Historical-cost termination only replaces inconclusive reuse by a current
   factorization. It introduces no additional acceptance event. The timing
   threshold is soft, and its compulsory power floor can produce more than
   one action of overshoot.

The implementation uses floating-point arithmetic and pseudorandom streams.
The probability theorem describes the ideal Gaussian experiment; the
reported numerical audits do not turn it into an interval certificate.
The later screening-work proposition is reviewed in its dedicated note.
