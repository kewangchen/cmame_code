# Final static lookahead audit

Reviewed `docs/lookahead_main.tex`, `docs/lookahead_theory.tex`, `lookahead_screening.py`, `docs/lookahead_implementation.md`, and their placement in `build_revision.py`. The new tests were read to understand intended cases, but were not executed. No numerical execution, imports, or compilation were performed. This report does not modify implementation or reviewed theory.

## Verdict

No blocking mathematical, acceptance, or probability-allocation defect was found. The implemented conservative finite-horizon predicate is a valid exact-arithmetic consequence of the proved per-column secant bound. The parent corrected both prose/edge-case clarifications identified below, and I re-read the revised supplement to verify them. Neither is outstanding, and neither permits unsafe acceptance.

## Proof-to-code correspondence

For signed symmetric K, spectral squared norms use |lambda_i|^(2q), so Cauchy–Schwarz gives N_q^2 <= N_(q-1)*N_(q+1). Positive live-column log norms therefore have nondecreasing increments. At q=1 the secant uses the original Gaussian log norm. At later powers the accumulated log magnitudes reproduce log||K^q omega|| in exact arithmetic; `previous` is initialized to the original log norms and updated only after an inconclusive, unpruned stage.

`_future_acceptance_impossible` evaluates every remaining integer power. Each row of its `prediction` array equals log(alpha)+f_q+(p-q)*(f_q-f_(q-1)); `threshold` equals p*log(tau). The maximum is taken over probes separately for each future power, as required. Different powers may have different witnessing columns. The rowwise strict inequalities rule out all remaining upper-estimate acceptances. The main text correctly describes O(s*(Q-q)) scalar work per lookahead evaluation; the supplement separately proves the stronger cap-only equivalence under failed immediate lower rejection. The implementation does not claim to use that simplification.

The positive configured margin is subtracted from each column's gap before taking maxima. In exact arithmetic this can only defer a valid pruning decision; it cannot turn an invalid predictor into a valid one. Nonfinite live data, overflowing predictions, or nonfinite guarded gaps defer pruning. The margin is not a forward-error certificate for the solves or accumulated logarithms. The prose correctly restricts exact decision/anchor equivalence to exact arithmetic and identical prescribed inputs, probes, and caps.

The ordinary acceptance, deterministic norm rejection, and final-cap branches execute before lookahead. A lookahead return is therefore the current `bound=beta_q>tau`; it is not the extrapolated lower predictor. The builder consequently refreshes the anchor. The distinction between predicted capped nonacceptance and a true norm violation is maintained in both prose and counters.

## Zero cases and completed documentation corrections

Items 2 and 3 retain the original findings and suggested wording for the audit trail. The current supplement now expressly describes accumulated-log differences, mathematical omission of zero original probes, and the inherited fail-closed behavior for an exactly zero original column, which has ideal Gaussian probability zero.

1. **Action-generated zero columns are correct.** Their accumulated logs are minus infinity, they are excluded from the lookahead live set, and their future powers remain zero. For ordinary nonzero original Gaussian probes, all-zero current actions produce beta=0 and accept before lookahead. The tau=0 branch is resolved by the existing acceptance/lower tests; the helper also avoids log(0).

2. **An exactly zero original column fails closed rather than being omitted by the whole screen.** At `lookahead_screening.py:134–135`, subtracting its original minus-infinity log norm from its minus-infinity current magnitude produces an invalid floating operation under the surrounding error state. This behavior is inherited from the existing progressive lower tests. Ideal Gaussian original columns are nonzero almost surely, and the failure does not create acceptance. The supplement's sentence “A zero original column stays zero and can be omitted throughout” is valid for the mathematical predictor, but should not be presented as an implemented zero-initial-probe handling guarantee. Suggested clarification: “A zero original column can be omitted mathematically; Gaussian originals are nonzero almost surely. An exactly zero original column in the floating implementation follows the numerical-failure path of the inherited lower test.” No change is needed to the zero-action theorem.

3. **Describe the implemented secant arithmetic.** The supplement's final numerical paragraph recommends using the logged unit-column action norm at q>1 to avoid subtracting accumulated logs. The current implementation instead uses `slope = current - previous` at line 72, as correctly described in `lookahead_implementation.md`. Both are algebraically identical; only their floating rounding differs. Suggested replacement: “The implementation stores the preceding accumulated log norm, initialized with the original probe norm, and forms secants by subtraction. Its numerical margin accounts heuristically for these logarithm magnitudes and the extrapolation horizon; it is not a rigorous error bound.” This aligns the numerical description without changing code or the mathematical result.

## Probability and work accounting

Exactly one inherited `draw` occurs per screened candidate, before all powers. It advances the original summable allocation and preserves the budget identity. Lookahead adds no draw or acceptance event. The same maximal-eigenvector event continues to bound every Gaussian power estimate, and conditional-history plus countable-union arguments retain the original lifetime safety probability. This remains true even if a numerical prediction causes an unnecessary rebuild: the rule only removes acceptances or advances rebuilding. Exact capped-policy equivalence, in contrast, is not guaranteed in floating point.

Completed action batches and column actions are incremented before each action. On pruning, the remaining effective powers enter only `lookahead_avoided_action_batches`; `_finish(power,False,False,power)` records the stopping histogram without adding mathematical early-stop savings or norm-rejection counts. Dimension-cap savings remain separate. Thus, for completed checks with configured maximum Q, Q*checks-actions equals dimension-cap savings plus ordinary early-stop savings plus lookahead savings. Interrupted/failed checks are not covered by that completed-check identity. The wrapper reports per-build differences and cumulative counters without changing the delegated cache/provenance logic.

## Manuscript integration and scope

`build_revision.py:303` places the main insert after `theory_main.tex` and `work_bound_main.tex`. The supplement insert follows the corresponding full theory and work-bound proofs. New labels have distinct lookahead prefixes. Q and alpha are locally defined as the effective cap and fixed multiplier, consistently suppressing the per-check index; an optional editorial clarification is to write Q=q_eff and alpha=alpha_j. This would not change their meaning. The current main live-column subscript is valid `\mathrm{live}`.

No absolute priority claim or assertion of a new general log-convexity principle appears in the reviewed inserts. The contribution is the deterministic capped-nonacceptance criterion applied to this screening recurrence, with no extra K action and exact-arithmetic preservation of capped decisions. Numerical speed and floating-point decision agreement remain separate empirical questions.
