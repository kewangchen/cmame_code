# Static audit of capped-power lookahead

Verdict: the proposed pruning is valid for symmetric K, including signed eigenvalues and singular matrices, in exact arithmetic. It predicts inability of the remaining capped Gaussian estimates to accept; it is not a lower bound proving violation of the energy contract. No numerical jobs, tests, imports, or compilation accompanied this derivation.

## Valid predictor and stopping implication

Write f_l(q)=log||K^q omega_l|| for live columns. The spectral identity ||K^q omega||^2=sum_i |lambda_i|^(2q)|c_i|^2 and Cauchy–Schwarz give N_q^2<=N_(q-1)N_(q+1). Thus successive log increments increase, and f_l(p)>=f_l(q)+(p-q)[f_l(q)-f_l(q-1)] for every integer p>q. The lower predictor for log beta_p is the maximum over columns of these extrapolations plus log alpha, divided by p. A strict predictor above log tau at every remaining integer power rules out every future upper-estimate acceptance. Equality is insufficient because the acceptance condition uses <=.

A finite loop costs O(s*(Q-q)) arithmetic and no matrix action. The stronger O(s) cap-only test is valid after the immediate norm lower-rejection test has failed: each secant a_l<=log tau, so p*(L_p-log tau)=max_l[p*(a_l-log tau)+b_l] is nonincreasing in p. Positive value at the cap is equivalent to positive values at every remaining power. This proof uses the lower-rejection ordering. A finite loop is reasonable in the implementation when Q<=6 and avoids relying on numerically identical secant and lower-test comparisons.

## Why arbitrary endpoint tests are invalid

Without the lower-test restriction, checking only the two endpoints of the upper envelope is unsound. Set q=1, Q=4, K=diag(tau*exp(-1),tau*exp(3/4)), and probes along the two eigenvectors with alpha*||omega_1||=exp(5/2) and alpha*||omega_2||=exp(-5/2). The predictions are exact. Their log gaps relative to tau are

- first column: -1+5/(2p);
- second column: 3/4-5/(2p).

The maximum is 1/4 at p=2, -1/12 at p=3, and 1/8 at p=4. Both endpoints exceed the threshold, but the interior does not. The actual progressive implementation would already reject this example by its immediate lower test because the second eigenvalue exceeds tau. Hence this counterexample does not invalidate the cap-only simplification under its stated hypothesis. It explains why that hypothesis must be retained.

## Cases and integration requirements

- A zero current power column stays zero and contributes no live logarithm. Nonzero current power implies nonzero previous and subsequent powers for symmetric K. At q=1 use the original Gaussian norm. If all columns vanish, the existing beta=0 test already accepts.
- At tau=0, any nonzero current action gives positive immediate lower rejection; otherwise beta=0 accepts. The lookahead need not take log(0).
- On pruning, return the current beta_q>tau, not the future lower predictor. Record lookahead rebuilds separately from lower_bound_rejections. The former do not assert eta>tau.
- One draw, one allocation, the same original probes, and the same effective cap preserve the unpruned capped retain/rebuild outcome for each fixed candidate. For the same sequence of external matrix updates, induction preserves the anchor sequence and subsequent RNG state. This does not promise equality of wall-clock-conditioned external updates, rejection-bound diagnostics, or floating-point decisions.
- Conservative floating margins and deferring ambiguous/nonfinite cases are prudent numerical safeguards, not interval certificates. Even an unnecessary lookahead rebuild adds no acceptance event; the underlying energy safety argument does not require exact acceptance equivalence.

The independent proof insert is `docs/lookahead_theory.tex`. Existing reviewed theory and frozen implementation files were not modified.

## Main-text contribution placement

Prepared `docs/lookahead_main.tex`: 370 whitespace-delimited source words, including TeX notation and comments. It contains the predictor, a concise proposition and proof, exact capped-decision scope, separate rejection classification, and the implemented O(s*(Q-q)) scalar check at each lookahead evaluation. It does not claim the current implementation uses the sharper O(s) cap-only simplification. Existing introduction and abstract files were read but not edited.

The current introduction presents contributions in connected paragraphs rather than an explicit list. Its progressive-screen paragraph emphasizes early decisions and a dimension cap, followed immediately by measured-cost stopping. Give lookahead its own short paragraph before measured-cost stopping so readers can distinguish exact preservation of capped decisions from an additional work limit that can change retention. Suggested insertion immediately before “We also examine a stopping rule ...”:

> We also derive a deterministic lookahead test from log-convexity of symmetric power norms. Using quantities already computed, it predicts when every remaining Gaussian estimate must exceed the tolerance. Rebuilding such candidates eliminates their remaining screening actions while preserving the capped policy's retain-or-rebuild decisions in exact arithmetic. The test needs no additional matrix action or random draw.

The next paragraph can retain the historical-cost policy, with its opening made explicitly separate:

> Separately, we examine a stopping rule that compares the elapsed test cost with the recorded cost of constructing its anchor.

For the abstract, replace the current sentences beginning “A progressive Gaussian screen shares ...” and ending “... inconclusive tests.” with:

> A progressive Gaussian screen shares one probability event across all powers of a candidate. A deterministic lookahead based on log-convex power norms predicts when no remaining power can accept, avoiding further matrix actions while preserving the capped screen's decisions in exact arithmetic. A separate cost-based rule limits inconclusive testing.

The abstract's existing lifetime guarantee, strict-drift work bound, small-cut scope, experimental counts, and `@PERF@` placeholder can remain. No new performance result should be attached to lookahead until its separate measurements and decision comparisons are available. In particular, “preserves the capped decisions” is a proved exact-arithmetic statement, while floating-point agreement is an empirical check requiring its own evidence.

If a contribution list is introduced during editing, one precise item is:

> A deterministic lookahead criterion predicts nonacceptance at every remaining Gaussian power without an additional matrix action or random draw, preserving the capped screen's retain-or-rebuild decisions in exact arithmetic.
