# Optional measured-anchor-cost screen

`cost_screening.py` is a separate experimental policy. It imports the frozen
numerical helpers and clones the frozen builder's globals; it does not change
any formal-campaign source or result. No speedup is asserted. The new source
and its tests were authored while timing jobs ran and have not yet been
compiled or executed; verification must wait for the parent's go-ahead.

## Policy and arithmetic

The API exports `TimedLocalFactor`, `CostEnergyBudget`,
`cost_progressive_bound`, and `build_cost_schwarz`. The wrapper has the original
builder signature and requires a separate cost-policy cache.

`TimedLocalFactor.factor` calls the original superclass classmethod with the
same matrix and diagnostics flag, measuring that call with `perf_counter`.
The superclass still performs its original validation, copying, equilibration
and Cholesky; the numerical matrix operations are unchanged. The subclass only
adds `factor_seconds`. Metadata updates through `dataclasses.replace` retain
that timing along with the original anchor. The timing is historical anchor
creation cost, not a new estimate of current-matrix factorization cost.
Singleton factors created directly by the original batched builder have zero
individual timing allowance because there was no per-singleton factor call.
They remain safe and retain the same power floor if a caller permits screening
at that size. The main dimension guard normally skips them.

`CostEnergyBudget` retains the same immutable probe, maximum-power, dimension
cap and sequence-allocation fields. Its additional immutable `rho` defaults to
0.25 and must be a finite positive numeric value; Boolean values are rejected.
This workload fraction was chosen before the proposed cost-aware ablation,
not fitted to its future measurements. `rho` is a policy parameter, not a
universal crossover constant.

For a candidate of dimension m, first set the same q_eff as the dimension-capped
progressive policy. Draw the same fresh Gaussian block and use the same
small-ball multiplier. At each q:

1. Compute the unchanged normalized power action, logarithmic upper estimate
   and deterministic lower diagnostics.
2. Accept if its upper estimate is at most tau and no lower diagnostic rejects;
   reject immediately if a lower diagnostic exceeds tau.
3. Return the final inconclusive estimate if q equals q_eff.
4. Otherwise, if q is at least min(2,q_eff) and measured screen elapsed time is
   at least `rho * anchor.factor_seconds`, stop and return that inconclusive
   estimate, which is above tau and therefore causes a fresh factorization.
5. Continue to q+1 when none of these conditions holds.

Thus the measured-cost rule cannot force an inconclusive stop before the
baseline two-power strength, except when the separate dimension cap is one.
The q=1 acceptance and deterministic rejection opportunities remain. Timing
never creates an acceptance or overrides a deterministic rejection.

The elapsed timer begins inside the callback and includes the draw, power
iterations and their diagnostics/counter work. The original builder separately
records inclusive randomized setup time including drift formation; that time
remains the appropriate screen-cost field for policy comparisons. The new
`measured_screen_seconds` field measures the callback's own monitoring scope,
not a replacement for all setup costs. Factor instrumentation and all callback
instrumentation remain inside the original setup timer.

## Probability and cost statements

For the fixed current K and the initially drawn probes, the existing common
small-ball event simultaneously bounds every power estimate. A stopping power
chosen from elapsed time, observed upper estimates, deterministic diagnostics,
or their combination is covered by that same event. The anchor factor time
and immutable rho belong to the pre-draw history. Therefore the original
conditional sequence union bound applies without spending an allocation for
each timing decision. This statement does not require runtime to be independent
of the probes. Fresh draws, anchor-state provenance and one continuing budget
per policy/sequence remain mandatory.

This is a soft cost rule. The mandatory floor can exceed the allowance before
timing truncation is permitted. After reaching that floor, an action started
below the allowance can cross it, so stopping can occur one action interval
after the threshold is crossed, plus checking/return overhead. There is no
hard bound on that interval, total screen runtime, or speedup. Historical
factor timings can be noisy and matrix-dependent. A stopped inconclusive
screen still pays for a new factor, and a more permissive accepted anchor can
increase CG cost; total policy time must be measured before any efficiency
claim is made.

## Records and pending verification

The original randomized counts, failure allocations, factor/setup times and
accepted metadata are retained. In addition to the dimension-cap and
power-histogram fields, the wrapper records:

- `screen_timing_cap_checks` and `screen_timing_cap_avoided_action_batches`;
- `screen_timing_cap_histogram`, distinct from the dimension cap histogram;
- callback `screen_measured_screen_seconds`, with cumulative counterpart;
- sums of historical factor times and timing allowances for screened anchors;
- the chosen `screen_rho` and `screen_kind='progressive_measured_anchor_cost'`.

Timing truncation does not increment early acceptance/rejection counts or
`screen_avoided_action_batches`; its avoided actions have their own counter.
The latter original field remains the savings from mathematical early stopping
relative to the effective dimension cap. Every attempted action and drawn
candidate remains counted, including nonfinite-action failures. Matrix input
validation stays on for public calls and the original builder; the validated
internal callback only skips redundant matrix scans. Nonfinite/negative factor
measurements, a nonfinite allowance, or invalid monotonic elapsed time fail
closed.

The pending tests use controlled clocks to verify the two-power floor,
post-floor overshoot, dimension-cap interaction and decision precedence. They
also compare original/timed factor arrays, check metadata replacement and cache
isolation, test fresh-probe spending/nonfinite behavior, and use independent
generalized spectra on accepted SPD blocks. No elapsed-time performance
assertion appears in those tests.

After all concurrent timing jobs stop and authorization is given:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  .venv/bin/python -W error -m pytest \
  cmame_trimmed/revision_v2/tests/test_cost_screening.py -q
```

A fair later ablation should compare fixed two-power, frozen progressive
maximum-six, and this optional cost policy on the same query sequences, with
separate own caches and warm starts, all current references, three complete
repetitions, rotated order, source hashes and all failures. Existing formal
results remain separate; this addition does not retroactively change them.
