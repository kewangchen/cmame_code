# Deterministic response formatter interface

`response_report.py` is authored but has not been executed against the incomplete campaign/audit records. It uses the standard library and the standard-library-only `audit_tables.audit_facts` helper. It never invokes an analyzer, numerical solve, test, figure renderer, compiler, finalizer or archive operation.

## Pre-archive output

After formal and cost summaries, all required audits, and the main verification record exist and are complete:

```sh
python -m cmame_trimmed.revision_v2.response_report --stage pre-archive
```

Defaults:

- Input directory: `revision_v2/results`.
- Template: `docs/revision_response_zh.md`, kept unchanged.
- Main verification: `results/verification.json`.
- Separate completed response: `docs/revision_response_completed_zh.md`.
- Fact ledger: `results/response_facts_ledger.json`.

The pre-archive output explicitly states that actual extraction, extracted-code tests, figure reproduction and manuscript rebuild remain pending. It does not claim archive verification merely because archives have been created.

## Final output alongside the archives

```sh
python -m cmame_trimmed.revision_v2.response_report --stage final \
  --archive-verification /path/to/archive_verification.json \
  --archive-root /path/to/archives
```

The final response and fact ledger can remain beside the archives and submission files. They need not be included in archives before those archives' hashes are established. Regenerating these two outputs does not change the verified archive files. The formatter does not modify the finalizer or copy outputs into a delivery directory.

The exact archive-record schema is:

```json
{
  "complete": true,
  "checks": {
    "extracted": true,
    "tests": true,
    "figure_reproduction": true,
    "manuscript_rebuild": true
  },
  "archives": [
    {"file": "code.zip", "sha256": "<64 lowercase hexadecimal digits>", "bytes": 123},
    {"file": "records.zip", "sha256": "<64 lowercase hexadecimal digits>", "bytes": 456}
  ],
  "verified_utc": "<actual verification time>",
  "commands": ["<actual commands>"],
  "results": {"<check name>": "<actual recorded outcome>"}
}
```

The byte counts above illustrate the schema only and are not measurements. At least two archive identities are required. `file` resolves relative to `--archive-root`, or the record's parent if that argument is omitted. The actual archive bytes, sizes and SHA-256 values must match the record. All four `checks` keys must be Boolean; a completed false check remains an explicit failed check. `verified_utc`, `commands` and `results` are optional metadata retained verbatim in the ledger.

If `results/archive_verification.json` exists, it is read automatically unless an explicit path is supplied. Final mode otherwise refuses to proceed. Pre-archive mode with no such record states that archive checks are pending.

The main `verification.json` requires Boolean `tests_passed`, `compilation_passed` and `visual_review_completed`. Optional `tests` (command/count/log/hash), `compilation` (documents), `visual_review` (pages/figures), `source_hashes_verified` and other fields are retained. The response reports only values supplied; it does not invent test counts or interpret page-inspection completion as an unrecorded visual pass.

## Validation and provenance

The formatter requires complete source sequence files and exact method–query–repetition coverage. It verifies formal and cost manifest hashes, recorded/live/snapshot source hashes, summary record hashes, per-repetition time sums, medians, failures, paired ratios and ratio extrema. A failed method remains visible and never acquires a successful speedup ratio. Missing exception phases stay unavailable. No aggregate combines formal timings with the separately rerun measured-cost study.

Mechanism, quadrature and active audits must be complete; completed failed checks are retained. Active-audit coverage is checked, and exact spectra remain distinct from Rayleigh lower diagnostics. The kernel grid must be complete, and its audit hash and diagnostic counts must agree with its rows. The formatter imports `audit_facts` only for its JSON-safe fact schema; it does not run audits.

Each of the seven named response slots is replaced exactly once. The ledger records every input's path, byte count and SHA-256; JSON field paths supporting each slot; rendered slot text and hash; derived values; failed rows; audit facts; verification outcomes; ratio direction and rounding. No clock is read, so fixed inputs and paths produce deterministic output. Output paths cannot overwrite any input or each other.

The completed prose corrects the obsolete theory-extension path to `docs/theory_main.tex` and `docs/theory_supplement.tex`. It also references `docs/work_bound_main.tex` and `docs/work_bound_supp.tex`, stating the strict drift-margin, adequate-cap and no-early-truncation assumptions of the sufficient action-count bound. Work-tail `epsilon` is distinguished from safety `delta`; leading operation counts are not described as measured runtime gains or a new Gaussian concentration principle.

Available overrides are `--results-dir`, `--code-root`, `--template`, `--verification`, `--archive-verification`, `--archive-root`, `--output` and `--ledger`. The formatter refuses an incomplete input set and leaves the original response template intact.

## Four-policy follow-up contract

The follow-up uses `energy`, `progressive`, `cost`, `lookahead`, in that manifest order, over exactly the four formal configurations with three repetitions: 1,488 method–query attempts and 48 persistent randomized sequence budgets. The per-sequence budget is `1e-8`; the union bound is `4.8e-7` and assumes no independence across methods or families. The formal campaign's separate 24-budget statement remains unchanged.

The method order at `(repeat, step)` is the above tuple shifted by `(repeat+step)%4`. Three repetitions partially rotate four positions; there is no complete per-query order balance. The four policies keep their own caches and warm starts. Both numerator and denominator timings come from this same follow-up batch.

The exact added-source set is `cmame_trimmed/revision_v2/cost_ablation.py`, `cmame_trimmed/revision_v2/cost_screening.py`, and `cmame_trimmed/revision_v2/lookahead_screening.py`. All three live files and their `cost_sources` snapshots must match the frozen follow-up manifest. Existing core hashes must still agree with the formal manifest and its snapshots.

`cost_summary.json` preserves `cases[case].ratios[baseline][metric]` and `geometric_mean[baseline][metric]`, with **cost as denominator**. It additionally supplies `cases[case].lookahead_ratios[baseline][metric]` and `geometric_mean_lookahead[baseline][metric]`, with **lookahead as denominator**. Both support all four method keys; self-ratios are identities. At least `energy` and `progressive` comparisons are retained in each collection when successful. Each ratio records numerator/denominator identities, ratio of three repetition medians, all three paired ratios and their minimum/maximum. A method with any failed query in any repetition has no successful ratio. Each geometric mean is checked against exactly four available family ratios; unavailable families cannot be dropped. The response shows both denominator collections and their separate geometric means.

Lookahead requires `stat_screen_kind="progressive_secant_lookahead"` and `stat_screen_lookahead_log_margin=1e-10`. Per-query raw counters are `stat_screen_lookahead_rejections`, `stat_screen_lookahead_avoided_action_batches`, `stat_screen_lookahead_evaluations`, `stat_screen_lookahead_margin_deferrals`, `stat_screen_lookahead_nonfinite_deferrals` and `stat_screen_lookahead_power_histogram`. Per-repetition totals retain these names without the `stat_` prefix, with additional short aliases `lookahead_rejections` and `lookahead_avoided_action_batches`. Avoided actions are partitioned into dimension-cap, ordinary mathematical early-stop, measured-time and lookahead terms; lookahead pruning is never relabeled as an immediate norm-lower-bound rejection. All scalar prediction and guard work belongs to inclusive screening/setup time. The implementation checks every remaining allowed integer power after ordinary acceptance and immediate rejection fail; the cap-only algebraic equivalence is qualified by that failed immediate rejection test. The margin guard is not an interval certificate.

Figure 19 uses the lookahead denominator for its energy/progressive/cost ratio panel and all four methods in its additive component panel. Its component bars are means normalized by mean lookahead linear time; they are not median ratios. Failed methods stay visible. The renderer never imports or substitutes formal measurements.

## Untimed floating-point equivalence records

Every complete raw case must contain `lookahead_audits`, ordered by repeat then query, with exactly `3*queries` entries:

```json
{
  "repeat": 0,
  "step": 0,
  "pair_available": true,
  "progressive_anchor_sha256": "<64 lowercase hexadecimal digits>",
  "lookahead_anchor_sha256": "<64 lowercase hexadecimal digits>",
  "anchors_equal": true,
  "solutions_equal": true,
  "rng_states_equal": true,
  "draw_counts_equal": true,
  "factor_counts_equal": true
}
```

These Boolean values illustrate the schema, not observed outcomes. Each audit occurs after all four methods' timers at that query. Anchor hashes use sorted cache keys and every current `factor.anchor` dtype, shape and bytes. Solutions are compared by array equality; RNG states and cumulative draw counts are compared directly; factor-count equality compares `new`, `refreshed`, `reused_energy`, `reused_exact`, `reused_unchanged`, and `retired`. If either compared method lacks a successful query result, `pair_available` is false and all seven hash/diagnostic values are null.

The analyzer supplies the following at both `cases[case].lookahead_equivalence` and top-level `lookahead_equivalence` (the latter sums the four families):

```json
{
  "checks": 0,
  "available": 0,
  "anchor_mismatches": 0,
  "solution_mismatches": 0,
  "rng_mismatches": 0,
  "draw_count_mismatches": 0,
  "factor_count_mismatches": 0
}
```

Zeros here are schema examples. The formatter independently recomputes these counts from raw audits, includes the raw field paths and input hashes in its ledger, and reports all mismatch/unavailable counts. A mismatch is a result, not malformed coverage or an added solve failure; it does not suppress an otherwise successful timing comparison. Query-end equality describes current recorded states and does not establish that all within-query intermediate decisions were identical. The exact-arithmetic theorem and this floating-point audit are kept distinct. `docs/lookahead_main.tex` and `docs/lookahead_theory.tex` join the theorem-support files hashed by the formatter.
