# Final static prose and claim audit

16 October 2026. Read-only inspection of the introduction, model/algorithm, experiment protocol, measured-cost note and manuscript builder while timings continued. No numerical results, plots, builds or parent-owned files were changed. Locations refer to the inspected source snapshot; the builder is still being integrated.

The article framing is substantially improved. The mechanics motivation, temporal anchor, common Gaussian event and changing-ID contribution now form a continuous argument. No unsupported first-in-field claim was found. Most remaining changes concern precise scope, a few result-dependent sentences and repeated exposition rather than wholesale rewriting.

## Correct before final generation

| Location | Finding | Concise edit |
|---|---|---|
| `docs/introduction.tex:45–46` | “its cost must be lower than the factorization it replaces” reads as an unconditional property that the algorithm does not guarantee. | “…and its testing cost must be assessed against the factorization work avoided.” |
| `docs/model_algorithm.tex:115–133` | Acceptance is described before lower-bound evaluation, followed by a claim that rejection has precedence. This is inconsistent as an executable description even though the intended implementation order is clear. | “At each power compute both diagnostics. Rebuild if the lower bound exceeds the tolerance; otherwise accept if the upper estimate meets it. Continue only if both tests are inconclusive.” |
| `docs/experiment_protocol.tex:15–19` | The first four policies share blocks, but stale reuse is also a Schwarz policy on the same current blocks. “All methods rebuild changed memberships” also includes Jacobi, which has no block cache. | “The five Schwarz policies use identical current blocks and rebuild changed memberships. Jacobi acts on the same current system.” Keep the common current coarse statement for all iterative policies. |
| `docs/experiment_protocol.tex:31–33` | “Subsequent queries restart that method from zero” can imply that warm starting is permanently disabled after one failure. | “The query following a failed solve starts from zero; warm starting resumes after a successful solve.” |
| `docs/model_algorithm.tex:169–170` | `O(ms)` temporary storage is accurate for the power recurrence, but the text also supplies an explicit dense discrepancy and stores dense anchors. | “The power recurrence uses `O(ms)` workspace beyond the `O(m²)` dense block and anchor storage.” |
| `docs/experiment_protocol.tex:45–53` versus `docs/cost_experiment_protocol.tex:51–55` | The main protocol defines `T_A = T_assembly + T_L`; the cost protocol calls the assembly-inclusive quantity `T_A + T_L`, charging linear time twice in the notation. | Keep the main definition throughout: the cost protocol should report `T_A = T_assembly + T_L`. |
| `build_revision.py:90–94` | “The largest edit includes the cost of a rejected test” assumes a measured rejection without inspecting its decision records. | “For each rejected candidate, the reported maintenance cost includes both screening and the subsequent factorization.” If the completed data support a more specific statement, generate it from the decisions. |
| `build_revision.py:117–126` | “seven-family scalar and planar comparison” omits the earlier extruded three-dimensional family. “not timings copied from those publications” is a defensive aside. | Use subsection “Additional scalar and elastic benchmarks”; describe the comparator implementations directly and cite their sources. Keep their actual Jacobi outcome. |
| `build_revision.py:185–191` and abstract at `:197` | “these savings” and “for which screening recovers its overhead” presume favorable outcomes; the generated ratios can instead be below one. | Use neutral cost language until results are read: “The paired totals and local measurements identify the measured cost regime.” Then state favorable and unfavorable families explicitly from the final records. |
| `build_revision.py:198–200,227–229` | “ratio relative to” and “ratios over” leave the numerator unclear. | Write `T_fresh/T_progressive` and `T_exact/T_progressive`, or “fresh-to-progressive time ratio.” Do not describe a sub-unit ratio as a gain. |

The measured-cost policy is introduced in the introduction, method and separate protocol. Its final results need their own named baseline/cost comparison in the generated article; do not silently relabel a progressive result as a measured-cost result. The separate follow-up must retain its own measurements and development disclosure.

## Tighten the remaining report-like phrasing

| Location | Suggested replacement or trim |
|---|---|
| `docs/introduction.tex:69–71` | Replace “remains a matched comparator” with “We compare this policy with a two-power test using twelve probes.” This removes implied revision history. |
| `docs/introduction.tex:114,121–124` | Replace “measures the costs of this distinction” by “compares cumulative maintenance costs.” Prefer “measure factor-size and edit-size dependence” to “resolve the crossover” until the completed data establish a favorable range. |
| `docs/model_algorithm.tex:135–136` | Replace “the new three-dimensional campaign” with “the three-dimensional experiments.” New cache entries, new memberships and newly drawn probes elsewhere are mathematical state descriptions and should remain. |
| `docs/model_algorithm.tex:188–191` | Replace “The asymptotic benefit therefore concerns sufficiently large local factors” by “The operation-count comparison favors sufficiently large local factors; elapsed costs also depend on rejection frequency.” The current sentence sounds like a runtime theorem. |
| `docs/experiment_protocol.tex:4–9,11` | Compress the question list to “We assess local energy accuracy, screen-versus-factor cost and cumulative analysis cost using independent spectral checks, local timings and repeated full-order solves.” Remove the duplicated “three-dimensional” in line 11. |
| `docs/experiment_protocol.tex:113–119` | Give the spline result positively: “The quadratic counterexample identifies changing normalized near dependence; the finite-matrix energy criterion applies independently of its leading-Gram limit.” Keep the separate timing scope for the active audit. |
| `docs/cost_experiment_protocol.tex:1–13` | Neutral heading: “Matched comparison of measured-cost stopping.” Retain one clear sentence that this follow-up was designed after the first cubic repetition and was not part of the earlier freeze. The word “disclosed” and a second original-versus-follow-up contrast need not recur. |
| `build_revision.py:135–147,186–191` | The discussion and conclusion repeat “contract,” “connect a decision,” and “workflow” without adding a finding. Keep the concrete local-to-global comparison, then discuss the actual screening/CG/factorization balance. End with the measured operating regime and its physical scope rather than “cost exposed to the workflow.” |

No user-facing “preserved” or “original method” framing remains in the inspected introduction. Internal Python names such as `OLD` and `legacy` are not article prose and need no cosmetic renaming.

## Qualifications to retain

- Exact arithmetic and conditionally fresh Gaussian draws, one sequence budget, and fixed candidate/probes within a check are necessary assumptions. State them where the theorem is introduced; do not replace them with unqualified “certified” floating-point language.
- The fresh method's cut/mesh/degree dependence and the requirement for the same current coarse correction are mathematical scope, not disclaimers. They can be stated once near the result and recalled briefly when interpreting costs.
- The measured-cost note is already compact and precise. Keep the minimum-power floor, action-boundary overshoot, historical-versus-current factor cost and inclusive timer scope. “A time-triggered rebuild is exact” can read “sets the local anchor to the current matrix” to preserve the distinction between an exact-arithmetic identity and numerical factorization.
- Keep analytic-extrusion scope, matched own warm starts, all failures, assembly attribution and observed-range interpretation. Consolidate repetitions, but do not erase unfavorable comparisons or development provenance to make the prose sound more confident.

## Supplement author information

The revised builder extracts `authorblock` from the main header starting at `\author{` and ending before `\begin{abstract}`, and inserts that block after the supplementary title. A pure string-extraction check confirms exactly one author, **Kewang Chen**, with the full College of Mathematics and Statistics / Nanjing University of Information Science and Technology affiliation, **Nanjing, 210044, China**, `kwchen@nuist.edu.cn`, and the matching corresponding-author note. The revised construction therefore retains the metadata that was previously at risk of being omitted.

`revision_v2/paper/supplement.tex` was not present at inspection. This verifies the source construction, not a generated supplement or rendered front page. After generation, check that its title is the supplementary title and that the author/address/email appear once. No build or rendering was performed during this audit.

At the inspected intermediate builder snapshot, `audit_sections()` and `audit_facts()` were called but not yet defined, and several optional audit claims were gated only by file existence. These may be in-progress integrations. Before final generation, require completed audit records and define the helpers; the presence of an unfinished JSON file is not evidence for a completed check. This is a build-state observation, not a prose change request.
