# Read-only formal campaign review

Reviewed the frozen `campaign.py`, `kernel_study.py`, their numerical dependencies,
and `results/formal_manifest.json` while the campaign ran. No numerical jobs,
timing experiments, source changes, or data changes were performed. SHA-256
verification found **all 11 live source files and all 11 archived source copies
identical to the manifest**. No concrete numerical or comparison defect was
found that requires invalidating the running declared campaign.

## Comparison and sequence state

Each repetition creates a new assembler, one independent cache dictionary entry
per retention policy, and one previous solution per method. The fresh method
always receives no retained cache, but receives its own prior successful
solution as a warm start, just like the other methods. Thus "cold solve included"
means the first query has no factor or solution history; it does not mean CPU
caches were flushed. Stable-ID intersection correctly transfers each method's
own solution and sets newly active IDs to zero. Failed solves do not supply a
warm start to the next query. A caught exception additionally clears that
method's anchor cache. A numerical nonconvergence may leave a valid factor
cache, but its failed solution is not recycled.

All methods see the identical current assembled system. A current-matrix LU
reference is computed independently of CG and retained factors before the
policy loop. Every iterative policy uses the same current coarse correction
when that case enables a coarse space. The coarse solve is rebuilt and charged
to each policy. The policy order rotates deterministically by query and
repetition; this counters order effects but is not randomized experimental
assignment or a guarantee of perfect balance.

Each energy/progressive method keeps one probability budget for the whole
sequence and spends it on rejected screens too. The fixed policy uses 12
probes and two powers; progressive uses the same probe count, maximum power 6,
the dimension cost cap, and the same dimension guard 288. The progressive
state records actual action counts, effective caps, stopping powers, and
separate cap/early-stop savings. A partial output schema check confirmed that
these fields are preserved in the saved policy rows. Initial anchors and
unchanged/exact matches do not spend screen budgets.

The bound `delta_total=1e-8` is per method/sequence. Across four cases, three
repetitions and two probabilistic methods, a simple simultaneous union bound
is `24e-8 = 2.4e-7`, if such a whole-campaign probability statement is desired.
Identical seeds are reused across methods and cases; their outcomes must not
be described as independent. This does not invalidate the separate conditional
sequence theorem. Repetition variation combines wall-time noise and any
changes in randomized anchor decisions.

## Timing and failures

Reported `linear` time includes equilibration, block generation, local
extraction, screens (including failed screens), refactorization, current coarse
setup when enabled, and the CG solve. Reported `total` adds the common current
assembly time to each policy equally. These are meaningful and matched cost
scopes, but they exclude stable-ID warm-start transfer, result copying, residual
and energy-error diagnostics, independent references, assembly audits, JSON
serialization, and driver orchestration. Figures should say "assembly + linear
solve time" or "linear setup + CG time", not imply complete application wall
time. A shared assembly cost is charged equally for comparison and should not
be summed over policies as actual process work.

Successful and unsuccessful numerical returns are appended. Caught exceptions
produce `success=False`, an error string and `attempt_seconds`, with missing
`linear`/`total` fields. Summaries must never drop these rows or replace their
missing costs by zero. A sequence containing failure is an unsuccessful
sequence with its attempted work retained; it cannot supply a successful speedup
point. The campaign does not catch assembly/reference failures or every
possible software exception, so interruption may leave `complete=False` without
a final policy failure row. Completion/schema checks must therefore precede
aggregation. A reference/assembly interruption is a failed/incomplete campaign
attempt, not evidence of a policy success.

Atomic per-policy checkpoints and refusal to overwrite formal sequence files
protect completed rows. The source snapshot, cases, query count and method
list are declared before formal measurements, with pilot files kept separate.
Host/library versions are recorded. The one-thread execution declaration is
not enforced by these modules themselves: retain the actual launch command or
thread-environment record with the results. BLAS vendor/backend details and
hardware model would improve reproducibility beyond package version and OS.

## Kernel study and presentation limits

The kernel study samples principal submatrices of actual equilibrated 3D
systems, using evenly spaced rows of one large physical block for smaller
sizes. These are actual matrix principal blocks, not necessarily the exact
geometric Schwarz blocks used by a campaign policy. Each trial compares
maintenance of one fixed anchor to a fresh current factorization; it is not a
sequence of retained anchors or a complete solve benchmark. The anchor setup
and independent dense eigenvalue oracle are outside the timed region. Failed
screens include their subsequent factorization in `seconds`. Screen timing
also includes probe-budget construction and drift scaling. `screen_seconds`
and total maintenance `seconds` must be distinguished in crossover claims.

The prescribed check index 1000 deliberately uses a later, smaller probability
allocation. It is not the actual number of prior checks performed in each
kernel trial. The saved full source identifies method probe/power/cap settings;
the result's short config does not repeat every method tuple. `powers` and
`column_actions` are actual observed work. Five repetitions rotate six methods,
so the kernel order is partially counterbalanced, not perfectly balanced.
The kernel output lacks a completion flag and writes once per size/increment
group. Verify every expected group, repetition and method before treating it
as complete; an interrupted group must not become a truncated favorable sample.

Prospective figures should retain these distinctions:

- Pair complete repetitions within each case; show the observed variation for
  only three sequence repetitions, without overstating inferential precision.
- Distinguish medians of paired ratios, ratios of total sequence times, and
  averages over queries. Label the chosen denominator explicitly.
- Report cold first queries and all 50 queries for the long cases; the quintic
  and refined cases contain 12 queries, not 50.
- Keep unsuccessful methods visible, including stale-policy failures. A cheap
  invalid solve is not an efficiency result.
- If a geometric mean is used, restrict it to the four predeclared formal
  families, give the exact comparator/weighting, and report every family's
  result. A later active-ID mechanism audit is separate evidence.
- Plot actual block dimension and observed drift, not requested subsample size
  or geometry increment as if either were the spectral change. Confirm that
  subsampling did not collapse two requested sizes to the same actual size.
- Use the independent kernel spectrum to flag any accepted screen above tau;
  do not treat the probabilistic bound as an exact eigenvalue observation.
- Separate upper bound conservatism from deterministic rejection and separate
  cost-cap truncation from early-stopping savings.
- Charge coarse construction equally and present its cost separately, since it
  changes solver quality but is not a local-factor maintenance innovation.

The partial result observed during this review was still `complete=False`;
this report makes no final performance or completion claim.
