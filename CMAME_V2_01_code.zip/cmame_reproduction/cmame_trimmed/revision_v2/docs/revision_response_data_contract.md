# Data-dependent revision-response slots

The Chinese response now has seven paired `FACT_SLOT` / `END_FACT_SLOT` HTML markers. Their visible text remains pending until the corresponding records are complete. The static explanation of the method stays separate from result insertion. This document specifies replacement logic; no data-dependent prose has been generated and no measurement has been invented.

## Inputs and validation before replacement

1. The formal summary and all four `sequence_*` source records must agree with the frozen formal manifest and their declared method/query/repetition coverage. Check completion before calculating any aggregate. The expected method count comes from the manifest; it is not inferred from successful rows.
2. The separate cost summary must have `complete=true` and `coverage.validated=true`. It must cover exactly `cubic_long`, `quartic_long`, `quintic`, and `refined_cubic`, each with three repetitions of `energy`, `progressive`, and `cost`. Preserve failed rows and missing exception components. Never combine these rerun timings with the original campaign to create a favorable baseline.
3. The active audit and mechanism/quadrature audits must report completion. Their failures and diagnostic types must remain visible. A Rayleigh lower witness cannot replace a missing full spectrum or an upper norm bound.
4. Kernel records require the complete expected dimension × increment × method × repetition grid, even where there is no explicit completion flag. No crossover statement may use only the groups written before an interruption.
5. Build, page-inspection and archive-extraction checks need their own dated records. The existence of a PDF or archive is not evidence that those checks passed.

## Slot mapping

| Stable slot | Input fields and replacement content | Scope check |
|---|---|---|
| `formal_performance` | Formal `cases[name].ratios[baseline][linear|total].ratio_of_medians`, `.paired`, `.minimum`, `.maximum`, and corresponding method success/failure fields. Give all four families and explicit baseline/progressive direction. | Use ratios of median complete sequence totals; the three paired ratios/ranges are separate summaries. If either policy failed, replace speedup by a failure statement and attempted work. |
| `cost_followup` | Cost `cases[name].ratios[energy|progressive][linear|total]`, method repetition `screen_time`, `factorization_time`, `coarse_setup`, `other_setup`, `solve`, timing-stop counters, power histograms and failures. | Denominator is `cost`. State this is a separately frozen follow-up. `screen_time` is inclusive randomized setup time; callback elapsed time and historical anchor times are not extra additive components. |
| `formal_coverage` | Per-case declared configuration and actual row coverage; method `nmin`, `nmax`, `largest_block`; per-repetition step indices and completion. | The two long cases have 50 queries; the quintic and refined cases have 12. Do not describe every family as a 50-query sequence or imply 200-query evidence. |
| `cost_decomposition` | Formal method repetition setup, factorization, randomized screening, coarse setup, solve and iterations; source-record assembly. Complete kernel rows and independent oracle drifts/decisions. | Add cost components within a repetition before reporting means/totals. Include all unsuccessful-screen refactorizations. Distinguish pure screen time from maintenance including a required factorization. Report actual sampled principal-block dimensions. |
| `active_state` | Active `geometry_audits` additions/deletions and steps, progressive row `stat_new`, `stat_refreshed`, `stat_retired`, `stat_reused_energy`, and `local_audits.audit_kind`. | Initial space creation is not a subsequent active-space change. Separate full generalized spectra from lower diagnostics. Treat this audit as separate mechanism evidence, not another formal timing family. |
| `external_coarse` | Formal Jacobi/stale method success/failures and available ratios, `coarse_dofs`, repetition `coarse_setup`, `setup`, and `linear`. | Every configured policy pays for the same current coarse correction. Its cost remains part of setup; no stale-coarse maintenance claim follows. |
| `final_delivery` | Verified test logs, source-hash comparison, complete-record audit, build diagnostics, page-review record, and extraction/rebuild manifest for each delivered archive. | Name what actually passed. Missing or failed checks stay explicit; do not copy the old package's completion statement. |

## Deterministic formatting and failure handling

For a ratio `r`, write `T_baseline/T_policy = r`; values greater than one favor the denominator policy. Retain at least three decimal places for modest gains, and give the observed three-pair range without labelling it a confidence interval. Time units are seconds. Report the median of complete sequence totals, never an average of per-query speedups. For stacked cost descriptions, use component means so their sum equals the mean total.

The eventual formatter should read the template, validate each marker occurs exactly once as a matched pair, and replace only the text between matching markers. Write a separate completed response first and retain a fact ledger with source paths, SHA-256 values, JSON field paths, ratio direction, rounding and validation outcomes. Refuse final-delivery status if any visible `[待填` marker or an unavailable required input remains. A failed policy is a valid reported outcome, not a reason to suppress the family; an incomplete experiment remains incomplete.

No automatic rule should turn every ratio above one into a universal benefit claim or remove an unfavorable comparison. Cross-family geometric means require all declared families, a stated weighting and successful paired methods. The measured-cost follow-up and original campaign keep separate aggregates and separate probability budgets. Author facts and final human approval are not inferred from numerical summaries.
