# Current static audit: measured-cost experiment and kernel study

Reviewed the current `cost_screening.py`, `cost_ablation.py`, `cost_analyze.py`
and frozen `kernel_study.py` by reading source only. No imports, compilation,
tests, analysis, numerical jobs or timing runs were executed. No frozen source
or result was changed. No blocking correctness defect was found for the
specified runs; execution tests remain pending.

## Cost rule and records

`TimedLocalFactor.factor` delegates the matrix operations to the original
superclass classmethod. Its additional historical creation time is preserved
by `dataclasses.replace`, including exact-anchor metadata resets. The cost
wrapper creates only timed factors and rejects caches from another factor
class. Directly batch-created scalar anchors have zero individual allowance;
the stated dimension guard skips them in the experiment.

An inconclusive screen retains the minimum of two and its effective dimension
cap. Acceptance or deterministic rejection can stop earlier. Timing is checked
only after a completed action, below the final configured cap, after neither
mathematical decision has fired. A timing stop therefore returns a bound above
tau and requests a new factor; it cannot manufacture acceptance. All powers use
the same fixed matrix, initial Gaussian block and single candidate allocation.
The historical anchor time belongs to the previous history; observed elapsed
time can select a stopping power under the existing common-event proof.

The historical time is not a prediction of a new factor's cost. The mandatory
floor can already exceed the threshold, and a later action can cross it before
its time is known. The code and current protocol correctly state a soft work
rule, not a hard cost guarantee or a guaranteed acceleration.

The explicit isolated solver namespace routes only the `cost` policy to the
new builder; its saved method identity is renamed to `cost`. The three policies
own separate caches, probability generators and previous solutions. Their
successful setup/CG scopes match. The current driver also places ID transfer
before the exception-attempt timer, correcting the earlier mismatch. Factor
instrumentation remains charged inside setup. Current coarse setup is shared
as a construction and charged to each policy.

The aggregator counts every scheduled method/query identity and validates
three repetitions of all four families. Exceptions remain failed rows with
attempt work; unavailable components and counters become unavailable, not zero.
Partial observed counts are labeled as observed. Any failed method comparison
is suppressed rather than restricted to successful repetitions. A missing or
incomplete case prevents summary output. Current/archived core and added source
hashes, embedded manifests, execution metadata, probability spending, action
histograms, dimension-cap savings and time-stop savings are checked before a
complete summary is written. Historical anchor times and nested callback times
are kept out of additive costs. Block-anchor creation counts are correctly
distinguished from literal Cholesky calls.

The follow-up manifest records its first execution environment. If separate
case invocations are used, run all of them in that same recorded environment:
manifest reuse checks source hashes but does not recompare runtime metadata on
every invocation. A single `cost_ablation all` process satisfies this condition.
Source hashes and seeds specify the implementation, not deterministic replay of
wall-time-dependent decisions on another machine.

## Kernel correctness and interpretation

The independent dense operator is constructed as `L^-1 delta L^-T` with the
correct transpose order. Its eigenvalues are computed outside all timed
sections, using the same anchor scaling as the screen. Every rejected screen
includes a fresh current factor in its total time. Reported column actions
match the number of performed powers; the special check index is correctly
1000. The raw `accepted=False` value for `fresh` means no anchor reuse, not a
failed solve; the existing kernel auditor excludes fresh rows from screen
acceptance diagnostics.

Two scope differences must remain visible in the crossover description:

- Each kernel screen times creation of a new budget/RNG. The sequence drivers
  construct persistent budgets outside per-query solve timers. The primitive
  kernel is therefore more inclusive in this one initialization component,
  especially at small dimensions.
- The direct kernel calls deliberately bypass the sequence dimension guard.
  Sizes 64, 128 and 256 are screened even though the deployed sequence policy
  would rebuild those changed blocks without screening. These samples measure
  the screen primitive; they are not guard-inclusive deployed-policy costs.

These differences do not invalidate the recorded primitive timings, but an
unqualified claim that the curves give the exact application crossover would
be too strong. The five repetitions rotate six methods only partially, and the
prescribed check index is a stress allocation rather than 999 prior executed
checks. Smaller matrices are subsampled principal blocks of a real large block,
not necessarily the geometric Schwarz blocks of the sequence cover.

The kernel driver writes completed size/increment groups, has no explicit
completion flag and does not catch numerical failures. A failure or interruption
must retain its partial output/log and must not be presented as a shorter
successful study. The current `audit_kernel` checks the entire expected
size/increment/repeat/method grid before reporting completion, which addresses
partial-output interpretation. If requested sizes collapse to duplicate actual
sizes, that coverage check rejects the file; the planned large block size should
remain distinct from the seven smaller requested sizes. The frozen source is
unchanged; none of these observations authorizes silently replacing a failed
or unfavorable kernel sample.
