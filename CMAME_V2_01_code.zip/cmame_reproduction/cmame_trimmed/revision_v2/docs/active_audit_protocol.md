# Supplementary active-ID audit protocol

`active_audit.py` is separate from the frozen four-family speed campaign and
must run serially after that campaign finishes. It is mechanism evidence,
excluded from any headline geometric mean or selection of timing families.

The declared grid is `(8,8,4)`, degree 3, elasticity, body load, left-face
boundary, quadrature 12, width 4, and no coarse correction. The trim top is
`(5+eta)/8`, following twelve eta values from `.25` to `-.20` across zero and
then eleven reversed values back to `.25`. This removes and reactivates a
background basis layer. Overlap blocks intersecting the crossing layer change
their ID tuples; other large overlapping blocks retain their IDs while their
local matrices still change. All five methods (fresh, exact-local, fixed
12-by-2, capped progressive 12-by-6, and transported stale reuse) keep their own cache and warm starts.
One repetition is the default; more repetitions are optional and must be
reported as this mechanism audit, not added to the formal family aggregate.

Every current full background matrix, active-ID list, and free RHS is compared
with a nonincremental assembly before policy timings. Every query has an
independent current LU reference. Returned failures and exceptions remain in
rows/ledger; assembly/reference errors abort with `complete=False` and a saved
failure stage. The output distinguishes completed scheduled attempts from
`all_success`. Exact added/deleted IDs, newly appearing/retired/surviving large
block counts/dimensions, screen statistics and cumulative probability budgets are recorded.
The summary explicitly counts probabilistic checks at active-change queries,
so screens on unrelated stable-ID queries cannot substitute for this mechanism.

Accepted local anchors are independently checked with full generalized spectra
only at dimensions at most the requested dense cap (default 400). Above that
cap, the audit records three independent Rayleigh lower witnesses and explicitly
marks the full spectrum as skipped. These lower witnesses cannot establish a
norm upper bound and never affect policy decisions. If there are no accepted
probabilistic blocks within the dense cap, the exact-spectrum count is zero;
no exact large-block spectral-validation claim is then permitted. The current
LU solution, residuals and energy errors remain independent solution checks.

The script verifies frozen core hashes, records its own hash and copies its
source alongside output. It refuses to overwrite either an existing result or
source snapshot. Default output is `results/active_audit.json`. Timing scope is
the same assembly-plus-linear scope as the formal driver; transfers, validation,
references, independent local/assembly audits, and output are excluded.

Do not compile or run during the formal timing process. After it finishes,
static compilation and then a serial mechanism run can be launched from the
repository root:

```sh
.venv/bin/python -m py_compile cmame_trimmed/revision_v2/active_audit.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  .venv/bin/python -u -m cmame_trimmed.revision_v2.active_audit
```

This protocol and driver were prepared without running numerical jobs alongside
the formal campaign. Runtime and successful completion have not yet been
verified by this authoring step.
