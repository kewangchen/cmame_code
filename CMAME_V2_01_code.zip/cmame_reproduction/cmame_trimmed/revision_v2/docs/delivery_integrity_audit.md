# Independent delivery review and corrections

Read-only review on 16 October 2026 identified five concrete gaps in the
new delivery orchestration. No frozen numerical source or timing record
was modified as part of the corrections.

1. The archive check originally compared rebuilt sources only against the
   live submission directory. It now compares with the extracted submission
   as well and compiles all three documents inside that extracted package.
2. Missing reproduced PNGs were omitted and differing hashes were only
   recorded. Expected PNGs now have to exist and match; otherwise verification
   fails explicitly.
3. Compilation lacked identities binding its inputs to its PDFs.
   `verify_compilation.py` now performs a fresh output-directory build,
   records input hashes before the build, checks them after each command,
   and records output PDF hashes. Finalization rechecks those identities
   and requires visual-review identities for the same PDFs.
4. Finalization could reuse an existing directory and overwrite ZIP files.
   It now refuses an existing delivery directory. An unsuccessful earlier
   attempt must be preserved before a new delivery is generated.
5. Unhandled orchestration exceptions could leave a waiting status.
   Future postprocessing and compilation invocations record terminal
   exceptions only in their own PID-identified status. The already-running
   waiting processes loaded the preceding version; their sessions are
   monitored directly rather than attributing the new handlers to them.

These are source-level corrections. Actual execution evidence is provided
by `compilation_evidence.json`, `verification.json` and the final
`archive_verification.json`; this note alone does not establish successful
compilation, rendering or clean archive reproduction.
