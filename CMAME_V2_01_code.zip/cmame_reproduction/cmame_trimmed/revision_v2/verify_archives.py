"""Verify the delivered archives by extracting and rebuilding in a clean tree.

This is a post-timing check. It never reruns the timing campaigns and never
marks visual review complete. The extracted files and all command logs remain
available for inspection after a failure.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
DEST = WORK/'delivery/CMAME_Trimmed_Reuse_V2_2026_10_16'


def now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    pipeline = json.loads((ROOT/'results/serial_pipeline.json').read_text())
    post = json.loads((ROOT/'results/postprocess_status.json').read_text())
    if not pipeline.get('complete') or not post.get('complete'):
        raise RuntimeError('All timing, audit and postprocessing jobs must finish first')
    if any(job.get('returncode') != 0 for job in pipeline['jobs']+post['jobs']):
        raise RuntimeError('An earlier pipeline command was unsuccessful')
    extraction = WORK/'delivery/.CMAME_V2_reproduction_check'
    if extraction.exists():
        raise FileExistsError('Preserve the earlier extracted check: '+str(extraction))
    report_path = DEST/'audit/archive_verification.json'
    if report_path.exists():
        raise FileExistsError('Preserve the earlier archive verification')
    extraction.mkdir(parents=True)
    logs = extraction/'logs';logs.mkdir()
    report = dict(complete=False, started_utc=now(), extraction=str(extraction),
                  checks=dict(extracted=False, tests=False, figure_reproduction=False,
                              manuscript_rebuild=False, submission_compilation=False), archives=[], commands=[], results={})

    def save():
        report_path.parent.mkdir(exist_ok=True, parents=True)
        temporary = report_path.with_suffix('.tmp')
        temporary.write_text(json.dumps(report, indent=2)+'\n')
        temporary.replace(report_path)

    save()
    manifest = json.loads((DEST/'archives.json').read_text())
    try:
        for item in manifest:
            archive = DEST/item['file']
            if archive.stat().st_size != item['bytes'] or sha(archive) != item['sha256']:
                raise ValueError('Archive identity differs: '+item['file'])
            with zipfile.ZipFile(archive) as package:
                if package.testzip() is not None:
                    raise ValueError('ZIP integrity check failed: '+item['file'])
                for member in package.namelist():
                    member_path = Path(member)
                    if member_path.is_absolute() or '..' in member_path.parts:
                        raise ValueError('Unsafe archive member: '+member)
                # Code and records are complementary under one common root.
                target = extraction/'submission' if item['file'].endswith('submission.zip') else extraction
                package.extractall(target)
            report['archives'].append(dict(item))
        report['checks']['extracted'] = True;save()
        expected_submission={str(p.relative_to(DEST/'01_submission')):sha(p)
            for p in (DEST/'01_submission').rglob('*') if p.is_file()}
        packaged_submission={str(p.relative_to(extraction/'submission')):sha(p)
            for p in (extraction/'submission').rglob('*') if p.is_file()}
        report['results']['packaged_submission_sha256']=packaged_submission
        report['results']['packaged_submission_matches_delivery']=(
            expected_submission==packaged_submission)
        if not expected_submission or expected_submission!=packaged_submission:
            raise ValueError('Extracted submission inventory or bytes differ from the delivery')
        save()
        reproduction = extraction/'cmame_reproduction'
        env = dict(os.environ)
        for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
            env[name] = '1'
        env['MPLCONFIGDIR'] = '/private/tmp/cmame_mpl_cache'
        env['XDG_CACHE_HOME'] = '/private/tmp/cmame_cache'
        env['PATH'] = '/Library/TeX/texbin:'+env.get('PATH','')
        jobs = [('tests', ['-m','pytest','cmame_trimmed/tests','cmame_trimmed/revision_v2/tests','-q'])]
        for name, module, args in [
            ('analysis','cmame_trimmed.revision_v2.analyze',[]),
            ('cost_analysis','cmame_trimmed.revision_v2.cost_analyze',[]),
            ('original_figures','cmame_trimmed.figures',[]),
            ('revision_figures','cmame_trimmed.revision_v2.figures',[]),
            ('cost_figures','cmame_trimmed.revision_v2.cost_figures',['--timings-finished']),
            ('audit_figures','cmame_trimmed.revision_v2.audit_figures',['--timings-finished']),
            ('saved_fields','cmame_trimmed.revision_v2.elastic_fields',['--from-records']),
            ('manuscript','cmame_trimmed.revision_v2.build_revision',[]),
        ]:
            jobs.append((name, ['-m',module]+args))
        for name, args in jobs:
            record = dict(name=name, command=[sys.executable]+args, cwd=str(reproduction),
                          started_utc=now(), log=str(logs/(name+'.log')))
            report['commands'].append(record);save()
            print(now(), 'START', name, flush=True)
            with Path(record['log']).open('w') as output:
                result = subprocess.run(record['command'], cwd=reproduction, env=env,
                                        stdout=output, stderr=subprocess.STDOUT)
            record.update(returncode=result.returncode, finished_utc=now());save()
            print(now(), 'END', name, result.returncode, flush=True)
            if result.returncode:
                raise RuntimeError('Extracted reproduction failed: '+name)
            if name == 'tests':report['checks']['tests'] = True
            if name == 'saved_fields':report['checks']['figure_reproduction'] = True
            save()
        rebuilt = reproduction/'cmame_trimmed/revision_v2/paper'
        documents = ('manuscript.tex','supplement.tex','cover_letter.tex','references.bib','highlights.txt')
        submission = extraction/'submission'
        same = {name: sha(rebuilt/name)==sha(submission/name)==sha(DEST/'01_submission'/name)
                for name in documents}
        report['results']['rebuilt_source_sha256_agreement'] = same
        if not all(same.values()):
            raise ValueError('Rebuilt submission source differs from the delivered source')
        report['checks']['manuscript_rebuild'] = True
        figures = {}
        for original in (ROOT/'figures').glob('*.png'):
            generated = reproduction/'cmame_trimmed/revision_v2/figures'/original.name
            figures[original.name] = generated.is_file() and sha(original)==sha(generated)
        report['results']['figure_png_sha256_agreement'] = figures
        if not figures or not all(figures.values()):
            report['checks']['figure_reproduction'] = False
            raise ValueError('Missing or different reproduced figure PNGs')
        # Compile the files actually extracted from submission.zip, including
        # their packaged figures and bibliography, in that extracted directory.
        bundled = Path('/Users/kewang/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
        compiler = Path('/Users/kewang/.codex/plugins/cache/openai-bundled/latex/0.2.8/scripts/compile_latex.py')
        for name in ('manuscript','supplement','cover_letter'):
            record = dict(name='compile_extracted_'+name,
                command=[str(bundled),str(compiler),str(submission/(name+'.tex')),
                         '--compiler','texlive','--json'], cwd=str(submission),
                started_utc=now(), log=str(logs/('compile_extracted_'+name+'.log')))
            report['commands'].append(record);save()
            with Path(record['log']).open('w') as output:
                result = subprocess.run(record['command'],cwd=submission,env=env,
                    stdout=output,stderr=subprocess.STDOUT)
            record.update(returncode=result.returncode,finished_utc=now());save()
            if result.returncode:
                raise RuntimeError('Extracted submission compilation failed: '+name)
        report['checks']['submission_compilation'] = True
        report.update(complete=True, verified_utc=now());save()
    except Exception as exc:
        report.update(error=repr(exc), finished_utc=now());save()
        raise
    print(json.dumps(report['checks'], indent=2))


if __name__ == '__main__':
    run()
