"""Build supplementary audit tables from recorded JSON, using stdlib only.

No audit is executed and no file is written by this module. Existing partial or
failed records are rendered explicitly. Missing audit files are errors, so a
manuscript cannot acquire invented or silently omitted audit outcomes.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
AUDIT_NAMES = ('mechanism', 'quadrature', 'active')
METHOD_NAMES = {'fresh': 'Fresh', 'exact_local': 'Exact local refresh',
                'energy': 'Fixed Gaussian', 'progressive': 'Progressive Gaussian',
                'cost': 'Measured-cost Gaussian', 'stale': 'Stale reuse'}


def _reject_constant(value):
    raise ValueError('Nonfinite JSON numeric constant: '+value)


def _load(results_dir):
    directory = ROOT/'results' if results_dir is None else Path(results_dir)
    documents, hashes = {}, {}
    for name in AUDIT_NAMES:
        path = directory/(name+'_audit.json')
        payload = path.read_bytes()  # Missing files must stop manuscript assembly.
        data = json.loads(payload, parse_constant=_reject_constant)
        if not isinstance(data, dict):
            raise ValueError('Audit must be a JSON object: '+str(path))
        for key in ('rows','leading_sets','geometry_audits','local_audits','failures'):
            if key in data and (not isinstance(data[key], list)
                                or not all(isinstance(r,dict) for r in data[key])):
                raise ValueError('Invalid record list '+key+' in '+str(path))
        documents[name] = data
        hashes[path.name] = hashlib.sha256(payload).hexdigest()
    return documents, hashes


def _number(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _maximum(rows, key):
    values = [_number(r.get(key)) for r in rows]
    return max((x for x in values if x is not None), default=None)


def _range(rows, key):
    values = [_number(r.get(key)) for r in rows]
    values = [x for x in values if x is not None]
    return [min(values), max(values)] if values else None


def _sum(rows, key):
    return sum(int(r.get(key,0)) for r in rows if _number(r.get(key)) is not None)


def _failed_checks(data):
    return [k for k,v in data.get('checks',{}).items() if k!='all_passed' and v is False]


def _status(data, active=False):
    completion = 'complete' if data.get('complete') is True else 'incomplete'
    outcome = data.get('all_success') if active else data.get('checks',{}).get('all_passed')
    if outcome is True:
        result = 'reported checks passed'
    elif outcome is False:
        result = 'reported checks failed'
    else:
        result = 'check outcome not recorded'
    return completion+'; '+result


def _mechanism_facts(data):
    rows = data.get('rows',[])
    families = {}
    for name in ('positive','counterexample'):
        selected = [r for r in rows if r.get('family')==name]
        ordered = sorted((r for r in selected if _number(r.get('epsilon')) is not None),
                         key=lambda r: float(r['epsilon']))
        smallest = ordered[0] if ordered else None
        keys = ('epsilon','normalized_condition','anchor_relative_drift',
                'epsilon_squared_condition','coupling_drift_from_limit',
                'small_cut_upper_bound')
        families[name] = {'record_count':len(selected),
            'smallest_scale': ({k:_number(smallest.get(k)) for k in keys} if smallest else None)}
    positive = [r for r in rows if r.get('family')=='positive']
    negative = [r for r in rows if r.get('family')=='counterexample']
    return {'complete':data.get('complete') is True,
            'status':data.get('status'),
            'reported_all_checks_passed':data.get('checks',{}).get('all_passed'),
            'failed_checks':_failed_checks(data), 'error':data.get('error'),
            'decimal_precision':data.get('decimal_precision'),
            'anchor_epsilon':_number(data.get('anchor_epsilon')),
            'tau':_number(data.get('tau')),
            'positive_constants':{k:_number(data.get('positive_constants',{}).get(k))
                for k in ('b','kappa0','sufficient_epsilon_max')},
            'leading_set_degrees':[r.get('degree') for r in data.get('leading_sets',[])],
            'leading_set_checks':[{'degree':r.get('degree'),
                'leading_gram_spd':r.get('leading_gram_spd'),
                'leading_principal_minors':r.get('leading_principal_minors',[])}
                for r in data.get('leading_sets',[])],
            'positive_sufficient_region_records':sum(r.get('within_sufficient_pair_region') is True for r in positive),
            'counterexample_theorem_mislabelled_records':sum(r.get('small_cut_theorem_applicable') is True for r in negative),
            'families':families}


def _quadrature_facts(data):
    rows = data.get('rows',[])
    orders = data.get('config',{}).get('comparison_orders',[])
    recorded = [r.get('order') for r in rows]
    metrics = ('matrix_relative_frobenius','rhs_relative_l2',
               'solution_relative_reference_energy','current_residual_relative_l2',
               'current_scaled_residual_relative_l2')
    return {'complete':data.get('complete') is True, 'status':data.get('status'),
            'reported_all_checks_passed':data.get('checks',{}).get('all_passed'),
            'failed_checks':_failed_checks(data), 'error':data.get('error'),
            'config':data.get('config',{}), 'thresholds':data.get('thresholds',{}),
            'reference_order':data.get('reference',{}).get('order',data.get('config',{}).get('reference_order')),
            'reference_dofs':data.get('reference',{}).get('dofs'),
            'reference_residual':_number(data.get('reference',{}).get('current_residual_relative_l2')),
            'reference_scaled_residual':_number(data.get('reference',{}).get('current_scaled_residual_relative_l2')),
            'recorded_orders':recorded, 'missing_orders':[q for q in orders if q not in recorded],
            'failed_orders':[r.get('order') for r in rows if r.get('passed') is False],
            'rows':[{'order':r.get('order'),'passed':r.get('passed'),'error':r.get('error'),
                     **{k:_number(r.get(k)) for k in metrics}} for r in rows]}


def _active_facts(data):
    rows, geometry, local = (data.get(k,[]) for k in ('rows','geometry_audits','local_audits'))
    methods = list(data.get('methods',[]))
    for row in rows:
        if row.get('method') not in methods:
            methods.append(row.get('method'))
    repetitions = _number(data.get('repeats'))
    queries = _number(data.get('config',{}).get('queries'))
    planned_per_policy = int(repetitions*queries) if repetitions is not None and queries is not None else None
    policy = {}
    for method in methods:
        selected = [r for r in rows if r.get('method')==method]
        changing = [r for r in selected if r.get('active_ids_changed') is True]
        budgets = {}
        for r in selected:
            if isinstance(r.get('probability_budget'),dict):
                budgets[str(r.get('repeat'))] = r['probability_budget']
        policy[method] = {
            'attempted_rows':len(selected), 'planned_rows':planned_per_policy,
            'missing_rows':max(0,planned_per_policy-len(selected)) if planned_per_policy is not None else None,
            'successful_rows':sum(r.get('success') is True for r in selected),
            'failed_rows':sum(r.get('success') is False for r in selected),
            'unknown_outcome_rows':sum(r.get('success') not in (True,False) for r in selected),
            'completed_setup_randomized_checks':_sum(selected,'stat_randomized_checks'),
            'active_change_randomized_checks':_sum(changing,'stat_randomized_checks'),
            'active_change_attempts':len(changing),
            'maximum_residual':_maximum(selected,'residual'),
            'maximum_scaled_residual':_maximum(selected,'scaled_residual'),
            'maximum_energy_error':_maximum(selected,'energy_error'),
            'rows_with_residual':sum(_number(r.get('scaled_residual')) is not None for r in selected),
            'rows_with_energy_error':sum(_number(r.get('energy_error')) is not None for r in selected),
            'new_large_block_events_after_initial':_sum([r for r in selected if r.get('step',0)>0],'new_large_blocks'),
            'retired_large_block_events_after_initial':_sum([r for r in selected if r.get('step',0)>0],'retired_large_blocks'),
            'last_recorded_budget_by_repeat':budgets}
    dense = [r for r in local if r.get('audit_kind')=='full_generalized_spectrum']
    witnesses = [r for r in local if r.get('audit_kind')=='three_rayleigh_lower_witnesses']
    groups = []
    for method,kind in sorted({(str(r.get('method')),str(r.get('audit_kind'))) for r in local}):
        selected = [r for r in local if str(r.get('method'))==method and str(r.get('audit_kind'))==kind]
        key = 'exact_drift' if kind=='full_generalized_spectrum' else 'rayleigh_lower_witness'
        groups.append({'method':method,'audit_kind':kind,'record_count':len(selected),
                       'dimensions':_range(selected,'dimension'),
                       'maximum_accepted_bound':_maximum(selected,'accepted_bound'),
                       'maximum_diagnostic':_maximum(selected,key),
                       'bound_contradictions':sum(r.get('bound_contradiction') is True for r in selected)})
    failure_stages = Counter(str(r.get('stage','unrecorded stage')) for r in data.get('failures',[]))
    return {'complete':data.get('complete') is True, 'reported_all_success':data.get('all_success'),
            'repeats':data.get('repeats'),'queries_per_repeat':data.get('config',{}).get('queries'),
            'planned_rows':planned_per_policy*len(methods) if planned_per_policy is not None else None,
            'recorded_rows':len(rows), 'policy':policy,
            'planned_geometry_records':planned_per_policy, 'assembly_records':len(geometry),
            'assembly_failed_records':sum(r.get('passed') is False for r in geometry),
            'active_id_mismatch_records':sum(r.get('identical_active_ids') is False for r in geometry),
            'dof_range':_range(geometry,'dofs'),
            'active_change_query_records':sum(r.get('initial') is False and
                (r.get('added_count',0)>0 or r.get('deleted_count',0)>0) for r in geometry),
            'added_id_events_after_initial':_sum([r for r in geometry if r.get('initial') is False],'added_count'),
            'deleted_id_events_after_initial':_sum([r for r in geometry if r.get('initial') is False],'deleted_count'),
            'maximum_matrix_reconstruction_error':_maximum(geometry,'matrix_relative_error'),
            'maximum_rhs_reconstruction_error':_maximum(geometry,'rhs_relative_error'),
            'dense_spectral_cap':data.get('dense_spectral_cap'),
            'dense_spectrum_records':len(dense), 'rayleigh_witness_records':len(witnesses),
            'maximum_full_spectrum_drift':_maximum(dense,'exact_drift'),
            'maximum_rayleigh_lower_witness':_maximum(witnesses,'rayleigh_lower_witness'),
            'dense_bound_contradictions':sum(r.get('bound_contradiction') is True for r in dense),
            'witness_bound_contradictions':sum(r.get('bound_contradiction') is True for r in witnesses),
            'local_diagnostic_groups':groups,
            'failure_ledger_records':len(data.get('failures',[])),
            'failure_stages':dict(failure_stages)}


def _facts(documents, hashes):
    return {'input_json_sha256':hashes, 'mechanism':_mechanism_facts(documents['mechanism']),
            'quadrature':_quadrature_facts(documents['quadrature']),
            'active':_active_facts(documents['active'])}


def audit_facts(results_dir=None):
    """Return JSON-safe measured facts, keeping unknown values as None."""
    documents, hashes = _load(results_dir)
    return _facts(documents, hashes)


def _tex(value):
    substitutions = {'\\':r'\textbackslash{}','&':r'\&','%':r'\%',
                     '$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}',
                     '~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    return ''.join(substitutions.get(c,c) for c in str(value))


def _num(value, significant=3):
    x = _number(value)
    if x is None:
        return '--'
    if x == 0:
        return '$0$'
    raw = format(x, '.'+str(significant)+'g')
    if 'e' in raw.lower():
        mantissa, exponent = raw.lower().split('e')
        return '$'+mantissa+r'\times10^{'+str(int(exponent))+'}$'
    return '$'+raw+'$'


def _integer(value):
    x = _number(value)
    return str(int(x)) if x is not None else '--'


def _yes(value):
    return 'yes' if value is True else 'no' if value is False else '--'


def _method(value):
    return _tex(METHOD_NAMES.get(value,value))


def _table(label, caption, columns, headers, rows):
    lines = [r'\begin{table}[!htbp]',r'\centering\small',
             r'\setlength{\tabcolsep}{3pt}',r'\caption{'+caption+'}',
             r'\label{'+label+'}',r'\begin{tabular}{'+columns+'}',
             r'\toprule',' & '.join(headers)+r' \\',r'\midrule']
    lines += [' & '.join(row)+r' \\' for row in rows]
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}','']
    return '\n'.join(lines)


def _failed_check_text(data):
    failed = _failed_checks(data)
    text = ''
    if failed:
        text += 'The recorded failed checks are '+', '.join(_tex(k) for k in failed)+'.\n'
    if data.get('error'):
        text += 'The audit recorded the error: '+_tex(data['error'])+'.\n'
    return text


def _mechanism_section(data, facts):
    output = [r'\section{Numerical evaluation of the spline mechanism}',
              r'\label{sec:vtwo-audit-mechanism}',
              'Audit state: '+_tex(_status(data))+'. '+
              'The following values evaluate the stated spline formulas with '+
              _integer(facts['decimal_precision'])+' decimal digits; they are not solver timing measurements.',
              _failed_check_text(data)]
    rows = data.get('rows',[])
    paired = {}
    for row in rows:
        epsilon = _number(row.get('epsilon'))
        if epsilon is None:
            continue
        family = row.get('family')
        if family in paired.setdefault(epsilon,{}):
            raise ValueError('Duplicate mechanism family/epsilon record')
        paired[epsilon][family] = row
    table_rows = []
    for epsilon,families in sorted(paired.items(),reverse=True):
        positive,negative = families.get('positive',{}),families.get('counterexample',{})
        table_rows.append([_num(epsilon),_num(positive.get('normalized_condition')),
            _num(positive.get('anchor_relative_drift')),
            _num(positive.get('coupling_drift_from_limit')),
            _num(negative.get('epsilon_squared_condition'),significant=6),
            _num(negative.get('anchor_relative_drift'),significant=6),
            _yes(positive.get('within_sufficient_pair_region'))])
    if table_rows:
        output.append(_table('tab:vtwo-audit-mechanism',
            r'Actual quadratic Bernstein pairs on $(0,\varepsilon)$. '
            r'The positive pair is $\{B_1^2,B_2^2\}$ and the negative pair is $\{B_0^2,B_1^2\}$. '
            r'Both anchor drifts use $\varepsilon_a=$ '+_num(facts['anchor_epsilon'])+
            r'. The last column denotes membership of both scales in the sufficient region, not randomized acceptance.',
            'rrrrrrc',[r'$\varepsilon$',r'$\kappa(C_+)$',r'$\eta_+$',
                      r'$|\rho_+-\rho_{+,0}|$',r'$\varepsilon^2\kappa(C_-)$',r'$\eta_-$','Region'],table_rows))
    else:
        output.append('No formula evaluation rows were recorded.\n')
    constants = facts['positive_constants']
    output.append('The recorded positive-pair constants are $b=$ '+_num(constants['b'])+
        ', $\\kappa_0=$ '+_num(constants['kappa0'])+', with sufficient radius '+
        _num(constants['sufficient_epsilon_max'])+' at $\\tau=$ '+_num(facts['tau'])+'. '+
        _integer(facts['positive_sufficient_region_records'])+' recorded positive-pair rows lie within that region. '+
        'The counterexample has a singular leading Gram; its limiting relative energy norm is undefined, '+
        'and the small-cut sufficient theorem does not certify that family.\n')
    if facts['counterexample_theorem_mislabelled_records']:
        output.append(r'\textbf{Audit inconsistency:} '+str(facts['counterexample_theorem_mislabelled_records'])+
                      ' counterexample rows were labelled theorem-applicable and require correction.\n')
    leading_rows = []
    for record in data.get('leading_sets',[]):
        minors = record.get('leading_principal_minors',[])
        leading_rows.append([_integer(record.get('degree')),
                            _integer(len(record.get('basis_indices',[]))),
                            _tex(minors[-1]) if minors else '--',
                            _yes(record.get('leading_gram_spd'))])
    if leading_rows:
        output.append(_table('tab:vtwo-audit-leading-gram',
            'Exact rational leading-Gram checks for the endpoint-vanishing Bernstein sets. '+
            'The last column records the check of every leading principal determinant; '+
            'the displayed determinant is that of the full leading Gram.',
            'rrrc',['Degree','Functions',r'$\det G_0$','All positive'],leading_rows))
    output.append('These finite coordinate families illustrate the proved mechanism and its failure case. '+
                  'They supply no degree-uniform estimate and no empirical probability guarantee.\n')
    return '\n'.join(output)


def _quadrature_section(data, facts):
    output = [r'\section{High-order quadrature sensitivity}',r'\label{sec:vtwo-audit-quadrature}',
              'Audit state: '+_tex(_status(data))+'. '+_failed_check_text(data)]
    config = facts['config']
    output.append('The recorded degree is '+_integer(config.get('degree'))+
                  ', on cells '+_tex(tuple(config.get('cells',[])))+
                  '. The reference uses order '+_integer(facts['reference_order'])+
                  ' and '+_integer(facts['reference_dofs'])+' free unknowns. '+
                  'Its physical and scaled algebraic residuals are '+_num(facts['reference_residual'])+
                  ' and '+_num(facts['reference_scaled_residual'])+', respectively.\n')
    records = {}
    for row in facts['rows']:
        if row['order'] in records:
            raise ValueError('Duplicate quadrature order')
        records[row['order']] = row
    order_list = list(config.get('comparison_orders',[]))
    order_list.extend(q for q in records if q not in order_list)
    table_rows = []
    for order in order_list:
        row = records.get(order,{})
        status = ('not recorded' if not row else 'passed' if row.get('passed') is True
                  else 'failed' if row.get('passed') is False else 'unknown')
        table_rows.append([_integer(order),_num(row.get('matrix_relative_frobenius')),
            _num(row.get('rhs_relative_l2')),_num(row.get('solution_relative_reference_energy')),
            _num(row.get('current_residual_relative_l2')),
            _num(row.get('current_scaled_residual_relative_l2')),status])
    if table_rows:
        output.append(_table('tab:vtwo-audit-quadrature',
            r'Fresh quadrature assemblies against the recorded order-'+_integer(facts['reference_order'])+
            r' numerical reference. $e_A$ is the relative physical-matrix Frobenius difference, '+
            r'$e_b$ the relative load difference, and $e_u$ the relative solution difference in the reference energy. '+
            r'$r$ and $r_s$ are current physical and scaled residuals. Failed and unrecorded orders are retained.',
            'rrrrrrl',['Order',r'$e_A$',r'$e_b$',r'$e_u$',r'$r$',r'$r_s$','Checks'],table_rows))
    thresholds = facts['thresholds']
    output.append('Recorded diagnostic thresholds are '+_num(thresholds.get('matrix_relative_frobenius'))+
        ' for $e_A$, '+_num(thresholds.get('solution_relative_reference_energy'))+
        ' for $e_u$, '+_num(thresholds.get('current_residual_relative_l2'))+
        ' for $r$, and '+_num(thresholds.get('current_scaled_residual_relative_l2'))+' for $r_s$. '+
        'The table reports '+str(len(facts['failed_orders']))+' failed and '+str(len(facts['missing_orders']))+
        ' unrecorded requested orders. Order '+_integer(facts['reference_order'])+
        ' is a numerical reference, not exact integration or a certified upper error bound. '+
        'Fresh caches give a quadrature-order sensitivity check using the same tensor implementation; '+
        'the direct solve controls algebraic error but does not measure continuum discretization error.\n')
    for row in facts['rows']:
        if row['error']:
            output.append('Order '+_integer(row['order'])+' recorded: '+_tex(row['error'])+'.\n')
    return '\n'.join(output)


def _active_section(data, facts):
    output = [r'\section{Active-identifier crossing audit}',r'\label{sec:vtwo-audit-active}',
              'Audit state: '+_tex(_status(data,active=True))+'. '+
              'There are '+_integer(facts['recorded_rows'])+' recorded policy attempts out of '+
              _integer(facts['planned_rows'])+' planned attempts, over '+_integer(facts['repeats'])+
              ' repetitions. This separate audit is excluded from the formal speed aggregate.\n']
    dofs = facts['dof_range']
    dof_text = '--' if dofs is None else _integer(dofs[0])+'--'+_integer(dofs[1])
    assembly_rows = [
        ['Recorded/planned geometry checks',_integer(facts['assembly_records'])+'/'+_integer(facts['planned_geometry_records'])],
        ['Failed recorded reconstruction checks',_integer(facts['assembly_failed_records'])],
        ['Active-ID mismatches',_integer(facts['active_id_mismatch_records'])],
        ['Observed free-unknown range',dof_text],
        ['Queries with changed active IDs',_integer(facts['active_change_query_records'])],
        ['Added/deleted ID events after initial query',_integer(facts['added_id_events_after_initial'])+'/'+_integer(facts['deleted_id_events_after_initial'])],
        ['Maximum full-matrix reconstruction error',_num(facts['maximum_matrix_reconstruction_error'])],
        ['Maximum free-load reconstruction error',_num(facts['maximum_rhs_reconstruction_error'])]]
    output.append(_table('tab:vtwo-audit-active-assembly',
        'Incremental versus fresh nonincremental assembly along the crossing path. '+
        'ID events count additions/deletions at each transition, including repeated reactivation; '+
        'they are not counts of distinct background coordinates.',
        'lr',['Quantity','Recorded value'],assembly_rows))
    solve_rows, churn_rows = [], []
    for method,record in facts['policy'].items():
        solve_rows.append([_method(method),str(record['attempted_rows'])+'/'+_integer(record['planned_rows']),
            str(record['failed_rows'])+'/'+str(record['unknown_outcome_rows']),
            str(record['completed_setup_randomized_checks']),str(record['active_change_randomized_checks']),
            _num(record['maximum_scaled_residual']),_num(record['maximum_energy_error'])])
        churn_rows.append([_method(method),str(record['new_large_block_events_after_initial']),
            str(record['retired_large_block_events_after_initial']),
            str(record['rows_with_residual']),str(record['rows_with_energy_error'])])
    if solve_rows:
        output.append(_table('tab:vtwo-audit-active-solves',
            r'Policy attempts, failures and Gaussian checks. $n_f/n_u$ counts failed/unknown outcomes; '+
            r'$J$ counts Gaussian checks from completed setup records, and $J_{\rm ID}$ restricts these '+
            r'to queries whose active IDs changed. Residual and energy maxima use every recorded finite value, '+
            r'including unsuccessful solves; missing attempts are not successes.',
            'lrrrrrr',['Policy','Attempted/planned',r'$n_f/n_u$',r'$J$',r'$J_{\rm ID}$',
                      r'$\max r_s$',r'$\max e_u$'],solve_rows))
        output.append(_table('tab:vtwo-audit-active-churn',
            'Large-block membership events after the initial query, and denominators for the reported error maxima. '+
            'The large-block definition follows the audit configuration; repeated events are counted.',
            'lrrrr',['Policy','New','Retired','Residual records','Energy records'],churn_rows))
    spectral_rows = []
    for group in facts['local_diagnostic_groups']:
        kind = ('Full spectrum' if group['audit_kind']=='full_generalized_spectrum'
                else 'Rayleigh lower' if group['audit_kind']=='three_rayleigh_lower_witnesses'
                else _tex(group['audit_kind']))
        dimensions = group['dimensions']
        dimension_text = '--' if dimensions is None else _integer(dimensions[0])+'--'+_integer(dimensions[1])
        spectral_rows.append([_method(group['method']),kind,str(group['record_count']),dimension_text,
                              _num(group['maximum_accepted_bound']),_num(group['maximum_diagnostic']),
                              str(group['bound_contradictions'])])
    if spectral_rows:
        output.append(_table('tab:vtwo-audit-active-spectra',
            r'Independent diagnostics on retained probabilistic anchors. Counts are diagnostic records, '+
            r'not distinct blocks. Full generalized spectra are computed only through dimension '+
            _integer(facts['dense_spectral_cap'])+r'; larger records use the maximum of three Rayleigh '+
            r'lower witnesses. $\beta$ is the stored accepted bound. The final column counts reported '+
            r'contradictions using the audit tolerances.',
            'llrrrrr',['Policy','Diagnostic','Records',r'$m$',r'$\max\beta$',
                      'Max. diagnostic','Contradictions'],spectral_rows))
    if facts['dense_spectrum_records']==0:
        output.append('No full generalized spectrum was recorded. '+str(facts['rayleigh_witness_records'])+
            ' Rayleigh lower-witness records therefore cannot establish upper bounds on the local drift norms '+
            'or support an exact large-block spectral-validation claim.\n')
    else:
        output.append('The audit contains '+str(facts['dense_spectrum_records'])+
            ' full generalized-spectrum records and '+str(facts['rayleigh_witness_records'])+
            ' Rayleigh lower-witness records. The recorded contradiction counts are '+
            str(facts['dense_bound_contradictions'])+' and '+str(facts['witness_bound_contradictions'])+
            ', respectively. Lower witnesses can expose an underestimated bound but cannot validate a norm upper bound; '+
            'floating-point full spectra are numerical diagnostics rather than interval certificates.\n')
    output.append('The separate failure ledger contains '+str(facts['failure_ledger_records'])+
                  ' records. Ledger entries can describe the same solve failures counted above and are not added '+
                  'to the policy-failure denominator.\n')
    if facts['failure_stages']:
        failure_rows = []
        for stage,count in sorted(facts['failure_stages'].items()):
            examples = [r for r in data.get('failures',[]) if str(r.get('stage','unrecorded stage'))==stage]
            first = examples[0]
            location = 'repeat '+_integer(first.get('repeat'))+', step '+_integer(first.get('step'))
            if first.get('method'):
                location += ', '+_method(first['method'])
            failure_rows.append([_tex(stage),str(count),location])
        output.append(_table('tab:vtwo-audit-failures',
            'Failure-ledger counts by stage. The location identifies the first recorded occurrence of each stage.',
            'lrl',['Stage','Records','First occurrence'],failure_rows))
        for stage in sorted(facts['failure_stages']):
            first = next(r for r in data['failures'] if str(r.get('stage','unrecorded stage'))==stage)
            output.append('First '+_tex(stage)+' record: '+_tex(first.get('error','error text not recorded'))+'.\n')
    output.append('The lifetime probability allocation is per policy sequence. Auxiliary direct solves, '+
                  'reconstruction checks and local diagnostics do not spend or reset that policy budget, '+
                  'and they are excluded from its timed solve.\n')
    return '\n'.join(output)


def audit_sections(results_dir=None):
    """Return standalone LaTeX sections requiring only amsmath and booktabs.

    Incomplete/failed audit files remain reportable. Missing files, invalid
    schemas, nonfinite JSON constants and duplicate evaluation keys raise.
    """
    documents, hashes = _load(results_dir)
    facts = _facts(documents, hashes)
    return '\n\n'.join((_mechanism_section(documents['mechanism'],facts['mechanism']),
                         _quadrature_section(documents['quadrature'],facts['quadrature']),
                         _active_section(documents['active'],facts['active'])))+'\n'
