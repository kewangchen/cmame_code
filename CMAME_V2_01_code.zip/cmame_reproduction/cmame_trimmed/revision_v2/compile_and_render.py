"""Compile and render only after the complete numerical/postprocessing pipeline.

Rendering produces review material, not an assertion of visual approval.
Run with the bundled document Python, which supplies pypdf and Pillow.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT/'results'
PAPER = ROOT/'paper'
RUNTIME = Path('/Users/kewang/.cache/codex-runtimes/codex-primary-runtime')
COMPILER = Path('/Users/kewang/.codex/plugins/cache/openai-bundled/latex/0.2.8/scripts/compile_latex.py')


def now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def main():
    status = RESULTS/'compile_render_status.json'
    if status.exists():
        raise FileExistsError('Preserve previous compile/render record')
    data = dict(started_utc=now(), pid=os.getpid(), stage='waiting_for_postprocessing',
                complete=False, commands=[], documents={})

    def save():
        temporary = status.with_suffix('.tmp')
        temporary.write_text(json.dumps(data, indent=2)+'\n')
        temporary.replace(status)

    save()
    while True:
        post = json.loads((RESULTS/'postprocess_status.json').read_text())
        if post.get('complete'):
            if any(j.get('returncode') != 0 for j in post['jobs']):
                raise RuntimeError('Unsuccessful postprocessing command')
            break
        if post.get('stage', '').startswith('stopped'):
            data.update(stage='stopped_after_postprocessing_failure', finished_utc=now())
            save()
            return 1
        time.sleep(20)
    env = dict(os.environ)
    env['PATH'] = '/Library/TeX/texbin:'+env.get('PATH', '')

    def command(name, args, log):
        if log.exists():
            raise FileExistsError('Preserve previous log: '+str(log))
        record = dict(name=name, command=list(map(str, args)), started_utc=now(), log=str(log))
        data['stage'] = name
        data['commands'].append(record)
        save()
        print(now(), 'START', name, flush=True)
        with log.open('w') as output:
            result = subprocess.run(record['command'], cwd=PAPER, env=env,
                                    stdout=output, stderr=subprocess.STDOUT)
        record.update(returncode=result.returncode, finished_utc=now())
        save()
        print(now(), 'END', name, result.returncode, flush=True)
        if result.returncode:
            raise RuntimeError('Unsuccessful command: '+name)

    try:
        command('artifact_marker', [RUNTIME/'dependencies/node/bin/node',
            RUNTIME/'plugins/openai-primary-runtime/plugins/pdf/skills/pdf/container_tools/mark_artifact_operation_started.mjs',
            '--operation-kind', 'create', '--expected-output-count', '3', '--output-format', 'pdf'],
            RESULTS/'pdf_artifact_operation.log')
        for name, logname in [('manuscript','main'),('supplement','supplement'),('cover_letter','cover')]:
            command('compile_'+name, [sys.executable, COMPILER, PAPER/(name+'.tex'),
                    '--compiler', 'texlive', '--json'], RESULTS/(logname+'_compile.log'))
        from pypdf import PdfReader
        from PIL import Image, ImageDraw
        render = ROOT/'review_pages'
        render.mkdir(exist_ok=True)
        poppler = RUNTIME/'dependencies/bin/override/pdftoppm'
        for name in ('manuscript', 'supplement', 'cover_letter'):
            folder = render/name
            folder.mkdir(exist_ok=True)
            command('render_'+name, [poppler, '-r', '105', '-png', PAPER/(name+'.pdf'), folder/'page'],
                    RESULTS/(name+'_render.log'))
            pdf = PdfReader(PAPER/(name+'.pdf'))
            pages = sorted(folder.glob('page-*.png'))
            if len(pages) != len(pdf.pages):
                raise ValueError('Incomplete page rendering: '+name)
            texts = [(p.extract_text() or '') for p in pdf.pages]
            (folder/'extracted_text.txt').write_text('\n\n'.join(texts))
            sheets = []
            for start in range(0,len(pages),4):
                selected = pages[start:start+4]
                canvas = Image.new('RGB',(1200,1740),'#e2e6e9')
                draw = ImageDraw.Draw(canvas)
                for index, path in enumerate(selected):
                    with Image.open(path) as image:
                        image.thumbnail((580,830))
                        x = (index%2)*600+(600-image.width)//2
                        y = (index//2)*870+25
                        canvas.paste(image,(x,y))
                    draw.text(((index%2)*600+15,(index//2)*870+6),
                              name+' / page '+str(start+index+1),fill='black')
                sheet = folder/('contact_'+str(start//4+1).zfill(2)+'.png')
                canvas.save(sheet)
                sheets.append(str(sheet))
            data['documents'][name] = dict(pages=len(pages), rendered_pages=list(map(str,pages)),
                contact_sheets=sheets, text_characters=[len(t) for t in texts],
                visual_review='pending human/model image inspection')
            save()
        data.update(stage='completed', complete=True, finished_utc=now())
        save()
        return 0
    except Exception as error:
        data.update(stage='stopped_after_unsuccessful_command',error=repr(error),finished_utc=now())
        save()
        raise


if __name__ == '__main__':
    try:
        code=main()
    except Exception as exc:
        status=RESULTS/'compile_render_status.json'
        if status.exists():
            state=json.loads(status.read_text())
            if state.get('pid')==os.getpid():
                state.update(stage='stopped_after_orchestration_exception',error=repr(exc),finished_utc=now())
                temporary=status.with_suffix('.tmp')
                temporary.write_text(json.dumps(state,indent=2)+'\n')
                temporary.replace(status)
        raise
    raise SystemExit(code)
