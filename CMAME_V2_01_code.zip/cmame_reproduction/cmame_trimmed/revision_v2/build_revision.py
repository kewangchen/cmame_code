"""Build merged CMAME manuscript/supplement from verified records."""
import json,re,shutil,math
from pathlib import Path
import numpy as np
from .campaign import CASES,METHODS
from .analyze import LABELS,analyze,audit_kernel
from .audit_tables import audit_sections,audit_facts
from .cost_analyze import analyze as analyze_cost
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent;P=ROOT/'paper';D=ROOT/'docs'
TITLE='Energy-controlled Schwarz maintenance for evolving trimmed isogeometric analysis'
NAMES={'cubic_long':'Cubic, 50 queries','quartic_long':'Quartic, 50 queries','quintic':'Quintic, 12 queries','refined_cubic':'Refined cubic, 12 queries'}
M={'fresh':'Fresh','exact_local':'Exact refresh','energy':'Fixed power 2','progressive':'Progressive','cost':'Measured cost','lookahead':'Lookahead','stale':'Stale','jacobi':'Jacobi'}
def read(name):return json.loads((ROOT/'results'/(name+'.json')).read_text())
def sci(v):
 if v==0:return '0'
 a,b=f'{v:.2e}'.split('e');return a+r'\times10^{'+str(int(b))+'}'
def table(headers,rows,caption,label,align=None):
 return '\\begin{table}[!htbp]\n\\centering\\small\\setlength{\\tabcolsep}{4pt}\n\\caption{'+caption+'}\\label{'+label+'}\n\\begin{tabular}{'+(align or 'l'+'r'*(len(headers)-1))+'}\\toprule\n'+' & '.join(headers)+r' \\ \midrule'+'\n'+'\n'.join(' & '.join(map(str,r))+r' \\' for r in rows)+'\n\\bottomrule\\end{tabular}\n\\end{table}\n'
def fig(name,caption,label,width=r'\linewidth'):
 return '\\begin{figure}[!htbp]\n\\centering\\includegraphics[width='+width+']{'+name+'.pdf}\n\\caption{'+caption+'}\\label{'+label+'}\n\\end{figure}\n'
def ratio(c,m,metric='linear'):
 return c['ratios'][m][metric]['ratio_of_medians']
def fmt(v):return '--' if v is None else f'{v:.2f}'
def count_fmt(v):return '--' if v is None else f'{v:,.0f}'

def cost_results(c):
 out=r'\subsection{Lookahead and measured-cost stopping}'+'\n'
 out+='The matched stopping-rule study repeats each of the four families three times. '
 out+=r'''The lookahead policy predicts capped nonacceptance, whereas the
time-based policy can rebuild candidates that additional powers might
accept. Both use the same energy acceptance criterion.
Table~\ref{tab:vtwo-cost} reports complete-sequence times from this
comparison; Figure~\ref{fig:vtwo-cost-screen} resolves the corresponding
time ratios and additive cost components.
'''
 rows=[]
 for name,case in c['cases'].items():
  vals=case['methods']
  rows.append([NAMES[name]]+[fmt(vals[m]['median']['linear'])+('*' if not vals[m]['success'] else '') for m in ['energy','progressive','cost','lookahead']])
 out+=table(['Family','Fixed','Progressive','Cost rule','Lookahead'],rows,r'Matched stopping-rule follow-up: median sequence setup-plus-solve times in seconds. Each policy has its own cache and warm starts. A star marks an unsuccessful method sequence.','tab:vtwo-cost')
 if c['failures']==0:
  out+=f"All {c['solves']:,} solves satisfy the residual and direct-reference energy checks. "
 else:
  out+=f"The {c['solves']:,} attempts include {c['failures']} unsuccessful solution checks or exceptions; these remain in the complete record. "
 if 'progressive' in c['geometric_mean_lookahead']:
  g=c['geometric_mean_lookahead']['progressive']
  out+=f"The four-family progressive/lookahead geometric-mean time ratio is {g['linear']:.3f}, or {g['total']:.3f} including assembly. "
 if 'progressive' in c['geometric_mean']:
  g=c['geometric_mean']['progressive']
  out+=f"The corresponding progressive/measured-cost ratios are {g['linear']:.3f} and {g['total']:.3f}. "
  if g['linear']<1:
   out+=f"Measured-cost stopping therefore increases the geometric-mean setup-plus-solve time by {100*(1/g['linear']-1):.1f}\\%. "
 if 'progressive' in c['geometric_mean_lookahead']:
  g=c['geometric_mean_lookahead']['progressive']
  if abs(1/g['linear']-1)<.01:
   out+='The aggregate lookahead and progressive times differ by less than one percent. '
 out+=r'''Table~\ref{tab:vtwo-lookahead-ratios} resolves the variation across
families. All ratios use baselines measured in this same follow-up;
complete cost-rule comparisons are included in the supplement.
'''
 rows=[]
 for name,case in c['cases'].items():
  pr=case['lookahead_ratios'].get('progressive');fr=case['lookahead_ratios'].get('energy')
  rows.append([NAMES[name],fmt(fr['linear']['ratio_of_medians']) if fr else '--',
   fmt(pr['linear']['ratio_of_medians']) if pr else '--',
   f"{pr['linear']['minimum']:.2f}--{pr['linear']['maximum']:.2f}" if pr else '--',
   fmt(pr['total']['ratio_of_medians']) if pr else '--'])
 out+=table(['Family','Fixed/lookahead','$T_L$ ratio','Paired range','$T_A$ ratio'],rows,r'Within-follow-up comparisons. The fixed/lookahead column uses $T_L$; the remaining ratio and range columns compare progressive screening with lookahead. Points are ratios of median sequence totals. Ranges contain the three paired sequence ratios. Values above one favor lookahead; a dash marks a comparison containing an unsuccessful sequence.','tab:vtwo-lookahead-ratios')
 eq=c['lookahead_equivalence']
 if all(eq[k]==0 for k in ('anchor_mismatches','solution_mismatches','rng_mismatches','draw_count_mismatches','factor_count_mismatches')):
  out+=f"All {eq['available']} available query-end pairs have matching cached-anchor hashes, coefficient arrays and identifiers, random states, draw counts and factor-decision counts; {eq['checks']-eq['available']} pairs are unavailable. These untimed checks concern the tested floating-point sequences. "
 else:
  out+=f"Of {eq['checks']} query-end comparisons, {eq['available']} have both successful policies available. The checks find {eq['anchor_mismatches']} unequal cached-anchor hashes, {eq['solution_mismatches']} unequal solution/identifier arrays, {eq['rng_mismatches']} unequal random states, {eq['draw_count_mismatches']} unequal draw counts and {eq['factor_count_mismatches']} unequal factor-decision counts. These are floating-point observations for the tested sequences. "
 if all(case['methods'][m]['success'] for case in c['cases'].values() for m in ('progressive','lookahead')):
  actions={m:sum(r['screen_column_actions'] for case in c['cases'].values() for r in case['methods'][m]['repetitions']) for m in ('progressive','lookahead')}
  if actions['progressive']>0:
   reduction=100*(1-actions['lookahead']/actions['progressive'])
   out+=f"Across all twelve matched sequences, lookahead uses {actions['lookahead']:,} Gaussian vector actions compared with {actions['progressive']:,} for progressive screening, a reduction of {reduction:.1f}\\%. "
 rows=[]
 for name,case in c['cases'].items():
  p=case['methods']['progressive']['median'];l=case['methods']['lookahead']['median'];t=case['methods']['cost']['median']
  rows.append([NAMES[name],fmt(p['screen_time']),fmt(l['screen_time']),count_fmt(l['screen_lookahead_rejections']),count_fmt(l['screen_lookahead_avoided_action_batches']),count_fmt(t['screen_timing_cap_checks'])])
 out+=table(['Family','Progr. (s)','Lookahead (s)','Pruned','Batches','Time stops'],rows,r'Stopping-rule diagnostics: medians over complete sequences. Screen times are seconds. An action batch applies the whitened discrepancy to twelve probe columns. Lookahead stops and their avoided batches belong to the lookahead policy; time stops belong to the separate measured-cost policy.','tab:vtwo-lookahead-work')
 out+=r'''The measured-cost rule trades potential factor retention for immediate
rebuilding. It can therefore reduce screening time while increasing
factorization work, and it changes the anchors seen by later queries.
The component totals expose this exchange, including any associated
change in Krylov work. Figure~\ref{fig:vtwo-cost-dynamics} tracks the
cumulative time balance through every query of each paired repetition.
Historical factor times guide this choice locally;
they do not predict the remainder of the geometry sequence.
'''
 out+=(D/'cost_figure_caption.tex').read_text().replace(r'\label{fig:v2-cost-stopping}',r'\label{fig:vtwo-cost-screen}')
 out+=(D/'cost_dynamics_caption.tex').read_text()
 return out

def cost_supplement(c):
 out=r'\section{Complete stopping-rule comparison records}'+'\n'
 for name,case in c['cases'].items():
  rows=[]
  for m,v in case['methods'].items():
   for r in v['repetitions']:
    rows.append([M[m],r['repeat']+1,fmt(r['setup']),fmt(r['screen_time']),fmt(r['factorization_time']),fmt(r['solve']),fmt(r['total']),r['failures']])
  out+=table(['Policy','Rep.','Setup','Screen','Factors','Solve','$T_A$','Fails'],rows,NAMES[name]+': separately measured follow-up costs in seconds. Screening and factor creation are subsets of setup.','tab:supp-cost-'+name.replace('_','-'))+'\n\\FloatBarrier\n'
  rows=[]
  for key,denominator in [('ratios','cost'),('lookahead_ratios','lookahead')]:
   for numerator,rr in case[key].items():
    if numerator==denominator:continue
    row=[M[numerator]+'/'+M[denominator]]
    for metric in ('linear','total'):
     a=rr[metric];row.extend([f"{a['ratio_of_medians']:.3f}",f"{a['minimum']:.3f}--{a['maximum']:.3f}"])
    rows.append(row)
  out+=table(['Numerator/denominator','$T_L$ ratio','Paired range','$T_A$ ratio','Paired range'],rows,NAMES[name]+': all successful within-follow-up comparisons. Ratios divide median complete-sequence times; ranges are the three paired repetition ratios.','tab:supp-cost-ratios-'+name.replace('_','-'))+'\n\\FloatBarrier\n'
 return out

def kernel_work_tables():
 d=read('kernel_formal');cfg=d['config'];tau=cfg['tau'];s=12;epsilon=.05
 alpha=math.sqrt(2/math.pi)*(6e-8/(math.pi**2*cfg['check_index']**2))**(-1/s)
 out=r'''\section{Action-count bound and recorded stopping powers}
The following diagnostic evaluates the sufficient power bound with
$s=12$, $\epsilon=0.05$ and check index 1000. The work-tail parameter
$\epsilon$ is separate from the safety budget $\delta=10^{-8}$.
The drift is the independently computed floating-point spectral value
from the kernel audit; the tabulation is a numerical evaluation of the
formula, not an outward-rounded bound on that drift.
The column $q_*$ is defined only for a strict drift margin below $\tau$.
Acceptance by that power requires $q_*\leq q_{\rm eff}$ and no further
truncation. Observed powers include both acceptances and rejections.
As in the kernel experiment, screening is invoked below the deployed
288-coordinate refresh threshold to expose its arithmetic cost.
'''
 ledger=[]
 for dt in cfg['increments']:
  rows=[]
  for n in cfg['sizes']:
   rr=[r for r in d['rows'] if r['method']=='progressive' and r['size']==n and r['increment']==dt]
   eta=rr[0]['exact_drift'];assert all(r['exact_drift']==eta for r in rr)
   cap=min(6,max(1,n//(12*s)))
   u=math.sqrt(2*n*math.log(2)+4*math.log(s/epsilon))
   qstar=(1 if eta==0 else max(1,math.ceil(math.log(alpha*u)/math.log(tau/eta)))) if eta<tau else None
   powers=[r['powers'] for r in rr];accepted=sum(r['accepted'] for r in rr)
   rows.append([n,f'{eta/tau:.3f}','--' if qstar is None else qstar,cap,f'{min(powers)}--{max(powers)}',f'{accepted}/{len(rr)}'])
   ledger.append(dict(size=n,increment=dt,drift=eta,drift_over_tau=eta/tau,qstar=qstar,effective_power=cap,work_tail=epsilon,accepted=accepted,attempts=len(rr),observed_power_range=[min(powers),max(powers)]))
  out+=table(['Size',r'$\eta/\tau$','$q_*$',r'$q_{\rm eff}$','Observed $q$','Accepted'],rows,'Sufficient and observed kernel powers for displacement increment $'+sci(dt)+'$. A dash denotes a drift without the strict margin required by the work bound.','tab:supp-work-'+str(cfg['increments'].index(dt)))+'\n\\FloatBarrier\n'
 (ROOT/'results/work_bound_diagnostics.json').write_text(json.dumps(dict(epsilon=epsilon,s=s,check_index=cfg['check_index'],alpha=alpha,rows=ledger),indent=2,allow_nan=False))
 return out

def results(s):
 out=r'''\subsection{Discretization and independent matrix checks}
The scalar approximation study uses degrees one through four
on successively refined circular-hole grids. The measured final-grid
$H^1$ orders are 0.985, 2.004, 3.008 and 3.973. The corresponding
independent cubic quadrature check gives a relative matrix difference
$3.49\times10^{-10}$ and a relative solution energy difference
$4.70\times10^{-9}$ between orders twelve and twenty-four.
'''
 out+=fig('02_accuracy','Discretization checks: manufactured-solution convergence at four degrees and an independent circular-trim quadrature comparison. These errors concern discretization and integration, separately from iterative-solver residuals.','fig:vtwo-accuracy')
 errors=[a['matrix_relative_error'] for c in s['cases'].values() for a in c['assembly_audits']]
 out+=f'Across the initial, middle and final queries of the four elastic families, the largest incremental-to-fresh matrix difference is ${sci(max(errors))}$ in relative Frobenius norm; all active identifier lists agree. '
 qpath=ROOT/'results/quadrature_audit.json'
 if qpath.exists():
  q=json.loads(qpath.read_text());out+='The additional quintic three-dimensional quadrature results are listed in the supplement. '
 out+=r'''The replacement update is also checked through disappearing and reappearing active rows. Full product-quadrature tests independently verify the tensor contractions used by the tensor assembler.
\subsection{Long sequences and higher-order elasticity}
'''
 rows=[]
 for name,c in s['cases'].items():
  cfg=c['config'];v=c['methods']['progressive'];rows.append([NAMES[name],r'$'+r'\times'.join(map(str,cfg['cells']))+'$',cfg['degree'],f"{v['nmin']:,}--{v['nmax']:,}",v['largest_block'],v['coarse_dofs']])
 out+=table(['Family','Cells','$p$','Free DOFs','Largest block','Coarse DOFs'],rows,'Three-dimensional elastic configurations. Each sequence is repeated three times. The largest block is measured after active-space restriction; zero coarse DOFs denotes the one-level construction.','tab:vtwo-cases',align='llrrrr')
 if (ROOT/'figures/17_elastic_fields.pdf').exists():out+=fig('17_elastic_fields','Computed linear-elastic responses to unit body-force density on the analytic extrusions. Surface colors show unscaled displacement magnitude; the displayed geometric displacement has a separately annotated scale in each panel. The rendering uses current spline coefficients and a display tessellation of the analytic boundary.','fig:vtwo-fields')
 allv=[v for c in s['cases'].values() for v in c['methods'].values()];good=[v for v in allv if v['success']]
 pgood=all(c['methods']['progressive']['success'] for c in s['cases'].values())
 out+=f"The three-dimensional comparison contains {s['solves']:,} solves, with {s['failures']} unsuccessful solution checks or factorization attempts. The systems contain up to {s['max_dofs']:,} free coefficients. "
 out+=f"Among complete successful method sequences, the largest physical residual is ${sci(max(v['max_residual'] for v in good))}$ and the largest relative energy difference from the direct solution is ${sci(max(v['max_energy_error'] for v in good))}$. "
 out+='Every progressive sequence satisfies the stated solution checks. ' if pgood else 'The unsuccessful progressive sequences are reported explicitly in the complete supplementary ledger. '
 for name,c in s['cases'].items():
  for m,v in c['methods'].items():
   if v['failures']:
    out+=f"In the {NAMES[name].lower()} family, {M[m]} has {v['failures']} unsuccessful queries and a maximum recorded iteration count of {v['max_iterations']}. "
 out+='Table~\\ref{tab:vtwo-times} reports the full time scope, including cold setup, and Figure~\\ref{fig:vtwo-comparison} shows paired repetition ranges.\n'
 rows=[]
 for name,c in s['cases'].items():
  rows.append([NAMES[name]]+[fmt(c['methods'][m]['median']['linear'])+('*' if not c['methods'][m]['success'] else '') for m in METHODS])
 out+=table(['Family','Fresh','Exact','Fixed','Progr.','Stale','Jacobi'],rows,r'Median complete-sequence setup-plus-solve times $T_L$ in seconds. A star marks a method with at least one unsuccessful query; its measured work is retained but is not treated as a successful speedup. All three repetitions and assembly-inclusive totals are given in the supplement.','tab:vtwo-times')
 g=s['geometric_mean']
 for base,word in [('fresh','fresh Schwarz'),('exact_local','exact local refresh'),('energy','the fixed two-power screen')]:
  if base in g:out+=f"The four-family geometric-mean $T_L$ ratio of {word} to progressive screening is {g[base]['linear']:.2f}; including assembly, the ratio is {g[base]['total']:.2f}. "
 out+='Each ratio gives equal weight to the four declared families. '
 out+='The family-wise ratios and paired ranges in Figure~\\ref{fig:vtwo-comparison} resolve the variation behind these aggregates.\n'
 out+=fig('13_campaign_comparison',r'Matched time ratios for all four families. Filled symbols use setup plus solve; open symbols also include assembly. Points are ratios of median sequence totals, and horizontal segments are the observed ranges of three paired ratios. Values above one favor progressive screening. Failed methods are labeled rather than assigned a speedup.','fig:vtwo-comparison')
 out+=fig('12_sequence_costs',r'The two 50-query families. Top: median cumulative setup-plus-solve times with observed three-repeat ranges. Bottom: mean sequence cost components, which add to the mean total, with minimum--maximum total ranges. Screening includes all checks, including checks followed by refactorization; current coarse work is charged separately.','fig:vtwo-costs')
 out+=r'\subsection{Screening work and factorization savings}'+'\n'
 rows=[]
 for name,c in s['cases'].items():
  f=c['methods']['fresh']['median'];b=c['methods']['energy']['median'];p=c['methods']['progressive']['median'];reps=c['methods']['progressive']['repetitions'];hist={q:sum(r['power_histogram'][str(q)] for r in reps) for q in range(1,7)}
  rows.append([NAMES[name],f"{f['factorizations']:.0f}",f"{b['factorizations']:.0f}",f"{p['factorizations']:.0f}",f"{b['randomized_time']:.2f}",f"{p['randomized_time']:.2f}"])
 out+=table(['Family','Fresh factors','Fixed factors','Progr. factors','Fixed test (s)','Progr. test (s)'],rows,'Median factorization counts and cumulative screen times per sequence. The screen timer includes forming the current-minus-anchor discrepancy, drawing probes and every attempted power.','tab:vtwo-work')
 out+=r'''The work counters distinguish two mechanisms. An early decision removes
remaining actions from a check; a higher power can instead retain an
anchor that the fixed two-power test would rebuild. The latter reduces
factorization counts but can increase screening and iteration costs.
The measured total, rather than the number of retained factors, determines
whether that choice is beneficial. Figure~\ref{fig:vtwo-powers} reports
both stopping frequencies and actual vector actions.
'''
 out+=fig('18_stopping_work','Progressive stopping powers and actual Gaussian vector actions. Fractions pool all three repetitions; action counts are means per complete sequence. A vector action is one application of the whitened drift to one probe column. Checks that ultimately reject remain included.','fig:vtwo-powers')
 out+=r'\subsection{Measured local crossover}'+'\n'
 k=read('kernel_formal');ka=audit_kernel();ks=[]
 for dt in k['config']['increments']:
  sizes=sorted({r['size'] for r in k['rows'] if r['increment']==dt});wins=[]
  for n in sizes:
   vals={m:np.median([r['seconds'] for r in k['rows'] if r['increment']==dt and r['size']==n and r['method']==m]) for m in ['fresh','progressive']}
   if vals['fresh']>vals['progressive']:wins.append(n)
  ks.append(dict(increment=dt,winning_sizes=wins))
  out+=f"For increment ${sci(dt)}$, progressive screening is cheaper than immediate factorization "+('at tested dimensions '+', '.join(map(str,wins)) if wins else 'at none of the tested dimensions')+'. '
 out+=r'''These sampled dimensions locate the observed crossover rather than a
universal threshold. For each rejected candidate, the maintenance cost includes both
screening and the subsequent factorization. Independent dense eigensolves
of the whitened drift assess every kernel candidate outside the timers.
'''
 out+=f"The {ka['checks']} recorded screens include {ka['accepted']} acceptances; the independent floating-point spectral audit finds {ka['unsafe_acceptances']} accepted drifts above $\\tau$ and {ka['underestimated_bounds']} underestimated bounds at the stated diagnostic tolerances. "
 out+=fig('14_kernel_crossover','Local maintenance cost on principal blocks of actual three-dimensional elasticity matrices. Curves show medians and shading the range of five repetitions. Each screen includes budget construction and a new factorization when it fails to accept. Screening is invoked below the deployed small-block guard. The check index is 1000; common extraction and dense spectral oracles are outside the kernel timer.','fig:vtwo-kernel')
 out+=r'\subsection{Changing active spaces and spline limits}'+'\n'
 out+=r'''The supplementary strip-crossing experiment first removes and then
reactivates coefficient rows. Ordered memberships make these transitions
explicit: new blocks are factored, retired blocks are removed, and
surviving blocks retain their cumulative anchors. Full current matrices
and right-hand sides are checked against uncached assembly at every
query. Local dense spectra and lower Rayleigh witnesses are distinguished
in the audit record.
'''
 if (ROOT/'figures/16_active_crossing.pdf').exists():out+=fig('16_active_crossing','Three-dimensional active-space crossing and reactivation. The forward and reverse paths share the same prescribed strip heights. Counts distinguish changed memberships from accepted energy reuse in surviving blocks; this one-repeat mechanism audit is excluded from the four-family speed aggregate.','fig:vtwo-active')
 out+=r'''Actual spline restrictions exhibit both sides of the transport
mechanism. The pair $\{B_1^2,B_2^2\}$ at an endpoint has independent
leading gradients and an SPD normalized limit. For
$\{B_0^2,B_1^2\}$, the leading gradients are dependent although every
positive-cut matrix is SPD; its normalized condition number satisfies
$\varepsilon^2\kappa(C_\varepsilon)\to48$. The energy test uses the
finite matrices in both cases. The supplement supplies the exact Gram
formulas and numerical checks.
'''
 if (ROOT/'figures/15_spline_limits.pdf').exists():out+=fig('15_spline_limits','Actual quadratic Bernstein restrictions near an endpoint. The independent-leading-gradient pair approaches an SPD normalized limit; the dependent pair has condition number asymptotic to $48/\\varepsilon^2$. Values are computed from exact Gram formulas at high arithmetic precision and are not benchmark timings.','fig:vtwo-spline')
 out+=r'\subsection{Additional scalar and elastic benchmarks}'+'\n'
 old=json.loads((OLD/'results/paper_facts.json').read_text())
 out+=f"The seven-family scalar and elastic comparison records {old['primary_solves']:,} successful solves on scalar and elastic systems with up to {old['max_dofs']:,} unknowns. With the fixed-power policy, the geometric-mean setup-plus-solve ratios are {old['gm_vs_fresh']:.2f} against fresh construction and {old['gm_vs_exact_local']:.2f} against exact local refresh. Jacobi is fastest in all seven families. "
 out+=r'''These measurements identify a distinct regime: small local factors
and already localized refresh leave little work for screening to save.
The three-dimensional study examines the larger-factor regime and
reports its scope separately. External comparators in this
study are local implementations of CbAS~\cite{dePrenter2019}, a balanced
coordinate-deflation variant motivated by~\cite{Voet2026}, and sparse
SuperLU. Their implementations and configurations are included in the
reproduction package.
'''
 out+=f"The independent global spectral audit places the retained-to-fresh generalized spectrum in $[{old['spectral_range'][0]:.6f},{old['spectral_range'][1]:.6f}]$, inside $[0.8,1.2]$. Its largest audited local drift is {old['spectral_max_drift']:.6f} and its largest condition-number ratio is {old['condition_ratio']:.6f}, below 1.5. "
 out+=r'These checks validate the recorded finite systems; the exact-arithmetic probability theorem supplies the sequence-wide risk statement.'+'\n'
 out+=fig('04_spectral_audit','Independent dense spectral audit of the fixed-power policy. The global retained-to-fresh comparison and condition-number ratios are checked against the common theoretical bounds. The progressive method shares the local acceptance implication; its independent local checks are supplied separately.','fig:vtwo-spectral')
 (ROOT/'results/kernel_summary.json').write_text(json.dumps(ks,indent=2));return out

def discussion(s,c):
 g=s['geometric_mean'];parts=[]
 parts.append(r'''\section{Discussion}
The spectral tolerance supplies a quantitative contract for retaining a
factor. Current scales account for amplitude changes, the stored anchor
accounts for accumulated coupling change, and the persistent probability
state covers adaptive decisions on current active spaces. The shared
Gaussian event permits the work within a check to be chosen progressively.
These properties connect a local implementation decision to an explicit
bound for the preconditioned system.

The computational tradeoff has two terms that factor counts alone miss:
the work needed to establish acceptance and the iteration work performed
with the retained inverse. Higher powers can strengthen acceptance while
increasing both terms. The full-sequence timings and rejected-screen
kernel costs therefore determine the operating regime. ''')
 if 'energy' in g:parts.append(f"Across the four three-dimensional families, the fixed/progressive geometric-mean $T_L$ ratio is {g['energy']['linear']:.2f}; the individual-family comparisons and their repetition ranges show how this balance varies. ")
 q=s['cases']['quartic_long']['methods']
 if q['energy']['success'] and q['progressive']['success']:
  f=q['energy']['median'];p=q['progressive']['median']
  parts.append(f"In the quartic family, the median factorization time falls from {f['factorization_time']:.2f} to {p['factorization_time']:.2f} seconds, while screening rises from {f['randomized_time']:.2f} to {p['randomized_time']:.2f} seconds and CG from {f['solve']:.2f} to {p['solve']:.2f} seconds. The extra retention therefore fails to recover its screening and iteration costs in this family. ")
 parts.append(r'''The dimension cap follows dense arithmetic counts, while the
measured crossover includes library behavior and data movement. A fixed
budget for screening cannot by itself predict future geometry edits or
the cost of subsequent Krylov iterations.

A common current coarse solve makes the maintenance result useful within
a two-level construction. Its setup is still paid at every query and
limits the fraction of analysis time that local reuse can remove. The
bound also retains the fresh solver's mesh and degree dependence. The
study consequently separates controlled maintenance from the selection
of an effective fresh solver; the Jacobi, stale and direct comparisons
remain relevant to that selection.

The three-dimensional computations cover serial linear elasticity on analytic extruded
trims, with two 50-query paths and degrees three through five. Together
with the additional scalar and elastic studies, they resolve a larger-factor regime
and active-space transitions. Nonextruded CAD surfaces, multipatch
interfaces, nonlinear material evolution and distributed multilevel
solvers remain computational extensions. The exact-arithmetic theorem
controls Gaussian underestimation. The reported floating-point checks
assess factorization, assembly and solve accuracy; an outward-rounded
acceptance rule would require an additional arithmetic error analysis.

\section{Conclusions}
We have developed energy-controlled maintenance with progressive screening for
local Schwarz factors on evolving trimmed spline spaces. Diagonal
transport and cumulative anchors separate changes in basis magnitude
from changes in normalized couplings. A common Gaussian event controls
all powers of a fixed candidate, enabling adaptive stopping under one
risk allocation. Summable allocations and stable identifiers extend the
spectral comparison to the full adaptive sequence, including changes in
active dimension and a common current coarse correction. Actual spline
examples identify both the reach and the limits of the small-cut
amplitude-removal mechanism.

Log-convexity adds a distinct computational result: checks that cannot
accept before the prescribed cap can be terminated without changing
the exact-arithmetic anchor sequence. The matched timings quantify the
benefit and overhead of this prediction separately from elapsed-cost
stopping, which can change factor retention.
''')
 if 'fresh' in g and 'exact_local' in g:parts.append(f"The three-dimensional comparison gives geometric-mean setup-plus-solve ratios of {g['fresh']['linear']:.2f} against fresh factors and {g['exact_local']['linear']:.2f} against exact local refresh. ")
 if 'progressive' in c['geometric_mean_lookahead']:
  a=c['geometric_mean_lookahead']['progressive'];parts.append(f"In the separate stopping-rule study, the progressive/lookahead time ratios are {a['linear']:.3f} for setup plus solve and {a['total']:.3f} when assembly is included. ")
  if abs(1/a['linear']-1)<.01:
   parts.append('Lookahead reduces the number of matrix actions while leaving aggregate runtime essentially unchanged on these sequences. ')
 parts.append(r'''The paired comparisons and local crossover measurements identify
when these savings recover the price of the acceptance decision. They
also show why further retention can be counterproductive. The resulting
method provides a controlled computational choice within a specified
Schwarz solver, with both its spectral tolerance and its maintenance
cost exposed to the repeated-analysis workflow.
''')
 return ''.join(parts)

def build():
 s=analyze();cost=analyze_cost();P.mkdir(exist_ok=True);g=s['geometric_mean']
 abstract=(D/'abstract_template.tex').read_text().strip()
 perf=''
 if 'fresh' in g and 'exact_local' in g:perf=f"For progressive screening, geometric-mean setup-plus-solve speedups are {g['fresh']['linear']:.2f} over fresh construction and {g['exact_local']['linear']:.2f} over exact local refresh; including assembly, they are {g['fresh']['total']:.2f} and {g['exact_local']['total']:.2f}."
 abstract=abstract.replace('@PERF@',perf)
 oldmain=(OLD/'paper/manuscript.tex').read_text();preamble=oldmain[:oldmain.index(r'\begin{abstract}')];preamble=re.sub(r'\\title\{[^\n]*\}',lambda m:r'\title{'+TITLE+'}',preamble)
 header=preamble+r'\begin{abstract}'+'\n'+abstract+'\n'+r'''\end{abstract}
\begin{keyword}
Trimmed isogeometric analysis \sep Additive Schwarz \sep Repeated analysis \sep Progressive Gaussian screening \sep Spectral equivalence
\end{keyword}
\end{frontmatter}
'''
 algorithm=(D/'model_algorithm.tex').read_text().replace(r'\subsection{A common current coarse correction}',(D/'measured_cost_note.tex').read_text()+'\n'+r'\subsection{A common current coarse correction}')
 body=(D/'introduction.tex').read_text()+'\n'+algorithm+'\n'+(D/'theory_main.tex').read_text()+'\n'+(D/'work_bound_main.tex').read_text()+'\n'+(D/'locality_rank_main.tex').read_text()+'\n'+(D/'lookahead_main.tex').read_text()+'\n'+(D/'experiment_protocol.tex').read_text()
 body+='\n'+(D/'cost_protocol_main.tex').read_text()
 body+=results(s)+cost_results(cost)+'\n\\FloatBarrier\n'+discussion(s,cost)
 declarations=(OLD/'docs/limitations_conclusion.tex').read_text().split(r'\section*{Funding}')[1]
 declarations=declarations.replace('All tabulated and plotted measurements can\nbe reconstructed from the included JSON records.',
  'Timing and diagnostic plots are generated from the included JSON records;\ndisplacement visualizations use the saved coefficient and field arrays.')
 body+='\n\\section*{Funding}'+declarations
 body=body.replace(r'\begin{figure}[t]',r'\begin{figure}[!htbp]')
 end='\n\\bibliographystyle{elsarticle-num}\n\\bibliography{references}\n\\end{document}\n'
 (P/'manuscript.tex').write_text(header+body+end)
 bib=(OLD/'paper/references.bib').read_text()+'\n'+(D/'revision_references.bib').read_text();(P/'references.bib').write_text(bib)
 shutil.copytree(OLD/'figures',P/'figures',dirs_exist_ok=True);shutil.copytree(ROOT/'figures',P/'figures',dirs_exist_ok=True)
 oldsupp=(OLD/'paper/supplement.tex').read_text()
 authorblock=header[header.index(r'\author{'):header.index(r'\begin{abstract}')]
 supphead=header[:header.index(r'\begin{frontmatter}')]+r'\begin{frontmatter}\title{Supplementary material: '+TITLE+'}\n'+authorblock+r'\begin{abstract}Detailed analysis, complete numerical records and reproducibility checks for progressive local-factor maintenance.\end{abstract}\end{frontmatter}'+'\n'
 supp=(D/'theory_supplement.tex').read_text()+'\n'+(D/'work_bound_supp.tex').read_text()+'\n'+(D/'locality_rank_supp.tex').read_text()+'\n'+(D/'lookahead_theory.tex').read_text()+'\n'+(D/'cost_experiment_protocol.tex').read_text()+supplement_tables(s)+cost_supplement(cost)+kernel_work_tables()+audit_sections()
 legacy=oldsupp.split(r'\end{frontmatter}',1)[1].split(r'\bibliographystyle',1)[0]
 # Replace the earlier small-cut exposition by the revised, self-contained
 # analysis above. Keep deterministic comparator bounds and all measured data.
 start=legacy.index(r'\section{A conditional small-cut asymptotic mechanism}')
 stop=legacy.index(r'\section{Geometry specifications}',start)
 legacy=legacy[:start]+legacy[stop:]
 supp+=r'\FloatBarrier\section{Additional fixed-power studies}'+'\n'+legacy
 (P/'supplement.tex').write_text(supphead+supp+end)
 shutil.copy(D/'highlights.txt',P/'highlights.txt')
 letter=(D/'cover_letter.tex').read_text().replace('Risk-controlled reuse of local Schwarz\nsolvers for evolving trimmed spline discretizations',TITLE)
 text=''
 if 'exact_local' in g and 'energy' in g:text=f"Across the four three-dimensional families, baseline/progressive geometric-mean setup-plus-solve time ratios are {g['exact_local']['linear']:.2f} for exact local refresh and {g['energy']['linear']:.2f} for the fixed two-power policy; the assembly-inclusive ratios are {g['exact_local']['total']:.2f} and {g['energy']['total']:.2f}. "
 if 'progressive' in cost['geometric_mean_lookahead']:
  a=cost['geometric_mean_lookahead']['progressive'];text+=f"A separate matched comparison gives progressive/lookahead ratios of {a['linear']:.3f} for setup plus solve and {a['total']:.3f} including assembly. "
 if not text:text='Unsuccessful method sequences are retained explicitly; no aggregate speed claim is assigned to a comparison with incomplete successful coverage.'
 letter=re.sub(r'\\textbf\{PERFORMANCE RESULT TO INSERT:.*?\}',lambda m:text,letter,flags=re.S);(P/'cover_letter.tex').write_text(letter)
 (ROOT/'results/paper_facts.json').write_text(json.dumps(dict(title=TITLE,geometric_mean=g,solves=s['solves'],failures=s['failures'],max_dofs=s['max_dofs'],cost_geometric_mean=cost['geometric_mean'],lookahead_geometric_mean=cost['geometric_mean_lookahead'],cost_solves=cost['solves'],cost_failures=cost['failures'],audits=audit_facts()),indent=2))
 print('Built',P)

def supplement_tables(s):
 out=r'\section{Complete three-dimensional timing records}'+'\n'+r'''Each row contains one complete sequence. Setup includes current coarse
work when configured. Screening is a subset of setup. Times are seconds;
iterations are totals across queries. A failed method remains listed,
and its attempted cost is not interpreted as a successful runtime.
'''
 for name,c in s['cases'].items():
  rows=[]
  for m,v in c['methods'].items():
   for r in v['repetitions']:rows.append([M[m],r['repeat']+1,fmt(r['setup']),fmt(r['randomized_time']),fmt(r['coarse_setup']),fmt(r['solve']),fmt(r['assembly']),fmt(r['total']),r['failures']])
  out+=table(['Method','Rep.','Setup','Screen','Coarse','Solve','Assem.','$T_A$','Fails'],rows,NAMES[name]+': complete sequence costs.','tab:supp-'+name.replace('_','-'))+'\n\\FloatBarrier\n'
 out+=r'\section{Independent audits and reproducibility}'+'\n'
 out+=r'''The accompanying records contain the exact configurations, sources,
SHA-256 hashes, all repeated timings, per-query residuals and energy errors,
local factor decisions, active identifiers and independent assembly checks.
The formal campaign comprises 24 separate probabilistic sequences; its
simple combined exact-arithmetic union bound is $2.4\times10^{-7}$.
The local-kernel study uses prescribed individual check indices rather
than a simulated full decision sequence. Mechanism and quadrature audits
are separate from timing measurements. Their computation and source
provenance are included in the reproduction package.
'''
 for name in ['quadrature_audit','mechanism_audit','active_audit']:
  p=ROOT/'results'/(name+'.json')
  if p.exists():out+=r'\paragraph{'+name.replace('_',' ')+r'.} The complete machine-readable result is included as \texttt{'+name.replace('_',r'\_')+r'.json}.'+'\n'
 return out
if __name__=='__main__':build()
