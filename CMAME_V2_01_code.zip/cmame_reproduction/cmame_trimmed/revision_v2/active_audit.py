"""Supplementary active-ID crossing audit; separate from formal speed families.

Run serially after the formal campaign. Every current assembled matrix is
compared with independent nonincremental tensor assembly outside policy timers.
Five policies keep their own anchors and warm starts. Failures are retained.
Large-block Rayleigh witnesses are LOWER diagnostics, not norm certificates.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np
import scipy
from scipy import linalg

from cmame_trimmed.src.geometry import TrimDomain
from cmame_trimmed.src.preconditioners import EnergyBudget
from cmame_trimmed.src.solver import direct_reference, equilibrate
from cmame_trimmed.src.space import SplineGrid
from .campaign import transfer
from .screening import ProgressiveEnergyBudget
from .tensor_assembly import TensorAssembler
from .twolevel import solve_revised

ROOT = Path(__file__).resolve().parent
METHODS = ('fresh', 'exact_local', 'energy', 'progressive', 'stale')
FORWARD_ETA = (.25, .20, .15, .10, .05, .01, 0., -.01, -.05, -.10, -.15, -.20)
ETA = FORWARD_ETA + FORWARD_ETA[-2::-1]
CONFIG = dict(cells=[8, 8, 4], degree=3, physics='elasticity', boundary='left',
              load='body', width=4, coarse_ratio=0, quadrature=12,
              tau=.2, probes=12, fixed_power=2, progressive_max_power=6,
              dimension_cost_cap=True, min_dimension=288,
              delta_per_policy_sequence=1e-8, eta=list(ETA),
              top_formula='(5+eta)/8', queries=len(ETA), maxiter=2000,
              local_bound_tolerance=dict(relative=1e-7, absolute=1e-10),
              purpose='active-ID mechanism; excluded from formal speed aggregate')


def atomic(path, data):
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False))
    temporary.replace(path)


def provenance():
    manifest = json.loads((ROOT/'results/formal_manifest.json').read_text())
    hashes = manifest['source_hashes']
    for relative, expected in hashes.items():
        actual = hashlib.sha256((ROOT.parent.parent/relative).read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError('Frozen core source changed: '+relative)
    own = Path(__file__).resolve()
    return dict(frozen_core_hashes=hashes,
                own_source={str(own.relative_to(ROOT.parent.parent)):
                            hashlib.sha256(own.read_bytes()).hexdigest()})


def budget_record(state):
    if state is None:
        return None
    fields = ('count', 'spent_failure_budget', 'action_batches', 'column_actions',
              'early_accepts', 'early_rejections', 'lower_bound_rejections',
              'avoided_action_batches', 'cost_capped_checks',
              'cost_cap_avoided_action_batches', 'last_effective_power')
    return {name: getattr(state, name) for name in fields if hasattr(state, name)}


def accepted_local_audits(system, cache, cap, seed):
    """Independent generalized spectra when small; Rayleigh witnesses otherwise.

    Applies to all current probabilistically retained anchors, including anchors
    carried through an unchanged query. The witness RNG is separate from the
    screen budget. It cannot be used to accept, refresh, or tune a policy.
    """
    C, _, _ = equilibrate(system.A, system.b)
    rng = np.random.default_rng(seed)
    records = []
    for key, factor in cache.items():
        if factor.last_is_exact or factor.certificate_kind != 'probabilistic':
            continue
        ids = np.asarray(key, dtype=int)
        rows = np.searchsorted(system.ids, ids)
        if np.any(rows >= len(system.ids)) or not np.array_equal(system.ids[rows], ids):
            raise AssertionError('Retained cache contains inactive background IDs')
        current = C[rows, :][:, rows].toarray()
        delta = current-factor.anchor
        bound = float(factor.last_accepted_bound)
        if len(ids) <= cap:
            values = linalg.eigvalsh(delta, factor.anchor, check_finite=True)
            exact = float(np.max(np.abs(values), initial=0.))
            record = dict(dimension=len(ids), accepted_bound=bound,
                          audit_kind='full_generalized_spectrum', exact_drift=exact,
                          bound_contradiction=bool(exact > bound*(1+1e-7)+1e-10))
        else:
            directions = rng.standard_normal((len(ids), 3))
            numerator = np.abs(np.sum(directions*(delta@directions), axis=0))
            denominator = np.sum(directions*(factor.anchor@directions), axis=0)
            if not np.all(np.isfinite(denominator)) or np.any(denominator <= 0):
                raise FloatingPointError('Nonpositive accepted-anchor Rayleigh energy')
            witness = float(np.max(numerator/denominator))
            if not np.isfinite(witness):
                raise FloatingPointError('Nonfinite Rayleigh witness')
            record = dict(dimension=len(ids), accepted_bound=bound,
                          audit_kind='three_rayleigh_lower_witnesses',
                          dense_spectrum_skipped_due_to_cap=True,
                          rayleigh_lower_witness=witness,
                          bound_contradiction=bool(witness > bound*(1+1e-7)+1e-10))
        records.append(record)
    return records


def run(repeats=1, dense_spectral_cap=400, output=None):
    if type(repeats) is not int or repeats < 1:
        raise ValueError('repeats must be a positive integer')
    if type(dense_spectral_cap) is not int or dense_spectral_cap < 1:
        raise ValueError('dense_spectral_cap must be a positive integer')
    path = Path(output) if output else ROOT/'results/active_audit.json'
    if path.exists():
        raise FileExistsError('Refusing to overwrite audit data: '+str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    data = dict(config=CONFIG, methods=list(METHODS), repeats=repeats,
                dense_spectral_cap=dense_spectral_cap, rows=[], references=[],
                geometry_audits=[], local_audits=[], failures=[],
                complete=False, all_success=False, provenance=provenance(),
                python=sys.version, numpy=np.__version__, scipy=scipy.__version__,
                platform=platform.platform(),
                timing_scope='assembly + linear setup + CG; ID transfer, references, '
                             'assembly/local spectral audits, diagnostics and output excluded')
    source_copy = path.parent/(path.stem+'_source.py')
    if source_copy.exists():
        raise FileExistsError('Refusing to overwrite audit source snapshot: '+str(source_copy))
    source_copy.write_bytes(Path(__file__).read_bytes())
    atomic(path, data)
    for rep in range(repeats):
        grid = SplineGrid(tuple(CONFIG['cells']), CONFIG['degree'])
        assembler = TensorAssembler(grid, physics='elasticity', quadrature=12)
        caches = {}
        previous_solutions = {}
        previous_keys = {}
        previous_ids = None
        budgets = {
            'energy': EnergyBudget(seed=2026101700+rep, probes=12, power=2, min_dimension=288),
            'progressive': ProgressiveEnergyBudget(seed=2026101700+rep, probes=12, power=6,
                               min_dimension=288, dimension_cost_cap=True),
        }
        for step, eta in enumerate(ETA):
            domain = TrimDomain(top=(5+eta)/8)
            stage = 'assembly'
            try:
                system = assembler.assemble(domain)
                stage = 'nonincremental_assembly_audit'
                other = TensorAssembler(grid, physics='elasticity', quadrature=12,
                                        incremental=False).assemble(domain)
                identical = bool(np.array_equal(system.ids, other.ids))
                difference = system.A_full-other.A_full
                matrix_error = float(np.linalg.norm(difference.data)/np.linalg.norm(other.A_full.data))
                rhs_error = (float(np.linalg.norm(system.b-other.b)/np.linalg.norm(other.b))
                             if identical else None)
                added = system.ids if previous_ids is None else np.setdiff1d(system.ids, previous_ids)
                deleted = np.empty(0, dtype=int) if previous_ids is None else np.setdiff1d(previous_ids, system.ids)
                passed = bool(identical and matrix_error < 2e-12 and rhs_error < 2e-12)
                data['geometry_audits'].append(dict(repeat=rep, step=step, eta=eta,
                    top=domain.top, dofs=len(system.ids), initial=previous_ids is None,
                    added_ids=added.tolist(), deleted_ids=deleted.tolist(),
                    added_count=len(added), deleted_count=len(deleted),
                    identical_active_ids=identical, matrix_relative_error=matrix_error,
                    rhs_relative_error=rhs_error, passed=passed,
                    changed_cells=system.changed_cells, cached_cells=system.cached_cells))
                del other, difference
                if not passed:
                    raise AssertionError('Incremental assembly disagrees with reconstruction')
                previous_ids = system.ids.copy()
                stage = 'current_direct_reference'
                reference, reference_time = direct_reference(system)
                data['references'].append(dict(repeat=rep, step=step, **reference_time))
            except Exception as exc:
                data['failures'].append(dict(repeat=rep, step=step, stage=stage,
                    error=type(exc).__name__+': '+str(exc), aborted_sequence=True))
                atomic(path, data)
                return path

            shift = (rep+step)%len(METHODS)
            order = METHODS[shift:]+METHODS[:shift]
            for method in order:
                x0 = transfer(previous_solutions.get(method), system.ids)
                started = time.perf_counter()
                successful_cache = None
                try:
                    x, current_cache, row = solve_revised(system, method,
                        cache=caches.get(method), step=step, tau=.2, width=4,
                        reference=reference, probability_state=budgets.get(method),
                        coarse_ratio=0, x0=x0, maxiter=2000)
                    keys = {key for key in current_cache if len(key)>288}
                    old_keys = previous_keys.get(method, set())
                    row.update(new_large_blocks=len(keys-old_keys),
                               retired_large_blocks=len(old_keys-keys),
                               surviving_large_blocks=len(old_keys & keys),
                               new_large_block_dimensions=sorted(len(key) for key in keys-old_keys),
                               retired_large_block_dimensions=sorted(len(key) for key in old_keys-keys),
                               large_blocks=len(keys),
                               large_block_dimensions=sorted(len(key) for key in keys))
                    previous_keys[method] = keys
                    if method != 'fresh':
                        caches[method] = current_cache
                    previous_solutions[method] = ((system.ids.copy(), x.copy())
                                                 if row['success'] else None)
                    if not row['success']:
                        data['failures'].append(dict(repeat=rep, step=step, method=method,
                            stage='policy_solve', error='Solver returned unsuccessful result',
                            info=row.get('info'), residual=row.get('residual'),
                            scaled_residual=row.get('scaled_residual')))
                    successful_cache = current_cache
                    del x
                except Exception as exc:
                    row = dict(method=method, step=step, success=False,
                               attempt_seconds=time.perf_counter()-started,
                               error=type(exc).__name__+': '+str(exc), dofs=len(system.b))
                    caches.pop(method, None)
                    previous_solutions[method] = None
                    data['failures'].append(dict(repeat=rep, step=step, method=method,
                                                 stage='policy_solve', error=row['error']))
                row.update(repeat=rep, eta=eta, top=domain.top,
                           active_ids_changed=bool(step>0 and len(added)+len(deleted)>0),
                           added_ids_count=len(added), deleted_ids_count=len(deleted),
                           probability_budget=budget_record(budgets.get(method)))
                data['rows'].append(row)
                atomic(path, data)
                # Explicitly outside solve timing; do not alter decisions based
                # on these independently computed validation diagnostics.
                if successful_cache is not None and method in budgets:
                    try:
                        local = accepted_local_audits(system, successful_cache,
                                  dense_spectral_cap, seed=87100+1000*rep+step)
                        data['local_audits'].extend(dict(repeat=rep, step=step,
                                                method=method, **record) for record in local)
                        if any(record['bound_contradiction'] for record in local):
                            data['failures'].append(dict(repeat=rep, step=step,
                                method=method, stage='local_bound_audit',
                                error='Independent local diagnostic contradicts accepted bound'))
                    except Exception as exc:
                        data['failures'].append(dict(repeat=rep, step=step,
                            method=method, stage='local_bound_audit',
                            error=type(exc).__name__+': '+str(exc)))
                    atomic(path, data)
                del successful_cache
            print('active_audit', 'repeat', rep, 'step', step, 'eta', eta,
                  'dofs', len(system.ids), 'added', len(added), 'deleted', len(deleted), flush=True)
    data['complete'] = True
    data['all_success'] = bool(not data['failures'] and all(row['success'] for row in data['rows']))
    data['summary'] = dict(
        expected_rows=repeats*len(ETA)*len(METHODS), actual_rows=len(data['rows']),
        active_change_queries=sum(not r['initial'] and (r['added_count']>0 or r['deleted_count']>0)
                                  for r in data['geometry_audits']),
        randomized_checks=sum(row.get('stat_randomized_checks', 0) for row in data['rows']),
        active_change_randomized_checks={method:
            sum(row.get('stat_randomized_checks', 0) for row in data['rows']
                if row['method']==method and row['active_ids_changed'])
            for method in ('energy', 'progressive')},
        dense_local_spectra=sum(r['audit_kind']=='full_generalized_spectrum' for r in data['local_audits']),
        large_local_witness_records=sum(r['audit_kind']=='three_rayleigh_lower_witnesses'
                                       for r in data['local_audits']),
        failure_records=len(data['failures']))
    atomic(path, data)
    return path


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repeats', type=int, default=1)
    parser.add_argument('--dense-spectral-cap', type=int, default=400)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = run(args.repeats, args.dense_spectral_cap, args.output)
    print(result, flush=True)
