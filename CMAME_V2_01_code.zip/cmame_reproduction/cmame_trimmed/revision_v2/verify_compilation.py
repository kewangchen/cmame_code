"""Fresh final compilation with before/after input and output identities.

Run after layout edits are complete. This does not grant visual approval.
The first compilation/rendering pass performs the PDF artifact marker.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PAPER = ROOT/'paper'
RESULTS = ROOT/'results'
COMPILER = Path('/Users/kewang/.codex/plugins/cache/openai-bundled/latex/0.2.8/scripts/compile_latex.py')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def inputs():
    paths = [PAPER/n for n in ('manuscript.tex','supplement.tex','cover_letter.tex','references.bib')]
    paths.extend(sorted((PAPER/'figures').glob('*.pdf')))
    return {str(p.relative_to(PAPER)):sha(p) for p in paths}


def main():
    initial = json.loads((RESULTS/'compile_render_status.json').read_text())
    if not initial.get('complete'):
        raise RuntimeError('Initial compilation/rendering must finish first')
    evidence = RESULTS/'compilation_evidence.json'
    build = ROOT/'verified_compile'
    if evidence.exists() or build.exists():
        raise FileExistsError('Preserve prior final compilation evidence and build tree')
    build.mkdir()
    record = dict(started_utc=now(),complete=False,inputs=inputs(),commands=[],outputs={})

    def save():
        temporary=evidence.with_suffix('.tmp')
        temporary.write_text(json.dumps(record,indent=2)+'\n')
        temporary.replace(evidence)

    save()
    env=dict(os.environ)
    env['PATH']='/Library/TeX/texbin:'+env.get('PATH','')
    try:
        for name in ('manuscript','supplement','cover_letter'):
            log=RESULTS/(name+'_verified_compile.log')
            if log.exists():raise FileExistsError('Preserve '+str(log))
            command=[sys.executable,str(COMPILER),str(PAPER/(name+'.tex')),
                     '--compiler','texlive','--output-directory',str(build),'--json']
            entry=dict(document=name,command=command,started_utc=now(),log=str(log))
            record['commands'].append(entry);save()
            with log.open('w') as output:
                result=subprocess.run(command,cwd=PAPER,env=env,stdout=output,stderr=subprocess.STDOUT)
            entry.update(returncode=result.returncode,finished_utc=now());save()
            if result.returncode:raise RuntimeError('Final compilation failed: '+name)
            if inputs()!=record['inputs']:
                raise RuntimeError('An input changed during final compilation')
            source=build/(name+'.pdf')
            if not source.is_file():raise FileNotFoundError(source)
            shutil.copy2(source,PAPER/source.name)
            record['outputs'][source.name]=sha(PAPER/source.name)
            entry['log_sha256']=sha(log);save()
        record.update(complete=True,finished_utc=now());save()
    except Exception as exc:
        record.update(error=repr(exc),finished_utc=now());save()
        raise


if __name__=='__main__':
    main()
