"""Figure 19 from the completed separate measured-cost ablation summary.

Do not run while timing jobs are active. Afterwards:
  python -m cmame_trimmed.revision_v2.cost_analyze
  python -m cmame_trimmed.revision_v2.cost_figures --timings-finished

Reads only cost_summary.json; formal-campaign measurements are never pooled.
No numerical benchmark, solver or eigensolver is imported or executed here.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from .audit_figures import digest, plotting_runtime, shared_palette

ROOT = Path(__file__).resolve().parent
CASES = ('cubic_long', 'quartic_long', 'quintic', 'refined_cubic')
METHODS = ('energy', 'progressive', 'cost', 'lookahead')
CASE_LABELS = ('Cubic\n50 queries', 'Quartic\n50 queries',
               'Quintic\n12 queries', 'Refined cubic\n12 queries')
METHOD_LABELS = ('Fixed 2', 'Progr.', 'Timed', 'LA')
WIDTH_MM = 180.0


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def load_summary(path):
    data = json.loads(Path(path).read_text())
    if data.get('complete') is not True or data.get('coverage', {}).get('validated') is not True:
        raise ValueError('Cost summary is incomplete or its coverage was not validated')
    if set(data['cases']) != set(CASES):
        raise ValueError('Cost figure requires exactly the four declared ablation families')
    for name in CASES:
        case = data['cases'][name]
        if set(case['methods']) != set(METHODS):
            raise ValueError('Cost figure requires exactly four method identities')
        for method in METHODS:
            records = case['methods'][method]['repetitions']
            if sorted(r['repeat'] for r in records) != [0, 1, 2]:
                raise ValueError('Cost summary lacks three complete repetitions: '+name+'/'+method)
            if case['methods'][method]['success']:
                for record in records:
                    if not record['success'] or record['failures']:
                        raise ValueError('Successful method contains failed repetition')
                    keys = ('linear', 'setup', 'solve', 'screen_time',
                            'factorization_time', 'coarse_setup', 'other_setup')
                    if not all(finite(record.get(key)) for key in keys):
                        raise ValueError('Successful method lacks finite additive components')
                    tolerance = 1e-10*max(1., record['linear'])
                    if any(record[key] < -tolerance for key in keys):
                        raise ValueError('Negative cost component in successful record')
                    total = (record['screen_time']+record['factorization_time']+
                             record['coarse_setup']+record['other_setup']+record['solve'])
                    if abs(total-record['linear']) > tolerance:
                        raise ValueError('Per-repetition cost components are not additive')
        for field, denominator in (('ratios','cost'), ('lookahead_ratios','lookahead')):
            for baseline in METHODS:
                ratios = case.get(field, {}).get(baseline)
                both_success = (case['methods'][baseline]['success'] and
                                case['methods'][denominator]['success'])
                if both_success != (ratios is not None):
                    raise ValueError('Ratio availability disagrees with method success')
                if ratios is not None:
                    for metric in ('linear', 'total'):
                        row = ratios[metric]
                        if row.get('numerator') != baseline or row.get('denominator') != denominator:
                            raise ValueError('Ratio direction label differs from data collection')
                        if (len(row['paired']) != 3 or
                                not all(finite(x) and x > 0 for x in row['paired'])):
                            raise ValueError('Invalid paired cost ratio')
                        if not finite(row['ratio_of_medians']) or row['ratio_of_medians'] <= 0:
                            raise ValueError('Invalid ratio of median sequence totals')
                        if not math.isclose(min(row['paired']), row['minimum'], rel_tol=1e-10):
                            raise ValueError('Cost ratio lower range disagrees with paired records')
                        if not math.isclose(max(row['paired']), row['maximum'], rel_tol=1e-10):
                            raise ValueError('Cost ratio upper range disagrees with paired records')
    return data


def draw(data, source, output, np, plt):
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    from matplotlib.ticker import FuncFormatter

    palette = shared_palette()
    colors = {'energy':palette['energy'], 'progressive':palette['progressive'],
              'cost':palette['fresh']}
    fig, (a, b) = plt.subplots(2, 1, figsize=(WIDTH_MM/25.4, 168/25.4))
    fig.subplots_adjust(left=.12, right=.98, bottom=.22, top=.82,
                        hspace=.75)
    fig.suptitle('Lookahead and cost stopping: four-policy matched follow-up',
                 y=.988, fontsize=10)
    for ax, letter, title in (
            (a, 'a', 'Complete sequence comparison'),
            (b, 'b', 'Screening, local factors and remaining linear costs')):
        ax.set_title(title, loc='left', pad=9)
        ax.text(-.09, 1.04, letter, transform=ax.transAxes,
                fontweight='bold', fontsize=11)
        ax.grid(axis='y', color='#e5e9ec', lw=.5, zorder=0)
    a.axhline(1, color=palette['stale'], ls='--', lw=.9, zorder=1)
    observed = [1.]
    for index, name in enumerate(CASES):
        case = data['cases'][name]
        for method, center in (('energy', -.26), ('progressive', 0.), ('cost', .26)):
            ratio = case.get('lookahead_ratios', {}).get(method)
            if ratio is None:
                failures = (case['methods'][method]['failures']+
                            case['methods']['lookahead']['failures'])
                a.text(index+center, .025, 'failed\n'+str(failures),
                       transform=a.get_xaxis_transform(), ha='center', va='bottom',
                       color=colors[method], fontsize=7.2)
                continue
            for metric, offset, filled in (('linear', -.045, True), ('total', .045, False)):
                row = ratio[metric]
                x = index+center+offset
                a.vlines(x, row['minimum'], row['maximum'], color=colors[method],
                         lw=1.1, zorder=3)
                a.hlines([row['minimum'], row['maximum']], x-.018, x+.018,
                         color=colors[method], lw=.8, zorder=3)
                a.plot(x, row['ratio_of_medians'], 'o', ms=4.5,
                       color=colors[method], mfc=colors[method] if filled else 'white',
                       mew=1., zorder=4)
                observed.extend([row['minimum'], row['maximum'], row['ratio_of_medians']])
    a.set_yscale('log', base=2)
    a.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f'{value:g}'))
    a.set_ylim(min(observed)/1.18, max(observed)*1.18)
    a.set_yticks([tick for tick in [.8, .9, 1., 1.1, 1.2, 1.3, 1.4]
                 if a.get_ylim()[0] <= tick <= a.get_ylim()[1]])
    a.minorticks_off()
    a.set_ylabel('Baseline / lookahead time')
    a.set_xticks(range(4), CASE_LABELS)
    a.set_xlim(-.55, 3.55)
    ratio_handles = [
        Line2D([], [], marker='o', lw=0, color=palette['energy'], label='Fixed power 2'),
        Line2D([], [], marker='o', lw=0, color=palette['progressive'], label='Progressive'),
        Line2D([], [], marker='o', lw=0, color=palette['fresh'], label='Measured-cost'),
        Line2D([], [], marker='o', lw=0, color=palette['fresh'], label='Setup + CG'),
        Line2D([], [], marker='o', lw=0, color=palette['fresh'], mfc='white',
               label='With assembly')]
    fig.legend(handles=ratio_handles, loc='upper center', bbox_to_anchor=(.54, .95),
               ncol=3, fontsize=7)

    components = [('screen_time', 'Screening', palette['energy']),
                  ('factorization_time', 'Local factorization', palette['exact_local']),
                  ('coarse_setup', 'Current coarse setup', palette['stale']),
                  ('other_setup', 'Other setup', '#d7e3e9'),
                  ('solve', 'CG solve', palette['jacobi'])]
    bar_positions, method_ticks, failures = [], [], []
    for case_index, name in enumerate(CASES):
        case = data['cases'][name]
        denominator_ok = case['methods']['lookahead']['success']
        denom = (np.mean([r['linear'] for r in case['methods']['lookahead']['repetitions']])
                 if denominator_ok else None)
        if denominator_ok and (not np.isfinite(denom) or denom <= 0):
            raise ValueError('Nonpositive lookahead normalization total')
        for method_index, method in enumerate(METHODS):
            position = case_index*(len(METHODS)+1)+method_index
            bar_positions.append(position)
            method_ticks.append(METHOD_LABELS[method_index])
            result = case['methods'][method]
            if not result['success'] or not denominator_ok:
                text = ('failed: '+str(result['failures']) if not result['success']
                        else 'LA failed')
                b.text(position, .025, text, transform=b.get_xaxis_transform(),
                       rotation=90, ha='center', va='bottom', fontsize=7.2,
                       color=palette['fresh'])
                failures.append(dict(case=name, method=method,
                                     failures=result['failures'],
                                     denominator_success=bool(denominator_ok)))
                continue
            records = result['repetitions']
            bottom = 0.
            for key, _, color in components:
                values = np.asarray([r[key] for r in records], dtype=float)/denom
                # The summary validated additive record-level scopes. Means add;
                # component medians would not generally add to the median total.
                height = float(np.mean(values))
                if height < 0:
                    # Only a negligible subtraction remainder can reach this
                    # branch after the validation tolerance; retain it as zero.
                    if key != 'other_setup' or abs(height) > 1e-10:
                        raise ValueError('Negative plotted time component')
                    height = 0.
                b.bar(position, height, bottom=bottom, width=.76,
                      color=color, edgecolor='white', linewidth=.35, zorder=3)
                bottom += height
            totals = np.asarray([r['linear'] for r in records], dtype=float)/denom
            b.vlines(position, totals.min(), totals.max(), color=palette['fresh'],
                     lw=.9, zorder=4)
            b.hlines([totals.min(), totals.max()], position-.12, position+.12,
                     color=palette['fresh'], lw=.8, zorder=4)
            b.plot(position, totals.mean(), '_', color=palette['fresh'], ms=5, zorder=5)
        b.text(case_index*(len(METHODS)+1)+(len(METHODS)-1)/2, -.35,
               CASE_LABELS[case_index].replace('\n', ' / '),
               transform=b.get_xaxis_transform(), ha='center', va='top', fontsize=7)
    b.axhline(1, color=palette['fresh'], ls=':', lw=.8)
    b.set_xticks(bar_positions, method_ticks, rotation=48, ha='right', fontsize=7.2)
    b.set_xlim(-.6, (len(CASES)-1)*(len(METHODS)+1)+len(METHODS)-.4)
    b.set_ylim(bottom=0)
    b.set_ylabel('Mean component time /\nmean lookahead linear time', fontsize=7.5)
    fig.legend(handles=[Patch(facecolor=color, label=label) for _, label, color in components],
               loc='lower center', bbox_to_anchor=(.54, .008), ncol=3, fontsize=7.2)
    total_failures = sum(data['cases'][name]['methods'][method]['failures']
                         for name in CASES for method in METHODS)
    fig.text(.12, .10, 'LA = lookahead; Timed = measured-cost. All four policies measured in the same batch.',
             fontsize=7.2, color=palette['fresh'])
    fig.text(.12, .075, 'Three complete repetitions; ranges are observed minima-maxima. '
             f'Failed solve records: {total_failures}.', fontsize=7.2, color=palette['fresh'])
    output.mkdir(parents=True, exist_ok=True)
    files = []
    for extension in ('pdf', 'svg', 'png'):
        path = output/('19_cost_stopping.'+extension)
        fig.savefig(path, dpi=300, bbox_inches=None, facecolor='white')
        files.append(path.name)
    plt.close(fig)
    record = dict(figure='19_cost_stopping', files=files, width_mm=WIDTH_MM,
                  png_dpi=300, summary_file=str(source), summary_sha256=digest(source),
                  renderer_sha256=digest(Path(__file__)),
                  shared_helper_sha256=digest(ROOT/'audit_figures.py'),
                  palette_sha256=digest(ROOT/'figures.py'),
                  plotted_cases=list(CASES), methods=list(METHODS),
                  numerator='energy, progressive or cost', denominator='lookahead',
                  ratio_statistic='ratio of median complete-sequence totals',
                  ratio_ranges='minimum and maximum paired repetition ratios',
                  stack_statistic='means of per-repetition additive components',
                  stack_denominator='case-wise mean lookahead linear total',
                  suppressed_failure_comparisons=failures,
                  data=data)
    (output/'cost_figure_manifest.json').write_text(
        json.dumps(record, indent=2, allow_nan=False)+'\n')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timings-finished', action='store_true')
    parser.add_argument('--summary', type=Path, default=ROOT/'results/cost_summary.json')
    parser.add_argument('--output-dir', type=Path, default=ROOT/'figures')
    args = parser.parse_args(argv)
    if not args.timings_finished:
        parser.error('Wait for all timing jobs to finish, then use --timings-finished')
    data = load_summary(args.summary)
    np, plt = plotting_runtime()
    draw(data, args.summary, args.output_dir, np, plt)
    from .cost_dynamics import render_cost_dynamics
    render_cost_dynamics(np, plt, summary_path=args.summary,
                         raw_dir=args.summary.parent, output_dir=args.output_dir)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
