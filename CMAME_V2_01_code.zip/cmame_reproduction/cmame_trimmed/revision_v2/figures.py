"""Publication figures from frozen measurements and stated analytic formulas."""
import json,csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .campaign import CASES,METHODS
from .analyze import LABELS
ROOT=Path(__file__).resolve().parent;F=ROOT/'figures';F.mkdir(exist_ok=True)
WIDTH=180/25.4
COL={'progressive':'#087f8c','energy':'#527eab','fresh':'#273d50','exact_local':'#c9983e','stale':'#a8afb4','jacobi':'#94699c'}
LAB={'progressive':'Progressive','energy':'Fixed power 2','fresh':'Fresh Schwarz','exact_local':'Exact local','stale':'Stale reuse','jacobi':'Jacobi'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.labelsize':8.5,'axes.titlesize':10,'legend.fontsize':7.5,'xtick.labelsize':8,'ytick.labelsize':8,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'savefig.dpi':300,'figure.facecolor':'white'})
MANIFEST=[]
def load(name):return json.loads((ROOT/'results'/(name+'.json')).read_text())
def save(fig,name,source):
 for ext in ['pdf','svg','png']:fig.savefig(F/(name+'.'+ext),bbox_inches=None)
 plt.close(fig);MANIFEST.append([name,source,'Python/matplotlib','PDF+SVG; PNG 300 dpi'])
def panel(ax,label,title):
 ax.set_title(title,loc='left',pad=11);ax.text(-.12,1.045,label,transform=ax.transAxes,fontweight='bold',fontsize=12);ax.grid(axis='y',lw=.5,color='#e5e9ec',zorder=0)
def legend(ax,**kw):ax.legend(frameon=False,**kw)
def sequence_costs():
 fig,axs=plt.subplots(2,2,figsize=(WIDTH,5.7),gridspec_kw={'height_ratios':[1.2,1]},layout='constrained')
 for j,name in enumerate(['cubic_long','quartic_long']):
  rows=load('sequence_'+name)['rows'];ax=axs[0,j]
  for m in METHODS:
   lines=np.array([np.cumsum([r['linear'] for r in sorted([r for r in rows if r['method']==m and r['repeat']==rep],key=lambda r:r['step'])]) for rep in range(3)])
   x=np.arange(1,lines.shape[1]+1);ax.plot(x,np.median(lines,axis=0),color=COL[m],lw=1.6 if m=='progressive' else 1.1,label=LAB[m]);ax.fill_between(x,lines.min(axis=0),lines.max(axis=0),color=COL[m],alpha=.10,lw=0)
  panel(ax,'ab'[j],LABELS[name]);ax.set(xlabel='Geometry query (cold start included)',ylabel='Cumulative setup + solve (s)')
  if j==0:legend(ax,ncol=2,loc='upper left')
  ax=axs[1,j];bottom=np.zeros(6);components=['factorization','screening','coarse','other setup','solve'];colors=['#40576b','#69aeb2','#abb8c3','#e4d5b5','#d7e3e9']
  for key,color in zip(components,colors):
   vals=[]
   for m in METHODS:
    r=[r for r in rows if r['method']==m]
    def value(z):
     f=z.get('stat_factorization_time',0);s=z.get('stat_randomized_time',0);c=z['coarse_setup']
     return {'factorization':f,'screening':s,'coarse':c,'other setup':z['setup']-f-s-c,'solve':z['solve']}[key]
    vals.append(sum(value(z) for z in r)/3)
   ax.bar(range(6),vals,bottom=bottom,color=color,edgecolor='white',linewidth=.35,label=key,zorder=3);bottom+=vals
  totals=np.array([[sum(r['linear'] for r in rows if r['method']==m and r['repeat']==rep) for rep in range(3)] for m in METHODS]);ax.errorbar(range(6),totals.mean(axis=1),yerr=np.array([totals.mean(axis=1)-totals.min(axis=1),totals.max(axis=1)-totals.mean(axis=1)]),fmt='none',ecolor='#273d50',capsize=2,lw=.7,zorder=4)
  ax.set_xticks(range(6),['Fresh','Exact','Fixed','Progr.','Stale','Jacobi'],rotation=32,ha='right');ax.set_ylabel('Mean sequence time (s)');panel(ax,'cd'[j],'Sequence cost components')
  if j==0:legend(ax,ncol=2,loc='upper right',fontsize=7.2)
 save(fig,'12_sequence_costs','sequence_cubic_long.json; sequence_quartic_long.json; three complete repetitions')

def campaign_comparison():
 summary=load('summary');fig,axs=plt.subplots(2,2,figsize=(WIDTH,5.3),layout='constrained');order=['fresh','exact_local','energy','progressive','stale','jacobi']
 for ax,(name,c),letter in zip(axs.flat,summary['cases'].items(),'abcd'):
  panel(ax,letter,LABELS[name]);ax.grid(False);ax.grid(axis='x',lw=.5,color='#e5e9ec');ax.axvline(1,color='#7a8a95',ls='--',lw=.8)
  for y,m in enumerate(order):
   if m not in c['ratios']:
    ax.text(.05,y,'failed: '+str(c['methods'][m]['failures']),color=COL[m],transform=ax.get_yaxis_transform(),fontsize=8);continue
   for metric,dy,filled in [('linear',-.12,True),('total',.12,False)]:
    a=c['ratios'][m][metric];x=a['ratio_of_medians'];ax.plot([a['minimum'],a['maximum']],[y+dy,y+dy],color=COL[m],lw=1);ax.plot(x,y+dy,'o',ms=5,color=COL[m],mfc=COL[m] if filled else 'white',mew=1)
  ax.set_yticks(range(6),[LAB[m] for m in order]);ax.set_ylim(5.5,-.5);ax.set_xlabel('Baseline / progressive time');ax.set_xlim(left=0)
 axs[1,1].plot([],[],'o',color='#273d50',label='Setup + solve');axs[1,1].plot([],[],'o',mfc='white',color='#273d50',label='With assembly');legend(axs[1,1],loc='lower right',fontsize=7)
 save(fig,'13_campaign_comparison','summary.json; ratios of median complete sequence totals; paired min-max ranges')

def crossover():
 rows=load('kernel_formal')['rows'];fig,axs=plt.subplots(1,3,figsize=(WIDTH,2.9),layout='constrained')
 for ax,dt,letter in zip(axs,[.00005,.0005,.005],'abc'):
  for m in ['fresh','fixed12x2','progressive']:
   rr=[r for r in rows if r['increment']==dt and r['method']==m];sizes=sorted({r['size'] for r in rr});values=np.array([[r['seconds'] for r in rr if r['size']==n] for n in sizes]);col=COL['energy' if m=='fixed12x2' else m];label='Fixed power 2' if m=='fixed12x2' else LAB[m]
   ax.loglog(sizes,np.median(values,axis=1),'o-',ms=3,lw=1.3,color=col,label=label);ax.fill_between(sizes,values.min(axis=1),values.max(axis=1),color=col,alpha=.13,lw=0)
  mantissa,exponent=format(dt,'.0e').split('e');panel(ax,letter,r'$\Delta x='+mantissa+r'\times10^{'+str(int(exponent))+'}$');ax.set(xlabel='Local block dimension',ylabel='Screen + required factor (s)');ax.set_xticks([64,256,1024,2700],['64','256','1024','2700']);ax.grid(which='major',axis='both',color='#e5e9ec',lw=.5)
 legend(axs[0],loc='upper left',fontsize=7)
 save(fig,'14_kernel_crossover','kernel_formal.json; five repeats, all rejection/refactorization work included')

def stopping():
 s=load('summary');fig,axs=plt.subplots(1,2,figsize=(WIDTH,2.9),layout='constrained');names=list(s['cases']);colors=['#c9e7e5','#94cbc8','#5babae','#268c96','#146977','#163f55']
 bottoms=np.zeros(4)
 for q,col in zip(range(1,7),colors):
  counts=np.array([sum(r['power_histogram'][str(q)] for r in s['cases'][name]['methods']['progressive']['repetitions']) for name in names]);checks=np.array([sum(r['randomized_checks'] for r in s['cases'][name]['methods']['progressive']['repetitions']) for name in names]);fraction=counts/np.maximum(checks,1);axs[0].bar(range(4),fraction,bottom=bottoms,color=col,label=str(q),edgecolor='white',linewidth=.4);bottoms+=fraction
 axs[0].set(ylabel='Fraction of progressive checks',ylim=(0,1.04));panel(axs[0],'a','Stopping-power distribution');legend(axs[0],ncol=6,loc='upper center',bbox_to_anchor=(.5,1.06),fontsize=7)
 for j,m in enumerate(['energy','progressive']):
  vals=[np.mean([r['randomized_checks']*24 if m=='energy' else r['screen_column_actions'] for r in s['cases'][name]['methods'][m]['repetitions']]) for name in names]
  axs[1].bar(np.arange(4)+(j-.5)*.32,vals,width=.32,color=COL[m],label=LAB[m])
 axs[1].set_ylim(0,axs[1].get_ylim()[1]*1.25)
 panel(axs[1],'b','Total Gaussian vector actions');axs[1].set_ylabel('Actions per complete sequence');legend(axs[1],loc='upper left')
 for ax in axs:ax.set_xticks(range(4),['Cubic','Quartic','Quintic','Refined'],rotation=25,ha='right')
 save(fig,'18_stopping_work','summary.json; all three repetitions; no work omitted for rejected screens')

def main():
 sequence_costs();campaign_comparison();crossover();stopping()
 with (F/'manifest.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['figure','source','backend','export']);w.writerows(MANIFEST)
if __name__=='__main__':main()
