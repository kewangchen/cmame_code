"""Optional measured-anchor-cost stopping for the same Gaussian screen.

Separate experimental policy; frozen campaign sources remain unchanged.
The measured limit is soft: inconclusive screens preserve two powers (or the
dimension cap), then an action may overshoot the limit before cost is observed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from types import FunctionType

import numpy as np
from scipy import linalg

from cmame_trimmed.src import preconditioners as baseline
from .screening import (ProgressiveEnergyBudget, _COUNTERS,
                        _finite_exp, _normalize_columns)


@dataclass
class TimedLocalFactor(baseline.LocalFactor):
    """Original factor arithmetic, plus its measured creation time.

    dataclasses.replace preserves this field when anchor metadata changes.
    The original builder creates singleton factors directly as a batch: they
    have zero individual timing allowance, while the required power floor
    still applies if a caller enables screening on singleton blocks.
    """
    factor_seconds: float = 0.

    def __post_init__(self):
        _valid_factor_seconds(self.factor_seconds)

    @classmethod
    def factor(cls, h, diagnostics=False):
        started = perf_counter()
        result = super().factor(h, diagnostics=diagnostics)
        elapsed = perf_counter()-started
        _valid_factor_seconds(elapsed)
        result.factor_seconds = elapsed
        return result


def _valid_factor_seconds(value):
    if (isinstance(value, (bool, np.bool_))
            or not isinstance(value, (int, float, np.integer, np.floating))
            or not np.isfinite(value) or value < 0):
        raise ValueError('factor_seconds must be finite and nonnegative')


@dataclass(frozen=True)
class CostEnergyBudget(ProgressiveEnergyBudget):
    """Immutable cost policy with the original sequence probability budget.

    rho=.25 is a predeclared workload fraction, not a calibrated speed claim.
    The threshold uses the retained anchor's historical factor creation time.
    """
    rho: float = .25
    timing_cap_checks: int = field(default=0, init=False)
    timing_cap_avoided_action_batches: int = field(default=0, init=False)
    measured_screen_seconds: float = field(default=0., init=False)
    last_screen_seconds: float = field(default=0., init=False)
    last_time_allowance: float = field(default=0., init=False)
    last_anchor_factor_seconds: float = field(default=0., init=False)
    timing_cap_histogram: dict = field(default_factory=dict, init=False, repr=False, compare=False)

    def __post_init__(self):
        if (isinstance(self.rho, (bool, np.bool_))
                or not isinstance(self.rho, (int, float, np.integer, np.floating))
                or not np.isfinite(self.rho) or self.rho <= 0):
            raise ValueError('rho must be finite and strictly positive')
        super().__post_init__()


def cost_progressive_bound(factor, change, state, tau=.2, validate=True):
    """Same Gaussian upper/lower estimates, with optional timing truncation.

    Accept/reject decisions take precedence. The timing cap cannot truncate
    before min(2,q_eff) powers. Thereafter, stop if elapsed >= rho*anchor_cost.
    Every stopping time is covered by the same all-powers small-ball event.
    A returned estimate above tau requests a fresh factor, as usual.
    """
    if not isinstance(state, CostEnergyBudget):
        raise TypeError('state must be a CostEnergyBudget')
    if not isinstance(factor, TimedLocalFactor):
        raise TypeError('TimedLocalFactor required; start a separate cost-policy cache')
    _valid_factor_seconds(factor.factor_seconds)
    allowance = float(state.rho)*float(factor.factor_seconds)
    if not np.isfinite(allowance):
        raise FloatingPointError('Nonfinite measured screen allowance')
    dimension = len(factor.scale)
    if validate:
        if not np.isfinite(tau) or not 0 <= tau < 1:
            raise ValueError('tau must be finite and in [0, 1)')
        change = np.asarray(change, dtype=float)
        if change.shape != (dimension, dimension) or not np.all(np.isfinite(change)):
            raise ValueError('change must be a finite square matrix matching the factor')
        symmetry = np.max(np.abs(change-change.T), initial=0.)
        if symmetry > 64*np.finfo(float).eps*max(1., np.max(np.abs(change), initial=0.)):
            raise ValueError('change must be symmetric to floating-point tolerance')

    effective_power = state.effective_power(dimension)
    floor = min(2, effective_power)
    object.__setattr__(state, 'last_time_allowance', allowance)
    object.__setattr__(state, 'last_anchor_factor_seconds', factor.factor_seconds)
    started = perf_counter()
    # Draw exactly one independent block and spend one candidate allocation.
    vectors, log_alpha = state.draw(dimension)
    object.__setattr__(state, 'last_effective_power', effective_power)
    state.effective_power_histogram[effective_power] = state.effective_power_histogram.get(effective_power, 0)+1
    if effective_power < state.power:
        state._increment('cost_capped_checks')
        state._increment('cost_cap_avoided_action_batches', state.power-effective_power)
    _, log_initial_lengths = _normalize_columns(vectors)
    log_magnitudes = np.zeros(state.probes)
    try:
        with np.errstate(over='raise', invalid='raise', divide='raise'):
            for power in range(1, effective_power+1):
                state._increment('action_batches')
                state._increment('column_actions', state.probes)
                if dimension == 1:
                    action = change@vectors
                else:
                    intermediate = linalg.solve_triangular(factor.cholesky, vectors, lower=True,
                                                           trans='T', check_finite=False)
                    action = linalg.solve_triangular(factor.cholesky, change@intermediate,
                                                    lower=True, check_finite=False)
                if not np.all(np.isfinite(action)):
                    raise FloatingPointError('Nonfinite cost-aware energy action')
                vectors, log_lengths = _normalize_columns(action)
                log_magnitudes += log_lengths
                input_lengths = log_initial_lengths if power == 1 else np.zeros(state.probes)
                log_local_lower = float(np.max(log_lengths-input_lengths))
                log_power_lower = float(np.max(log_magnitudes-log_initial_lengths))/power
                lower = _finite_exp(max(log_local_lower, log_power_lower), 'energy lower bound')
                object.__setattr__(state, 'last_lower_bound', lower)
                bound = _finite_exp((log_alpha+float(np.max(log_magnitudes)))/power,
                                    'cost-aware energy bound')
                elapsed = perf_counter()-started
                if not np.isfinite(elapsed) or elapsed < 0:
                    raise FloatingPointError('Invalid monotonic screen time')
                lower_rejection = lower > tau
                accepted = bound <= tau and not lower_rejection
                # Mathematical decisions and the configured dimension cap take
                # precedence over timing. Timing never creates an acceptance.
                if accepted or lower_rejection or power == effective_power:
                    state._finish(power, accepted, lower_rejection, effective_power)
                    return max(bound, lower) if lower_rejection else bound
                if power >= floor and elapsed >= allowance:
                    state._increment('timing_cap_checks')
                    state._increment('timing_cap_avoided_action_batches', effective_power-power)
                    state.timing_cap_histogram[power] = state.timing_cap_histogram.get(power, 0)+1
                    # Do not mislabel timing truncation as early acceptance or
                    # deterministic rejection. Its saved actions are separate.
                    state._finish(power, False, False, power)
                    return bound
    finally:
        elapsed = perf_counter()-started
        if not np.isfinite(elapsed) or elapsed < 0:
            raise FloatingPointError('Invalid monotonic screen time')
        object.__setattr__(state, 'last_screen_seconds', elapsed)
        object.__setattr__(state, 'measured_screen_seconds', state.measured_screen_seconds+elapsed)
    raise AssertionError('positive effective power must terminate')


_COST_COUNTERS = _COUNTERS + ('timing_cap_checks', 'timing_cap_avoided_action_batches',
                             'measured_screen_seconds')


def build_cost_schwarz(A_csr, blocks, global_ids, mode='prob_energy', cache=None,
                      tau=.2, step=0, period=5, diagnostics=False,
                      changed_global_ids=None, spectral_cap=32, probability_state=None):
    """Original builder with measured factors and isolated cost-aware callback.

    Use a separate cache for this policy. Neither the baseline module nor
    existing frozen progressive code is patched or modified. Existing matrix,
    factor and parameter validation is retained; internal callback validation
    skips only redundant matrix scans, as in the frozen progressive adapter.
    """
    if mode == 'prob_energy' and not isinstance(probability_state, CostEnergyBudget):
        raise TypeError('prob_energy requires a CostEnergyBudget')
    if cache is not None and any(not isinstance(factor, TimedLocalFactor) for factor in cache.values()):
        raise TypeError('Use a separate cache of TimedLocalFactor anchors')
    state = probability_state
    before = {name: getattr(state, name, 0) for name in _COST_COUNTERS}
    histogram_names = ('power_histogram', 'effective_power_histogram', 'timing_cap_histogram')
    histograms_before = {name: dict(getattr(state, name, {})) for name in histogram_names}
    max_lower = [0.]
    anchor_seconds = [0.]
    time_allowance = [0.]

    def callback(factor, change, budget):
        bound = cost_progressive_bound(factor, change, budget, tau=tau, validate=False)
        max_lower[0] = max(max_lower[0], budget.last_lower_bound)
        anchor_seconds[0] += budget.last_anchor_factor_seconds
        time_allowance[0] += budget.last_time_allowance
        return bound

    namespace = dict(baseline.build_schwarz.__globals__)
    namespace['LocalFactor'] = TimedLocalFactor
    namespace['_probabilistic_bound'] = callback
    builder = FunctionType(baseline.build_schwarz.__code__, namespace,
                           'build_cost_schwarz_core', baseline.build_schwarz.__defaults__,
                           baseline.build_schwarz.__closure__)
    op, current, stats = builder(A_csr, blocks, global_ids, mode=mode, cache=cache,
                                tau=tau, step=step, period=period, diagnostics=diagnostics,
                                changed_global_ids=changed_global_ids, spectral_cap=spectral_cap,
                                probability_state=state)
    for name in _COST_COUNTERS:
        after = getattr(state, name, 0)
        stats['screen_'+name] = after-before[name]
        stats['cumulative_screen_'+name] = after
    for name in histogram_names:
        stats['screen_'+name] = {str(q): count-histograms_before[name].get(q, 0)
                                for q, count in getattr(state, name, {}).items()
                                if count != histograms_before[name].get(q, 0)}
    stats.update(screen_dimension_cost_cap=getattr(state, 'dimension_cost_cap', False),
                 screen_max_lower_bound=max_lower[0],
                 screen_anchor_factor_seconds_sum=anchor_seconds[0],
                 screen_time_allowance_sum=time_allowance[0],
                 screen_rho=getattr(state, 'rho', None),
                 screen_kind='progressive_measured_anchor_cost')
    return op, current, stats
