"""Second CMAME revision; original benchmark implementation remains frozen."""
