"""Create compact, source/data-separated CMAME revision delivery after QA."""
import json,shutil,hashlib,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent;WORK=OLD.parent
DEST=WORK/'delivery/CMAME_Trimmed_Reuse_V2_2026_10_16'

def copy(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def archive(folder,target):
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(folder))
 with zipfile.ZipFile(target) as z:assert z.testzip() is None
 return dict(file=target.name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest())

def run():
 if DEST.exists():raise FileExistsError('Preserve the earlier delivery: '+str(DEST))
 s=json.loads((ROOT/'results/summary.json').read_text());facts=json.loads((ROOT/'results/paper_facts.json').read_text());g=s['geometric_mean']
 cost=json.loads((ROOT/'results/cost_summary.json').read_text())
 verification=json.loads((ROOT/'results/verification.json').read_text())
 assert verification['tests_passed'] and verification['compilation_passed'] and verification['visual_review_completed']
 compiled=json.loads((ROOT/'results/compilation_evidence.json').read_text())
 assert compiled['complete'] and all(c['returncode']==0 for c in compiled['commands'])
 for relative,digest in {**compiled['inputs'],**compiled['outputs']}.items():
  assert hashlib.sha256((ROOT/'paper'/relative).read_bytes()).hexdigest()==digest, 'Compiled input/output changed: '+relative
 assert verification.get('reviewed_pdf_sha256')==compiled['outputs'], 'Visual review must identify the final compiled PDFs'
 for n in ['manuscript.pdf','supplement.pdf','cover_letter.pdf']:
  assert (ROOT/'paper'/n).exists(),n+' missing'
 for n in ['main_compile.log','supplement_compile.log','cover_compile.log']:
  assert (ROOT/'results'/n).exists(),n+' missing'
 DEST.mkdir(parents=True,exist_ok=False);sub=DEST/'01_submission';code=DEST/'02_code/cmame_reproduction';data=DEST/'03_records/cmame_reproduction'
 for n in ['manuscript.tex','manuscript.pdf','supplement.tex','supplement.pdf','cover_letter.tex','cover_letter.pdf','references.bib','highlights.txt']:
  copy(ROOT/'paper'/n,sub/n)
 # Submission figures are PDF only. Editable SVG and display PNG remain in records.
 cited_figures=set()
 for document in ('manuscript.tex','supplement.tex'):
  cited_figures.update(Path(v).name for v in re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',(ROOT/'paper'/document).read_text()))
 for name in sorted(cited_figures):
  p=ROOT/'paper/figures'/name
  if not p.suffix:p=p.with_suffix('.pdf')
  if not p.exists():raise FileNotFoundError('Cited submission figure: '+str(p))
  copy(p,sub/'figures'/p.name)
 for p in OLD.glob('*.py'):
  if not p.name.startswith('pilot'):copy(p,code/'cmame_trimmed'/p.name)
 for d in ['src','tests','docs']:
  for p in (OLD/d).rglob('*'):
   if p.is_file() and p.suffix in ['.py','.tex','.bib','.md','.txt','.json']:copy(p,code/'cmame_trimmed'/p.relative_to(OLD))
 for p in OLD.glob('*.bib'):copy(p,code/'cmame_trimmed'/p.name)
 for p in (OLD/'paper').iterdir():
  if p.is_file() and p.suffix in ['.tex','.bib']:copy(p,code/'cmame_trimmed/paper'/p.name)
 for p in ROOT.glob('*.py'):
  if not p.name.startswith('pilot'):copy(p,code/'cmame_trimmed/revision_v2'/p.name)
 for d in ['docs','tests']:
  for p in (ROOT/d).rglob('*'):
   if p.is_file() and p.suffix in ['.py','.tex','.bib','.md','.txt']:copy(p,code/'cmame_trimmed/revision_v2'/p.relative_to(ROOT))
 for base in [OLD,ROOT]:
  rel=base.relative_to(WORK)
  for d in ['results','figures']:
   for p in (base/d).rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    if any(k in str(p.relative_to(base)) for k in ['pilot','exploratory','_red.log','kernel_study.json','kernel_study.log']):continue
    if p.suffix in ['.json','.npz','.csv','.log','.py','.md','.txt','.pdf','.svg','.png']:copy(p,data/rel/p.relative_to(base))
 # Source data reproduce the original figures needed by the integrated build.
 req='numpy==1.26.2\nscipy==1.13.1\nmatplotlib==3.8.1\npytest>=7,<9\n'
 (code/'requirements.txt').write_text(req)
 instructions='''# CMAME revision reproducibility

Unzip the code archive and the records archive into the SAME directory.
Both contain `cmame_reproduction/`; their files are complementary.
Python3.9.7 was used. Install requirements in a fresh virtual environment.

```sh
python -m pip install -r requirements.txt
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
python -m pytest cmame_trimmed/tests cmame_trimmed/revision_v2/tests -q
python -m cmame_trimmed.revision_v2.analyze
python -m cmame_trimmed.revision_v2.cost_analyze
python -m cmame_trimmed.figures
python -m cmame_trimmed.revision_v2.figures
python -m cmame_trimmed.revision_v2.cost_figures --timings-finished
python -m cmame_trimmed.revision_v2.audit_figures --timings-finished
python -m cmame_trimmed.revision_v2.elastic_fields --from-records
python -m cmame_trimmed.revision_v2.build_revision
```

The plot commands regenerate figures from included measurements. They do
not rerun timing experiments. `elastic_fields --from-records` plots the
saved spline fields; omitting the flag recomputes their direct-reference
solutions and display surfaces. To repeat timings, make a separate copy
and preserve its entire `cmame_trimmed/revision_v2/results` directory under
a different name before starting with an empty results directory. This
regenerates the manifests and source snapshots for the new environment;
retaining a published manifest would retain its original environment
metadata. Run `python -m cmame_trimmed.revision_v2.campaign all`, followed
serially by `python -m cmame_trimmed.revision_v2.cost_ablation all`.
Record the new processor and memory configuration alongside those results.
Never run timed studies concurrently. Each driver refuses to overwrite its
formal records. Manifests verify frozen source hashes; new experiment code
must get a new manifest, not masquerade as the archived implementation.

Independent audit commands:
`python -m cmame_trimmed.revision_v2.kernel_study`
`python -m cmame_trimmed.revision_v2.active_audit`
`python -m cmame_trimmed.revision_v2.mechanism_audit --mode all`
Run these audits in the same fresh results tree before rebuilding a paper
from newly measured timings. Preserve previous audit records separately.

The original seven-family records and the new 3D records have separate
configurations and timing provenance. Pilots are excluded from paper claims.
The four-policy stopping-rule experiment is a disclosed follow-up study.
It adds measured-cost stopping and deterministic lookahead to the repeated
fixed-power and progressive baselines. The time scopes
exclude warm-start transfer, reference solves, validation and file output.
All unsuccessful attempts are preserved; no failed sequence is a speedup.

For LaTeX, compile the merged manuscript and supplement with a current
TeXLive/MacTeX installation providing elsarticle and its bibliography style:
`latexmk -pdf manuscript.tex` and `latexmk -pdf supplement.tex` in the
submission directory. Each document has one body source file; figures and
BibTeX remain separate. Manuscript preparation does not submit the article.
'''
 (code/'REPRODUCE.md').write_text(instructions)
 report=f'''# CMAME V2 稿件审核与交付说明

题目：{facts['title']}

## 本轮完成的实质修订

- 明确研究对象为演化裁剪样条系统的局部因子维护，并区分当前缩放、累计锚点漂移和活跃基函数变化。
- 补充同一高斯事件控制所有幂次的证明、相对于历史的条件失效界、全序列可求和风险分配，以及共同当前粗空间校正下的谱继承。
- 新增基于幂范数对数凸性的前瞻判据：无需额外矩阵作用即可预测剩余幂次无法接受，并在精确算术下保留原有截断策略的复用决策。
- 给出严格漂移裕度下的检测工作量界，并以归一化差矩阵的秩细化；累计修改支撑在固定成员条件下给出至多两倍支撑大小的秩界，未将该分析冒充为已经实现的低秩求解器。
- 给出实际 Bernstein/B-spline 的正例与反例，明确 leading-gradient independence 是渐近解释的充分条件，不是有限矩阵谱保证的前提。
- 新增四类三维弹性配置、三至五阶样条、两条50查询序列、三次完整重复；保持旧七类数据并单独报告。
- 新增实际局部矩阵的性能交叉点、三维活跃维数跨越、高阶求积及独立装配核查。正文、补充材料、图稿与源数据共同交付。

## 已完成测量的主要结果

新主实验共{s['solves']:,}次求解，最大{s['max_dofs']:,}个自由度，失败检查/异常共{s['failures']}次。所有失败均保留在原始记录中。

| 对照 | 构造+求解几何平均比值 | 加入装配后的比值 |
|---|---:|---:|
'''
 for m,label in [('fresh','完全重建'),('exact_local','精确局部更新'),('energy','固定两次幂')]:
  if m in g:report+=f"| {label} / 渐进检测 | {g[m]['linear']:.3f} | {g[m]['total']:.3f} |\n"
 report+=f"\n另外完成了独立的停止策略对照，共{cost['solves']:,}次查询求解，失败检查/异常{cost['failures']}次。该对照重新计时固定幂次、渐进检测、成本停止和前瞻检测四种策略，未与主试验跨批次拼接加速比。\n\n"
 for m,label in [('energy','固定两次幂 / 成本停止'),('progressive','渐进检测 / 成本停止')]:
  if m in cost['geometric_mean']:
   c=cost['geometric_mean'][m];report+=f"- {label}：构造加求解比值 {c['linear']:.3f}；计入装配后 {c['total']:.3f}。\n"
 for m,label in [('energy','固定两次幂 / 前瞻检测'),('progressive','渐进检测 / 前瞻检测'),('cost','成本停止 / 前瞻检测')]:
  if m in cost['geometric_mean_lookahead']:
   c=cost['geometric_mean_lookahead'][m];report+=f"- {label}：构造加求解比值 {c['linear']:.3f}；计入装配后 {c['total']:.3f}。\n"
 report+='\n比值均为标签中的前一方法时间除以后一个方法时间；大于1表示分母方法更快。逐例配对范围及未获益的情形均保留。\n'
 if 'energy' in g and g['energy']['linear'] < 1:
  report+=f"\n在新主实验中，渐进检测的构造加求解时间相对固定两次幂策略的几何平均比值为 {1/g['energy']['linear']:.3f}，即约慢 {(1/g['energy']['linear']-1)*100:.1f}%。因此，本轮结果支持相对重建策略的收益，尚不支持渐进检测整体优于固定幂次检测。\n"
 report+='''
这里是四个预先指定三维配置的等权几何平均，不能替换成“所有问题上的普遍加速”。三次重复的配对范围和逐例负结果见正文及补充表；范围不是置信区间。原七类配置的1.16/1.03结果未删除，也未与新配置混合成更有利的总体数字。

## 科学判断

理论与工程问题的关联已更清楚：给出的是“相对于指定当前 fresh Schwarz 的全序列谱质量控制”。完整时间对照区分了减少分解、增加筛选和改变 Krylov 迭代的成本；正文保留 Jacobi、stale 和固定幂次较优的情形。谱比较继承所选 fresh 构造的网格、次数与切割依赖，不能用维护保证代替基础预条件子的稳健性分析。

研究范围仍为解析裁剪域及其三维拉伸、串行线性弹性和中等规模系统。当前证据未覆盖任意三维真实CAD裁剪、多块耦合、非线性材料或成熟并行多层库。不能据此宣称解决一般大规模工业CAD求解或优于所有主流预条件子。投稿竞争力应结合这些范围和逐例结果判断，不能将格式完整等同于录用保障。

概率结论属于精确算术；数值残差、直接解和独立谱核查是浮点实现验证，不等同于外向舍入证明。原始高斯估计、Schwarz谱比较与已有因子复用工作均明确引用，未作“首次提出随机检测/自适应预条件”的优先权宣称。

接近本文维护问题的 DC-JSR 目前依据公开代码进行定位比较；尚未取得其完整论文，也未将其纳入本轮运行对照。文中据此描述可核实的代码机制，不宣称在理论或性能上全面优于该方法。相关访问记录见 `audit/jsr_related_work_audit.md`。

## 文件与作者声明

`01_submission` 含合并的正文与补充材料LaTeX/PDF、BibTeX、PDF图稿、Highlights和Cover letter。
`02_code` 和 `03_records` 为两个数值复现子文件夹，各自压缩；共同解压至同一路径即可运行。

作者信息为 Kewang Chen，南京信息工程大学数学与统计学院，kwchen@nuist.edu.cn；正文已标注通讯作者。无基金资助及无利益冲突沿用本稿已确认的信息。AI研究/代码/写作辅助使用如实披露，语言润色没有删除披露。稿件未向期刊提交。新CMAME稿的最终人工审阅、作者责任确认及独家投稿声明需由作者在实际提交时作出，未代为虚构。

本轮按 elsarticle 组织文件。期刊最新 Guide for Authors 的官方页面未能成功读取，因此不声称已逐项核实当前投稿门户字段或匿名要求；已保留完整署名版供作者终审。
'''
 report+='\n## 构建与检查记录\n\n'+verification.get('summary_zh','检查详见随包 verification.json。')+'\n'
 (DEST/'FINAL_REVIEW_zh.md').write_text(report)
 copy(ROOT/'results/verification.json',DEST/'audit/verification.json')
 copy(ROOT/'results/compilation_evidence.json',DEST/'audit/compilation_evidence.json')
 copy(ROOT/'docs/delivery_integrity_audit.md',DEST/'audit/delivery_integrity_audit.md')
 for p in [ROOT/'docs/revision_response_completed_zh.md',ROOT/'docs/venue_style_evidence.md',ROOT/'docs/campaign_review.md',ROOT/'docs/final_static_theory_audit.md',ROOT/'docs/lookahead_audit.md',ROOT/'docs/lookahead_final_static_audit.md',ROOT/'docs/locality_rank_independent_audit.md',ROOT/'docs/jsr_related_work_audit.md',ROOT/'docs/final_abstract_intro_audit.md',ROOT/'docs/cost_kernel_current_audit.md']:
  if p.exists():copy(p,DEST/'audit'/p.name)
 archives=[archive(DEST/'02_code',DEST/'CMAME_V2_01_code.zip'),archive(DEST/'03_records',DEST/'CMAME_V2_02_records.zip'),archive(sub,DEST/'CMAME_V2_submission.zip')]
 (DEST/'archives.json').write_text(json.dumps(archives,indent=2));(DEST/'README_zh.md').write_text('# CMAME V2\n\n先阅读 `FINAL_REVIEW_zh.md`。署名稿与投稿配套文件在 `01_submission`。数值代码与记录已拆成两个压缩包，解压到同一路径后按 `cmame_reproduction/REPRODUCE.md` 运行。\n\n'+ '\n'.join(f"- {a['file']}: {a['bytes']/1024/1024:.2f} MiB" for a in archives)+'\n')
 print(json.dumps(archives,indent=2))
if __name__=='__main__':run()
