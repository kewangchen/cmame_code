"""Strict, standard-library-only aggregation of the separate cost follow-up.

Requires every declared case, repetition, method and query. Failed attempts
remain visible; incomplete components become None, never zero or a speedup.
Do not run while timing jobs are active or sequence files remain incomplete.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent.parent
CASES = ('cubic_long', 'quartic_long', 'quintic', 'refined_cubic')
METHODS = ('energy', 'progressive', 'cost', 'lookahead')
REPEATS = 3
DELTA = 1e-8
BASE_TIMES = ('setup', 'solve', 'linear', 'assembly', 'total', 'coarse_setup')
ADDITIVE_COUNTERS = ('randomized_checks', 'reused_energy', 'new', 'refreshed', 'retired',
    'reused_exact', 'reused_unchanged', 'skipped_small_blocks',
    'screen_action_batches', 'screen_column_actions', 'screen_early_accepts',
    'screen_early_rejections', 'screen_lower_bound_rejections',
    'screen_avoided_action_batches', 'screen_cost_capped_checks',
    'screen_cost_cap_avoided_action_batches', 'screen_timing_cap_checks',
    'screen_timing_cap_avoided_action_batches', 'screen_lookahead_rejections',
    'screen_lookahead_avoided_action_batches', 'screen_lookahead_evaluations',
    'screen_lookahead_margin_deferrals', 'screen_lookahead_nonfinite_deferrals')
HISTOGRAMS = ('power_histogram', 'effective_power_histogram', 'timing_cap_histogram',
              'lookahead_power_histogram')
RATIO_METRICS = ('setup', 'solve', 'linear', 'assembly', 'total', 'screen_time',
                 'factorization_time', 'coarse_setup', 'iterations', 'factorizations')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(value, label, positive=False):
    require(type(value) in (int, float) and math.isfinite(value), label+' is not finite numeric data')
    require(value > 0 if positive else value >= 0, label+' is negative or zero where prohibited')
    return value


def integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, label+' is not an integer in range')
    return value


def reject_constant(value):
    raise ValueError('Nonfinite JSON constant: '+value)


def read(path):
    return json.loads(Path(path).read_text(), parse_constant=reject_constant)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def close(a, b):
    return math.isclose(a, b, rel_tol=2e-9, abs_tol=2e-9)


def checked_source(relative):
    path = Path(relative)
    require(not path.is_absolute() and '..' not in path.parts, 'Unsafe source path in manifest')
    return path


def provenance(folder):
    formal = read(folder/'formal_manifest.json')
    manifest = read(folder/'cost_ablation_manifest.json')
    require(set(formal['cases']) == set(CASES), 'Formal case coverage changed')
    require(manifest['cases'] == formal['cases'], 'Follow-up configurations differ from declared cases')
    require(manifest['methods'] == list(METHODS), 'Unexpected follow-up method identities/order')
    integer(manifest['repeats'], 'manifest repetitions', 1)
    require(manifest['repeats'] == REPEATS, 'Expected three complete repetitions')
    require(manifest['rho'] == .25 and manifest['minimum_inconclusive_powers'] == 2,
            'Measured-cost rule differs from declared quarter/floor-two policy')
    require(manifest['seed_base'] == 2026101700, 'Unexpected follow-up seeds')
    require(formal['delta_per_sequence'] == DELTA, 'Unexpected sequence probability budget')
    require(manifest['core_source_hashes'] == formal['source_hashes'], 'Core source provenance mismatch')
    for key in ('python', 'numpy', 'scipy', 'platform'):
        require(isinstance(manifest.get(key), str) and bool(manifest[key]), 'Missing runtime metadata: '+key)
    require(all(manifest.get('threads', {}).get(k) == '1' for k in
                ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')),
            'Single-thread launch metadata is missing or differs from the protocol')
    source_counts = {}
    for field, archive in (('core_source_hashes', 'formal_sources'),
                           ('added_source_hashes', 'cost_sources')):
        hashes = manifest[field]
        require(bool(hashes), 'Empty source manifest: '+field)
        for relative, expected in hashes.items():
            path = checked_source(relative)
            require(isinstance(expected, str) and len(expected) == 64, 'Invalid SHA-256 value')
            require(digest(PROJECT/path) == expected, 'Current source changed: '+relative)
            require(digest(folder/archive/path) == expected, 'Archived source changed: '+relative)
        source_counts[field] = len(hashes)
    require(set(manifest['added_source_hashes']) ==
            {'cmame_trimmed/revision_v2/cost_ablation.py',
             'cmame_trimmed/revision_v2/cost_screening.py',
             'cmame_trimmed/revision_v2/lookahead_screening.py'},
            'Unexpected added follow-up source coverage')
    return formal, manifest, source_counts


def histogram(row, key, required):
    raw = row.get('stat_screen_'+key)
    if raw is None and not required:
        return {}
    require(isinstance(raw, dict), 'Missing or invalid '+key)
    result = {}
    for q, count in raw.items():
        require(q in tuple(str(i) for i in range(1, 7)), 'Invalid power in '+key)
        integer(count, key+' count')
        result[q] = count
    return result


def normalize(row, method, cfg):
    """Validate one returned/exception row and provide uniform cost components."""
    require(type(row.get('success')) is bool, 'Missing Boolean solve success')
    integer(row.get('dofs'), 'dofs', 1)
    returned = 'linear' in row
    if not returned:
        require(not row['success'], 'A successful row has no linear timing')
        number(row.get('attempt_seconds'), 'exception attempt_seconds')
        require(isinstance(row.get('error'), str), 'Exception attempt lacks error message')
        return dict(row, components_complete=False, screen_time=None,
                    factorization_time=None, other_setup=None, factorizations=None,
                    action_count_kind='unavailable_after_exception')
    for key in BASE_TIMES:
        number(row.get(key), key, positive=key in ('linear', 'total'))
    require(close(row['linear'], row['setup']+row['solve']), 'Inconsistent linear timing')
    require(close(row['total'], row['assembly']+row['linear']), 'Inconsistent assembly-inclusive timing')
    require(row.get('tau') == .2 and row.get('width') == cfg['width'], 'Solver settings mismatch')
    require(row.get('coarse_ratio') == cfg['coarse_ratio'], 'Coarse setting mismatch')
    require(type(row.get('warm_start')) is bool, 'Missing warm-start record')
    require(type(row.get('info')) is int, 'CG info is not an integer')
    integer(row.get('iterations'), 'CG iterations')
    for key in ('residual', 'scaled_residual', 'energy_error'):
        number(row.get(key), key)
    if row['success']:
        require(row['info'] == 0 and row['residual'] <= 1e-8
                and row['scaled_residual'] <= 1e-8 and row['energy_error'] <= 1e-6,
                'A success flag contradicts accuracy diagnostics')
    screen = number(row.get('stat_randomized_time'), 'randomized_time')
    factor = number(row.get('stat_factorization_time'), 'factorization_time')
    number(row.get('stat_extraction_time'), 'extraction_time')
    other = row['setup']-screen-factor-row['coarse_setup']
    require(other >= -1e-10*max(1., row['linear']), 'Cost components exceed setup time')
    checks = integer(row.get('stat_randomized_checks'), 'randomized_checks')
    for key in ('new', 'refreshed', 'retired', 'reused_energy', 'reused_exact',
                'reused_unchanged', 'skipped_small_blocks'):
        integer(row.get('stat_'+key), key)
    accepted = number(row.get('stat_max_accepted_bound'), 'maximum accepted bound')
    require(accepted <= .2+1e-12, 'Recorded accepted bound exceeds threshold')
    cumulative = integer(row.get('stat_cumulative_checks'), 'cumulative checks')
    spent = number(row.get('stat_spent_failure_budget'), 'spent failure allocation')
    require(spent <= DELTA*(1+1e-12), 'Sequence probability allocation exceeds budget')
    expected_spending = 6*DELTA/math.pi**2*math.fsum(1/(j*j) for j in range(1, cumulative+1))
    require(math.isclose(spent, expected_spending, rel_tol=1e-10, abs_tol=1e-20),
            'Failure allocation does not match the cumulative candidate count')
    result = dict(row, components_complete=True, screen_time=screen,
                  factorization_time=factor, other_setup=other,
                  factorizations=row['stat_new']+row['stat_refreshed'])
    if method == 'energy':
        require(row.get('stat_screen_kind') is None, 'Fixed-power policy used another screen builder')
        result.update(screen_action_batches=2*checks, screen_column_actions=24*checks,
                      action_count_kind='inferred_from_fixed_two_power_policy')
        for key in ADDITIVE_COUNTERS:
            if key.startswith('screen_') and key not in result:
                result[key] = 0
        result.update({key: {} for key in HISTOGRAMS})
    else:
        require(row.get('stat_screen_dimension_cost_cap') is True, 'Dimension cap was disabled')
        expected_kind = {'cost':'progressive_measured_anchor_cost',
                         'lookahead':'progressive_secant_lookahead',
                         'progressive':'progressive_same_probe'}[method]
        require(row.get('stat_screen_kind') == expected_kind, 'Wrong screen builder routing')
        for key in ADDITIVE_COUNTERS:
            if key.startswith('screen_'):
                needed = ((not key.startswith('screen_timing_') or method == 'cost')
                          and (not key.startswith('screen_lookahead_') or method == 'lookahead'))
                result[key] = integer(row.get('stat_'+key, 0) if not needed else row.get('stat_'+key), key)
        for key in HISTOGRAMS:
            needed = (key in ('power_histogram','effective_power_histogram')
                      or key == 'timing_cap_histogram' and method == 'cost'
                      or key == 'lookahead_power_histogram' and method == 'lookahead')
            result[key] = histogram(row, key, required=needed)
        stops, caps, times, lookahead = (result[key] for key in HISTOGRAMS)
        require(sum(stops.values()) == checks and sum(caps.values()) == checks, 'Screen histogram coverage mismatch')
        actions = result['screen_action_batches']
        require(sum(int(q)*n for q, n in stops.items()) == actions, 'Action count differs from stopping histogram')
        require(result['screen_column_actions'] == 12*actions, 'Probe-column action count mismatch')
        cap_actions = sum(int(q)*n for q, n in caps.items())
        require(result['screen_cost_cap_avoided_action_batches'] == 6*checks-cap_actions,
                'Dimension cap avoided-action count mismatch')
        require(result['screen_cost_capped_checks'] == sum(n for q, n in caps.items() if int(q)<6),
                'Dimension-capped check count mismatch')
        require(6*checks-actions == result['screen_cost_cap_avoided_action_batches']
                +result['screen_avoided_action_batches']+result['screen_timing_cap_avoided_action_batches']
                +result['screen_lookahead_avoided_action_batches'],
                'Avoided actions double-counted or missing')
        require(sum(times.values()) == result['screen_timing_cap_checks'], 'Timing cap histogram mismatch')
        require(result['screen_timing_cap_checks'] <= checks, 'Too many timing-cap decisions')
        require(all(2<=int(q)<6 for q in times), 'Timing rule stopped before floor or at final cap')
        predictions = result['screen_lookahead_rejections']
        avoided = result['screen_lookahead_avoided_action_batches']
        evaluations = result['screen_lookahead_evaluations']
        require(sum(lookahead.values()) == predictions, 'Lookahead rejection histogram mismatch')
        require(predictions <= checks and predictions <= evaluations <= actions,
                'Lookahead evaluation/rejection count mismatch')
        require(all(1<=int(q)<6 for q in lookahead), 'Lookahead pruned at or beyond final cap')
        require(predictions <= avoided <= sum((6-int(q))*n for q,n in lookahead.items()),
                'Lookahead avoided-action count is inconsistent')
        require(result['screen_lookahead_margin_deferrals'] <= evaluations
                and result['screen_lookahead_nonfinite_deferrals'] <= evaluations,
                'Lookahead deferrals exceed evaluations')
        require(predictions+result['screen_lookahead_margin_deferrals']
                +result['screen_lookahead_nonfinite_deferrals'] <= evaluations,
                'Lookahead outcomes exceed prediction calls')
        if method != 'lookahead':
            require(all(result[k] == 0 for k in ADDITIVE_COUNTERS if k.startswith('screen_lookahead_'))
                    and not lookahead, 'Other policy reported lookahead work')
        if method != 'cost':
            require(result['screen_timing_cap_checks'] == 0
                    and result['screen_timing_cap_avoided_action_batches'] == 0 and not times,
                    'Other policy reported measured-cost stopping')
        if method == 'lookahead':
            require(row.get('stat_screen_lookahead_log_margin') == 1e-10,
                    'Lookahead logarithmic margin differs from the declared policy')
            require(result['screen_timing_cap_checks'] == 0
                    and result['screen_timing_cap_avoided_action_batches'] == 0,
                    'Lookahead policy unexpectedly used elapsed-time stopping')
        if method == 'cost':
            require(row.get('stat_screen_rho') == .25, 'Timing fraction differs from protocol')
            measured = number(row.get('stat_screen_measured_screen_seconds'), 'callback measured screen time')
            require(measured <= screen+max(1e-8,screen*1e-8), 'Callback time exceeds inclusive randomized timing')
            anchor = number(row.get('stat_screen_anchor_factor_seconds_sum'), 'historical anchor factor time')
            allowance = number(row.get('stat_screen_time_allowance_sum'), 'time allowance')
            require(close(allowance, .25*anchor), 'Time allowance does not match historical factor cost')
    return result


def total_if_complete(rows, key):
    values = [r.get(key) for r in rows]
    return math.fsum(values) if all(type(v) in (int, float) for v in values) else None


def aggregate_repetition(rows, repeat):
    returned = [r for r in rows if r['components_complete']]
    exceptions = [r for r in rows if not r['components_complete']]
    value = dict(repeat=repeat, success=all(r['success'] for r in rows),
                 failures=sum(not r['success'] for r in rows), queries=len(rows),
                 components_complete=not exceptions,
                 known_linear_work=math.fsum(r['linear'] for r in returned),
                 exception_attempt_work=math.fsum(r['attempt_seconds'] for r in exceptions))
    value['attempt_work'] = value['known_linear_work']+value['exception_attempt_work']
    for key in BASE_TIMES+('iterations', 'screen_time', 'factorization_time', 'other_setup', 'factorizations'):
        value[key] = total_if_complete(rows, key)
    for key in ADDITIVE_COUNTERS:
        if key.startswith('screen_'):
            values = [r.get(key) for r in rows]
        else:
            values = [r.get('stat_'+key) for r in rows]
        value[key] = sum(values) if all(type(v) is int for v in values) else None
        value['observed_'+key] = sum(v for v in values if type(v) is int)
    value['extraction_time'] = total_if_complete(rows, 'stat_extraction_time')
    for key in HISTOGRAMS:
        value[key] = ({str(q):sum(r[key].get(str(q),0) for r in returned) for q in range(1,7)}
                      if not exceptions else None)
    value['final_cumulative_checks'] = rows[-1].get('stat_cumulative_checks')
    value['final_spent_failure_budget'] = rows[-1].get('stat_spent_failure_budget')
    value['maximum_observed_cumulative_checks'] = max((r.get('stat_cumulative_checks',0) for r in rows), default=0)
    value['callback_measured_screen_seconds'] = (total_if_complete(rows, 'stat_screen_measured_screen_seconds')
                                                 if rows[0]['method']=='cost' else None)
    for key in ('lookahead_rejections', 'lookahead_avoided_action_batches'):
        value[key] = value['screen_'+key]
    return value


def describe(repetitions):
    result = {}
    for name, function in (('median', statistics.median), ('mean', statistics.mean),
                           ('minimum', min), ('maximum', max)):
        result[name] = {key: float(function([r[key] for r in repetitions]))
                       if all(type(r.get(key)) in (int, float) for r in repetitions) else None
                       for key in repetitions[0]
                       if key not in ('repeat', 'success', 'components_complete')+HISTOGRAMS}
    return result


def ratio(numerator, denominator, numerator_name, denominator_name):
    if not numerator['success'] or not denominator['success']:
        return None
    result = {}
    for metric in RATIO_METRICS:
        a, b = numerator['median'].get(metric), denominator['median'].get(metric)
        if a is None or b is None or b <= 0:
            continue
        paired_values = [(x.get(metric), y.get(metric))
                         for x, y in zip(numerator['repetitions'], denominator['repetitions'])]
        if any(x is None or y is None or y <= 0 for x,y in paired_values):
            continue
        paired = [x/y for x,y in paired_values]
        result[metric] = dict(numerator=numerator_name, denominator=denominator_name,
            ratio_of_medians=a/b, paired=paired, paired_repeats=[0,1,2],
            minimum=min(paired), maximum=max(paired))
    return result


def lookahead_equivalence(data, queries):
    """Validate untimed query-end audit coverage; retain every mismatch."""
    audits = data.get('lookahead_audits')
    expected = [(rep, step) for rep in range(3) for step in range(queries)]
    require(isinstance(audits, list) and all(isinstance(a, dict) for a in audits),
            'Missing lookahead equivalence audits')
    require([(a.get('repeat'), a.get('step')) for a in audits] == expected,
            'Lookahead audit query/repetition coverage differs')
    diagnostics = ('anchors_equal', 'solutions_equal', 'rng_states_equal',
                   'draw_counts_equal', 'factor_counts_equal')
    hashes = ('progressive_anchor_sha256', 'lookahead_anchor_sha256')
    rows = {(r['repeat'], r['step'], r['method']): r for r in data['rows']}
    result = dict(checks=len(expected), available=0, anchor_mismatches=0,
                  solution_mismatches=0, rng_mismatches=0,
                  draw_count_mismatches=0, factor_count_mismatches=0)
    count_names = ('anchor_mismatches', 'solution_mismatches', 'rng_mismatches',
                   'draw_count_mismatches', 'factor_count_mismatches')
    for audit in audits:
        require(type(audit.get('pair_available')) is bool, 'Missing audit availability')
        rep, step = audit['repeat'], audit['step']
        successful = all(rows[(rep, step, m)]['success'] for m in ('progressive', 'lookahead'))
        require(audit['pair_available'] == successful,
                'Lookahead audit availability differs from successful pair')
        if not audit['pair_available']:
            require(all(audit.get(k) is None for k in diagnostics+hashes),
                    'Unavailable lookahead pair has nonnull diagnostics')
            continue
        result['available'] += 1
        require(all(type(audit.get(k)) is bool for k in diagnostics),
                'Available lookahead audit lacks Boolean diagnostics')
        require(all(isinstance(audit.get(k), str) and len(audit[k]) == 64
                    and all(c in '0123456789abcdef' for c in audit[k]) for k in hashes),
                'Lookahead anchor hash is not lowercase SHA-256')
        require(audit['anchors_equal'] == (audit[hashes[0]] == audit[hashes[1]]),
                'Anchor equality contradicts recorded anchor hashes')
        for key, count_name in zip(diagnostics, count_names):
            result[count_name] += not audit[key]
    return result


def analyze(folder=ROOT/'results', output=None):
    folder = Path(folder)
    formal, manifest, source_counts = provenance(folder)
    result = dict(complete=False, all_success=False, cases={}, record_hashes={},
        coverage=dict(validated=False, expected_cases=list(CASES), expected_repeats=REPEATS,
                      expected_methods=list(METHODS)), manifest=manifest,
        source_validation=dict(verified=True, **source_counts),
        analysis_source_sha256=digest(__file__),
        manifest_hashes={name:digest(folder/name) for name in
                        ('formal_manifest.json','cost_ablation_manifest.json')},
        probability=dict(per_policy_sequence_delta=DELTA, policy_sequence_budgets=48,
                         whole_followup_union_bound=48*DELTA,
                         independence_across_methods_or_cases_assumed=False),
        timing_scope='linear=equilibration/local setup/current coarse+CG; '
                     'total=shared assembly+linear; transfers, references, validation and I/O excluded',
        factor_count_scope='created/refreshed block anchors, including batched singleton anchors; not Cholesky-call count')
    failures = []
    for name in CASES:
        cfg = manifest['cases'][name]
        path = folder/('cost_sequence_'+name+'.json')
        data = read(path)
        require(data.get('complete') is True, 'Incomplete follow-up case: '+name)
        require(data.get('case')==name and data.get('config')==cfg, 'Case/config mismatch: '+name)
        require(data.get('methods')==list(METHODS) and data.get('repeats')==REPEATS, 'Method/repetition mismatch')
        require(data.get('manifest')==manifest, 'Embedded provenance differs: '+name)
        count = integer(cfg['queries'], 'queries', 1)
        require(count == (50 if name in ('cubic_long','quartic_long') else 12),
                'Declared query count differs from the four-family protocol')
        expected = [(rep,step,m) for rep in range(REPEATS) for step in range(count)
                    for m in METHODS[(rep+step)%len(METHODS):]+METHODS[:(rep+step)%len(METHODS)]]
        rows = data.get('rows')
        require(isinstance(rows,list) and len(rows)==len(expected), 'Missing or extra attempts: '+name)
        identities = []
        normalized = []
        for row in rows:
            require(isinstance(row,dict), 'Invalid policy row')
            integer(row.get('repeat'),'repeat');integer(row.get('step'),'step')
            require(row.get('method') in METHODS and row.get('case')==name
                    and row.get('degree')==cfg['degree'], 'Row identity mismatch')
            identities.append((row['repeat'],row['step'],row['method']))
            normalized.append(normalize(row,row['method'],cfg))
        require(identities==expected, 'Query/method coverage or deterministic rotation mismatch: '+name)
        references = data.get('references')
        require(isinstance(references,list) and [(r.get('repeat'),r.get('step')) for r in references]
                ==[(rep,k) for rep in range(REPEATS) for k in range(count)], 'Reference coverage mismatch')
        for reference in references:
            for key in ('setup','solve','linear'):number(reference.get(key),'reference '+key)
            require(close(reference['linear'],reference['setup']+reference['solve']), 'Reference timing mismatch')
        for rep in range(REPEATS):
            for step in range(count):
                paired=[r for r in normalized if r['repeat']==rep and r['step']==step]
                require(len({r['dofs'] for r in paired})==1,'Policies used different active systems')
                assemblies=[r['assembly'] for r in paired if r['components_complete']]
                require(not assemblies or all(v==assemblies[0] for v in assemblies),'Unequal common assembly charge')
        case = dict(config=cfg, complete=True, expected_rows=len(expected), actual_rows=len(rows),
                    methods={}, ratios={}, lookahead_ratios={}, pairwise_ratios={},
                    lookahead_equivalence=lookahead_equivalence(data, count))
        for method in METHODS:
            method_rows=[r for r in normalized if r['method']==method]
            repetitions=[]
            for rep in range(REPEATS):
                sequence=[r for r in method_rows if r['repeat']==rep]
                previous_success=False;previous_checks=0;gap=False
                for row in sequence:
                    if row['components_complete']:
                        require(row['warm_start']==previous_success,'Warm start is not own prior successful solution')
                        checks=row['stat_cumulative_checks'];current=row['stat_randomized_checks']
                        require(checks>=previous_checks+current,'Cumulative check count decreased')
                        if not gap:require(checks==previous_checks+current,'Unexpected probability-state reset/gap')
                        previous_checks=checks;gap=False
                    else:
                        gap=True
                    previous_success=row['success']
                repetitions.append(aggregate_repetition(sequence,rep))
            method_result=dict(success=all(r['success'] for r in method_rows),
                failures=sum(not r['success'] for r in method_rows), repetitions=repetitions,
                action_count_kind=('inferred_fixed_two_power' if method=='energy' else 'recorded_actual_actions'),
                max_iterations=max((r.get('iterations',0) for r in method_rows),default=0),
                max_residual=max((r.get('residual',0) for r in method_rows),default=0),
                max_scaled_residual=max((r.get('scaled_residual',0) for r in method_rows),default=0),
                max_energy_error=max((r.get('energy_error',0) for r in method_rows),default=0),
                largest_block=max((r.get('stat_largest_block',0) for r in method_rows),default=0),
                nmin=min(r['dofs'] for r in method_rows),nmax=max(r['dofs'] for r in method_rows),
                **describe(repetitions))
            case['methods'][method]=method_result
            for row in method_rows:
                if not row['success']:
                    failures.append({k:row[k] for k in ('case','repeat','step','method','error','info',
                        'attempt_seconds','linear','total','residual','scaled_residual','energy_error') if k in row})
        for numerator in METHODS:
            convenience=ratio(case['methods'][numerator],case['methods']['cost'],numerator,'cost')
            if convenience is not None:case['ratios'][numerator]=convenience
            lookahead=ratio(case['methods'][numerator],case['methods']['lookahead'],numerator,'lookahead')
            if lookahead is not None:case['lookahead_ratios'][numerator]=lookahead
        for a,b in (('energy','progressive'),('energy','cost'),('progressive','cost'),
                    ('energy','lookahead'),('progressive','lookahead'),('cost','lookahead')):
            values=ratio(case['methods'][a],case['methods'][b],a,b)
            if values is not None:case['pairwise_ratios'][a+'_over_'+b]=values
        result['cases'][name]=case
        result['record_hashes'][path.name]=digest(path)
    result['geometric_mean']={}
    result['geometric_mean_lookahead']={}
    for method in METHODS:
        if all(method in case['ratios'] for case in result['cases'].values()):
            result['geometric_mean'][method]={metric:math.exp(statistics.mean(
                math.log(case['ratios'][method][metric]['ratio_of_medians'])
                for case in result['cases'].values())) for metric in ('setup','linear','total')}
        if all(method in case['lookahead_ratios'] for case in result['cases'].values()):
            result['geometric_mean_lookahead'][method]={metric:math.exp(statistics.mean(
                math.log(case['lookahead_ratios'][method][metric]['ratio_of_medians'])
                for case in result['cases'].values())) for metric in ('setup','linear','total')}
    result['lookahead_equivalence']={key:sum(case['lookahead_equivalence'][key]
        for case in result['cases'].values()) for key in next(iter(result['cases'].values()))['lookahead_equivalence']}
    expected_rows=sum(manifest['cases'][name]['queries']*REPEATS*len(METHODS) for name in CASES)
    result.update(complete=True, all_success=not failures, failures=len(failures),
                  failure_rows=failures, solves=expected_rows,
                  max_dofs=max(m['nmax'] for case in result['cases'].values() for m in case['methods'].values()))
    result['coverage'].update(validated=True, expected_rows=expected_rows, actual_rows=expected_rows,
                              cases={name:dict(expected_rows=case['expected_rows'],actual_rows=case['actual_rows'])
                                     for name,case in result['cases'].items()})
    target=Path(output) if output else folder/'cost_summary.json'
    temporary=target.with_suffix(target.suffix+'.tmp')
    temporary.write_text(json.dumps(result,indent=2,allow_nan=False));temporary.replace(target)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir',type=Path,default=ROOT/'results')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    summary=analyze(args.input_dir,args.output)
    print(json.dumps({key:summary[key] for key in ('complete','all_success','solves','failures',
                     'geometric_mean','geometric_mean_lookahead')},indent=2))
