"""Actual spline fields and reproducible rendering from checked saved records.

Default: independently assemble/solve the two current problems, save fields,
then render. --from-records: validate saved NPZ/JSON records and render only.
"""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from scipy.spatial import Delaunay
from scipy.sparse.linalg import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize,LinearSegmentedColormap
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from .campaign import CASES,geometry,freeze
from .tensor_assembly import TensorAssembler
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.solver import direct_reference
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.titlesize':10,'pdf.fonttype':42,'svg.fonttype':'none','savefig.dpi':300})

def evaluate(grid,coeff,points):
 out=[]
 for start in range(0,len(points),500):
  pts=points[start:start+500];B=[grid.splines[k](pts[:,k]) for k in range(3)]
  out.append(np.einsum('qi,qj,qk,ijkc->qc',*B,coeff,optimize=True))
 return np.concatenate(out)

def surface(geom):
 xy=np.stack(np.meshgrid(np.linspace(0,1,26),np.linspace(0,1,26),indexing='ij'),axis=-1).reshape(-1,2)
 keep=np.ones(len(xy),dtype=bool)
 for cx,cy,r in geom.holes:keep&=((xy[:,0]-cx)**2+(xy[:,1]-cy)**2)>(r+1e-5)**2
 points=[xy[keep]];theta=np.linspace(0,2*np.pi,97)[:-1]
 for cx,cy,r in geom.holes:points.append(np.c_[cx+r*np.cos(theta),cy+r*np.sin(theta)])
 xy=np.concatenate(points);tri=Delaunay(xy).simplices;centers=xy[tri].mean(axis=1);keep=np.ones(len(tri),dtype=bool)
 for cx,cy,r in geom.holes:keep&=((centers[:,0]-cx)**2+(centers[:,1]-cy)**2)>r*r
 tri=tri[keep];vertices=[];faces=[]
 def add(v,t):
  offset=sum(len(q) for q in vertices);vertices.append(v);faces.append(t+offset)
 for z in [0.,1.]:add(np.c_[xy,np.full(len(xy),z)],tri)
 def strip(v):
  # v dimensions along circumferential/linear and thickness directions.
  n,m=v.shape[:2];t=[]
  for i in range(n-1):
   for j in range(m-1):
    k=i*m+j;t.extend([[k,k+m,k+1],[k+1,k+m,k+m+1]])
  add(v.reshape(-1,3),np.asarray(t))
 z=np.linspace(0,1,9);u=np.linspace(0,1,27)
 for axis,value in [(0,0),(0,1),(1,0),(1,1)]:
  U,Z=np.meshgrid(u,z,indexing='ij');v=np.zeros(U.shape+(3,));v[:,:,axis]=value;v[:,:,1-axis]=U;v[:,:,2]=Z;strip(v)
 theta=np.linspace(0,2*np.pi,97);T,Z=np.meshgrid(theta,z,indexing='ij')
 for cx,cy,r in geom.holes:strip(np.stack([cx+r*np.cos(T),cy+r*np.sin(T),Z],axis=-1))
 return np.concatenate(vertices),np.concatenate(faces)

FIELD_CASES=('cubic_long','refined_cubic')
ARRAY_NAMES=('points','faces','displacement','ids','coefficients')


def digest(path):
 return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition,message):
 if not condition:raise ValueError(message)


def finite_scalar(value,name,positive=False):
 require(type(value) in (int,float) and np.isfinite(value),name+' must be finite numeric data')
 require(value>0 if positive else value>=0,name+' is outside the valid range')
 return value


def compute_records():
 """Independent current solves; save the arrays required by the renderer."""
 freeze();folder=ROOT/'results/field_data';folder.mkdir(parents=True,exist_ok=True);records=[]
 for name in FIELD_CASES:
  cfg=CASES[name];geom=geometry(cfg,cfg['queries']-1);grid=SplineGrid(tuple(cfg['cells']),cfg['degree']);system=TensorAssembler(grid,physics='elasticity',quadrature=12).assemble(geom);x,timing=direct_reference(system)
  full=np.zeros(grid.size*3);full[system.ids]=x;coeff=full.reshape(tuple(n+p for n,p in zip(grid.cells,grid.degrees))+(3,));points,faces=surface(geom);u=evaluate(grid,coeff,points);magnitude=np.linalg.norm(u,axis=1);scale=.16/np.max(magnitude)
  rec=dict(case=name,dofs=len(system.b),degree=cfg['degree'],query=cfg['queries']-1,display_scale=float(scale),maximum_sampled_displacement=float(magnitude.max()),physical_residual=float(np.linalg.norm(system.b-system.A@x)/np.linalg.norm(system.b)),geometry=dict(holes=geom.holes),source_sha256=digest(__file__))
  require(np.isfinite(rec['physical_residual']) and rec['physical_residual']<1e-8,'Independent field solve failed its residual check: '+name)
  arrays=dict(points=points,faces=faces,displacement=u,ids=system.ids,coefficients=x)
  path=folder/(name+'.npz');np.savez_compressed(path,**arrays)
  rec.update(record_version=1,npz_file='field_data/'+name+'.npz',npz_sha256=digest(path),
             array_shapes={key:list(value.shape) for key,value in arrays.items()},
             coefficient_max_abs=float(np.max(np.abs(x))))
  records.append(rec)
 path=ROOT/'results/elastic_fields.json';temporary=path.with_suffix('.tmp')
 temporary.write_text(json.dumps(records,indent=2,allow_nan=False));temporary.replace(path)
 return records


def validate_arrays(record,arrays):
 """Check saved shapes, indices and norms without assembly, solves or evaluation."""
 name=record['case'];cfg=CASES[name]
 require(record.get('record_version')==1,'Unsupported or missing field record version: '+name)
 require(type(record.get('dofs')) is int and record['dofs']>0,'Invalid field DOF count: '+name)
 require(record.get('degree')==cfg['degree'] and record.get('query')==cfg['queries']-1,'Field configuration mismatch: '+name)
 expected_geometry=dict(holes=[list(hole) for hole in geometry(cfg,cfg['queries']-1).holes])
 require(record.get('geometry')==expected_geometry,'Saved field geometry differs from its case: '+name)
 require(isinstance(record.get('array_shapes'),dict),'Missing saved array shapes: '+name)
 require(set(record['array_shapes'])==set(ARRAY_NAMES),'Saved shape coverage mismatch: '+name)
 for key in ARRAY_NAMES:
  value=arrays[key]
  require(list(value.shape)==record['array_shapes'][key],'Saved array shape mismatch: '+name+'/'+key)
  require(np.issubdtype(value.dtype,np.integer if key in ('faces','ids') else np.floating),'Invalid array dtype: '+name+'/'+key)
  require(np.all(np.isfinite(value)),'Nonfinite saved array: '+name+'/'+key)
 points=arrays['points'];faces=arrays['faces'];u=arrays['displacement'];ids=arrays['ids'];coeff=arrays['coefficients']
 require(points.ndim==2 and points.shape[1]==3 and len(points)>0,'Invalid point shape: '+name)
 require(u.shape==points.shape,'Displacement and point shapes differ: '+name)
 require(faces.ndim==2 and faces.shape[1]==3 and len(faces)>0,'Invalid triangle shape: '+name)
 require(np.min(faces)>=0 and np.max(faces)<len(points),'Triangle index is out of range: '+name)
 require(ids.ndim==1 and coeff.ndim==1 and len(ids)==len(coeff)==record['dofs'],'Saved coefficient count mismatch: '+name)
 background_size=int(np.prod([n+p for n,p in zip(cfg['cells'],(cfg['degree'],)*3)]))*3
 require(np.all(ids>=0) and np.all(ids<background_size) and np.all(ids[1:]>ids[:-1]),'Invalid or duplicate background IDs: '+name)
 maximum=finite_scalar(record.get('maximum_sampled_displacement'),'maximum displacement',positive=True)
 scale=finite_scalar(record.get('display_scale'),'display scale',positive=True)
 coefficient_max=finite_scalar(record.get('coefficient_max_abs'),'coefficient maximum')
 residual=finite_scalar(record.get('physical_residual'),'physical residual')
 require(residual<1e-8,'Saved field solve did not pass its residual check: '+name)
 magnitude=np.linalg.norm(u,axis=1)
 require(np.isclose(float(magnitude.max()),maximum,rtol=1e-12,atol=0.),'Displacement maximum does not match its record: '+name)
 require(np.isclose(scale,.16/maximum,rtol=1e-12,atol=0.),'Display scale does not match the saved maximum: '+name)
 require(np.isclose(float(np.max(np.abs(coeff))),coefficient_max,rtol=1e-12,atol=0.),'Coefficient maximum does not match its record: '+name)
 return points,faces,u,magnitude,record


def load_records():
 """Load authenticated saved arrays; no freeze, assembly or solver calls."""
 path=ROOT/'results/elastic_fields.json'
 require(path.is_file(),'Missing saved field records: '+str(path))
 records=json.loads(path.read_text())
 require(isinstance(records,list) and len(records)==len(FIELD_CASES),'Expected two complete field records')
 require(all(isinstance(rec,dict) for rec in records),'Invalid field record entry')
 require([rec.get('case') for rec in records]==list(FIELD_CASES),'Missing, duplicated or reordered field cases')
 items=[]
 for record in records:
  name=record['case'];relative='field_data/'+name+'.npz';npz=ROOT/'results'/relative
  require(record.get('npz_file')==relative,'Unexpected field array filename: '+name)
  require(npz.is_file(),'Missing saved field arrays: '+str(npz))
  expected=record.get('npz_sha256')
  require(isinstance(expected,str) and len(expected)==64 and digest(npz)==expected,'Field NPZ SHA-256 mismatch: '+name)
  with np.load(npz,allow_pickle=False) as archive:
   require(set(archive.files)==set(ARRAY_NAMES),'Missing or unexpected arrays in '+str(npz))
   arrays={key:archive[key] for key in ARRAY_NAMES}
  items.append(validate_arrays(record,arrays))
 return items


def render_fields(items):
 """Render validated saved fields with the original plot design."""
 cmap=LinearSegmentedColormap.from_list('elastic',['#e9f1e8','#a6cece','#5b9db0','#245470']);normal=Normalize(0,max(v[3].max() for v in items));fig=plt.figure(figsize=(180/25.4,3.6));axs=[]
 for i,(points,faces,u,magnitude,rec) in enumerate(items):
  ax=fig.add_subplot(1,2,i+1,projection='3d');axs.append(ax);v=points+rec['display_scale']*u
  poly=Poly3DCollection(v[faces],facecolors=cmap(normal(magnitude[faces].mean(axis=1))),edgecolors='none',linewidth=0,rasterized=True);ax.add_collection3d(poly)
  # Fixed-face outline in a muted accent. Reference cube edges stay visible.
  for z in [0,1]:
   ax.plot([0,0],[0,1],[z,z],color='#9f4457',lw=1.3)
  for y in [0,1]:ax.plot([0,0],[y,y],[0,1],color='#9f4457',lw=1.3)
  for a in [0,1]:
   for b in [0,1]:ax.plot([0,1],[a,a],[b,b],color='#b6c0c5',lw=.5,ls='--',alpha=.7)
  ax.view_init(elev=22,azim=-54);lo=np.minimum(v.min(axis=0),0);hi=np.maximum(v.max(axis=0),1);mid=(lo+hi)/2;half=max(hi-lo)/2+.05;ax.set(xlim=(mid[0]-half,mid[0]+half),ylim=(mid[1]-half,mid[1]+half),zlim=(mid[2]-half,mid[2]+half));ax.set_box_aspect((1,1,1));ax.set_axis_off();title=('Single through-hole' if i==0 else 'Two moving/fixed cutouts')
  ax.set_title(chr(97+i)+'  '+title,loc='left',pad=0);ax.text2D(.05,.02,f"p={rec['degree']}; {rec['dofs']:,} free coefficients\nDisplay scale {rec['display_scale']:.4g}; clamped face in red",transform=ax.transAxes,fontsize=8)
 cb=fig.colorbar(plt.cm.ScalarMappable(norm=normal,cmap=cmap),ax=axs,orientation='horizontal',fraction=.035,pad=.10,shrink=.63);cb.set_label('Displacement norm for unit body-force density (unscaled)')
 (ROOT/'figures').mkdir(exist_ok=True)
 for ext in ['pdf','svg','png']:fig.savefig(ROOT/'figures'/('17_elastic_fields.'+ext),bbox_inches=None,dpi=300)
 plt.close(fig)


def run(from_records=False):
 if not from_records:compute_records()
 render_fields(load_records())


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--from-records',action='store_true',help='Validate saved field records and render without assembly or solving')
 args=parser.parse_args();run(from_records=args.from_records)
