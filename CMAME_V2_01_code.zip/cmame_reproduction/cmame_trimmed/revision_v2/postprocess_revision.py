"""Build analysis and figures only after every timed job has finished.

This driver does not declare visual review or publication readiness. Each
command is logged, and a failed command stops the remaining work.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
RESULTS = ROOT/'results'


def now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def save(data):
    path = RESULTS/'postprocess_status.json'
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2)+'\n')
    temp.replace(path)


def run(wait=False):
    if (RESULTS/'postprocess_status.json').exists():
        raise FileExistsError('Preserve the previous postprocessing record')
    data = dict(started_utc=now(), pid=os.getpid(), stage='waiting_for_serial_pipeline', jobs=[], complete=False)
    save(data)
    while True:
        path = RESULTS/'serial_pipeline.json'
        pipeline = json.loads(path.read_text()) if path.exists() else {}
        if pipeline.get('complete'):
            if not all(j.get('returncode') == 0 for j in pipeline['jobs']):
                raise ValueError('A pipeline job did not pass')
            break
        if pipeline.get('stage') == 'stopped_after_unsuccessful_command':
            data.update(stage='stopped_after_pipeline_failure', finished_utc=now())
            save(data)
            return 1
        if not wait:
            raise RuntimeError('Numerical pipeline has not completed')
        time.sleep(20)
    time.sleep(3)
    env = dict(os.environ)
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
        env[key] = '1'
    env['MPLCONFIGDIR'] = '/private/tmp/cmame_mpl_cache'
    env['XDG_CACHE_HOME'] = '/private/tmp/cmame_cache'
    jobs = [
        ('analyze_final', 'analyze', []),
        ('analyze_cost_final', 'cost_analyze', []),
        ('figures_final', 'figures', []),
        ('cost_figures_final', 'cost_figures', ['--timings-finished']),
        ('audit_figures_final', 'audit_figures', ['--timings-finished']),
        ('elastic_fields_final', 'elastic_fields', []),
        ('build_final', 'build_revision', []),
    ]
    for name, module, args in jobs:
        log = RESULTS/(name+'.log')
        if log.exists():
            raise FileExistsError('Refusing to overwrite '+str(log))
        record = dict(name=name, command=[sys.executable, '-m',
            'cmame_trimmed.revision_v2.'+module]+args, started_utc=now(),
            log=str(log.relative_to(WORK)))
        data['stage'] = name
        data['jobs'].append(record)
        save(data)
        print(now(), 'START', name, flush=True)
        with log.open('w') as output:
            result = subprocess.run(record['command'], cwd=WORK, env=env,
                stdout=output, stderr=subprocess.STDOUT)
        record.update(returncode=result.returncode, finished_utc=now())
        save(data)
        print(now(), 'END', name, 'returncode', result.returncode, flush=True)
        if result.returncode:
            data.update(stage='stopped_after_unsuccessful_command')
            save(data)
            return result.returncode
    data.update(stage='completed', complete=True, finished_utc=now())
    save(data)
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--wait', action='store_true')
    args = parser.parse_args()
    try:
        code=run(wait=args.wait)
    except Exception as exc:
        path=RESULTS/'postprocess_status.json'
        if path.exists():
            state=json.loads(path.read_text())
            if state.get('pid')==os.getpid():
                state.update(stage='stopped_after_orchestration_exception',error=repr(exc),finished_utc=now())
                save(state)
        raise
    raise SystemExit(code)
