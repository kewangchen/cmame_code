"""Secant lookahead for provably inconclusive capped Gaussian power screens.

For a symmetric fixed K, log(||K**q omega||) is convex in q. A secant therefore
lower-predicts every later log norm. Prune only if every remaining capped upper
estimate is predicted above tau. This is not proof that ||K|| exceeds tau.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from math import log
from types import FunctionType

import numpy as np
from scipy import linalg

from cmame_trimmed.src import preconditioners as baseline
from .screening import (ProgressiveEnergyBudget, _COUNTERS,
                        _finite_exp, _normalize_columns)


@dataclass(frozen=True)
class LookaheadEnergyBudget(ProgressiveEnergyBudget):
    """Original sequence budget plus separate capped-nonacceptance counters.

    The positive log margin scales with extrapolation/logarithm magnitudes.
    It avoids fragile comparisons; it is not an interval error certificate.
    """
    lookahead_log_margin: float = 1e-10
    lookahead_rejections: int = field(default=0, init=False)
    lookahead_avoided_action_batches: int = field(default=0, init=False)
    lookahead_evaluations: int = field(default=0, init=False)
    lookahead_margin_deferrals: int = field(default=0, init=False)
    lookahead_nonfinite_deferrals: int = field(default=0, init=False)
    lookahead_power_histogram: dict = field(default_factory=dict, init=False, repr=False, compare=False)

    def __post_init__(self):
        value = self.lookahead_log_margin
        if (isinstance(value, (bool, np.bool_))
                or not isinstance(value, (int, float, np.integer, np.floating))
                or not np.isfinite(value) or value <= 0):
            raise ValueError('lookahead_log_margin must be finite and strictly positive')
        super().__post_init__()


def _future_acceptance_impossible(current, previous, log_alpha, power,
                                  effective_power, tau, margin):
    """Return (prune, margin_deferral, nonfinite_deferral).

    Check every remaining integer power, using only finite live columns.
    Zero current columns remain zero. A malformed/nonfinite live secant causes
    fallback to the unpruned recurrence rather than an aggressive decision.
    """
    if tau <= 0 or power >= effective_power:
        return False, False, False
    current = np.asarray(current)
    previous = np.asarray(previous)
    live = current != -np.inf
    if not np.any(live):
        # The ordinary zero upper estimate has already accepted in this case.
        return False, False, False
    if (not np.isfinite(log_alpha) or not np.all(np.isfinite(current[live]))
            or not np.all(np.isfinite(previous[live]))):
        return False, False, True
    f = current[live]
    old = previous[live]
    log_tau = log(tau)
    # All remaining powers fit in a tiny horizon-by-probe array. A single
    # broadcast avoids a Python/NumPy dispatch loop at every stopping chance.
    future = np.arange(power+1, effective_power+1)[:, None]
    distance = future-power
    with np.errstate(over='ignore', invalid='ignore'):
        slope = f-old
        prediction = log_alpha+f[None, :]+distance*slope[None, :]
        threshold = future*log_tau
        scale = (1.+abs(log_alpha)+np.abs(f)[None, :]
                 +distance*(np.abs(f)+np.abs(old))[None, :]+np.abs(threshold))
        gaps = prediction-threshold
        guarded = gaps-float(margin)*scale
        if not np.all(np.isfinite(gaps)) or not np.all(np.isfinite(guarded)):
            return False, False, True
        raw_all = bool(np.all(np.max(gaps, axis=1) > 0.))
        guarded_all = bool(np.all(np.max(guarded, axis=1) > 0.))
    return guarded_all, raw_all and not guarded_all, False


def lookahead_bound(factor, change, state, tau=.2, validate=True):
    """Original progressive estimates with an extra rebuild-only lookahead.

    In exact arithmetic the capped unpruned acceptance/refresh outcome and
    accepted bound are unchanged for the same fixed input and Gaussian draw.
    Floating-point margins are conservative heuristics, not certified bounds
    on factor/solve rounding errors; computational equivalence is tested, not
    universally guaranteed. Every acceptance still uses the original test.
    """
    if not isinstance(state, LookaheadEnergyBudget):
        raise TypeError('state must be a LookaheadEnergyBudget')
    dimension = len(factor.scale)
    if validate:
        if not np.isfinite(tau) or not 0 <= tau < 1:
            raise ValueError('tau must be finite and in [0, 1)')
        change = np.asarray(change, dtype=float)
        if change.shape != (dimension, dimension) or not np.all(np.isfinite(change)):
            raise ValueError('change must be a finite square matrix matching the factor')
        symmetry = np.max(np.abs(change-change.T), initial=0.)
        if symmetry > 64*np.finfo(float).eps*max(1., np.max(np.abs(change), initial=0.)):
            raise ValueError('change must be symmetric to floating-point tolerance')

    effective_power = state.effective_power(dimension)
    vectors, log_alpha = state.draw(dimension)
    object.__setattr__(state, 'last_effective_power', effective_power)
    state.effective_power_histogram[effective_power] = state.effective_power_histogram.get(effective_power, 0)+1
    if effective_power < state.power:
        state._increment('cost_capped_checks')
        state._increment('cost_cap_avoided_action_batches', state.power-effective_power)
    _, log_initial_lengths = _normalize_columns(vectors)
    previous = log_initial_lengths.copy()
    log_magnitudes = np.zeros(state.probes)
    with np.errstate(over='raise', invalid='raise', divide='raise'):
        for power in range(1, effective_power+1):
            state._increment('action_batches')
            state._increment('column_actions', state.probes)
            if dimension == 1:
                action = change@vectors
            else:
                intermediate = linalg.solve_triangular(factor.cholesky, vectors, lower=True,
                                                       trans='T', check_finite=False)
                action = linalg.solve_triangular(factor.cholesky, change@intermediate,
                                                lower=True, check_finite=False)
            if not np.all(np.isfinite(action)):
                raise FloatingPointError('Nonfinite lookahead energy action')
            vectors, log_lengths = _normalize_columns(action)
            log_magnitudes += log_lengths
            input_lengths = log_initial_lengths if power == 1 else np.zeros(state.probes)
            log_local_lower = float(np.max(log_lengths-input_lengths))
            log_power_lower = float(np.max(log_magnitudes-log_initial_lengths))/power
            lower = _finite_exp(max(log_local_lower, log_power_lower), 'energy lower bound')
            object.__setattr__(state, 'last_lower_bound', lower)
            bound = _finite_exp((log_alpha+float(np.max(log_magnitudes)))/power,
                                'lookahead energy bound')
            lower_rejection = lower > tau
            accepted = bound <= tau and not lower_rejection
            if accepted or lower_rejection or power == effective_power:
                state._finish(power, accepted, lower_rejection, effective_power)
                return max(bound, lower) if lower_rejection else bound
            state._increment('lookahead_evaluations')
            prune, margin_deferral, nonfinite_deferral = _future_acceptance_impossible(
                log_magnitudes, previous, log_alpha, power, effective_power,
                tau, state.lookahead_log_margin)
            if margin_deferral:
                state._increment('lookahead_margin_deferrals')
            if nonfinite_deferral:
                state._increment('lookahead_nonfinite_deferrals')
            if prune:
                state._increment('lookahead_rejections')
                state._increment('lookahead_avoided_action_batches', effective_power-power)
                state.lookahead_power_histogram[power] = state.lookahead_power_histogram.get(power, 0)+1
                # Keep mathematical early stopping and lookahead work separate.
                state._finish(power, False, False, power)
                # The current beta remains an upper estimate on the common
                # event. The secant prediction is a lower predictor, not a
                # replacement upper bound or a deterministic norm violation.
                return bound
            previous = log_magnitudes.copy()
    raise AssertionError('positive effective power must terminate')


_LOOKAHEAD_COUNTERS = _COUNTERS + ('lookahead_rejections', 'lookahead_avoided_action_batches',
    'lookahead_evaluations', 'lookahead_margin_deferrals', 'lookahead_nonfinite_deferrals')


def build_lookahead_schwarz(A_csr, blocks, global_ids, mode='prob_energy', cache=None,
                           tau=.2, step=0, period=5, diagnostics=False,
                           changed_global_ids=None, spectral_cap=32, probability_state=None):
    """Frozen builder with an isolated secant-lookahead callback and counters."""
    if mode == 'prob_energy' and not isinstance(probability_state, LookaheadEnergyBudget):
        raise TypeError('prob_energy requires a LookaheadEnergyBudget')
    state = probability_state
    before = {name:getattr(state, name, 0) for name in _LOOKAHEAD_COUNTERS}
    histogram_names = ('power_histogram', 'effective_power_histogram', 'lookahead_power_histogram')
    histograms_before = {name:dict(getattr(state, name, {})) for name in histogram_names}
    max_lower = [0.]

    def callback(factor, change, budget):
        bound = lookahead_bound(factor, change, budget, tau=tau, validate=False)
        max_lower[0] = max(max_lower[0], budget.last_lower_bound)
        return bound

    namespace = dict(baseline.build_schwarz.__globals__)
    namespace['_probabilistic_bound'] = callback
    builder = FunctionType(baseline.build_schwarz.__code__, namespace,
                           'build_lookahead_schwarz_core', baseline.build_schwarz.__defaults__,
                           baseline.build_schwarz.__closure__)
    op, current, stats = builder(A_csr, blocks, global_ids, mode=mode, cache=cache,
                                tau=tau, step=step, period=period, diagnostics=diagnostics,
                                changed_global_ids=changed_global_ids, spectral_cap=spectral_cap,
                                probability_state=state)
    for name in _LOOKAHEAD_COUNTERS:
        after = getattr(state, name, 0)
        stats['screen_'+name] = after-before[name]
        stats['cumulative_screen_'+name] = after
    for name in histogram_names:
        stats['screen_'+name] = {str(q):count-histograms_before[name].get(q, 0)
                                for q, count in getattr(state, name, {}).items()
                                if count != histograms_before[name].get(q, 0)}
    stats.update(screen_dimension_cost_cap=getattr(state, 'dimension_cost_cap', False),
                 screen_max_lower_bound=max_lower[0],
                 screen_lookahead_log_margin=getattr(state, 'lookahead_log_margin', None),
                 screen_kind='progressive_secant_lookahead')
    return op, current, stats
