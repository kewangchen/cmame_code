"""Figure 20: complete paired prefix costs from the four-policy follow-up.

Figure contract: a four-panel quantitative grid reveals whether and when the
observed cumulative progressive-minus-cost balance changes sign. Each panel
contains all three complete paired repetitions and every scheduled query;
marked queries have one or more measured-time stops in the cost policy.
This is a temporal accounting comparison, not an event-level causal payoff.
T_L includes setup and CG, including the cold first query; assembly is excluded.

Authoring only while timing jobs run. After all jobs and cost_analyze finish,
call render_cost_dynamics(np, plt) after Figure 19 using its existing runtime,
or invoke this module with --timings-finished. Importing this module does not
import numerical/plotting libraries, analyzers, campaign drivers or solvers.
Exports: exactly 180 mm wide, editable PDF/SVG text and 300 dpi PNG, plus an
input-hash/coverage/curve ledger. Failed pairs are unavailable, never zero.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import statistics

from .audit_figures import digest, plotting_runtime, shared_palette

ROOT = Path(__file__).resolve().parent
CASES = ('cubic_long', 'quartic_long', 'quintic', 'refined_cubic')
METHODS = ('energy', 'progressive', 'cost', 'lookahead')
QUERIES = dict(zip(CASES, (50, 50, 12, 12)))
LABELS = {'cubic_long': 'Cubic', 'quartic_long': 'Quartic',
          'quintic': 'Quintic', 'refined_cubic': 'Refined cubic'}
TIMES = ('setup', 'solve', 'linear', 'assembly', 'total', 'coarse_setup')
WIDTH_MM = 180.0


def require(condition, message):
    if not condition:
        raise ValueError(message)


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def close(left, right):
    return finite(left) and finite(right) and math.isclose(
        left, right, rel_tol=2e-9, abs_tol=2e-9)


def reject_constant(value):
    raise ValueError('Nonfinite JSON constant: '+value)


def read_json(path):
    return json.loads(Path(path).read_text(), parse_constant=reject_constant)


def source_record(path):
    path = Path(path)
    return dict(file=str(path.resolve()), bytes=path.stat().st_size,
                sha256=digest(path))


def complete_sum(rows, key):
    values = [r.get(key) for r in rows]
    return math.fsum(values) if all(finite(v) for v in values) else None


def checked_repetition(rows, saved, repeat, label):
    require(saved.get('repeat') == repeat, 'Repetition identity differs: '+label)
    success = all(r['success'] for r in rows)
    failures = sum(not r['success'] for r in rows)
    require(saved.get('success') is success and saved.get('failures') == failures,
            'Repetition failures disagree with raw rows: '+label)
    totals = {}
    for key in TIMES:
        value = complete_sum(rows, key)
        recorded = saved.get(key)
        require((value is None and recorded is None) or close(value, recorded),
                'Repetition total differs: '+label+'/'+key)
        totals[key] = value
    attempt = math.fsum(r['linear'] if 'linear' in r else r['attempt_seconds'] for r in rows)
    require(close(saved.get('attempt_work'), attempt), 'Attempt cost differs: '+label)
    return dict(success=success, failures=failures, totals=totals)


def load_inputs(summary_path, raw_dir=None):
    """Stdlib validation only; rendering is deferred to the explicit entrypoint."""
    summary_path = Path(summary_path)
    raw_dir = Path(raw_dir) if raw_dir is not None else summary_path.parent
    summary = read_json(summary_path)
    require(summary.get('complete') is True and
            summary.get('coverage', {}).get('validated') is True,
            'Cost summary must be complete and coverage-validated')
    require(set(summary.get('cases', {})) == set(CASES), 'Expected all four follow-up families')
    require(summary.get('source_validation', {}).get('verified') is True,
            'Cost summary lacks source verification')
    manifest = summary['manifest']
    require(manifest.get('methods') == list(METHODS) and manifest.get('repeats') == 3,
            'Follow-up must contain the four declared methods and three repetitions')
    require(set(manifest.get('cases', {})) == set(CASES), 'Manifest family coverage differs')
    cases, sources = {}, dict(summary=source_record(summary_path), raw={})
    total_rows = total_failures = 0
    for name in CASES:
        path = raw_dir/('cost_sequence_'+name+'.json')
        data = read_json(path)
        require(data.get('complete') is True, 'Incomplete follow-up source: '+name)
        require(data.get('case') == name and data.get('methods') == list(METHODS)
                and data.get('repeats') == 3 and data.get('manifest') == manifest,
                'Raw follow-up identity/provenance differs: '+name)
        case = summary['cases'][name]
        cfg = manifest['cases'][name]
        count = QUERIES[name]
        require(cfg.get('queries') == count and data.get('config') == cfg
                and case.get('config') == cfg, 'Follow-up configuration differs: '+name)
        sources['raw'][name] = source_record(path)
        require(summary['record_hashes'].get(path.name) == sources['raw'][name]['sha256'],
                'Summary is stale relative to raw source: '+name)
        rows = data.get('rows')
        require(isinstance(rows, list) and all(isinstance(r, dict) for r in rows),
                'Missing policy rows: '+name)
        expected = [(rep, step, method) for rep in range(3) for step in range(count)
                    for method in METHODS[(rep+step)%4:]+METHODS[:(rep+step)%4]]
        actual = [(r.get('repeat'), r.get('step'), r.get('method')) for r in rows]
        require(actual == expected, 'Incomplete/duplicate/out-of-order method-query coverage: '+name)
        require(case.get('expected_rows') == len(expected) and case.get('actual_rows') == len(rows),
                'Summary row coverage differs: '+name)
        require(set(case.get('methods', {})) == set(METHODS), 'Summary methods differ: '+name)
        for row in rows:
            require(row.get('case') == name and type(row.get('success')) is bool,
                    'Raw row identity/outcome is invalid: '+name)
            if 'linear' not in row:
                require(not row['success'] and finite(row.get('attempt_seconds'))
                        and row['attempt_seconds'] >= 0,
                        'Exception row lacks explicit failure/attempt cost')
                continue
            require(all(finite(row.get(k)) and row[k] >= 0 for k in TIMES),
                    'Returned row lacks finite nonnegative timing')
            require(close(row['linear'], row['setup']+row['solve']) and
                    close(row['total'], row['assembly']+row['linear']), 'Timing scope differs')
            require(type(row.get('warm_start')) is bool, 'Missing warm-start provenance')
            if row['step'] == 0:
                require(row['warm_start'] is False and row.get('stat_randomized_checks') == 0,
                        'First query is not the declared cold start')
            if row['method'] == 'cost':
                value = row.get('stat_screen_timing_cap_checks')
                require(type(value) is int and value >= 0, 'Missing measured-time stop count')
        total_rows += len(rows)
        total_failures += sum(not r['success'] for r in rows)
        repetitions, grouped = {}, {}
        for method in METHODS:
            method_rows = [r for r in rows if r['method'] == method]
            saved_method = case['methods'][method]
            require(saved_method.get('success') is all(r['success'] for r in method_rows)
                    and saved_method.get('failures') == sum(not r['success'] for r in method_rows),
                    'Summary method outcome differs: '+name+'/'+method)
            saved_reps = saved_method.get('repetitions')
            require(isinstance(saved_reps, list) and
                    sorted(r.get('repeat') for r in saved_reps) == [0, 1, 2],
                    'Summary repetition coverage differs: '+name+'/'+method)
            repetitions[method], grouped[method] = {}, {}
            for rep in range(3):
                sequence = [r for r in method_rows if r['repeat'] == rep]
                saved = next(r for r in saved_reps if r['repeat'] == rep)
                label = name+'/'+method+'/'+str(rep)
                repetitions[method][rep] = checked_repetition(sequence, saved, rep, label)
                grouped[method][rep] = sequence
                if method == 'cost':
                    stops = complete_sum(sequence, 'stat_screen_timing_cap_checks')
                    require((stops is None and saved.get('screen_timing_cap_checks') is None)
                            or close(stops, saved.get('screen_timing_cap_checks')),
                            'Summary timing-stop count differs: '+label)
            for key in TIMES:
                values = [repetitions[method][rep]['totals'][key] for rep in range(3)]
                median = statistics.median(values) if all(finite(v) for v in values) else None
                require((median is None and saved_method['median'].get(key) is None)
                        or close(median, saved_method['median'].get(key)),
                        'Method median differs from raw sequences: '+name+'/'+method+'/'+key)
        curves = []
        for rep in range(3):
            prog, cost = grouped['progressive'][rep], grouped['cost'][rep]
            pstats, cstats = repetitions['progressive'][rep], repetitions['cost'][rep]
            failed = {m: [r['step']+1 for r in grouped[m][rep] if not r['success']]
                      for m in ('progressive', 'cost')}
            if not pstats['success'] or not cstats['success']:
                curves.append(dict(repeat=rep, available=False, failed_queries=failed,
                                   query=list(range(1, count+1)), balance=None, endpoint=None,
                                   time_stop_queries=None, time_stop_counts=None))
                continue
            differences = [p['linear']-c['linear'] for p, c in zip(prog, cost)]
            balance = [math.fsum(differences[:k]) for k in range(1, count+1)]
            endpoint = pstats['totals']['linear']-cstats['totals']['linear']
            require(close(balance[-1], endpoint), 'Curve endpoint differs from summary totals')
            stop_counts = [r['stat_screen_timing_cap_checks'] for r in cost]
            curves.append(dict(repeat=rep, available=True, failed_queries=failed,
                query=list(range(1, count+1)), query_difference=differences, balance=balance,
                endpoint=endpoint, progressive_linear=pstats['totals']['linear'],
                cost_linear=cstats['totals']['linear'], time_stop_counts=stop_counts,
                time_stop_queries=[k+1 for k, stops in enumerate(stop_counts) if stops > 0]))
        cases[name] = dict(queries=count, curves=curves)
    require(total_rows == 1488 and summary.get('solves') == total_rows,
            'Whole follow-up attempt coverage differs')
    require(summary.get('failures') == total_failures, 'Whole follow-up failure total differs')
    coverage = summary['coverage']
    require(coverage.get('expected_rows') == total_rows and coverage.get('actual_rows') == total_rows,
            'Whole summary coverage differs')
    return dict(cases=cases, inputs=sources, attempts=total_rows, failures=total_failures,
                all_queries_included=True, all_repetitions_included=True)


def render_cost_dynamics(np, plt, summary_path=ROOT/'results/cost_summary.json',
                         raw_dir=None, output_dir=ROOT/'figures'):
    """Use the existing Figure 19 runtime; perform no solves or fresh timing."""
    from matplotlib.lines import Line2D

    data = load_inputs(summary_path, raw_dir)
    palette = shared_palette()
    colors = (palette['progressive'], palette['energy'], palette['fresh'])
    styles = ('-', '--', ':')
    # The shared runtime sets these too; retain the export contract for callers.
    plt.rcParams.update({'pdf.fonttype': 42, 'svg.fonttype': 'none'})
    fig, axes = plt.subplots(2, 2, figsize=(WIDTH_MM/25.4, 140/25.4))
    fig.subplots_adjust(left=.105, right=.98, bottom=.19, top=.80, hspace=.58, wspace=.34)
    fig.suptitle('Cumulative cost balance across complete query sequences', y=.985, fontsize=10)
    handles = [Line2D([], [], color=colors[rep], ls=styles[rep], lw=1.4,
                      label='Repeat '+str(rep+1)) for rep in range(3)]
    handles.append(Line2D([], [], color=palette['fresh'], marker='o', ls='none',
                          ms=4, label='Time-triggered rebuild in cost'))
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.54, .94),
               ncol=2, fontsize=7)
    unavailable = []
    for ax, name, letter in zip(axes.flat, CASES, 'abcd'):
        case = data['cases'][name]
        ax.set_title(LABELS[name]+': '+str(case['queries'])+' queries', loc='left', pad=8)
        ax.text(-.14, 1.04, letter, transform=ax.transAxes, fontsize=11, fontweight='bold')
        ax.grid(axis='y', color='#e5e9ec', lw=.5, zorder=0)
        ax.axhline(0, color=palette['stale'], lw=.9, zorder=1)
        missing = []
        for curve in case['curves']:
            rep = curve['repeat']
            if not curve['available']:
                details = ', '.join(m+':'+str(len(queries)) for m, queries in
                                    curve['failed_queries'].items() if queries)
                missing.append('Repeat '+str(rep+1)+' unavailable ('+details+' failed)')
                unavailable.append(dict(case=name, **curve))
                continue
            x = np.asarray(curve['query'], dtype=int)
            y = np.asarray(curve['balance'], dtype=float)
            ax.plot(x, y, color=colors[rep], ls=styles[rep], lw=1.35, zorder=3)
            marked = np.asarray(curve['time_stop_queries'], dtype=int)
            if marked.size:
                ax.plot(marked, y[marked-1], 'o', color=colors[rep], ms=3.4,
                        markeredgecolor='white', markeredgewidth=.4, zorder=4)
        if missing:
            ax.text(.02, .03, '\n'.join(missing), transform=ax.transAxes,
                    va='bottom', fontsize=7.2, color=palette['fresh'],
                    bbox=dict(facecolor='white', edgecolor='none', alpha=.90, pad=2))
        ticks = ([1, 10, 20, 30, 40, 50] if case['queries'] == 50 else [1, 3, 6, 9, 12])
        ax.set_xticks(ticks)
        ax.set_xlim(1, case['queries'])
        ax.set_xlabel('Query (cold first query included)')
        ax.set_ylabel(r'Cumulative $\Delta T_L$ (s)')
        ax.ticklabel_format(axis='y', style='sci', scilimits=(-3, 4), useOffset=False)
    fig.text(.105, .065,
        r'$\Delta T_L(k)=\sum_{j=1}^{k}(T^{\mathrm{progressive}}_{L,j}-T^{\mathrm{cost}}_{L,j})$; '
        r'$T_L=$ setup + CG (assembly excluded).', fontsize=7)
    fig.text(.105, .028, 'Positive balance favors cost stopping. Markers locate stop queries; '
             'they do not identify a causal payoff.', fontsize=7.2, color=palette['fresh'])
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    files = []
    for extension in ('pdf', 'svg', 'png'):
        path = output/('20_cost_dynamics.'+extension)
        fig.savefig(path, dpi=300, facecolor='white', bbox_inches=None)
        files.append(path.name)
    plt.close(fig)
    record = dict(figure='20_cost_dynamics', files=files, backend='Python/matplotlib',
        width_mm=WIDTH_MM, height_mm=140.0, png_dpi=300,
        renderer=source_record(__file__), shared_helper=source_record(ROOT/'audit_figures.py'),
        shared_palette=source_record(ROOT/'figures.py'), sources=data['inputs'],
        coverage=dict(validated=True, attempts=data['attempts'], failures=data['failures'],
                      cases=list(CASES), methods=list(METHODS), repetitions=[0, 1, 2],
                      all_scheduled_queries=True, cold_first_query_included=True),
        balance='sum over queries of progressive linear minus cost linear, seconds',
        positive_favors='cost', time_scope='setup+CG; no assembly, transfers, references, audits or I/O',
        marker='one or more stat_screen_timing_cap_checks in cost at that query',
        statistics='three separate paired repetition trajectories; no median or interval',
        interpretation='descriptive prefix accounting; not causal event-level payback',
        unavailable_pairs=unavailable, curves=data['cases'])
    target = output/'cost_dynamics_manifest.json'
    temporary = target.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    temporary.replace(target)
    return record


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timings-finished', action='store_true')
    parser.add_argument('--summary', type=Path, default=ROOT/'results/cost_summary.json')
    parser.add_argument('--raw-dir', type=Path)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'figures')
    args = parser.parse_args(argv)
    if not args.timings_finished:
        parser.error('Wait for all timing jobs, then use --timings-finished')
    # Validate complete records before initializing any numerical/plot runtime.
    load_inputs(args.summary, args.raw_dir)
    np, plt = plotting_runtime()
    render_cost_dynamics(np, plt, args.summary, args.raw_dir, args.output_dir)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
