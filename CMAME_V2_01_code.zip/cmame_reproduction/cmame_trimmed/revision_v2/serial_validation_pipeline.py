"""Serial post-campaign jobs; never overlap formal timings with other work.

This orchestration file is not a benchmark implementation. It records the
commands and return codes, and stops at the first unsuccessful command.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
RESULTS = ROOT/'results'
CASES = ('cubic_long', 'quartic_long', 'quintic', 'refined_cubic')


def now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def save(data):
    p = RESULTS/'serial_pipeline.json'
    temp = p.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2)+'\n')
    temp.replace(p)


def main():
    if (RESULTS/'serial_pipeline.json').exists():
        raise FileExistsError('Preserve the previous orchestration record')
    data = dict(started_utc=now(), stage='waiting_for_formal', jobs=[], complete=False)
    save(data)
    while True:
        ready = True
        for name in CASES:
            p = RESULTS/('sequence_'+name+'.json')
            if not p.exists() or not json.loads(p.read_text()).get('complete'):
                ready = False
                break
        if ready:
            break
        time.sleep(20)
    # The completion flag is the final campaign write. Allow its process to exit.
    time.sleep(3)
    env = dict(os.environ)
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
        env[key] = '1'
    env['MPLCONFIGDIR'] = '/private/tmp/cmame_mpl_cache'
    env['XDG_CACHE_HOME'] = '/private/tmp/cmame_cache'
    jobs = [
        ('final_tests', ['-m','pytest','cmame_trimmed/tests','cmame_trimmed/revision_v2/tests','-q']),
        ('cost_ablation', ['-m','cmame_trimmed.revision_v2.cost_ablation','all']),
        ('kernel_formal', ['-m','cmame_trimmed.revision_v2.kernel_study']),
        ('active_audit', ['-m','cmame_trimmed.revision_v2.active_audit']),
        ('mechanism_quadrature', ['-m','cmame_trimmed.revision_v2.mechanism_audit','--mode','all']),
    ]
    for name, args in jobs:
        log = RESULTS/(name+'.log')
        if log.exists():
            raise FileExistsError('Refusing to overwrite log: '+str(log))
        record = dict(name=name, command=[sys.executable]+args,
                      started_utc=now(), log=str(log.relative_to(WORK)))
        data['stage'] = name
        data['jobs'].append(record)
        save(data)
        print(now(), 'START', name, flush=True)
        with log.open('w') as output:
            result = subprocess.run(record['command'], cwd=WORK, env=env,
                                    stdout=output, stderr=subprocess.STDOUT)
        record.update(returncode=result.returncode, finished_utc=now())
        save(data)
        print(now(), 'END', name, 'returncode', result.returncode, flush=True)
        if result.returncode:
            data['stage'] = 'stopped_after_unsuccessful_command'
            save(data)
            return result.returncode
    data.update(stage='completed', complete=True, finished_utc=now())
    save(data)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
