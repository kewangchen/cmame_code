"""Deterministic Chinese response from completed records; stdlib only.

Do not execute while timing jobs or required audits are incomplete. This module
never runs an analyzer, test, compiler, plotting command or archive operation.

Before packaging (archive verification is explicitly pending):
  python -m cmame_trimmed.revision_v2.response_report --stage pre-archive
After extraction/reproduction checks, regenerate alongside the archives:
  python -m cmame_trimmed.revision_v2.response_report --stage final \
    --archive-verification /path/archive_verification.json --archive-root /path

Archive record schema:
  {"complete": true,
   "checks": {"extracted": true, "tests": true,
              "figure_reproduction": true, "manuscript_rebuild": true},
   "archives": [{"file": "code.zip", "sha256": "64 hex digits", "bytes": 123}],
   "verified_utc": "recorded time", "commands": [...], "results": {...}}
The last three metadata fields are optional and retained when present. Archive
files resolve relative to --archive-root, or the record's parent directory.
False completed checks are reported as failures, never changed to success.
At least two verified archive identities are required in final mode. The final
response/ledger may live beside the archives; neither must already be inside
an archive whose hash is being checked.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

from .audit_tables import audit_facts

ROOT = Path(__file__).resolve().parent
CASES = ('cubic_long', 'quartic_long', 'quintic', 'refined_cubic')
NAMES = {'cubic_long': '三次样条长序列', 'quartic_long': '四次样条长序列',
         'quintic': '五次样条', 'refined_cubic': '加密三次样条'}
METHODS = ('fresh', 'exact_local', 'energy', 'progressive', 'stale', 'jacobi')
COST_METHODS = ('energy', 'progressive', 'cost', 'lookahead')
SLOTS = ('formal_performance', 'cost_followup', 'formal_coverage',
         'cost_decomposition', 'active_state', 'external_coarse', 'final_delivery')
TIMES = ('setup', 'solve', 'linear', 'assembly', 'total', 'coarse_setup', 'iterations')
ARCHIVE_CHECKS = ('extracted', 'tests', 'figure_reproduction', 'manuscript_rebuild')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest_bytes(payload):
    return hashlib.sha256(payload).hexdigest()


def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)


def close(a, b):
    return numeric(a) and numeric(b) and math.isclose(a, b, rel_tol=2e-9, abs_tol=1e-10)


def reject_constant(value):
    raise ValueError('Nonfinite JSON constant: '+value)


def finite_float(value):
    result = float(value)
    require(math.isfinite(result), 'Nonfinite/overflowed JSON number: '+value)
    return result


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: '+key)
        result[key] = value
    return result


class Inputs:
    def __init__(self):
        self.records = {}

    def bytes(self, name, path):
        path = Path(path).resolve()
        payload = path.read_bytes()
        item = dict(path=str(path), bytes=len(payload), sha256=digest_bytes(payload))
        require(name not in self.records or self.records[name] == item,
                'Input changed or identifier reused: '+name)
        self.records[name] = item
        return payload

    def json(self, name, path):
        data = json.loads(self.bytes(name, path), parse_constant=reject_constant, parse_float=finite_float,
                          object_pairs_hook=unique_object)
        require(isinstance(data, dict), 'Expected JSON object: '+name)
        return data


def verify_sources(inputs, hashes, code_root, snapshot, prefix):
    require(isinstance(hashes, dict) and hashes, 'Missing source hashes: '+prefix)
    for relative, expected in sorted(hashes.items()):
        require(isinstance(expected, str) and re.fullmatch('[0-9a-f]{64}', expected),
                'Invalid source SHA-256: '+relative)
        for tag, base in (('live', code_root), ('snapshot', snapshot)):
            key = prefix+':'+tag+':'+relative
            payload = inputs.bytes(key, Path(base)/relative)
            require(digest_bytes(payload) == expected, 'Source hash mismatch: '+key)


def total(rows, key):
    values = [r.get(key) for r in rows]
    return math.fsum(values) if all(numeric(v) for v in values) else None


def repetition(rows, rep, cost=False):
    failures = sum(r['success'] is False for r in rows)
    result = dict(repeat=rep, success=not failures, failures=failures,
                  attempt_work=math.fsum(r.get('linear', r.get('attempt_seconds', 0)) for r in rows))
    result.update({key: total(rows, key) for key in TIMES})
    for key in ('factorization_time', 'randomized_time', 'new', 'refreshed', 'retired'):
        result[key] = total(rows, 'stat_'+key)
    result['screen_time'] = result['randomized_time']
    for key in ('lookahead_rejections', 'lookahead_avoided_action_batches'):
        result[key] = total(rows, 'stat_screen_'+key)
    components = ('setup', 'factorization_time', 'screen_time', 'coarse_setup')
    result['other_setup'] = (result['setup']-result['factorization_time']-
                             result['screen_time']-result['coarse_setup']
                             if all(numeric(result[k]) for k in components) else None)
    return result


def check_summary_method(source_rows, summary, method, repeats=3, cost=False):
    rows = [r for r in source_rows if r['method'] == method]
    expected = [repetition([r for r in rows if r['repeat'] == rep], rep, cost)
                for rep in range(repeats)]
    require(summary['success'] == all(r['success'] for r in rows), 'Method success disagrees: '+method)
    require(summary['failures'] == sum(not r['success'] for r in rows), 'Failure count disagrees: '+method)
    require(summary['nmin'] == min(r['dofs'] for r in rows) and
            summary['nmax'] == max(r['dofs'] for r in rows), 'Active-DOF range disagrees')
    require(summary['largest_block'] == max(r.get('stat_largest_block', 0) for r in rows),
            'Largest-block dimension disagrees')
    if 'coarse_dofs' in summary:
        require(summary['coarse_dofs'] == max(r.get('coarse_dofs', 0) for r in rows),
                'Coarse dimension disagrees')
    actual = sorted(summary['repetitions'], key=lambda r: r['repeat'])
    require([r['repeat'] for r in actual] == list(range(repeats)), 'Missing repetition: '+method)
    for a, b in zip(actual, expected):
        require(a['success'] == b['success'] and a['failures'] == b['failures'],
                'Repetition outcomes disagree: '+method)
        for key in TIMES+('attempt_work',):
            require((a.get(key) is None and b[key] is None) or close(a.get(key), b[key]),
                    'Repetition aggregate disagrees: '+method+'/'+key)
        for key in ('factorization_time', 'screen_time', 'other_setup') if cost else ('factorization_time', 'randomized_time'):
            # The formal analyzer historically reports known diagnostic subtotals
            # through an exception. Do not promote them to complete phase costs.
            if b[key] is not None:
                require(close(a.get(key), b[key]), 'Phase aggregate disagrees: '+method+'/'+key)
        if cost and method == 'lookahead':
            for key in ('lookahead_rejections', 'lookahead_avoided_action_batches'):
                require((a.get(key) is None and b[key] is None) or close(a.get(key), b[key]),
                        'Lookahead counter aggregate disagrees: '+key)
        if b['success']:
            require(all(numeric(b[k]) and b[k] >= 0 for k in TIMES),
                    'Successful repetition lacks nonnegative times: '+method)
            require(close(b['linear'], b['setup']+b['solve']), 'Linear scope mismatch')
            require(close(b['total'], b['assembly']+b['linear']), 'Assembly scope mismatch')
    for key in TIMES:
        values = [r[key] for r in expected]
        if all(numeric(v) for v in values):
            require(close(summary['median'].get(key), statistics.median(values)),
                    'Median disagrees with source rows: '+method+'/'+key)
    return expected


def check_ratios(case, denominator, field='ratios'):
    for method, method_data in case['methods'].items():
        valid = method_data['success'] and case['methods'][denominator]['success']
        recorded = case.get(field, {}).get(method)
        require(valid == (recorded is not None), 'Ratio presence disagrees with failures')
        if not valid:
            continue
        for metric in ('setup', 'linear', 'total'):
            a = sorted(method_data['repetitions'], key=lambda r: r['repeat'])
            b = sorted(case['methods'][denominator]['repetitions'], key=lambda r: r['repeat'])
            require(all(numeric(y[metric]) and y[metric] > 0 for y in b), 'Nonpositive ratio denominator')
            paired = [x[metric]/y[metric] for x, y in zip(a, b)]
            saved = recorded[metric]
            if denominator in ('cost', 'lookahead'):
                require(saved.get('numerator') == method and saved.get('denominator') == denominator,
                        'Recorded ratio direction differs from its collection')
            require(len(saved['paired']) == len(paired) and
                    all(close(x, y) for x, y in zip(saved['paired'], paired)), 'Paired ratio mismatch')
            ratio = statistics.median([x[metric] for x in a])/statistics.median([y[metric] for y in b])
            require(close(saved['ratio_of_medians'], ratio) and
                    close(saved['minimum'], min(paired)) and close(saved['maximum'], max(paired)),
                    'Ratio summary mismatch')


def campaign_inputs(inputs, folder, code_root):
    manifest = inputs.json('formal_manifest', folder/'formal_manifest.json')
    summary = inputs.json('formal_summary', folder/'summary.json')
    require(set(manifest['cases']) == set(CASES) == set(summary['cases']), 'Formal case coverage differs')
    require(tuple(manifest['methods']) == METHODS and manifest['repeats'] == 3, 'Formal methods/repeats differ')
    require(manifest['probes'] == 12 and manifest['progressive_max_power'] == 6 and
            manifest['min_dimension'] == 288 and manifest['delta_per_sequence'] == 1e-8,
            'Formal policy differs from the response template')
    require(summary['source_hashes'] == manifest['source_hashes'], 'Formal summary provenance differs')
    verify_sources(inputs, manifest['source_hashes'], code_root, folder/'formal_sources', 'formal_source')
    documents, derived = {}, {}
    for name in CASES:
        filename = 'sequence_'+name+'.json'
        data = inputs.json('formal:'+name, folder/filename)
        require(data.get('complete') is True and data['config'] == manifest['cases'][name], 'Incomplete/configured formal case: '+name)
        require(data['source_hashes'] == manifest['source_hashes'], 'Formal case hashes differ')
        require(summary['record_hashes'][filename] == inputs.records['formal:'+name]['sha256'], 'Stale formal summary: '+name)
        queries = manifest['cases'][name]['queries']
        require(queries == (50 if name in CASES[:2] else 12), 'Query count differs from declaration')
        expected = {(rep, step, method) for rep in range(3) for step in range(queries) for method in METHODS}
        identities = [(r['repeat'], r['step'], r['method']) for r in data['rows']]
        require(len(identities) == len(expected) and set(identities) == expected, 'Formal identity coverage failed')
        require(all(type(r.get('success')) is bool for r in data['rows']), 'Missing formal outcome')
        require(all(numeric(r.get('linear', r.get('attempt_seconds'))) for r in data['rows']), 'Missing attempted work')
        require(len(data['references']) == 3*queries, 'Formal references incomplete')
        case = summary['cases'][name]
        require(case['config'] == data['config'] and set(case['methods']) == set(METHODS),
                'Formal summary configuration/methods disagree')
        derived[name] = {method: check_summary_method(data['rows'], case['methods'][method], method)
                         for method in METHODS}
        check_ratios(case, 'progressive')
        documents[name] = data
    require(summary['solves'] == sum(len(d['rows']) for d in documents.values()), 'Formal solve count differs')
    require(summary['failures'] == sum(not r['success'] for d in documents.values() for r in d['rows']), 'Formal failure total differs')
    return manifest, summary, documents, derived


def lookahead_equivalence(data, queries):
    """Validate untimed query-end audit coverage; retain every mismatch."""
    audits = data.get('lookahead_audits')
    expected = [(rep, step) for rep in range(3) for step in range(queries)]
    require(isinstance(audits, list) and all(isinstance(a, dict) for a in audits),
            'Missing lookahead equivalence audits')
    require([(a.get('repeat'), a.get('step')) for a in audits] == expected,
            'Lookahead audit query/repetition coverage differs')
    diagnostics = ('anchors_equal', 'solutions_equal', 'rng_states_equal',
                   'draw_counts_equal', 'factor_counts_equal')
    hashes = ('progressive_anchor_sha256', 'lookahead_anchor_sha256')
    rows = {(r['repeat'], r['step'], r['method']): r for r in data['rows']}
    result = dict(checks=len(expected), available=0, anchor_mismatches=0,
                  solution_mismatches=0, rng_mismatches=0,
                  draw_count_mismatches=0, factor_count_mismatches=0)
    count_names = ('anchor_mismatches', 'solution_mismatches', 'rng_mismatches',
                   'draw_count_mismatches', 'factor_count_mismatches')
    for audit in audits:
        require(type(audit.get('pair_available')) is bool, 'Missing audit availability')
        rep, step = audit['repeat'], audit['step']
        successful = all(rows[(rep, step, m)]['success'] for m in ('progressive', 'lookahead'))
        require(audit['pair_available'] == successful,
                'Lookahead audit availability differs from successful pair')
        if not audit['pair_available']:
            require(all(audit.get(k) is None for k in diagnostics+hashes),
                    'Unavailable lookahead pair has nonnull diagnostics')
            continue
        result['available'] += 1
        require(all(type(audit.get(k)) is bool for k in diagnostics),
                'Available lookahead audit lacks Boolean diagnostics')
        require(all(isinstance(audit.get(k), str) and len(audit[k]) == 64
                    and all(c in '0123456789abcdef' for c in audit[k]) for k in hashes),
                'Lookahead anchor hash is not lowercase SHA-256')
        require(audit['anchors_equal'] == (audit[hashes[0]] == audit[hashes[1]]),
                'Anchor equality contradicts recorded anchor hashes')
        for key, count_name in zip(diagnostics, count_names):
            result[count_name] += not audit[key]
    return result


def check_geometric_means(summary):
    for field, aggregate in (('ratios', 'geometric_mean'),
                              ('lookahead_ratios', 'geometric_mean_lookahead')):
        saved = summary[aggregate]
        for method in COST_METHODS:
            valid = all(method in summary['cases'][n][field] for n in CASES)
            require(valid == (method in saved), 'Geometric mean availability disagrees with failures')
            if not valid:
                continue
            for metric in ('setup', 'linear', 'total'):
                expected = math.exp(statistics.mean(math.log(
                    summary['cases'][n][field][method][metric]['ratio_of_medians']) for n in CASES))
                require(close(saved[method][metric], expected), 'Geometric mean differs from four-family ratios')


def cost_inputs(inputs, folder, code_root, formal_manifest):
    manifest = inputs.json('cost_manifest', folder/'cost_ablation_manifest.json')
    summary = inputs.json('cost_summary', folder/'cost_summary.json')
    require(summary.get('complete') is True and summary.get('coverage', {}).get('validated') is True,
            'Cost summary incomplete or unvalidated')
    require(set(summary['cases']) == set(CASES) and tuple(manifest['methods']) == COST_METHODS,
            'Cost family/method coverage differs')
    require(manifest['repeats'] == 3 and manifest['cases'] == formal_manifest['cases'], 'Cost configurations differ')
    require(manifest['rho'] == .25 and manifest['minimum_inconclusive_powers'] == 2,
            'Cost stopping rule differs from the response template')
    require(manifest['core_source_hashes'] == formal_manifest['source_hashes'], 'Cost core provenance differs')
    require(summary['source_validation'].get('verified') is True, 'Cost analyzer did not validate sources')
    require(set(manifest['added_source_hashes']) == {
        'cmame_trimmed/revision_v2/cost_ablation.py',
        'cmame_trimmed/revision_v2/cost_screening.py',
        'cmame_trimmed/revision_v2/lookahead_screening.py'}, 'Follow-up source coverage differs')
    require(summary['probability']['policy_sequence_budgets'] == 48
            and math.isclose(summary['probability']['whole_followup_union_bound'], 48e-8, rel_tol=1e-12, abs_tol=1e-20),
            'Four-policy follow-up probability scope differs')
    verify_sources(inputs, manifest['added_source_hashes'], code_root, folder/'cost_sources', 'cost_source')
    for filename in ('formal_manifest.json', 'cost_ablation_manifest.json'):
        key = 'formal_manifest' if filename.startswith('formal') else 'cost_manifest'
        require(summary['manifest_hashes'][filename] == inputs.records[key]['sha256'], 'Stale cost manifest hash')
    documents, derived = {}, {}
    for name in CASES:
        filename = 'cost_sequence_'+name+'.json'
        data = inputs.json('cost:'+name, folder/filename)
        require(data.get('complete') is True and data.get('manifest') == manifest, 'Incomplete/mismatched cost record')
        require(data.get('methods') == list(COST_METHODS) and data.get('repeats') == 3
                and data.get('config') == manifest['cases'][name], 'Cost source declaration differs')
        require(summary['record_hashes'][filename] == inputs.records['cost:'+name]['sha256'], 'Stale cost summary')
        require(summary['cases'][name]['config'] == data['config'] and
                set(summary['cases'][name]['methods']) == set(COST_METHODS),
                'Cost summary configuration/methods disagree')
        queries = manifest['cases'][name]['queries']
        expected = {(rep, step, method) for rep in range(3) for step in range(queries) for method in COST_METHODS}
        actual = [(r['repeat'], r['step'], r['method']) for r in data['rows']]
        require(len(actual) == len(expected) and set(actual) == expected, 'Cost query identities incomplete')
        expected_order = [(rep, step, method) for rep in range(3) for step in range(queries)
                          for method in COST_METHODS[(rep+step)%len(COST_METHODS):]+
                          COST_METHODS[:(rep+step)%len(COST_METHODS)]]
        require(actual == expected_order, 'Cost four-policy cyclic order differs')
        require(all(type(r.get('success')) is bool for r in data['rows']), 'Missing cost outcome')
        require(all(numeric(r.get('linear', r.get('attempt_seconds'))) for r in data['rows']), 'Missing cost attempted work')
        derived[name] = {method: check_summary_method(data['rows'], summary['cases'][name]['methods'][method], method, cost=True)
                         for method in COST_METHODS}
        check_ratios(summary['cases'][name], 'cost')
        check_ratios(summary['cases'][name], 'lookahead', 'lookahead_ratios')
        equivalence = lookahead_equivalence(data, queries)
        require(summary['cases'][name]['lookahead_equivalence'] == equivalence,
                'Lookahead equivalence counts differ from raw query audits')
        documents[name] = data
    combined={key:sum(summary['cases'][n]['lookahead_equivalence'][key] for n in CASES)
              for key in summary['cases'][CASES[0]]['lookahead_equivalence']}
    require(summary['lookahead_equivalence'] == combined, 'Aggregate lookahead equivalence differs')
    check_geometric_means(summary)
    require(summary['solves'] == sum(len(d['rows']) for d in documents.values()), 'Cost solve count differs')
    require(summary['failures'] == sum(not r['success'] for d in documents.values() for r in d['rows']), 'Cost failure total differs')
    return summary, documents, derived


def audit_inputs(inputs, folder, formal_manifest, code_root):
    documents = {name: inputs.json('audit:'+name, folder/(name+'_audit.json'))
                 for name in ('mechanism', 'quadrature', 'active')}
    require(all(d.get('complete') is True for d in documents.values()), 'Required audit incomplete')
    mechanism, quadrature, active = (documents[k] for k in ('mechanism', 'quadrature', 'active'))
    for name in ('mechanism', 'quadrature'):
        doc = documents[name]
        verify_sources(inputs, doc['source_hashes'], code_root,
                       folder/doc['source_snapshot'], 'audit_source:'+name)
    require(active['provenance']['frozen_core_hashes'] == formal_manifest['source_hashes'],
            'Active-audit core hashes differ')
    for relative, sha in active['provenance']['own_source'].items():
        live = inputs.bytes('active_source:live:'+relative, code_root/relative)
        snapshot = inputs.bytes('active_source:snapshot:'+relative, folder/'active_audit_source.py')
        require(digest_bytes(live) == sha == digest_bytes(snapshot), 'Active-audit source changed')
    expected = {(f, str(e)) for f in ('positive', 'counterexample') for e in mechanism['epsilon_values']}
    actual = [(r['family'], str(r['epsilon'])) for r in mechanism['rows']]
    # Float spelling can differ from the declared decimal string; compare values.
    require(len(actual) == len(expected) and
            {(f, float(e)) for f, e in actual} == {(f, float(e)) for f, e in expected},
            'Mechanism formula coverage differs')
    require(mechanism['decimal_precision'] >= 80, 'Mechanism precision is below declared audit')
    orders = [r['order'] for r in quadrature['rows']]
    require(orders == quadrature['config']['comparison_orders'], 'Quadrature order coverage differs')
    reps, queries, methods = active['repeats'], active['config']['queries'], active['methods']
    expected_active = {(r, q, m) for r in range(reps) for q in range(queries) for m in methods}
    actual_active = [(r['repeat'], r['step'], r['method']) for r in active['rows']]
    require(len(actual_active) == len(expected_active) and set(actual_active) == expected_active,
            'Active audit row coverage incomplete')
    geometry = [(r['repeat'], r['step']) for r in active['geometry_audits']]
    require(len(geometry) == reps*queries and set(geometry) == {(r,q) for r in range(reps) for q in range(queries)},
            'Active geometry coverage incomplete')
    require(all(type(r.get('success')) is bool for r in active['rows']), 'Missing active outcome')
    facts = audit_facts(folder)  # stdlib-only extraction; no audit is run.
    for filename, sha in facts['input_json_sha256'].items():
        name = filename.removesuffix('_audit.json') if hasattr(str, 'removesuffix') else filename[:-11]
        require(sha == inputs.records['audit:'+name]['sha256'], 'Audit changed during formatting')
    kernel = inputs.json('kernel', folder/'kernel_formal.json')
    kernel_check = inputs.json('kernel_audit', folder/'kernel_audit.json')
    require(kernel['source_hashes'] == formal_manifest['source_hashes'], 'Kernel source hashes differ')
    require(kernel_check.get('complete') is True and kernel_check['sha256'] == inputs.records['kernel']['sha256'],
            'Kernel audit missing or stale')
    config = kernel['config']
    methods = ('fresh', 'fixed12x2', 'adaptive8x3', 'adaptive4x6', 'adaptive12x2', 'progressive')
    expected_kernel = {(size, increment, rep, method) for size in config['sizes']
                       for increment in config['increments'] for rep in range(config['repeats']) for method in methods}
    identities = [(r['size'], r['increment'], r['repeat'], r['method']) for r in kernel['rows']]
    require(len(identities) == len(expected_kernel) and set(identities) == expected_kernel,
            'Kernel grid incomplete or duplicated')
    require(all(numeric(r.get('seconds')) and r['seconds'] > 0 for r in kernel['rows']), 'Invalid kernel timing')
    checked = [r for r in kernel['rows'] if r['method'] != 'fresh']
    for row in checked:
        require(type(row.get('accepted')) is bool and numeric(row.get('bound')) and row['bound'] >= 0,
                'Missing kernel acceptance diagnostic')
        require(numeric(row.get('exact_drift')) and row['exact_drift'] >= 0,
                'Missing independent kernel drift')
        require(row['accepted'] == (row['bound'] <= config['tau']), 'Kernel acceptance label differs')
    unsafe = sum(r['accepted'] and r['exact_drift'] > config['tau']+1e-10 for r in checked)
    under = sum(r['bound']+max(1e-13,1e-10*r['exact_drift']) < r['exact_drift'] for r in checked)
    require(kernel_check['rows'] == len(kernel['rows']) and kernel_check['checks'] == len(checked)
            and kernel_check['unsafe_acceptances'] == unsafe
            and kernel_check['underestimated_bounds'] == under, 'Kernel diagnostic totals disagree')
    return documents, facts, kernel, kernel_check


def verification_inputs(inputs, args):
    verification = inputs.json('verification', args.verification)
    keys = ('tests_passed', 'compilation_passed', 'visual_review_completed')
    require(all(type(verification.get(k)) is bool for k in keys), 'Verification lacks completed Boolean outcomes')
    if 'source_hashes_verified' in verification:
        require(type(verification['source_hashes_verified']) is bool, 'Source-hash verification outcome must be Boolean')
    archive = None
    if args.archive_verification is not None:
        archive = inputs.json('archive_verification', args.archive_verification)
        require(archive.get('complete') is True, 'Archive verification incomplete')
        require(all(type(archive.get('checks', {}).get(k)) is bool for k in ARCHIVE_CHECKS),
                'Archive check outcomes missing')
        require(isinstance(archive.get('archives'), list) and len(archive['archives']) >= 2,
                'At least two archive identities required')
        base = args.archive_root or args.archive_verification.parent
        files = [a['file'] for a in archive['archives']]
        require(len(files) == len(set(files)), 'Duplicate archive identity')
        for index, item in enumerate(archive['archives']):
            payload = inputs.bytes('archive:'+str(index), Path(base)/item['file'])
            require(len(payload) == item['bytes'] and digest_bytes(payload) == item['sha256'],
                    'Archive bytes/SHA-256 differ: '+item['file'])
    require(args.stage != 'final' or archive is not None, 'Final stage requires archive verification')
    return verification, archive


def number(value, digits=3):
    if value is None:
        return '不可完整汇总'
    require(numeric(value), 'Nonfinite prose number')
    return f'{value:.{digits}f}'


def mean(values):
    return statistics.mean(values) if all(numeric(v) for v in values) else None


def table(headers, rows):
    def cell(value):
        return str(value).replace('|', '\\|').replace('\n', ' ')
    return '\n'.join(['| '+' | '.join(map(cell, headers))+' |',
                       '| '+' | '.join('---' for _ in headers)+' |']+
                      ['| '+' | '.join(map(cell, row))+' |' for row in rows])


def ratio_text(case, baseline, denominator, metric):
    field = 'lookahead_ratios' if denominator == 'lookahead' else 'ratios'
    values = case.get(field, {}).get(baseline)
    if values is None:
        a, b = case['methods'][baseline], case['methods'][denominator]
        return (f'不报告成功比值：失败 {a["failures"]}/{b["failures"]} 次；'
                f'累计尝试开销 {number(math.fsum(r["attempt_work"] for r in a["repetitions"]))}/'
                f'{number(math.fsum(r["attempt_work"] for r in b["repetitions"]))} s')
    row = values[metric]
    return (number(row['ratio_of_medians'])+'；配对 '+
            '/'.join(number(x) for x in row['paired'])+
            f'；范围 [{number(row["minimum"])}, {number(row["maximum"])}]')


def result_slots(formal, raw_formal, fderived, cost, cderived, documents, facts, kernel,
                 kernel_check, verification, archive, stage):
    slots, values = {}, {}
    rows = [[NAMES[name], base+'/progressive', ratio_text(formal['cases'][name], base, 'progressive', 'linear'),
             ratio_text(formal['cases'][name], base, 'progressive', 'total')]
            for name in CASES for base in ('fresh', 'exact_local', 'energy')]
    slots['formal_performance'] = ('正式四家族记录已完成；每项比值为两个完整序列中位时间之比，配对值按重复 0、1、2 列出。分母为 progressive，大于 1 才有利于它；不利结果照列。\n\n'+
        table(['家族', '比值方向', 'setup+CG', '含装配'], rows)+
        f'\n\n共 {formal["solves"]} 次查询求解，失败或异常 {formal["failures"]} 次；失败方法的尝试开销不解释为成功速度。')
    successful = [r for d in raw_formal.values() for r in d['rows'] if r['success']]
    require(successful and all(numeric(r.get(k)) for r in successful
                               for k in ('residual', 'scaled_residual', 'energy_error')),
            'Successful formal solves lack accuracy diagnostics')
    slots['formal_performance'] += ('成功求解记录的最大物理残差、缩放残差与相对参考能量差分别为 '+
        '、'.join(f'{max(r[k] for r in successful):.3e}' for k in ('residual','scaled_residual','energy_error'))+'。')
    rows = []
    phase_rows, lookahead_rows = [], []
    for name in CASES:
        case = cost['cases'][name]
        for base in ('energy', 'progressive', 'lookahead'):
            rows.append([NAMES[name], base+'/cost', ratio_text(case, base, 'cost', 'linear'),
                         ratio_text(case, base, 'cost', 'total')])
        for base in ('energy', 'progressive', 'cost'):
            lookahead_rows.append([NAMES[name], base+'/lookahead',
                ratio_text(case, base, 'lookahead', 'linear'),
                ratio_text(case, base, 'lookahead', 'total')])
        for method in COST_METHODS:
            records = cderived[name][method]
            phase_rows.append([NAMES[name], method]+[number(mean([r[k] for r in records])) for k in
                ('screen_time', 'factorization_time', 'coarse_setup', 'other_setup', 'solve')]+[case['methods'][method]['failures']])
    stops = {name: [r.get('screen_timing_cap_checks') for r in cost['cases'][name]['methods']['cost']['repetitions']]
             for name in CASES}
    lookahead_counts = {name: {key:[r.get(key) for r in cost['cases'][name]['methods']['lookahead']['repetitions']]
        for key in ('lookahead_rejections','lookahead_avoided_action_batches')} for name in CASES}
    slots['cost_followup'] = ('后续实验使用四策略同批重跑记录，未借用正式实验的计时作分子。下表先保留以 cost 为分母的比较，再列出以 lookahead 为分母的比较；两种分母不混用。\n\n'+
        table(['家族', '方向', 'setup+CG', '含装配'], rows)+'\n\n'+
        table(['家族', '方向', 'setup+CG', '含装配'], lookahead_rows)+'\n\n'+
        table(['家族', '策略', '筛查均值(s)', '局部分解', '当前粗层', '其他设置', 'CG', '失败'], phase_rows)+
        '\n\n上述成本是每次完整重复内先求和、再取三重复均值；无法完整取得的分项不补零。各家族 cost 时间停止次数按重复为：'+
        '；'.join(NAMES[n]+' '+('/'.join(str(x) if x is not None else '不可完整汇总' for x in stops[n])) for n in CASES)+
        '。lookahead 提前重建次数/避免块作用次数按重复为：'+
        '；'.join(NAMES[n]+' 重建 '+('/'.join(str(v) if v is not None else '不可完整汇总'
            for v in lookahead_counts[n]['lookahead_rejections']))+'，避免作用 '+
            ('/'.join(str(v) if v is not None else '不可完整汇总'
            for v in lookahead_counts[n]['lookahead_avoided_action_batches'])) for n in CASES)+
        f'。共 {cost["solves"]} 次查询求解，失败或异常 {cost["failures"]} 次。48 条随机策略序列的并集界为 4.8×10⁻⁷。'
        '历史因子时间与回调监测时间没有重复加入 inclusive screen 成本；lookahead 的标量预测和保护检查包含在筛查及 setup 内。'
        'lookahead 通过幂作用对数范数割线检查全部剩余允许幂是否均不可能接受，触发的只是提前重建，不是能量漂移越界证明。')
    gm_rows=[]
    for denominator, key in (('cost','geometric_mean'), ('lookahead','geometric_mean_lookahead')):
        for baseline in COST_METHODS:
            if baseline == denominator:
                continue
            entry=cost[key].get(baseline)
            gm_rows.append([baseline+'/'+denominator]+[
                number(entry[metric]) if entry is not None else '不可汇总：存在失败家族'
                for metric in ('setup','linear','total')])
    eq_rows=[[NAMES[n]]+[cost['cases'][n]['lookahead_equivalence'][key] for key in
        ('checks','available','anchor_mismatches','solution_mismatches','rng_mismatches',
         'draw_count_mismatches','factor_count_mismatches')] for n in CASES]
    slots['cost_followup'] += ('\n\n四家族几何均值仅在四个家族的对应比较均成功时给出：\n\n'+
        table(['方向','setup','setup+CG','含装配'],gm_rows)+
        '\n\n查询后逐对检查位于四种方法计时之外。下表列出可比较对数及不一致次数；未取得的成功对不当作相同：\n\n'+
        table(['家族','检查','可比较','锚点不符','解不符','RNG不符','抽样计数不符','因子计数不符'],eq_rows)+
        '\n\n这里的锚点哈希覆盖当前缓存键、anchor 的 dtype、shape 与数据。'
        '查询末相同不自动证明查询内全部中间决定相同；精确算术的等价定理也不替代该浮点核对。')
    values['cost_followup'] = dict(timing_stops=stops, lookahead_counts=lookahead_counts,
        lookahead_equivalence=cost['lookahead_equivalence'],
        geometric_mean=cost['geometric_mean'], geometric_mean_lookahead=cost['geometric_mean_lookahead'])
    coverage = [[NAMES[n], formal['cases'][n]['config']['queries'], 3, len(METHODS), len(raw_formal[n]['rows']),
                 f'{formal["cases"][n]["methods"]["progressive"]["nmin"]}–{formal["cases"][n]["methods"]["progressive"]["nmax"]}',
                 formal['cases'][n]['methods']['progressive']['largest_block']] for n in CASES]
    slots['formal_coverage'] = table(['家族', '查询/重复', '重复', '策略', '实际行数', '自由度范围', '最大局部维数'], coverage)+\
        '\n\n全部方法–查询–重复标识与冻结配置逐一匹配。两条 50 查询与两条 12 查询保持各自范围，没有 200 查询证据。'
    phase_rows = []
    for n in CASES:
        for method in METHODS:
            rr = fderived[n][method]
            phase_rows.append([NAMES[n], method]+[('不适用' if method == 'jacobi' and k in ('screen_time','factorization_time')
                else number(mean([r[k] for r in rr]))) for k in
                ('setup', 'screen_time', 'factorization_time', 'coarse_setup', 'solve', 'total')]+
                [number(mean([r['iterations'] for r in rr]), 1), formal['cases'][n]['methods'][method]['failures']])
    wins = []
    for increment in kernel['config']['increments']:
        by_size = []
        for size in sorted(set(kernel['config']['sizes'])):
            selected = [r for r in kernel['rows'] if r['increment'] == increment and r['size'] == size]
            med = {m: statistics.median(r['seconds'] for r in selected if r['method'] == m)
                   for m in ('fresh', 'fixed12x2', 'progressive')}
            by_size.append(dict(size=size, fixed_over_fresh=med['fixed12x2']/med['fresh'],
                                progressive_over_fresh=med['progressive']/med['fresh']))
        wins.append(dict(increment=increment, sizes=by_size))
    slots['cost_decomposition'] = ('逐家族、逐策略成本均值如下，时间单位 s，迭代数为每条序列累计次数的均值。失败保持在列，缺失分项不视为零。\n\n'+
        table(['家族', '方法', 'setup', 'screen', 'factor', 'coarse', 'CG', '含装配', '迭代', '失败'], phase_rows)+
        '\n\n完整核实验中，progressive 的维护中位时间低于立即分解的已测维数为：'+
        '；'.join(f'增量 {group["increment"]:g}: '+(', '.join(str(r['size']) for r in group['sizes'] if r['progressive_over_fresh'] < 1) or '无') for group in wins)+
        f'。这只是离散采样点，不外推为连续或硬件无关阈值。核实验错误接受记录 {kernel_check["unsafe_acceptances"]}，低估诊断 {kernel_check["underestimated_bounds"]}；拒绝后的分解费用均计入维护时间。')
    values['cost_decomposition'] = dict(kernel_sampled_ratios=wins)
    a = facts['active']
    pr = [r for r in documents['active']['rows'] if r['method'] == 'progressive']
    changed = [dict(repeat=r['repeat'], step=r['step'], added=r['added_count'], deleted=r['deleted_count'])
               for r in documents['active']['geometry_audits'] if not r['initial'] and (r['added_count'] or r['deleted_count'])]
    events = {key: total(pr, 'stat_'+key) for key in ('new', 'refreshed', 'retired', 'reused_energy')}
    slots['active_state'] = (f'独立活动空间审计完成 {a["repeats"]} 次重复，每次 {a["queries_per_repeat"]} 个查询，'
        f'记录 {a["recorded_rows"]}/{a["planned_rows"]} 次方法–查询求解。除初始空间建立外，'
        f'发生标识变化的查询记录 {a["active_change_query_records"]} 个，增加标识事件 {a["added_id_events_after_initial"]}，'
        f'删除事件 {a["deleted_id_events_after_initial"]}。\n\n'+
        table(['重复', '查询(从0起)', '增加', '删除'], [[r['repeat'],r['step'],r['added'],r['deleted']] for r in changed])+
        '\n\nprogressive 全路径块事件（含冷启动）为：'+
        '，'.join(k+'='+number(v, 0) for k,v in events.items())+
        f'。完整局部广义谱 {a["dense_spectrum_records"]} 条，三方向 Rayleigh 下界诊断 {a["rayleigh_witness_records"]} 条；'
        f'对应上界矛盾记录分别 {a["dense_bound_contradictions"]}、{a["witness_bound_contradictions"]}。'
        f'审计失败账目 {a["failure_ledger_records"]} 条。下界诊断不充作完整谱或范数上界，初始建立也不计作之后的活动变化。')
    values['active_state'] = dict(changed_query_records=changed, progressive_events=events)
    external = []
    for n in CASES:
        case = formal['cases'][n]
        for method in ('jacobi', 'stale'):
            external.append([NAMES[n], method, case['methods'][method]['failures'],
                             ratio_text(case, method, 'progressive', 'linear'),
                             case['methods'][method]['coarse_dofs'],
                             number(mean([r['coarse_setup'] for r in fderived[n][method]]))])
    slots['external_coarse'] = table(['家族', '外部/简单基线', '失败', '基线/progressive', '粗维数', '粗设置均值(s)'], external)+\
        '\n\n共同当前粗层费用已包含在各方法设置时间中。失败求解的较短用时不视为优势；小于 1 的成功比值表示该基线比 progressive 更快，原样保留。这些对照仍属于本地串行实现。'
    passed = lambda value: '通过' if value is True else '未通过'
    lines = [f'验证记录：测试 {passed(verification["tests_passed"])}；编译 {passed(verification["compilation_passed"])}；'
             f'视觉逐页检查'+('已完成' if verification['visual_review_completed'] else '未完成')+'。']
    if 'source_hashes_verified' in verification:
        lines.append('验证记录的源哈希检查：'+passed(verification['source_hashes_verified'])+'。')
    tests = verification.get('tests')
    if isinstance(tests, dict):
        lines.append('测试记录提供：'+json.dumps(tests, ensure_ascii=False, sort_keys=True)+'。')
    for key in ('compilation', 'visual_review'):
        if isinstance(verification.get(key), dict):
            lines.append(key+' 记录：'+json.dumps(verification[key], ensure_ascii=False, sort_keys=True)+'。')
    lines.append('本次格式化逐项核对了正式/后续记录与冻结源快照的哈希、覆盖及成功/失败统计；没有重跑测试、求解或计时。')
    if archive is None:
        lines.append('压缩包实际解压、测试、图形复现与稿件重建：尚待完成。本输出处于 pre-archive 阶段，不声称压缩包已验证；最终回应和归档审核可在验证后另行置于压缩包旁。')
    else:
        labels = {'extracted':'实际解压','tests':'解压后测试','figure_reproduction':'图形复现','manuscript_rebuild':'稿件重建'}
        lines.append('压缩包验证：'+'；'.join(labels[k]+' '+passed(archive['checks'][k]) for k in ARCHIVE_CHECKS)+'。')
        lines.append(table(['压缩包', '字节数', 'SHA-256'], [[r['file'], r['bytes'], r['sha256']] for r in archive['archives']]))
    lines.append('机制与求积审计状态：'+', '.join(k+'='+str(facts[k]['status']) for k in ('mechanism','quadrature'))+
                 '；未通过的检查保留于事实账本，不改写为通过。')
    slots['final_delivery'] = '\n\n'.join(lines)
    return slots, values


def theory_update(text):
    text = text.replace('`docs/theory_extensions.tex`', '`docs/theory_main.tex` 与 `docs/theory_supplement.tex`')
    heading = '## 5. '
    require(text.count(heading) == 1, 'Cannot locate unique active-space response heading')
    paragraph = ('还补充了充分的筛查行动次数界，见 `docs/work_bound_main.tex` 与 '
        '`docs/work_bound_supp.tex`。对严格满足 `0<η<τ` 的固定候选，若有效幂数上限允许所推导的 `q_*`，'
        '且时间停止等规则未提前重建，则以至少 `1−ε` 的概率在 `q_*` 次块作用内接受。'
        '`η=0` 时第一个作用即接受。`ε` 是工作量尾界参数，不替代安全预算 `δ`；在维度、探针数、工作尾概率参数与严格漂移余量固定时，'
        '可求和安全分配使这一充分幂数仅随检查序号呈对数增长。`12s q_*≤m` 比较领先算术量，'
        '不保证墙钟加速。推导使用高斯初始向量范数和范数次乘性，将漂移余量连接到充分工作量，'
        '不把标准概率工具宣称为新的集中原理。\n\n')
    paragraph += ('割线 lookahead 及其精确算术等价的条件见 `docs/lookahead_main.tex` 与 '
        '`docs/lookahead_theory.tex`。实现显式检查全部剩余允许幂，先执行普通接受与即时下界拒绝；'
        '只有后者未触发时，cap-only 条件才与全部未来幂的判定等价。'
        '它不增加接受事件，浮点 margin guard 也不声称区间保证。\n\n')
    return text.replace(heading, paragraph+heading, 1)


def slot_fields():
    return {
        'formal_performance': [('formal_summary', '$.cases.*.ratios'), ('formal_summary', '$.cases.*.methods.*.repetitions'), ('formal_summary', '$.failures')]+
            [('formal:'+n, '$.rows[?(@.success==true)].{residual,scaled_residual,energy_error}') for n in CASES],
        'cost_followup': [('cost_summary', '$.cases.*.ratios'), ('cost_summary', '$.cases.*.lookahead_ratios'),
            ('cost_summary', '$.geometric_mean'), ('cost_summary', '$.geometric_mean_lookahead'),
            ('cost_summary', '$.cases.*.lookahead_equivalence'),
            *[('cost:'+n, '$.lookahead_audits[*]') for n in CASES], ('cost_summary', '$.cases.*.methods.*.repetitions'),
            ('cost_summary', '$.failure_rows'), ('cost_summary', '$.probability')],
        'formal_coverage': [('formal_manifest', '$.cases'), ('formal_summary', '$.cases.*.methods.progressive'), ('formal_summary', '$.solves')],
        'cost_decomposition': [('formal_summary', '$.cases.*.methods.*.repetitions'), ('kernel', '$.rows[*]'), ('kernel', '$.config'), ('kernel_audit', '$')],
        'active_state': [('audit:active', '$.geometry_audits[*]'), ('audit:active', '$.rows[?(@.method=="progressive")].stat_*'), ('audit:active', '$.local_audits[*]'), ('audit:active', '$.failures')],
        'external_coarse': [('formal_summary', '$.cases.*.methods.jacobi'), ('formal_summary', '$.cases.*.methods.stale'), ('formal_summary', '$.cases.*.ratios')],
        'final_delivery': [('verification', '$'), ('audit:mechanism', '$.checks'), ('audit:quadrature', '$.checks')],
    }


def run(args):
    inputs = Inputs()
    template = inputs.bytes('template', args.template).decode('utf-8')
    starts = re.findall(r'<!-- FACT_SLOT: ([a-z_]+) -->', template)
    ends = re.findall(r'<!-- END_FACT_SLOT: ([a-z_]+) -->', template)
    require(len(starts) == len(SLOTS) and set(starts) == set(SLOTS) and starts == ends,
            'Template must contain exactly seven unique matching slots')
    manifest, formal, raw_formal, fderived = campaign_inputs(inputs, args.results_dir, args.code_root)
    cost, raw_cost, cderived = cost_inputs(inputs, args.results_dir, args.code_root, manifest)
    documents, facts, kernel, kernel_check = audit_inputs(inputs, args.results_dir, manifest, args.code_root)
    verification, archive = verification_inputs(inputs, args)
    for filename in ('theory_main.tex','theory_supplement.tex','work_bound_main.tex','work_bound_supp.tex','lookahead_main.tex','lookahead_theory.tex'):
        inputs.bytes('theory:'+filename, ROOT/'docs'/filename)
    slots, derived = result_slots(formal, raw_formal, fderived, cost, cderived, documents,
                                 facts, kernel, kernel_check, verification, archive, args.stage)
    output = template
    fields = slot_fields()
    if archive is not None:
        fields['final_delivery'].append(('archive_verification', '$'))
    ledger_slots = {}
    for name in SLOTS:
        pattern = r'(<!-- FACT_SLOT: '+re.escape(name)+r' -->).*?(<!-- END_FACT_SLOT: '+re.escape(name)+r' -->)'
        output, count = re.subn(pattern, lambda m: m.group(1)+'\n'+slots[name]+'\n'+m.group(2), output, flags=re.S)
        require(count == 1, 'Slot replacement did not occur exactly once: '+name)
        ledger_slots[name] = dict(field_paths=[dict(input_id=i, field_path=p) for i,p in fields[name]],
                                 rendered_sha256=digest_bytes(slots[name].encode()),
                                 rendered_markdown=slots[name], derived_values=derived.get(name, {}))
    output = theory_update(output)
    output = output.replace('最终性能、图表、编译和包装结果仍以明确占位符标出。',
                            '下列结果来自完整记录；包装状态按实际验证阶段单独说明。')
    require('[待填' not in output and 'docs/theory_extensions.tex' not in output, 'Unresolved result placeholder or obsolete theory path')
    source_files = ('analyze.py','cost_analyze.py','audit_tables.py','response_report.py')
    for name in source_files:
        inputs.bytes('formatter_support:'+name, ROOT/name)
    all_qa = all(verification[k] for k in ('tests_passed','compilation_passed','visual_review_completed'))
    if 'source_hashes_verified' in verification:
        all_qa = all_qa and verification['source_hashes_verified']
    archive_ok = archive is not None and all(archive['checks'][k] for k in ARCHIVE_CHECKS)
    ledger = dict(schema_version=1, stage=args.stage,
                  delivery_status=('pre_archive_pending' if archive is None else
                                   'verified' if all_qa and archive_ok else 'verification_failed'),
                  inputs=inputs.records, slots=ledger_slots,
                  audit_facts=facts, formal_failure_rows=[{**r, 'case':n} for n,d in raw_formal.items() for r in d['rows'] if not r['success']],
                  cost_failure_rows=cost['failure_rows'],
                  validation=dict(formal_coverage=True, cost_coverage=True,
                      live_and_snapshot_hashes=True, summary_recalculation=True,
                      audit_coverage=True, kernel_coverage=True, main_verification=verification,
                      archive_verification=archive),
                  theory_support=dict(files=['docs/theory_main.tex','docs/theory_supplement.tex',
                      'docs/work_bound_main.tex','docs/work_bound_supp.tex',
                      'docs/lookahead_main.tex','docs/lookahead_theory.tex'],
                      scope='Conditional action counts with strict margin/cap/no-truncation assumptions; safety delta distinct from work epsilon.'),
                  formatting=dict(time_unit='seconds', ratio_direction='numerator baseline / named policy denominator',
                      decimals=3, intervals='observed paired minima/maxima, not confidence intervals',
                      component_statistic='means of per-repetition sums', no_failed_sequence_speedup=True))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.ledger.parent.mkdir(parents=True, exist_ok=True)
    output_paths = {args.output.resolve(), args.ledger.resolve()}
    input_paths = {Path(record['path']) for record in inputs.records.values()}
    require(len(output_paths) == 2 and output_paths.isdisjoint(input_paths),
            'Response and ledger must be distinct and must not overwrite inputs')
    payload = output.encode('utf-8')
    ledger['output'] = dict(path=str(args.output.resolve()), sha256=digest_bytes(payload))
    response_tmp = args.output.with_suffix(args.output.suffix+'.tmp')
    ledger_tmp = args.ledger.with_suffix(args.ledger.suffix+'.tmp')
    response_tmp.write_bytes(payload)
    ledger_tmp.write_text(json.dumps(ledger, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)+'\n')
    response_tmp.replace(args.output)
    ledger_tmp.replace(args.ledger)
    return ledger


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', required=True, choices=('pre-archive','final'))
    parser.add_argument('--results-dir', type=Path, default=ROOT/'results')
    parser.add_argument('--code-root', type=Path, default=ROOT.parent.parent)
    parser.add_argument('--template', type=Path, default=ROOT/'docs/revision_response_zh.md')
    parser.add_argument('--verification', type=Path)
    parser.add_argument('--archive-verification', type=Path)
    parser.add_argument('--archive-root', type=Path)
    parser.add_argument('--output', type=Path, default=ROOT/'docs/revision_response_completed_zh.md')
    parser.add_argument('--ledger', type=Path, default=ROOT/'results/response_facts_ledger.json')
    args = parser.parse_args(argv)
    if args.verification is None:
        args.verification = args.results_dir/'verification.json'
    if args.archive_verification is None and (args.results_dir/'archive_verification.json').is_file():
        args.archive_verification = args.results_dir/'archive_verification.json'
    ledger = run(args)
    print(json.dumps(dict(stage=ledger['stage'], delivery_status=ledger['delivery_status'],
                          response=str(args.output), ledger=str(args.ledger)), ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
