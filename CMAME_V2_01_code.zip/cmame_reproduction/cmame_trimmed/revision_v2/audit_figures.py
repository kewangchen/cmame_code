"""Render separate spline/active-space audit figures after all timing jobs finish.

Run only after both audit JSON records exist and report complete=True:
  python -m cmame_trimmed.revision_v2.audit_figures --timings-finished

No assembly, solve, spectral audit or benchmark is performed here. Figure 15
uses the saved 80-digit formula evaluations, not fresh eigensolver output.
Figure 16 reports state counts; Rayleigh witnesses are never upper bounds.
"""
from __future__ import annotations

import argparse
import ast
from decimal import Decimal
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WIDTH_MM = 180.0
DPI = 300


def read_json(path):
    data = json.loads(Path(path).read_text())
    if data.get('complete') is not True:
        raise ValueError('Audit is incomplete: '+str(path))
    return data


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def shared_palette():
    """Read the shared literal without importing the campaign/figure driver."""
    path = ROOT/'figures.py'
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == 'COL' for t in node.targets):
            palette = ast.literal_eval(node.value)
            required = {'progressive', 'energy', 'fresh', 'exact_local', 'stale', 'jacobi'}
            if not required <= palette.keys():
                raise ValueError('Shared figure palette lacks required identities')
            return palette
    raise ValueError('COL palette not found in shared figure driver')


def plotting_runtime():
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.labelsize': 8, 'axes.titlesize': 9,
        'legend.fontsize': 7, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5,
        'pdf.fonttype': 42, 'svg.fonttype': 'none',
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.linewidth': .65, 'savefig.dpi': DPI, 'savefig.bbox': None,
        'figure.facecolor': 'white', 'legend.frameon': False,
    })
    return np, plt


def panel(ax, letter, title):
    ax.set_title(title, loc='left', pad=8)
    ax.text(-.13, 1.035, letter, transform=ax.transAxes,
            fontsize=11, fontweight='bold', va='bottom')
    ax.grid(axis='y', color='#e5e9ec', lw=.5, zorder=0)


def save_figure(fig, name, output, source, source_data, plt):
    """Keep the canvas exactly 180 mm wide; do not tight-crop its dimensions."""
    output.mkdir(parents=True, exist_ok=True)
    files = []
    for ext in ('pdf', 'svg', 'png'):
        path = output/(name+'.'+ext)
        fig.savefig(path, dpi=DPI, facecolor='white', bbox_inches=None)
        files.append(path.name)
    plt.close(fig)
    return dict(figure=name, files=files, width_mm=WIDTH_MM,
                backend='Python/matplotlib', png_dpi=DPI,
                source_file=str(source), source_sha256=digest(source),
                source_data=source_data)


def stable_value(row, key):
    """Convert the already stable high-precision scalar only for plotting."""
    if key not in row.get('decimal', {}):
        raise ValueError('Missing saved Decimal mechanism scalar: '+key)
    value = Decimal(row['decimal'][key])
    if not value.is_finite():
        raise ValueError('Nonfinite mechanism scalar: '+key)
    return float(value)


def spline_limits(source, output, palette, np, plt):
    data = read_json(source)
    if data.get('kind') != 'exact_formula_evaluation':
        raise ValueError('Mechanism source is not a formula audit')
    if data.get('decimal_precision', 0) < 80 or not data['checks']['all_passed']:
        raise ValueError('Mechanism audit lacks passed 80-digit evaluations')
    families = {}
    for name in ('positive', 'counterexample'):
        rows = sorted((r for r in data['rows'] if r['family'] == name),
                      key=lambda r: stable_value(r, 'epsilon'))
        if not rows or len({r['decimal']['epsilon'] for r in rows}) != len(rows):
            raise ValueError('Missing or duplicate mechanism scales: '+name)
        families[name] = rows
    if ([r['decimal']['epsilon'] for r in families['positive']] !=
            [r['decimal']['epsilon'] for r in families['counterexample']]):
        raise ValueError('Spline families have different evaluated scales')
    values = {name: {key: np.asarray([stable_value(r, key) for r in rows])
                    for key in ('epsilon', 'lambda_min_normalized',
                                'lambda_max_normalized', 'normalized_condition',
                                'epsilon_squared_condition')}
              for name, rows in families.items()}
    if any(np.any(v[key] <= 0) for v in values.values()
           for key in ('epsilon', 'lambda_min_normalized', 'normalized_condition')):
        raise ValueError('Formula audit contains nonpositive spectral values')
    constants = data['positive_constants']['decimal']
    kappa0 = float(Decimal(constants['kappa0']))
    rho0 = float(Decimal(constants['rho0']))
    positive, negative = palette['progressive'], palette['exact_local']
    neutral = palette['fresh']
    fig, axes = plt.subplots(2, 2, figsize=(WIDTH_MM/25.4, 130/25.4))
    fig.subplots_adjust(left=.105, right=.98, bottom=.11, top=.91,
                        hspace=.62, wspace=.40)
    fig.suptitle('Quadratic spline limits: analytic formula evaluations',
                 x=.5, y=.985, fontsize=10)
    ax = axes[0, 0]
    panel(ax, 'a', 'Actual one-span B-spline pairs')
    ax.axis('off')
    boxes = [(.52, positive, r'$B_1^2=2x(1-x),\quad B_2^2=x^2$',
              r'Leading fields: $2,\ 2y$; $G_0\succ0$'),
             (.01, negative, r'$B_0^2=(1-x)^2,\quad B_1^2=2x(1-x)$',
              r'Leading fields: $-2,\ 2$; $G_0$ singular')]
    for bottom, color, formula, detail in boxes:
        ax.add_patch(plt.Rectangle((0, bottom), 1, .43,
                     transform=ax.transAxes, facecolor=color, alpha=.08,
                     edgecolor=color, linewidth=.7))
        ax.text(.04, bottom+.31, formula, transform=ax.transAxes,
                va='center', color=color, fontsize=8)
        ax.text(.04, bottom+.13, detail, transform=ax.transAxes,
                va='center', fontsize=7.5)
    ax.text(0, -.15, r'Restrictions to $(0,\varepsilon)$, $0<\varepsilon\leq0.1$',
            transform=ax.transAxes, fontsize=7.5)

    ax = axes[0, 1]
    panel(ax, 'b', 'Positive pair: normalized spectrum')
    v = values['positive']
    for key, ls, label, limit in (
            ('lambda_max_normalized', '-', r'$\lambda_{\max}(C_\varepsilon)$', 1+rho0),
            ('lambda_min_normalized', '--', r'$\lambda_{\min}(C_\varepsilon)$', 1-rho0)):
        ax.semilogx(v['epsilon'], v[key], 'o', ms=3, color=positive)
        ax.semilogx(v['epsilon'], v[key], ls, lw=1.3, color=positive, label=label)
        ax.axhline(limit, color=neutral, lw=.7, ls=':')
    ax.set(xlabel=r'Cut scale $\varepsilon$', ylabel='Normalized eigenvalue',
           ylim=(0, 2.06))
    ax.legend(loc='center right')
    ax.text(.03, .52, r'Limits $1\pm\sqrt{3}/2$', transform=ax.transAxes,
            fontsize=7.5, color=neutral)

    ax = axes[1, 0]
    panel(ax, 'c', 'Normalization and near dependence')
    for family, color, label in (
            ('positive', positive, r'$B_1^2,B_2^2$'),
            ('counterexample', negative, r'$B_0^2,B_1^2$')):
        v = values[family]
        ax.loglog(v['epsilon'], v['normalized_condition'], 'o-', ms=3,
                  lw=1.3, color=color, label=label)
    e = values['counterexample']['epsilon']
    ax.loglog(e, 48/e**2, ':', color=neutral, lw=.9, label=r'$48/\varepsilon^2$')
    ax.axhline(kappa0, color=positive, lw=.75, ls=':')
    ax.set(xlabel=r'Cut scale $\varepsilon$', ylabel=r'$\kappa_2(C_\varepsilon)$')
    ax.legend(loc='upper right', fontsize=7.2)

    ax = axes[1, 1]
    panel(ax, 'd', 'Singular-leading-Gram limit')
    v = values['counterexample']
    ax.semilogx(v['epsilon'], v['epsilon_squared_condition'], 'o-', ms=3,
                color=negative, lw=1.4,
                label=r'$\varepsilon^2\kappa_2(C_\varepsilon)$')
    ax.axhline(48, color=neutral, ls=':', lw=1, label='Limit 48')
    ax.set(xlabel=r'Cut scale $\varepsilon$',
           ylabel=r'$\varepsilon^2\kappa_2(C_\varepsilon)$')
    ax.legend(loc='lower left')
    fig.text(.105, .025, 'Saved 80-digit formula values; no timing or sampled performance data.',
             fontsize=7, color=neutral)
    return save_figure(fig, '15_spline_limits', output, source,
                       dict(kind=data['kind'], decimal_precision=data['decimal_precision'],
                            formulas=data['formulas'], rows=data['rows'],
                            positive_constants=data['positive_constants']), plt)


def indexed_records(records, repeats, queries, label):
    expected = {(r, q) for r in range(repeats) for q in range(queries)}
    found = {(int(r['repeat']), int(r['step'])): r for r in records}
    if len(found) != len(records) or set(found) != expected:
        raise ValueError('Missing or duplicate '+label+' records')
    return found


def active_crossing(source, output, palette, np, plt):
    data = read_json(source)
    repeats, queries = int(data['repeats']), int(data['config']['queries'])
    if repeats < 1 or queries < 3:
        raise ValueError('Active audit has no complete path')
    geometry = indexed_records(data['geometry_audits'], repeats, queries, 'geometry')
    progressive_rows = [r for r in data['rows'] if r['method'] == 'progressive']
    progressive = indexed_records(progressive_rows, repeats, queries, 'progressive')
    eta = np.asarray(data['config']['eta'], dtype=float)
    if len(eta) != queries or not np.all(np.isfinite(eta)):
        raise ValueError('Active path does not match declared query count')
    turn = int(np.argmin(eta))
    if not 0 < turn < queries-1:
        raise ValueError('Active path lacks a forward/reverse turning point')
    x = np.arange(1, queries+1)
    fig = plt.figure(figsize=(WIDTH_MM/25.4, 124/25.4))
    grid = fig.add_gridspec(2, 2, height_ratios=(1.05, 1),
                           left=.10, right=.98, bottom=.16, top=.90,
                           hspace=.68, wspace=.40)
    a = fig.add_subplot(grid[0, :])
    b = fig.add_subplot(grid[1, 0])
    c = fig.add_subplot(grid[1, 1])
    neutral, signal = palette['fresh'], palette['progressive']
    fig.suptitle('Active-space crossing: current memberships and local-factor decisions',
                 y=.985, fontsize=10)
    panel(a, 'a', 'Forward / reverse active-DOF trace')
    a.texts[-1].set_x(-.06)
    dofs = np.asarray([[geometry[r, q]['dofs'] for q in range(queries)]
                       for r in range(repeats)], dtype=float)
    mean = dofs.mean(axis=0)
    a.fill_between(x, dofs.min(axis=0), dofs.max(axis=0), color=signal,
                   alpha=.13, lw=0)
    a.plot(x[:turn+1], mean[:turn+1], 'o-', ms=3, lw=1.4,
           color=neutral, label='Forward path')
    a.plot(x[turn:], mean[turn:], 's--', ms=3, lw=1.4,
           color=signal, label='Reverse path')
    a.axvline(turn+1, color=palette['stale'], ls=':', lw=.8)
    a.set(xlabel='Geometry query (initial state included)', ylabel='Active free DOFs',
          xlim=(.5, queries+.5))
    a.legend(ncol=2, loc='upper center', bbox_to_anchor=(.5, .95))
    failed = [q for q in range(queries)
              if any(not progressive[r, q]['success'] for r in range(repeats))]
    if failed:
        a.plot(x[failed], mean[failed], 'x', color=palette['exact_local'],
               ms=7, mew=1.2, label='Unsuccessful progressive solve')
        a.legend(ncol=2, loc='best')

    panel(b, 'b', 'Actual free-ID additions and deletions')
    for field, sign, color, label in (
            ('added_count', 1, signal, 'Added after initial state'),
            ('deleted_count', -1, palette['exact_local'], 'Deleted')):
        counts = np.asarray([[geometry[r, q][field] if q > 0 else 0
                              for q in range(queries)] for r in range(repeats)], dtype=float)
        values = sign*counts
        b.bar(x, values.mean(axis=0), width=.72, color=color,
              label=label, zorder=3)
        if repeats > 1:
            b.vlines(x, values.min(axis=0), values.max(axis=0),
                     lw=.7, color=neutral, zorder=4)
    b.axhline(0, color=neutral, lw=.65)
    b.set(xlabel='Geometry query', ylabel='Free-ID events (deletions below zero)',
          xlim=(.5, queries+.5))
    b.legend(loc='best', fontsize=7.2)

    panel(c, 'c', 'Progressive local-factor decisions')
    styles = [('new', neutral, 'o', 'New'),
              ('refreshed', palette['exact_local'], '^', 'Refreshed'),
              ('retired', palette['stale'], 'x', 'Retired'),
              ('reused_energy', signal, 's', 'Energy-reused')]
    for field, color, marker, label in styles:
        values = np.asarray([[progressive[r, q].get('stat_'+field, float('nan'))
                              for q in range(queries)] for r in range(repeats)], dtype=float)
        # A failed query with missing diagnostics remains a gap, never zero.
        c.plot(x, values.mean(axis=0), marker=marker, ms=2.5, lw=1,
               color=color, label=label)
        if repeats > 1:
            c.fill_between(x, values.min(axis=0), values.max(axis=0),
                           color=color, alpha=.10, lw=0)
    c.set_yscale('symlog', linthresh=1)
    c.set(xlabel='Geometry query', ylabel='Block events (symmetric-log count)',
          xlim=(.5, queries+.5))
    c.legend(ncol=2, loc='upper center', bbox_to_anchor=(.5, 1.48), fontsize=7.2)
    dense = sum(r['audit_kind'] == 'full_generalized_spectrum'
                for r in data['local_audits'])
    witness = sum(r['audit_kind'] == 'three_rayleigh_lower_witnesses'
                  for r in data['local_audits'])
    failure_count = len(data['failures'])
    repeat_text = ('One audit repetition; no interval estimated.' if repeats == 1 else
                   f'Means and observed min-max ranges over {repeats} complete repetitions.')
    fig.text(.10, .068, repeat_text, fontsize=7, color=neutral)
    fig.text(.10, .030,
             f'Dense local spectra: {dense}; Rayleigh lower-diagnostic sets: {witness}; '
             f'audit failure records: {failure_count}.', fontsize=7, color=neutral)
    return save_figure(fig, '16_active_crossing', output, source,
                       dict(repeats=repeats, config=data['config'],
                            geometry_audits=data['geometry_audits'],
                            progressive_rows=progressive_rows,
                            local_diagnostic_record_counts=dict(full_spectra=dense,
                                                               rayleigh_lower_sets=witness),
                            failures=data['failures'],
                            summary_scope='Separate mechanism audit; no timing aggregate.'), plt)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timings-finished', action='store_true',
                        help='Explicitly confirm that formal timing jobs have finished')
    parser.add_argument('--mechanism', type=Path, default=ROOT/'results/mechanism_audit.json')
    parser.add_argument('--active', type=Path, default=ROOT/'results/active_audit.json')
    parser.add_argument('--output-dir', type=Path, default=ROOT/'figures')
    args = parser.parse_args(argv)
    if not args.timings_finished:
        parser.error('Rendering is deferred until timing jobs finish; then use --timings-finished')
    # Validate source completion before loading the plotting runtime.
    read_json(args.mechanism)
    read_json(args.active)
    palette = shared_palette()
    np, plt = plotting_runtime()
    records = [spline_limits(args.mechanism, args.output_dir, palette, np, plt),
               active_crossing(args.active, args.output_dir, palette, np, plt)]
    manifest = dict(backend='Python/matplotlib', width_mm=WIDTH_MM,
                    renderer_sha256=digest(Path(__file__)),
                    palette_sha256=digest(ROOT/'figures.py'), records=records)
    # This separate manifest never overwrites the main figure driver's manifest.
    (args.output_dir/'audit_figure_manifest.json').write_text(
        json.dumps(manifest, indent=2, allow_nan=False)+'\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
