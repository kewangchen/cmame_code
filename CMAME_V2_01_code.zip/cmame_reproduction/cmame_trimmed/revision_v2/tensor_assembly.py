"""Exact tensor contractions for extruded geometry, with bounded COO batches.

Uses the same positive XY cut quadrature as the original assembler. The Z
integrals separate exactly. This is a common assembly path for every policy,
not a gain attributed to preconditioner reuse.
"""
from time import perf_counter
import numpy as np
from scipy import sparse
from scipy.interpolate import BSpline
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.geometry import cut_quadrature,gauss
from cmame_trimmed.src.assembly import Assembler,System


class TensorAssembler(Assembler):
    def __init__(self,grid,*args,batch_entries=2000000,incremental=True,**kwargs):
        if grid.dim!=3:raise ValueError('TensorAssembler requires three dimensions')
        super().__init__(grid,*args,**kwargs)
        if self.load!='body':raise ValueError('Tensor assembler implements the stated body load only')
        if self.bc!='left':raise ValueError('Tensor assembler supports the tested left-face boundary condition only')
        self.plane=SplineGrid(grid.cells[:2],grid.degrees[:2]);self.xy_cache={};self.z_cache={};self.full_cache={}
        self.batch_entries=int(batch_entries)
        self.incremental=bool(incremental);self._full_rhs=None

    def _axis_type(self,e,a):
        n=self.grid.cells[a];p=self.grid.degrees[a]
        return (min(e,p),min(n-1-e,p))

    def _plane_integrals(self,cell,geometry,order):
        xy=tuple(cell[:2]);bounds=self.plane.bounds(xy);sig=geometry.signature(bounds)
        key=(xy,order);old=self.xy_cache.get(key)
        if old is not None and old[0]==sig:return old[1]
        pts,w=cut_quadrature(bounds,geometry,order)
        if not len(w):record=None
        else:
            _,N,G=self.plane.local(xy,pts)
            M=N.T@(w[:,None]*N)
            H=np.einsum('qia,qjb,q->abij',G,G,w,optimize=True)
            B=np.einsum('qia,qj,q->aij',G,N,w,optimize=True)
            record=(M,H,B,N.T@w,float(w.sum()))
        self.xy_cache[key]=(sig,record)
        return record

    def _z_integrals(self,e,order):
        key=(self._axis_type(e,2),order)
        if key not in self.z_cache:
            v,w=gauss(order);n=self.grid.cells[2];z=(e+(v+1)/2)/n;w=w/(2*n)
            p=self.grid.degrees[2];s=self.grid.splines[2];N=s(z)[:,e:e+p+1];D=s(z,nu=1)[:,e:e+p+1]
            self.z_cache[key]=(N.T@(w[:,None]*N),D.T@(w[:,None]*D),D.T@(w[:,None]*N),N.T@w)
        return self.z_cache[key]

    def local_matrix(self,cell,geometry,order):
        scalar=self.grid.cell_ids(cell);ids=(scalar[:,None]*self.components+np.arange(self.components)).ravel()
        sig=geometry.signature(self.grid.bounds(cell)[:4]);fullkey=(tuple(self._axis_type(e,a) for a,e in enumerate(cell)),order)
        if sig[0]=='full' and fullkey in self.full_cache:
            K,f,vol=self.full_cache[fullkey];return ids,K,f,vol
        xy=self._plane_integrals(cell,geometry,order)
        if xy is None:return ids,None,None,0.
        M,H,B,fxy,area=xy;Z,DZ,BZ,fz=self._z_integrals(cell[2],order)
        ns=len(scalar);H3=np.empty((3,3,ns,ns))
        for a in range(2):
            for b in range(2):H3[a,b]=np.kron(H[a,b],Z)
            H3[a,2]=np.kron(B[a],BZ.T);H3[2,a]=np.kron(B[a].T,BZ)
        H3[2,2]=np.kron(M,DZ)
        scalar_f=np.kron(fxy,fz)
        if self.components==1:
            K=np.einsum('aaij->ij',H3)
            if self.reaction:K+=self.reaction*np.kron(M,Z)
            f=scalar_f
        else:
            K=self.mu*np.einsum('ab,ij->iajb',np.eye(3),np.einsum('aaij->ij',H3))
            K+=self.mu*np.einsum('baij->iajb',H3)+self.lam*np.einsum('abij->iajb',H3)
            K=K.reshape(len(ids),len(ids));f=(scalar_f[:,None]*np.array([0.,0.,-1.])).ravel()
        K=.5*(K+K.T);vol=area/self.grid.cells[2]
        if sig[0]=='full':self.full_cache[fullkey]=(K,f,vol)
        return ids,K,f,vol

    def assemble(self,geometry):
        start=perf_counter();n=self.grid.size*self.components
        update=self.incremental and self.previous is not None
        records=[];fractions=[];changed=[];changed_count=cached=0;measure=0.;strong=np.zeros(self.grid.size,dtype=bool)
        full_measure=1/np.prod(self.grid.cells)
        for cell in self.grid.cell_indices:
            signature=geometry.signature(self.grid.bounds(cell)[:4]);previous=self.cache.get(cell)
            if previous is not None and signature==previous[0]:record=previous[1];cached+=1
            else:
                record=self.local_matrix(cell,geometry,self.quadrature_order);self.cache[cell]=(signature,record);changed_count+=1;changed.extend(record[0])
            ids,K,f,volume=record;records.append(record);measure+=volume;fractions.append(volume/full_measure)
            if signature[0]=='full':strong[self.grid.cell_ids(cell)]=True
        changed_ids=np.unique(changed).astype(int)
        if update:
            # Replace the entire affected principal block, summing CURRENT
            # contributions from all incident cells. Never subtract old large
            # element energies from tiny current energies near vanishing cuts.
            selected=np.zeros(n,dtype=bool);selected[changed_ids]=True
            D=sparse.diags(selected.astype(float),format='csr')
            A=self.previous.A_full-D@self.previous.A_full@D
            rhs=self._full_rhs.copy();rhs[changed_ids]=0.
        else:
            selected=np.ones(n,dtype=bool);A=sparse.csr_matrix((n,n));rhs=np.zeros(n)
        rows=[];cols=[];values=[];entries=0
        def flush():
            nonlocal A,rows,cols,values,entries
            if not values:return
            part=sparse.coo_matrix((np.concatenate(values),(np.concatenate(rows),np.concatenate(cols))),shape=(n,n)).tocsr()
            A=A+part;rows=[];cols=[];values=[];entries=0
        for ids,K,f,volume in records:
            if K is None:continue
            take=np.flatnonzero(selected[ids])
            if not len(take):continue
            bg=ids[take];local=K[np.ix_(take,take)] if len(take)<len(ids) else K
            rhs[bg]+=f[take]
            rows.append(np.repeat(bg,len(bg)));cols.append(np.tile(bg,len(bg)));values.append(local.ravel());entries+=local.size
            if entries>=self.batch_entries:flush()
        flush();A.sum_duplicates();A.eliminate_zeros();diag=A.diagonal()
        if np.any(diag<0):raise ArithmeticError('negative assembled diagonal')
        free=np.flatnonzero((diag>0)&~self.fixed);weak=np.flatnonzero(~np.repeat(strong,self.components)[free])
        result=System(A[free,:][:,free].tocsr(),rhs[free],free,A,geometry,measure,np.asarray(fractions),changed_ids,changed_count,cached,perf_counter()-start,weak,self.grid,self.components)
        self.previous=result;self._full_rhs=rhs;return result


def coarse_prolongation(grid,ratio=2,components=1):
    """Exact nested B-spline coefficient map, including all background rows."""
    if any(n%ratio for n in grid.cells):raise ValueError('coarse ratio must divide every cell count')
    factors=[]
    for n,p,fineknots in zip(grid.cells,grid.degrees,grid.knots):
        nc=n//ratio;knots=np.r_[np.zeros(p),np.linspace(0,1,nc+1),np.ones(p)]
        spline=BSpline(knots,np.eye(nc+p),p,extrapolate=False)
        for i in range(1,n):
            if i%ratio:spline=spline.insert_knot(i/n)
        assert len(spline.t)==len(fineknots)
        factors.append(sparse.csr_matrix(spline.c[:n+p]))
    P=factors[0]
    for q in factors[1:]:P=sparse.kron(P,q,format='csr')
    return sparse.kron(P,sparse.eye(components),format='csr') if components>1 else P
