import numpy as np
import pytest
from scipy import sparse
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.geometry import TrimDomain
from cmame_trimmed.src.assembly import Assembler
from cmame_trimmed.revision_v2.tensor_assembly import TensorAssembler, coarse_prolongation

@pytest.mark.parametrize('physics',['poisson','elasticity'])
@pytest.mark.parametrize('degree',[2,3])
def test_tensor_local_matches_independent_full_quadrature(physics,degree):
    grid=SplineGrid((4,5,3),degree);domain=TrimDomain(holes=((.48,.51,.18),))
    old=Assembler(grid,physics=physics,quadrature=9);new=TensorAssembler(grid,physics=physics,quadrature=9)
    for cell in [(0,0,0),(1,2,1),(3,4,2)]:
        a=old.local_matrix(cell,domain,9);b=new.local_matrix(cell,domain,9)
        assert np.array_equal(a[0],b[0]);np.testing.assert_allclose(a[1],b[1],rtol=2e-12,atol=2e-14)
        np.testing.assert_allclose(a[2],b[2],rtol=1e-13,atol=1e-15);assert abs(a[3]-b[3])<1e-14

def test_chunk_assembly_and_incremental_cache_preserve_system():
    grid=SplineGrid((4,4,3),2);old=Assembler(grid,physics='elasticity',quadrature=7);new=TensorAssembler(grid,physics='elasticity',quadrature=7,batch_entries=100000)
    for domain in [TrimDomain(holes=((.48,.51,.17),)),TrimDomain(holes=((.49,.51,.17),))]:
        a=old.assemble(domain);b=new.assemble(domain)
        assert np.array_equal(a.ids,b.ids);assert np.array_equal(a.changed_ids,b.changed_ids)
        assert np.array_equal(a.weak_rows,b.weak_rows)
        assert sparse.linalg.norm(a.A-b.A)/sparse.linalg.norm(a.A)<1e-13
        np.testing.assert_allclose(a.b,b.b,rtol=1e-13,atol=1e-15)
        assert a.changed_cells==b.changed_cells and a.cached_cells==b.cached_cells

def test_nested_coarse_prolongation_reproduces_spline_values():
    fine=SplineGrid((8,6,4),3);coarse=SplineGrid((4,3,2),3)
    P=coarse_prolongation(fine,2,1)
    rng=np.random.default_rng(5);c=rng.normal(size=coarse.size)
    # Compare tensor collocation without relying on the prolongation routine.
    x=rng.uniform(0,1,(30,3))
    def basis(g):
        out=g.splines[0](x[:,0])
        for k in [1,2]:out=(out[:,:,None]*g.splines[k](x[:,k])[:,None,:]).reshape(len(x),-1)
        return out
    np.testing.assert_allclose(basis(fine)@(P@c),basis(coarse)@c,rtol=2e-13,atol=2e-14)

def test_tensor_assembler_rejects_untested_boundary_configuration():
    with pytest.raises(ValueError,match='left'):
        TensorAssembler(SplineGrid((4,4,4),2),bc='outer')

def test_incremental_sparse_updates_match_reconstruction_over_crossing_path():
    grid=SplineGrid((4,4,4),2)
    incremental=TensorAssembler(grid,physics='elasticity',quadrature=8,incremental=True)
    for t in range(12):
        domain=TrimDomain(holes=((.45+.002*t,.51,.18),),top=.70+.005*t)
        actual=incremental.assemble(domain)
        reference=TensorAssembler(grid,physics='elasticity',quadrature=8,incremental=False).assemble(domain)
        assert np.array_equal(actual.ids,reference.ids)
        assert sparse.linalg.norm(actual.A-reference.A)/sparse.linalg.norm(reference.A)<3e-14
        np.testing.assert_allclose(actual.b,reference.b,rtol=2e-13,atol=2e-16)

def test_shrinking_active_space_removes_only_zero_support_rows():
    grid=SplineGrid((4,4,4),2);a=TensorAssembler(grid,quadrature=8)
    for top in [.9,.76,.74,.51,.49,.26,.24]:
        domain=TrimDomain(top=top);actual=a.assemble(domain)
        reference=TensorAssembler(grid,quadrature=8,incremental=False).assemble(domain)
        assert np.array_equal(actual.ids,reference.ids)
        assert sparse.linalg.norm(actual.A-reference.A)/sparse.linalg.norm(reference.A)<3e-14
