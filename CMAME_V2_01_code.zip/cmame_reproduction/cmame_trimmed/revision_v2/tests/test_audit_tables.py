"""Synthetic-schema tests for reporting; never treated as measured evidence.

Prepared without execution during the formal timing campaign.
"""
import json
from pathlib import Path
import tempfile
import unittest

from cmame_trimmed.revision_v2 import audit_tables


def fixtures():
    return {
        'mechanism': {'complete': True, 'status': 'passed', 'decimal_precision': 80,
            'anchor_epsilon': '0.0001', 'tau': '.2',
            'positive_constants': {'b': 2.3, 'kappa0': 13.9, 'sufficient_epsilon_max': .0007},
            'leading_sets': [{'degree': 2, 'basis_indices': [1,2],
                'leading_principal_minors': ['4','4/3'], 'leading_gram_spd': True}],
            'rows': [dict(family='positive',epsilon=1e-6,normalized_condition=13.9,
                anchor_relative_drift=.0002,coupling_drift_from_limit=3e-7,
                within_sufficient_pair_region=True,small_cut_upper_bound=.01,
                small_cut_theorem_applicable=True),
                dict(family='counterexample',epsilon=1e-6,normalized_condition=4.8e13,
                epsilon_squared_condition=48.,anchor_relative_drift=.9999,
                coupling_drift_from_limit=2e-14,small_cut_theorem_applicable=False)],
            'checks': {'all_passed': True}},
        'quadrature': {'complete': True, 'status': 'failed',
            'config': {'degree':5,'cells':[6,6,4], 'reference_order':24,
                       'comparison_orders':[12,16,20]},
            'thresholds': {'matrix_relative_frobenius':1e-8,
                'solution_relative_reference_energy':1e-6,
                'current_residual_relative_l2':1e-8,
                'current_scaled_residual_relative_l2':1e-8},
            'reference': {'order':24,'dofs':100,
                'current_residual_relative_l2':1e-12,
                'current_scaled_residual_relative_l2':1e-12},
            'rows': [{'order':12,'passed':False,'matrix_relative_frobenius':1e-5,
                'rhs_relative_l2':1e-6,'solution_relative_reference_energy':1e-4,
                'current_residual_relative_l2':1e-12,
                'current_scaled_residual_relative_l2':1e-12},
                {'order':20,'passed':False,'error':'synthetic_failure: 100% invalid'}],
            'checks': {'all_passed':False}},
        'active': {'complete':False,'all_success':False,'repeats':1,
            'config': {'queries':2,'tau':.2},'methods':['fresh','energy'],
            'dense_spectral_cap':400,
            'geometry_audits':[{'repeat':0,'step':0,'initial':True,'dofs':100,
                'added_count':100,'deleted_count':0,'passed':True,
                'identical_active_ids':True,'matrix_relative_error':1e-14,'rhs_relative_error':1e-14},
                {'repeat':0,'step':1,'initial':False,'dofs':99,'added_count':1,
                 'deleted_count':2,'passed':False,'identical_active_ids':False,
                 'matrix_relative_error':1e-5,'rhs_relative_error':None}],
            'rows':[{'method':'fresh','repeat':0,'step':0,'success':False,
                     'residual':.2,'scaled_residual':.1,'energy_error':.3},
                    {'method':'energy','repeat':0,'step':0,'success':True,
                     'residual':1e-12,'scaled_residual':1e-12,'energy_error':1e-10,
                     'stat_randomized_checks':2,'active_ids_changed':True}],
            'local_audits':[{'method':'energy','dimension':700,
                'audit_kind':'three_rayleigh_lower_witnesses',
                'accepted_bound':.1,'rayleigh_lower_witness':.03,'bound_contradiction':False}],
            'failures':[{'stage':'policy_solve','repeat':0,'step':0,'method':'fresh',
                         'error':'synthetic unsuccessful solve'},
                        {'stage':'nonincremental_assembly_audit','repeat':0,'step':1,
                         'error':'synthetic mismatched active IDs'}]}}


class AuditTableTests(unittest.TestCase):
    def write(self, directory):
        for name,data in fixtures().items():
            (Path(directory)/(name+'_audit.json')).write_text(json.dumps(data))

    def test_requires_missing_audit_files(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(FileNotFoundError):
                audit_tables.audit_sections(directory)

    def test_counts_failures_and_keeps_witnesses_separate(self):
        with tempfile.TemporaryDirectory() as directory:
            self.write(directory)
            facts = audit_tables.audit_facts(directory)
            self.assertFalse(facts['active']['complete'])
            self.assertEqual(facts['active']['dense_spectrum_records'], 0)
            self.assertIsNone(facts['active']['maximum_full_spectrum_drift'])
            self.assertEqual(facts['active']['rayleigh_witness_records'], 1)
            self.assertEqual(facts['active']['assembly_failed_records'], 1)
            self.assertEqual(facts['active']['policy']['fresh']['failed_rows'], 1)
            self.assertEqual(facts['active']['policy']['fresh']['attempted_rows'], 1)
            self.assertEqual(facts['quadrature']['missing_orders'], [16])
            self.assertEqual(facts['quadrature']['failed_orders'], [12,20])
            json.dumps(facts, allow_nan=False)

    def test_latex_reports_missing_rows_failures_and_no_full_spectrum(self):
        with tempfile.TemporaryDirectory() as directory:
            self.write(directory)
            text = audit_tables.audit_sections(directory)
            self.assertIn('No full generalized spectrum was recorded', text)
            self.assertIn('not recorded', text)
            self.assertIn('incomplete', text)
            self.assertIn('100\\% invalid', text)
            self.assertIn('Rayleigh lower', text)
            self.assertIn('48', text)

    def test_failed_mechanism_checks_are_not_reworded_as_success(self):
        with tempfile.TemporaryDirectory() as directory:
            self.write(directory)
            path = Path(directory)/'mechanism_audit.json'
            data = json.loads(path.read_text())
            data['status']='failed';data['checks']={'all_passed':False,'example_check':False}
            path.write_text(json.dumps(data))
            text = audit_tables.audit_sections(directory)
            self.assertIn('example\\_check',text)
            facts = audit_tables.audit_facts(directory)
            self.assertFalse(facts['mechanism']['reported_all_checks_passed'])


if __name__ == '__main__':
    unittest.main()
