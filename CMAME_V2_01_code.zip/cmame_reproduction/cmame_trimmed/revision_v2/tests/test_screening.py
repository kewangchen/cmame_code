"""Independent small-matrix oracles for progressive energy screening."""
import importlib
from pathlib import Path
import unittest

import numpy as np
from scipy import linalg, sparse

from cmame_trimmed.src import preconditioners as old


class ScreeningTests(unittest.TestCase):
    def api(self):
        path = Path(__file__).parents[1] / 'screening.py'
        self.assertTrue(path.exists(), 'progressive screening implementation is missing')
        return importlib.import_module('cmame_trimmed.revision_v2.screening')

    def test_budget_spends_once_per_candidate_and_replays(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=7, probes=12, power=2)
        other = api.ProgressiveEnergyBudget(seed=7, probes=12, power=2)
        f = old.LocalFactor.factor(np.eye(5))
        results = [api.progressive_bound(f, .001*np.eye(5), state, tau=.2) for _ in range(8)]
        replay = [api.progressive_bound(f, .001*np.eye(5), other, tau=.2) for _ in range(8)]
        self.assertEqual(results, replay)
        self.assertEqual(state.count, 8)
        expected = 6*state.delta_total/np.pi**2*sum(1/j**2 for j in range(1, 9))
        self.assertAlmostEqual(state.spent_failure_budget, expected, places=22)
        self.assertLess(state.spent_failure_budget, state.delta_total)
        self.assertEqual(state.action_batches, 8)
        self.assertEqual(state.column_actions, 8*state.probes)
        self.assertEqual(state.early_accepts, 8)

    def test_small_drift_accepts_after_one_action(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=123, probes=12, power=2)
        f = old.LocalFactor.factor(np.eye(6))
        bound = api.progressive_bound(f, .001*np.eye(6), state, tau=.2)
        omega = np.random.default_rng(123).standard_normal((6, 12))
        alpha = np.sqrt(2/np.pi)*(6e-8/np.pi**2)**(-1/12)
        self.assertAlmostEqual(bound, alpha*.001*np.linalg.norm(omega, axis=0).max(), places=14)
        self.assertLessEqual(bound, .2)
        self.assertEqual(state.action_batches, 1)
        self.assertEqual(state.early_accepts, 1)

    def test_large_isotropic_drift_rejects_after_one_action(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=123, power=4)
        bound = api.progressive_bound(old.LocalFactor.factor(np.eye(8)), .3*np.eye(8), state, tau=.2)
        self.assertGreater(bound, .2)
        self.assertEqual(state.action_batches, 1)
        self.assertEqual(state.early_rejections, 1)
        self.assertEqual(state.count, 1)

    def test_second_power_matches_frozen_baseline(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=123, probes=12, power=2)
        baseline = old.EnergyBudget(seed=123, probes=12, power=2)
        factor = old.LocalFactor.factor(np.eye(6))
        change = .035*np.eye(6)
        actual = api.progressive_bound(factor, change, state, tau=.2)
        expected = old._probabilistic_bound(factor, change, baseline)
        self.assertAlmostEqual(actual, expected, places=14)
        self.assertLessEqual(actual, .2)
        self.assertEqual(state.action_batches, 2)
        self.assertEqual(state.early_accepts, 0)
        self.assertEqual(state.early_rejections, 0)
        self.assertEqual(repr(state.rng.bit_generator.state), repr(baseline.rng.bit_generator.state))

    def test_independent_generalized_eigenvalues_for_actual_accepted_matrices(self):
        api = self.api()
        rng = np.random.default_rng(91)
        state = api.ProgressiveEnergyBudget(seed=444, probes=12, power=2)
        for n in (3, 7, 11):
            q = rng.normal(size=(n, n))
            anchor = q.T@q + np.eye(n)
            factor = old.LocalFactor.factor(anchor)
            delta = .002*rng.normal(size=(n, n))
            delta = (delta+delta.T)/2
            change = delta/factor.scale[:, None]/factor.scale[None, :]
            bound = api.progressive_bound(factor, change, state, tau=.2)
            exact = np.abs(linalg.eigvalsh(delta, anchor)).max()
            self.assertLessEqual(bound, .2)
            self.assertLessEqual(exact, bound*(1+1e-12))

    def test_wrapper_preserves_global_spectral_contract_and_original_function(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=12)
        original_bound = old._probabilistic_bound
        anchor = np.diag(np.arange(1., 7.)) + .1*np.ones((6, 6))
        blocks = [np.arange(4), np.arange(2, 6)]
        ids = np.arange(6)
        _, cache, _ = api.build_progressive_schwarz(sparse.csr_matrix(anchor), blocks, ids,
                                                   mode='prob_energy', probability_state=state)
        current = 1.001*anchor
        op, cache, stats = api.build_progressive_schwarz(sparse.csr_matrix(current), blocks, ids,
                         mode='prob_energy', probability_state=state, cache=cache, tau=.2)
        fresh, _, _ = old.build_schwarz(sparse.csr_matrix(current), blocks, ids)
        eigenvalues = linalg.eigvalsh(op@np.eye(6), fresh@np.eye(6))
        self.assertGreaterEqual(eigenvalues.min(), .8-1e-12)
        self.assertLessEqual(eigenvalues.max(), 1.2+1e-12)
        self.assertEqual(stats['screen_action_batches'], 2)
        self.assertEqual(stats['screen_column_actions'], 24)
        self.assertEqual(stats['screen_early_accepts'], 2)
        self.assertEqual(stats['screen_early_rejections'], 0)
        self.assertEqual(stats['reused_energy'], 2)
        self.assertIs(original_bound, old._probabilistic_bound)
        self.assertTrue(all(f.inverse_diagonal is None for f in cache.values()))

    def test_wrapper_unchanged_provenance_and_dimension_skip(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=12, min_dimension=3)
        a = sparse.eye(3, format='csr')
        args = (a, [np.arange(3)], np.arange(3))
        _, cache, cold = api.build_progressive_schwarz(*args, mode='prob_energy', probability_state=state)
        _, _, exact = api.build_progressive_schwarz(*args, mode='prob_energy', probability_state=state, cache=cache)
        _, _, skipped = api.build_progressive_schwarz(1.001*a, args[1], args[2], mode='prob_energy', probability_state=state, cache=cache)
        self.assertEqual(cold['screen_action_batches'], 0)
        self.assertEqual(exact['reused_exact'], 1)
        self.assertEqual(skipped['skipped_small_blocks'], 1)
        self.assertEqual(state.count, 0)
        state = api.ProgressiveEnergyBudget(seed=12)
        _, cache, _ = api.build_progressive_schwarz(*args, mode='prob_energy', probability_state=state)
        _, cache, _ = api.build_progressive_schwarz(1.001*a, args[1], args[2], mode='prob_energy', probability_state=state, cache=cache)
        _, _, skipped = api.build_progressive_schwarz(1.001*a, args[1], args[2], mode='prob_energy', probability_state=state, cache=cache, changed_global_ids=[])
        self.assertEqual(skipped['reused_unchanged'], 1)
        self.assertEqual(skipped['screen_action_batches'], 0)
        other = api.ProgressiveEnergyBudget(seed=12)
        _, _, rechecked = api.build_progressive_schwarz(1.001*a, args[1], args[2], mode='prob_energy', probability_state=other, cache=cache, changed_global_ids=[])
        self.assertEqual(rechecked['randomized_checks'], 1)

    def test_zero_operator_and_repeated_powers(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=1, power=5)
        self.assertEqual(api.progressive_bound(old.LocalFactor.factor(np.eye(3)), np.zeros((3, 3)), state, tau=0.), 0.)
        self.assertEqual(state.action_batches, 1)
        self.assertEqual(state.early_accepts, 1)

    def test_nonfinite_and_asymmetry_fail_closed_without_spending(self):
        api = self.api()
        factor = old.LocalFactor.factor(np.eye(3))
        state = api.ProgressiveEnergyBudget(seed=1)
        for value in (np.nan, np.inf):
            with self.assertRaises((ValueError, FloatingPointError)):
                api.progressive_bound(factor, value*np.ones((3, 3)), state, tau=.2)
        with self.assertRaises(ValueError):
            api.progressive_bound(factor, np.triu(np.ones((3, 3))), state, tau=.2)
        self.assertEqual(state.count, 0)
        self.assertEqual(state.action_batches, 0)

    def test_assembled_extruded_spline_drift_against_generalized_eigenvalues(self):
        from cmame_trimmed.src.assembly import Assembler
        from cmame_trimmed.src.geometry import TrimDomain
        from cmame_trimmed.src.space import SplineGrid
        api = self.api()
        assembler = Assembler(SplineGrid((3, 3, 2), 2), quadrature=5)
        first = assembler.assemble(TrimDomain(top=.81))
        second = assembler.assemble(TrimDomain(top=.810001))
        np.testing.assert_array_equal(first.ids, second.ids)
        anchor = first.A.toarray()
        delta = (second.A-first.A).toarray()
        factor = old.LocalFactor.factor(anchor)
        change = delta/factor.scale[:, None]/factor.scale[None, :]
        state = api.ProgressiveEnergyBudget(seed=810, probes=12, power=2)
        bound = api.progressive_bound(factor, change, state, tau=.2)
        actual = np.abs(linalg.eigvalsh(delta, anchor)).max()
        self.assertLessEqual(bound, .2)
        self.assertLessEqual(actual, bound*(1+1e-7))

    def test_full_rejection_matches_original_bound(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=123, probes=12, power=2)
        other = old.EnergyBudget(seed=123, probes=12, power=2)
        factor = old.LocalFactor.factor(np.eye(6))
        change = .08*np.eye(6)
        actual = api.progressive_bound(factor, change, state, tau=.2)
        self.assertGreater(actual, .2)
        self.assertAlmostEqual(actual, old._probabilistic_bound(factor, change, other), places=14)
        self.assertEqual(state.action_batches, 2)
        self.assertEqual(state.early_rejections, 0)
        self.assertEqual(state.lower_bound_rejections, 0)

    def test_subnormal_scale_preserves_nonzero_bound(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=7, power=4)
        bound = api.progressive_bound(old.LocalFactor.factor(np.eye(4)), 1e-250*np.eye(4), state, tau=0.)
        self.assertTrue(np.isfinite(bound))
        self.assertGreater(bound, 0.)
        self.assertEqual(state.action_batches, 1)
        self.assertEqual(state.early_rejections, 1)

    def test_nonfinite_action_records_spent_budget_and_attempted_work(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=1)
        with self.assertRaises(FloatingPointError):
            api.progressive_bound(old.LocalFactor.factor(np.eye(3)), 1e308*np.eye(3), state, tau=.2)
        self.assertEqual(state.count, 1)
        self.assertGreater(state.spent_failure_budget, 0.)
        self.assertEqual(state.action_batches, 1)
        self.assertEqual(state.column_actions, state.probes)

    def test_builder_uses_validated_input_fastpath(self):
        from unittest import mock
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=123)
        args = (sparse.eye(4, format='csr'), [np.arange(4)], np.arange(4))
        _, cache, _ = api.build_progressive_schwarz(*args, probability_state=state)
        original = api.progressive_bound
        flags = []
        def record(*args, **kwargs):
            flags.append(kwargs.get('validate', True))
            return original(*args, **kwargs)
        with mock.patch.object(api, 'progressive_bound', side_effect=record):
            _, _, stats = api.build_progressive_schwarz(1.001*args[0], args[1], args[2],
                                                   probability_state=state, cache=cache)
        self.assertEqual(flags, [False])
        self.assertEqual(stats['reused_energy'], 1)
        # External sparse-matrix validation still runs before the callback.
        bad = sparse.eye(4, format='csr'); bad.data[0] = np.nan
        with self.assertRaises(ValueError):
            api.build_progressive_schwarz(bad, args[1], args[2], probability_state=state, cache=cache)

    def test_dimension_cost_cap_is_immutable_and_requires_a_boolean(self):
        from dataclasses import FrozenInstanceError
        api = self.api()
        for invalid in (0, 1, 'yes', None, np.bool_(True)):
            with self.assertRaises(ValueError):
                api.ProgressiveEnergyBudget(dimension_cost_cap=invalid)
        state = api.ProgressiveEnergyBudget(dimension_cost_cap=True, power=6)
        with self.assertRaises(FrozenInstanceError):
            state.dimension_cost_cap = False
        self.assertEqual(state.effective_power(143), 1)
        self.assertEqual(state.effective_power(144), 1)
        self.assertEqual(state.effective_power(288), 2)
        self.assertEqual(state.effective_power(864), 6)
        self.assertEqual(state.effective_power(1440), 6)
        unlimited = api.ProgressiveEnergyBudget(power=6)
        self.assertEqual(unlimited.effective_power(1), 6)

    def test_dimension_caps_one_two_six_match_baseline_and_count_actual_work(self):
        api = self.api()
        for dimension, expected_power in ((12, 1), (24, 2), (72, 6)):
            state = api.ProgressiveEnergyBudget(seed=8, probes=1, power=6, dimension_cost_cap=True)
            baseline = old.EnergyBudget(seed=8, probes=1, power=expected_power)
            factor = old.LocalFactor.factor(np.eye(dimension))
            change = .05*np.eye(dimension)
            actual = api.progressive_bound(factor, change, state, tau=.2)
            expected = old._probabilistic_bound(factor, change, baseline)
            self.assertGreater(actual, .2)
            self.assertAlmostEqual(actual, expected, delta=1e-12*expected)
            self.assertEqual(state.action_batches, expected_power)
            self.assertEqual(state.early_accepts, 0)
            self.assertEqual(state.early_rejections, 0)
            self.assertEqual(state.avoided_action_batches, 0)
            self.assertEqual(state.cost_cap_avoided_action_batches, 6-expected_power)
            self.assertEqual(state.cost_capped_checks, int(expected_power<6))
            self.assertEqual(state.last_effective_power, expected_power)
            self.assertEqual(state.effective_power_histogram, {expected_power: 1})
            self.assertEqual(state.count, 1)

    def test_cost_cap_acceptance_against_independent_dense_spectrum(self):
        api = self.api()
        rng = np.random.default_rng(122)
        for n in (12, 24, 72):
            q = rng.normal(size=(n,n))
            anchor = q.T@q+np.eye(n)
            delta = rng.normal(size=(n,n))*1e-10
            delta = (delta+delta.T)/2
            factor = old.LocalFactor.factor(anchor)
            change = delta/factor.scale[:,None]/factor.scale[None,:]
            state = api.ProgressiveEnergyBudget(seed=17, probes=1, power=6, dimension_cost_cap=True)
            bound = api.progressive_bound(factor, change, state, tau=.2)
            actual = np.abs(linalg.eigvalsh(delta,anchor)).max()
            self.assertLessEqual(bound,.2)
            self.assertLessEqual(actual,bound*(1+1e-11))
            cap = min(6,max(1,n//12))
            stopped = next(iter(state.power_histogram))
            self.assertEqual(state.avoided_action_batches,cap-stopped)
            self.assertEqual(state.early_accepts,int(stopped<cap))

    def test_wrapper_reports_effective_cap_and_resets_build_deltas(self):
        api = self.api()
        state = api.ProgressiveEnergyBudget(seed=12, probes=1, power=6, dimension_cost_cap=True)
        a = sparse.eye(24,format='csr');rows=[np.arange(24)];ids=np.arange(24)
        _,cache,_=api.build_progressive_schwarz(a,rows,ids,probability_state=state)
        _,cache,stats=api.build_progressive_schwarz(1.000000001*a,rows,ids,cache=cache,probability_state=state)
        self.assertTrue(stats['screen_dimension_cost_cap'])
        self.assertEqual(stats['screen_cost_capped_checks'],1)
        self.assertEqual(stats['screen_cost_cap_avoided_action_batches'],4)
        self.assertEqual(stats['screen_effective_power_histogram'],{'2':1})
        _,_,unchanged=api.build_progressive_schwarz(1.000000001*a,rows,ids,cache=cache,probability_state=state,changed_global_ids=[])
        self.assertEqual(unchanged['screen_cost_capped_checks'],0)
        self.assertEqual(unchanged['screen_effective_power_histogram'],{})
        self.assertEqual(unchanged['cumulative_screen_cost_capped_checks'],1)

    def test_invalid_threshold_and_wrong_budget(self):
        api = self.api()
        factor = old.LocalFactor.factor(np.eye(3))
        for tau in (-.1, 1., np.nan):
            with self.assertRaises(ValueError):
                api.progressive_bound(factor, np.eye(3), api.ProgressiveEnergyBudget(), tau=tau)
        with self.assertRaises(TypeError):
            api.progressive_bound(factor, np.eye(3), old.EnergyBudget(), tau=.2)
        with self.assertRaises(TypeError):
            api.build_progressive_schwarz(sparse.eye(3), [np.arange(3)], np.arange(3), mode='prob_energy', probability_state=old.EnergyBudget())


if __name__ == '__main__':
    unittest.main()
