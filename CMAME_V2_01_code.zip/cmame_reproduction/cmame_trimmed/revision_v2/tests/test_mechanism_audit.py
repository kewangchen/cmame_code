"""Correctness tests prepared for serial execution AFTER formal timings.

These tests are intentionally not run by the authoring agent while the formal
campaign is active. They do not run the high-order quadrature audit.
"""
import json
import tempfile
import unittest
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
from types import SimpleNamespace

from cmame_trimmed.revision_v2 import mechanism_audit as audit


def integrate_product(a, b, endpoint):
    """Independent exact integration of two polynomial coefficient lists."""
    return sum(Fraction(u)*Fraction(v)*endpoint**(i+j+1)/Fraction(i+j+1)
               for i,u in enumerate(a) for j,v in enumerate(b))


class MechanismAuditTests(unittest.TestCase):
    def test_actual_spline_stiffness_matches_independent_polynomial_integral(self):
        endpoint = Fraction(1, 10)
        families = {'positive': ([2, -4], [0, 2]),
                    'counterexample': ([-2, 2], [2, -4])}
        with localcontext() as ctx:
            ctx.prec = 80
            for family, gradients in families.items():
                row = audit.bernstein_pair('0.1', family)
                for i in range(2):
                    for j in range(2):
                        exact = integrate_product(gradients[i], gradients[j], endpoint)
                        expected = Decimal(exact.numerator)/Decimal(exact.denominator)
                        actual = Decimal(row['decimal']['stiffness'][i][j])
                        self.assertLess(abs(actual-expected), Decimal('1e-70'))

    def test_counterexample_small_eigenvalue_and_coefficient_survive_small_cut(self):
        row = audit.bernstein_pair('0.000001', 'counterexample')
        value = Decimal(row['decimal']['epsilon_squared_condition'])
        self.assertLess(abs(value-Decimal(48)), Decimal('0.001'))
        self.assertGreater(Decimal(row['decimal']['lambda_min_normalized']), 0)
        self.assertGreater(row['anchor_relative_drift'], .99)
        self.assertFalse(row['leading_gram_spd'])
        self.assertFalse(row['small_cut_theorem_applicable'])
        self.assertIsNone(row['small_cut_upper_bound'])

    def test_positive_pair_constants_and_sufficient_region(self):
        with localcontext() as ctx:
            ctx.prec = 80
            constants = audit.positive_constants()
            b = Decimal(constants['decimal']['b'])
            self.assertLess(abs(b*b-Decimal(16)/3), Decimal('1e-70'))
        row = audit.bernstein_pair('0.000001', 'positive')
        self.assertTrue(row['leading_gram_spd'])
        self.assertTrue(row['small_cut_theorem_applicable'])
        self.assertTrue(row['within_sufficient_pair_region'])
        self.assertLessEqual(row['anchor_relative_drift'], row['small_cut_upper_bound'])
        self.assertLessEqual(row['anchor_relative_drift'], .2)

    def test_anchor_drift_matches_independent_generalized_eigensolver(self):
        import numpy as np
        from scipy.linalg import eigvalsh
        for family in ('positive', 'counterexample'):
            current = audit.bernstein_pair('0.03', family, anchor_epsilon='0.04')
            anchor = audit.bernstein_pair('0.04', family, anchor_epsilon='0.04')
            C = np.array([[1., current['correlation']], [current['correlation'], 1.]])
            H = np.array([[1., anchor['correlation']], [anchor['correlation'], 1.]])
            oracle = max(abs(eigvalsh(C-H, H)))
            self.assertAlmostEqual(current['anchor_relative_drift'], oracle, places=9)

    def test_exact_leading_gram_principal_minors_are_positive(self):
        sets = audit.bernstein_leading_sets((2, 3, 5))
        for record in sets:
            self.assertTrue(all(Fraction(v)>0 for v in record['leading_principal_minors']))
        self.assertEqual(Fraction(sets[0]['leading_principal_minors'][-1]), Fraction(4, 3))

    def test_snapshot_copies_identical_bytes_and_hashes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root/'source.py'
            source.write_bytes(b'answer = 42\n')
            hashes = audit.snapshot_sources([source], root, root/'snapshot')
            self.assertEqual((root/'snapshot/source.py').read_bytes(), source.read_bytes())
            self.assertEqual(hashes['source.py'], audit.sha256(source))

    def test_quadrature_metrics_use_reference_energy_and_reject_different_ids(self):
        import numpy as np
        from scipy import sparse
        reference = SimpleNamespace(A=sparse.diags([2., 8.], format='csr'),
                                    b=np.array([2., 8.]), ids=np.array([3, 7]))
        current = SimpleNamespace(A=sparse.diags([2.1, 8.], format='csr'),
                                  b=np.array([2.1, 8.]), ids=reference.ids.copy())
        metrics = audit.comparison_metrics(current, reference,
                                           np.array([1.01, 1.]), np.ones(2))
        self.assertAlmostEqual(metrics['matrix_relative_frobenius'], .1/(68**.5))
        self.assertAlmostEqual(metrics['solution_relative_reference_energy'], (2*.01**2/10)**.5)
        current.ids = np.array([3, 8])
        with self.assertRaises(ValueError):
            audit.comparison_metrics(current, reference, np.ones(2), np.ones(2))

    def test_mechanism_report_does_not_assign_theorem_to_counterexample(self):
        report = audit.mechanism_report(('0.1', '0.001', '0.000001'))
        self.assertTrue(report['checks']['all_passed'])
        negative = [r for r in report['rows'] if r['family']=='counterexample']
        self.assertTrue(negative)
        self.assertTrue(all(not r['small_cut_theorem_applicable'] for r in negative))
        json.dumps(report, allow_nan=False)


if __name__ == '__main__':
    unittest.main()
