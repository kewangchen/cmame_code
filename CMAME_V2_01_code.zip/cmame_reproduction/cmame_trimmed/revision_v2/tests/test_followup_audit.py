"""Small audit regressions; no benchmark or assembled PDE is required."""
import unittest

import numpy as np

from cmame_trimmed.src.preconditioners import LocalFactor
from cmame_trimmed.revision_v2 import cost_ablation as followup
from cmame_trimmed.revision_v2.cost_screening import build_cost_schwarz
from cmame_trimmed.revision_v2.lookahead_screening import (
    LookaheadEnergyBudget, build_lookahead_schwarz,
)
from cmame_trimmed.revision_v2.screening import (
    ProgressiveEnergyBudget, build_progressive_schwarz,
)


METHODS = ('progressive', 'lookahead')
COUNTERS = ('new', 'refreshed', 'reused_energy', 'reused_exact',
            'reused_unchanged', 'retired')
COMPARISONS = ('anchors_equal', 'solutions_equal', 'rng_states_equal',
               'draw_counts_equal', 'factor_counts_equal')


class FollowupAuditTests(unittest.TestCase):
    def fixture(self):
        """Independent real two-by-two factors and fresh matching probe states."""
        anchor = np.array([[2., .25], [.25, 1.]])
        caches = {m: {(4, 7): LocalFactor.factor(anchor)} for m in METHODS}
        previous = {m: (np.array([4, 7]), np.array([.1, -.2])) for m in METHODS}
        states = {
            'progressive': ProgressiveEnergyBudget(seed=17, probes=12, power=6),
            'lookahead': LookaheadEnergyBudget(seed=17, probes=12, power=6),
        }
        rows = {m: dict(success=True, **{'stat_'+n: 0 for n in COUNTERS})
                for m in METHODS}
        for row in rows.values():
            row['stat_new'] = 1
        return caches, previous, states, rows

    def audit(self, fixture):
        return followup.lookahead_audit(2, 9, *fixture)

    def assert_unavailable(self, audit):
        self.assertFalse(audit['pair_available'])
        for key in COMPARISONS + ('progressive_anchor_sha256',
                                  'lookahead_anchor_sha256'):
            self.assertIsNone(audit[key], key)

    def test_digest_covers_membership_anchor_and_not_dictionary_order(self):
        cache, _, _, _ = self.fixture()
        first = cache['progressive']
        factor = first[(4, 7)]
        changed_membership = {(4, 8): factor}
        changed_anchor = {(4, 7): LocalFactor.factor(
            np.array([[2., .25], [.25, 1.125]]))}
        expected = followup.anchor_digest(first)
        self.assertNotEqual(expected, followup.anchor_digest(changed_membership))
        self.assertNotEqual(expected, followup.anchor_digest(changed_anchor))
        # Separate blocks and their dictionary insertion order have no effect.
        extra = LocalFactor.factor(np.array([[3.]]))
        ordered = {(4, 7): factor, (11,): extra}
        reversed_order = {(11,): extra, (4, 7): factor}
        self.assertEqual(followup.anchor_digest(ordered),
                         followup.anchor_digest(reversed_order))
        self.assertNotEqual(expected, followup.anchor_digest(ordered))

    def test_independent_matching_cache_solution_and_states_pass(self):
        audit = self.audit(self.fixture())
        self.assertEqual((audit['repeat'], audit['step']), (2, 9))
        self.assertTrue(audit['pair_available'])
        self.assertEqual(audit['progressive_anchor_sha256'],
                         audit['lookahead_anchor_sha256'])
        for key in COMPARISONS:
            self.assertTrue(audit[key], key)

    def test_changed_cache_and_solution_are_detected_independently(self):
        fixture = self.fixture()
        cache, previous, _, _ = fixture
        cache['lookahead'] = {(4, 8): cache['lookahead'][(4, 7)]}
        previous['lookahead'][1][0] = np.nextafter(.1, np.inf)
        audit = self.audit(fixture)
        self.assertTrue(audit['pair_available'])
        self.assertFalse(audit['anchors_equal'])
        self.assertFalse(audit['solutions_equal'])
        self.assertTrue(audit['rng_states_equal'])
        self.assertTrue(audit['draw_counts_equal'])
        self.assertTrue(audit['factor_counts_equal'])

    def test_identical_coefficient_values_with_different_ids_do_not_match(self):
        fixture = self.fixture()
        fixture[1]['lookahead'][0][1] = 8
        audit = self.audit(fixture)
        self.assertTrue(audit['pair_available'])
        self.assertFalse(audit['solutions_equal'])
        self.assertTrue(audit['anchors_equal'])
        self.assertTrue(audit['rng_states_equal'])

    def test_failure_or_missing_cache_cannot_report_equivalence(self):
        for method in METHODS:
            with self.subTest(method=method, reason='unsuccessful row'):
                fixture = self.fixture()
                fixture[3][method]['success'] = False
                # Keep stale arrays deliberately: the row must still gate them.
                self.assert_unavailable(self.audit(fixture))
            with self.subTest(method=method, reason='missing previous solution'):
                fixture = self.fixture()
                fixture[1][method] = None
                self.assert_unavailable(self.audit(fixture))
            with self.subTest(method=method, reason='missing cache'):
                fixture = self.fixture()
                fixture[0].pop(method)
                self.assert_unavailable(self.audit(fixture))
            with self.subTest(method=method, reason='empty cache'):
                fixture = self.fixture()
                fixture[0][method] = {}
                self.assert_unavailable(self.audit(fixture))

    def test_rng_state_and_draw_counter_are_independent_checks(self):
        fixture = self.fixture()
        states = fixture[2]
        # Consume random numbers without spending an EnergyBudget draw.
        states['lookahead'].rng.standard_normal(1)
        audit = self.audit(fixture)
        self.assertFalse(audit['rng_states_equal'])
        self.assertTrue(audit['draw_counts_equal'])

        fixture = self.fixture()
        states = fixture[2]
        states['progressive'].draw(2)
        # Match the actual RNG advance but deliberately omit its budget update.
        states['lookahead'].rng.standard_normal((2, 12))
        audit = self.audit(fixture)
        self.assertTrue(audit['rng_states_equal'])
        self.assertFalse(audit['draw_counts_equal'])

        fixture = self.fixture()
        for state in fixture[2].values():
            state.draw(2)
        audit = self.audit(fixture)
        self.assertTrue(audit['rng_states_equal'])
        self.assertTrue(audit['draw_counts_equal'])

    def test_each_reported_factor_counter_is_compared(self):
        for counter in COUNTERS:
            with self.subTest(counter=counter):
                fixture = self.fixture()
                fixture[3]['lookahead']['stat_'+counter] += 1
                audit = self.audit(fixture)
                self.assertFalse(audit['factor_counts_equal'])
                for key in COMPARISONS[:-1]:
                    self.assertTrue(audit[key], key)

    def test_followup_solver_clones_keep_builder_routes_isolated(self):
        original = followup.solve_revised.__globals__
        cost = followup._cost_solver.__globals__
        lookahead = followup._lookahead_solver.__globals__
        self.assertIsNot(original, cost)
        self.assertIsNot(original, lookahead)
        self.assertIsNot(cost, lookahead)
        self.assertIs(original['build_progressive_schwarz'], build_progressive_schwarz)
        self.assertIs(cost['build_progressive_schwarz'], build_cost_schwarz)
        self.assertIs(lookahead['build_progressive_schwarz'], build_lookahead_schwarz)
        self.assertEqual(followup.METHODS,
                         ['energy', 'progressive', 'cost', 'lookahead'])


if __name__ == '__main__':
    unittest.main()
