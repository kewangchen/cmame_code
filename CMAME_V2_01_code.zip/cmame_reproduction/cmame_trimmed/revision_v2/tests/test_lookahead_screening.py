"""Independent fixed-stream comparisons for secant lookahead; not timing tests."""
from dataclasses import FrozenInstanceError
from math import log
import unittest

import numpy as np
from scipy import linalg, sparse

from cmame_trimmed.src.preconditioners import LocalFactor
from cmame_trimmed.revision_v2.screening import (
    ProgressiveEnergyBudget, progressive_bound, build_progressive_schwarz,
)
from cmame_trimmed.revision_v2 import lookahead_screening as look


class LookaheadTests(unittest.TestCase):
    def test_signed_isotropic_candidate_below_tau_can_be_pruned(self):
        for sign in (np.ones(72), -np.ones(72), np.resize([-1.,1.],72)):
            change=np.diag(.15*sign);factor=LocalFactor.factor(np.eye(72))
            old=ProgressiveEnergyBudget(seed=123,probes=12,power=6)
            state=look.LookaheadEnergyBudget(seed=123,probes=12,power=6)
            expected=progressive_bound(factor,change,old,tau=.2)
            actual=look.lookahead_bound(factor,change,state,tau=.2)
            self.assertGreater(expected,.2)
            self.assertGreater(actual,.2)
            self.assertAlmostEqual(np.abs(linalg.eigvalsh(change)).max(),.15)
            self.assertEqual(old.action_batches,6)
            self.assertEqual(state.action_batches,1)
            self.assertEqual(state.lookahead_rejections,1)
            self.assertEqual(state.lookahead_avoided_action_batches,5)
            self.assertEqual(state.lower_bound_rejections,0)
            self.assertEqual(state.early_rejections,0)
            self.assertEqual(state.lookahead_power_histogram,{1:1})

    def test_inconclusive_first_power_must_continue_then_accept(self):
        factor=LocalFactor.factor(np.eye(6));change=.035*np.eye(6)
        old=ProgressiveEnergyBudget(seed=123,probes=12,power=6)
        state=look.LookaheadEnergyBudget(seed=123,probes=12,power=6)
        expected=progressive_bound(factor,change,old,tau=.2)
        actual=look.lookahead_bound(factor,change,state,tau=.2)
        self.assertLessEqual(actual,.2)
        self.assertAlmostEqual(actual,expected,places=14)
        self.assertEqual(state.action_batches,2)
        self.assertEqual(state.lookahead_rejections,0)
        self.assertGreaterEqual(state.lookahead_evaluations,1)

    def test_dense_symmetric_cases_preserve_unpruned_decisions_and_stream(self):
        rng=np.random.default_rng(932)
        for n in (3,7,11,24):
            q=rng.normal(size=(n,n));h=q.T@q+np.eye(n)
            factor=LocalFactor.factor(h)
            rotation,_=np.linalg.qr(rng.normal(size=(n,n)))
            for radius in (0.,.001,.02,.08,.15,.19,.21,.45):
                for probes in (1,4,12):
                    eigenvalues=radius*np.linspace(-1.,1.,n)
                    k=(rotation*eigenvalues)@rotation.T
                    change=factor.cholesky@k@factor.cholesky.T
                    for seed in (1,13,102):
                        old=ProgressiveEnergyBudget(seed=seed,probes=probes,power=6)
                        state=look.LookaheadEnergyBudget(seed=seed,probes=probes,power=6)
                        expected=progressive_bound(factor,change,old,tau=.2)
                        actual=look.lookahead_bound(factor,change,state,tau=.2)
                        self.assertEqual(actual<=.2,expected<=.2,
                                         (n,radius,probes,seed,actual,expected))
                        self.assertLessEqual(state.action_batches,old.action_batches)
                        if actual<=.2:
                            self.assertAlmostEqual(actual,expected,delta=1e-12*max(1.,expected))
                            delta=factor.scale[:,None]*change*factor.scale[None,:]
                            independent=np.abs(linalg.eigvalsh(delta,h)).max()
                            self.assertLessEqual(independent,actual*(1+1e-9)+1e-13)
                        self.assertEqual(state.count,old.count)
                        self.assertEqual(state.spent_failure_budget,old.spent_failure_budget)
                        self.assertEqual(repr(state.rng.bit_generator.state),repr(old.rng.bit_generator.state))
                        self.assertEqual(6-state.action_batches,
                            state.avoided_action_batches+state.lookahead_avoided_action_batches)

    def test_zero_and_tau_zero_use_existing_decisions(self):
        factor=LocalFactor.factor(np.eye(4))
        for tau in (0.,.2):
            state=look.LookaheadEnergyBudget(seed=1,power=6)
            self.assertEqual(look.lookahead_bound(factor,np.zeros((4,4)),state,tau=tau),0.)
            self.assertEqual(state.action_batches,1)
            self.assertEqual(state.lookahead_evaluations,0)
            self.assertEqual(state.lookahead_rejections,0)
        state=look.LookaheadEnergyBudget(seed=1,power=6)
        self.assertGreater(look.lookahead_bound(factor,1e-250*np.eye(4),state,tau=0.),0.)
        self.assertEqual(state.lower_bound_rejections,1)
        self.assertEqual(state.lookahead_evaluations,0)

    def test_dimension_cap_and_pruning_savings_remain_separate(self):
        for n,cap in ((12,1),(24,2),(72,6)):
            state=look.LookaheadEnergyBudget(seed=8,probes=1,power=6,dimension_cost_cap=True)
            actual=look.lookahead_bound(LocalFactor.factor(np.eye(n)),.05*np.eye(n),state)
            self.assertGreater(actual,.2)
            self.assertEqual(state.action_batches,1)
            self.assertEqual(state.last_effective_power,cap)
            self.assertEqual(state.cost_cap_avoided_action_batches,6-cap)
            self.assertEqual(state.lookahead_avoided_action_batches,cap-1)
            self.assertEqual(state.lookahead_rejections,int(cap>1))
            self.assertEqual(state.avoided_action_batches,0)

    def test_null_columns_and_margin_deferral_in_finite_horizon_test(self):
        impossible,deferred,nonfinite=look._future_acceptance_impossible(
            np.array([-np.inf,log(.15)]),np.array([0.,0.]),
            log_alpha=log(100.),power=1,effective_power=6,tau=.2,margin=1e-10)
        self.assertTrue(impossible)
        self.assertFalse(deferred)
        self.assertFalse(nonfinite)
        # Cap prediction is just above tau, but inside the conservative margin.
        impossible,deferred,nonfinite=look._future_acceptance_impossible(
            np.array([log(.1)]),np.array([0.]),
            log_alpha=6*log(2.)+1e-12,power=1,effective_power=6,tau=.2,margin=1e-10)
        self.assertFalse(impossible)
        self.assertTrue(deferred)
        self.assertFalse(nonfinite)
        impossible,_,nonfinite=look._future_acceptance_impossible(
            np.array([log(.15)]),np.array([np.nan]),
            log_alpha=log(100.),power=1,effective_power=6,tau=.2,margin=1e-10)
        self.assertFalse(impossible)
        self.assertTrue(nonfinite)

    def test_wrapper_preserves_anchors_decisions_and_probe_history(self):
        ids=np.arange(6);blocks=[ids];anchor=sparse.eye(6,format='csr')
        old=ProgressiveEnergyBudget(seed=123,probes=12,power=6)
        state=look.LookaheadEnergyBudget(seed=123,probes=12,power=6)
        old_cache=new_cache=None
        for amplitude in (1.,1.15,1.151,1.152,1.5,1.501):
            old_op,old_cache,expected=build_progressive_schwarz(amplitude*anchor,blocks,ids,
                                     cache=old_cache,probability_state=old)
            op,new_cache,actual=look.build_lookahead_schwarz(amplitude*anchor,blocks,ids,
                                      cache=new_cache,probability_state=state)
            for key in ('new','refreshed','reused_energy','reused_exact'):
                self.assertEqual(actual[key],expected[key])
            np.testing.assert_array_equal(next(iter(new_cache.values())).anchor,
                                          next(iter(old_cache.values())).anchor)
            np.testing.assert_array_equal(op@np.eye(6),old_op@np.eye(6))
            self.assertEqual(state.count,old.count)
            self.assertEqual(state.spent_failure_budget,old.spent_failure_budget)
            self.assertEqual(repr(state.rng.bit_generator.state),repr(old.rng.bit_generator.state))
            self.assertEqual(actual['screen_kind'],'progressive_secant_lookahead')
        self.assertGreater(state.lookahead_rejections,0)
        self.assertLess(state.action_batches,old.action_batches)
        _,_,unchanged=look.build_lookahead_schwarz(1.501*anchor,blocks,ids,
                        cache=new_cache,probability_state=state,changed_global_ids=[])
        self.assertEqual(unchanged['screen_lookahead_rejections'],0)
        self.assertEqual(unchanged['screen_lookahead_power_histogram'],{})
        self.assertEqual(unchanged['cumulative_screen_lookahead_rejections'],state.lookahead_rejections)

    def test_configuration_and_nonfinite_inputs_fail_closed(self):
        for value in (0.,-1.,np.nan,np.inf,True,'small'):
            with self.assertRaises(ValueError):
                look.LookaheadEnergyBudget(lookahead_log_margin=value)
        state=look.LookaheadEnergyBudget(seed=1)
        with self.assertRaises(FrozenInstanceError):
            state.lookahead_log_margin=.1
        factor=LocalFactor.factor(np.eye(3))
        with self.assertRaises(ValueError):
            look.lookahead_bound(factor,np.full((3,3),np.nan),state)
        with self.assertRaises(ValueError):
            look.lookahead_bound(factor,np.triu(np.ones((3,3))),state)
        self.assertEqual(state.count,0)
        with self.assertRaises(FloatingPointError):
            look.lookahead_bound(factor,1e308*np.eye(3),state)
        self.assertEqual(state.count,1)
        self.assertEqual(state.action_batches,1)
        self.assertEqual(state.lookahead_rejections,0)
        with self.assertRaises(TypeError):
            look.lookahead_bound(factor,np.eye(3),ProgressiveEnergyBudget())


if __name__=='__main__':
    unittest.main()
