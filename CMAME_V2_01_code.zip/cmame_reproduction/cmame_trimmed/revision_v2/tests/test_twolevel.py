import numpy as np
from scipy import linalg
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.geometry import TrimDomain
from cmame_trimmed.src.solver import equilibrate,direct_reference
from cmame_trimmed.revision_v2.tensor_assembly import TensorAssembler
from cmame_trimmed.revision_v2.twolevel import build_coarse,solve_revised
from cmame_trimmed.revision_v2.screening import ProgressiveEnergyBudget

def test_coarse_action_is_symmetric_positive_and_exact_on_coarse_space():
    grid=SplineGrid((4,4,4),2);s=TensorAssembler(grid,quadrature=7).assemble(TrimDomain(holes=((.51,.49,.17),)))
    C,_,d=equilibrate(s.A,s.b);M,P,E=build_coarse(s,C,d,2)
    rng=np.random.default_rng(10);v=rng.normal(size=E.shape[0]);z=P@v
    np.testing.assert_allclose(M@(C@z),z,rtol=2e-10,atol=1e-10)
    dense=M@np.eye(len(s.b));np.testing.assert_allclose(dense,dense.T,rtol=1e-11,atol=1e-11)
    assert linalg.eigvalsh((dense+dense.T)/2)[0]>-1e-10

def test_revised_twolevel_solver_matches_direct_for_all_retention_policies():
    a=TensorAssembler(SplineGrid((4,4,4),2),physics='elasticity',quadrature=7);cache={};budgets={}
    for t in range(2):
        s=a.assemble(TrimDomain(holes=((.47+.001*t,.51,.18),)));ref,_=direct_reference(s)
        for method in ['fresh','exact_local','progressive','stale','jacobi']:
            if method=='progressive':budgets.setdefault(method,ProgressiveEnergyBudget(min_dimension=0,probes=8,power=3))
            x,cache[method],row=solve_revised(s,method,cache=cache.get(method),step=t,width=2,reference=ref,probability_state=budgets.get(method),coarse_ratio=2)
            assert row['success'],row
            assert row['coarse_dofs']>0 and row['coarse_setup']>0
