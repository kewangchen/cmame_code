"""Clock-controlled cost-policy tests; run only after serial timing jobs stop."""
from dataclasses import FrozenInstanceError, replace
from unittest import mock
import unittest

import numpy as np
from scipy import linalg, sparse

from cmame_trimmed.src import preconditioners as baseline
from cmame_trimmed.revision_v2 import cost_screening as cost


class CostScreeningTests(unittest.TestCase):
    @staticmethod
    def factor(n=72, seconds=1.):
        factor = cost.TimedLocalFactor.factor(np.eye(n))
        factor.factor_seconds = seconds
        return factor

    def test_timed_factor_preserves_original_arithmetic_and_replace_metadata(self):
        rng = np.random.default_rng(71)
        q = rng.normal(size=(7, 7));h=q.T@q+np.eye(7)
        old = baseline.LocalFactor.factor(h, diagnostics=True)
        actual = cost.TimedLocalFactor.factor(h, diagnostics=True)
        np.testing.assert_array_equal(actual.anchor, old.anchor)
        np.testing.assert_array_equal(actual.scale, old.scale)
        np.testing.assert_array_equal(actual.cholesky, old.cholesky)
        self.assertEqual(actual.factor_residual, old.factor_residual)
        self.assertTrue(np.isfinite(actual.factor_seconds))
        self.assertGreaterEqual(actual.factor_seconds, 0.)
        changed = replace(actual, last_accepted_bound=.1, last_is_exact=False)
        self.assertEqual(changed.factor_seconds, actual.factor_seconds)
        self.assertIsInstance(changed, cost.TimedLocalFactor)

    def test_rho_is_positive_finite_numeric_and_immutable(self):
        for value in (0., -1., np.nan, np.inf, True, np.bool_(False), '.25', None):
            with self.assertRaises(ValueError):
                cost.CostEnergyBudget(rho=value)
        state = cost.CostEnergyBudget(rho=.25)
        with self.assertRaises(FrozenInstanceError):
            state.rho = .5
        self.assertEqual(state.rho, .25)

    def test_timing_cap_never_stops_before_two_powers(self):
        factor = self.factor()
        state = cost.CostEnergyBudget(seed=8, probes=1, power=6)
        change = .05*np.eye(72)
        with mock.patch.object(cost, 'perf_counter', side_effect=[0., 100., 101., 102.]):
            bound = cost.cost_progressive_bound(factor, change, state)
        expected = baseline._probabilistic_bound(factor, change,
                            baseline.EnergyBudget(seed=8, probes=1, power=2))
        self.assertAlmostEqual(bound, expected, delta=expected*1e-12)
        self.assertGreater(bound, .2)
        self.assertEqual(state.action_batches, 2)
        self.assertEqual(state.column_actions, 2)
        self.assertEqual(state.timing_cap_checks, 1)
        self.assertEqual(state.timing_cap_avoided_action_batches, 4)
        self.assertEqual(state.timing_cap_histogram, {2: 1})
        self.assertEqual(state.avoided_action_batches, 0)
        self.assertEqual(state.early_accepts, 0)
        self.assertEqual(state.early_rejections, 0)
        self.assertEqual(state.count, 1)
        self.assertEqual(state.last_screen_seconds, 102.)
        self.assertEqual(state.last_time_allowance, .25)

    def test_one_extra_action_can_overshoot_after_floor(self):
        state = cost.CostEnergyBudget(seed=8, probes=1, power=6, dimension_cost_cap=True)
        factor = self.factor(seconds=8.)
        change = .05*np.eye(72)
        with mock.patch.object(cost, 'perf_counter', side_effect=[0., .5, 1.5, 2.5, 3.]):
            actual = cost.cost_progressive_bound(factor, change, state)
        expected = baseline._probabilistic_bound(factor, change,
                         baseline.EnergyBudget(seed=8, probes=1, power=3))
        self.assertAlmostEqual(actual, expected, delta=expected*1e-12)
        self.assertEqual(state.action_batches, 3)
        self.assertEqual(state.timing_cap_histogram, {3: 1})
        self.assertEqual(state.timing_cap_avoided_action_batches, 3)
        self.assertEqual(state.last_time_allowance, 2.)
        self.assertGreater(state.last_screen_seconds, state.last_time_allowance)

    def test_early_acceptance_and_lower_rejection_take_precedence(self):
        for drift, clocks, actions, accepted, rejected in (
                (.001, [0., 10., 11.], 1, 1, 0),
                (.3, [0., 10., 11.], 1, 0, 1),
                (.035, [0., 10., 11., 12.], 2, 1, 0)):
            state = cost.CostEnergyBudget(seed=123, probes=12, power=6)
            factor = self.factor(6)
            with mock.patch.object(cost, 'perf_counter', side_effect=clocks):
                bound = cost.cost_progressive_bound(factor, drift*np.eye(6), state)
            self.assertEqual(bound <= .2, bool(accepted))
            self.assertEqual(state.action_batches, actions)
            self.assertEqual(state.early_accepts, accepted)
            self.assertEqual(state.early_rejections, rejected)
            self.assertEqual(state.timing_cap_checks, 0)
            self.assertEqual(state.lower_bound_rejections, rejected)

    def test_dimension_cap_one_two_six_is_separate_from_timing(self):
        for n, q, clocks in ((12, 1, [0., 100., 101.]),
                             (24, 2, [0., 100., 101., 102.]),
                             (72, 6, [0., 1., 2., 3., 4., 5., 6., 7.])):
            factor = self.factor(n, seconds=1000.)
            state = cost.CostEnergyBudget(seed=8, probes=1, power=6, dimension_cost_cap=True)
            with mock.patch.object(cost, 'perf_counter', side_effect=clocks):
                actual = cost.cost_progressive_bound(factor, .05*np.eye(n), state)
            expected = baseline._probabilistic_bound(factor, .05*np.eye(n),
                           baseline.EnergyBudget(seed=8, probes=1, power=q))
            self.assertAlmostEqual(actual, expected, delta=expected*1e-12)
            self.assertEqual(state.action_batches, q)
            self.assertEqual(state.last_effective_power, q)
            self.assertEqual(state.cost_cap_avoided_action_batches, 6-q)
            self.assertEqual(state.timing_cap_checks, 0)

    def test_zero_timing_allowance_still_preserves_floor(self):
        factor = self.factor(seconds=0.)
        state = cost.CostEnergyBudget(seed=8, probes=1, power=6)
        with mock.patch.object(cost, 'perf_counter', side_effect=[0., .1, .2, .3]):
            bound = cost.cost_progressive_bound(factor, .05*np.eye(72), state)
        self.assertGreater(bound, .2)
        self.assertEqual(state.action_batches, 2)
        self.assertEqual(state.timing_cap_checks, 1)

    def test_accepted_dense_matrices_match_independent_generalized_spectrum(self):
        rng = np.random.default_rng(85)
        for n in (3, 7, 12):
            q=rng.normal(size=(n,n));h=q.T@q+np.eye(n)
            factor=cost.TimedLocalFactor.factor(h)
            factor.factor_seconds=1.
            delta=rng.normal(size=(n,n))*1e-5;delta=(delta+delta.T)/2
            change=delta/factor.scale[:,None]/factor.scale[None,:]
            state=cost.CostEnergyBudget(seed=9, probes=12, power=6)
            with mock.patch.object(cost, 'perf_counter', side_effect=[0., 100., 101.]):
                bound=cost.cost_progressive_bound(factor, change, state)
            exact=np.max(np.abs(linalg.eigvalsh(delta,h)))
            self.assertLessEqual(bound,.2)
            self.assertLessEqual(exact,bound*(1+1e-11))
            self.assertEqual(state.count,1)

    def test_wrapper_keeps_separate_timed_anchors_and_current_certificate(self):
        original_factor=baseline.LocalFactor
        original_bound=baseline._probabilistic_bound
        state=cost.CostEnergyBudget(seed=123,probes=12,power=6)
        args=(sparse.eye(6,format='csr'),[np.arange(6)],np.arange(6))
        _,cache,cold=cost.build_cost_schwarz(*args,probability_state=state)
        factor=next(iter(cache.values()));seconds=factor.factor_seconds
        self.assertIsInstance(factor,cost.TimedLocalFactor)
        self.assertGreaterEqual(seconds,0.)
        op,cache,stats=cost.build_cost_schwarz(1.001*args[0],args[1],args[2],
                             probability_state=state,cache=cache)
        retained=next(iter(cache.values()))
        self.assertEqual(retained.factor_seconds,seconds)
        self.assertEqual(stats['reused_energy'],1)
        self.assertEqual(stats['screen_action_batches'],1)
        self.assertEqual(stats['screen_timing_cap_checks'],0)
        self.assertEqual(stats['screen_rho'],.25)
        self.assertEqual(stats['screen_kind'],'progressive_measured_anchor_cost')
        np.testing.assert_allclose(op@np.eye(6),np.eye(6))
        self.assertIs(baseline.LocalFactor,original_factor)
        self.assertIs(baseline._probabilistic_bound,original_bound)
        _,_,unchanged=cost.build_cost_schwarz(1.001*args[0],args[1],args[2],
                    probability_state=state,cache=cache,changed_global_ids=[])
        self.assertEqual(unchanged['screen_action_batches'],0)
        self.assertEqual(unchanged['screen_timing_cap_histogram'],{})
        self.assertEqual(unchanged['cumulative_screen_action_batches'],1)
        _,old_cache,_=baseline.build_schwarz(*args)
        with self.assertRaises(TypeError):
            cost.build_cost_schwarz(*args,probability_state=state,cache=old_cache)

    def test_invalid_measurements_inputs_and_nonfinite_actions_fail_closed(self):
        state=cost.CostEnergyBudget(seed=1)
        factor=self.factor(3)
        for bad in (np.nan,np.inf,-1.,True):
            factor.factor_seconds=bad
            with self.assertRaises(ValueError):
                cost.cost_progressive_bound(factor,np.eye(3),state)
        self.assertEqual(state.count,0)
        factor.factor_seconds=1.
        with self.assertRaises(ValueError):
            cost.cost_progressive_bound(factor,np.full((3,3),np.nan),state)
        with self.assertRaises(ValueError):
            cost.cost_progressive_bound(factor,np.eye(3),state,tau=1.)
        self.assertEqual(state.count,0)
        with mock.patch.object(cost,'perf_counter',side_effect=[0.,1.]):
            with self.assertRaises(FloatingPointError):
                cost.cost_progressive_bound(factor,1e308*np.eye(3),state)
        self.assertEqual(state.count,1)
        self.assertEqual(state.action_batches,1)
        self.assertEqual(state.measured_screen_seconds,1.)
        with self.assertRaises(TypeError):
            cost.cost_progressive_bound(baseline.LocalFactor.factor(np.eye(3)),np.eye(3),state)

    def test_nonfinite_allowance_or_elapsed_time_cannot_accept(self):
        factor=self.factor(3,seconds=1e308)
        state=cost.CostEnergyBudget(rho=1e308)
        with self.assertRaises(FloatingPointError):
            cost.cost_progressive_bound(factor,np.eye(3),state)
        self.assertEqual(state.count,0)
        factor.factor_seconds=1.
        state=cost.CostEnergyBudget(seed=1)
        with mock.patch.object(cost,'perf_counter',side_effect=[0.,np.nan,np.nan]):
            with self.assertRaises(FloatingPointError):
                cost.cost_progressive_bound(factor,.001*np.eye(3),state)
        self.assertEqual(state.count,1)
        self.assertEqual(state.action_batches,1)
        self.assertEqual(state.early_accepts,0)


if __name__=='__main__':
    unittest.main()
