"""Matched current coarse correction and local-factor policies for V2 studies."""
from time import perf_counter
import numpy as np
from scipy import sparse,linalg
from scipy.sparse.linalg import LinearOperator,cg,splu
from cmame_trimmed.src.solver import equilibrate
from cmame_trimmed.src.preconditioners import build_schwarz,jacobi
from .tensor_assembly import coarse_prolongation
from .screening import build_progressive_schwarz


def build_coarse(system,C,d,ratio):
    grid=system.grid;c=system.components
    P=coarse_prolongation(grid,ratio,c)
    shape=tuple(n//ratio+p for n,p in zip(grid.cells,grid.degrees))
    # Strong homogeneous Dirichlet boundary at xi_1=0.
    fixed=np.repeat(np.arange(np.prod(shape))//np.prod(shape[1:])==0,c)
    P=P[system.ids,:][:,~fixed].tocsr();P.eliminate_zeros()
    P=P[:,np.asarray(P.getnnz(axis=0)).ravel()>0].tocsr()
    P=sparse.diags(1/d)@P
    E=(P.T@C@P).toarray();sc=np.sqrt(np.diag(E))
    L=linalg.cholesky(.5*(E+E.T)/sc[:,None]/sc[None,:],lower=True,check_finite=True)
    def action(v):
        b=P.T@v;s=sc if b.ndim==1 else sc[:,None]
        return P@(linalg.cho_solve((L,True),b/s,check_finite=False)/s)
    return LinearOperator(C.shape,matvec=action,matmat=action,rmatvec=action,dtype=float),P,E


def solve_revised(system,method,cache=None,step=0,tau=.2,width=4,reference=None,maxiter=2000,x0=None,probability_state=None,coarse_ratio=0):
    start=perf_counter();A=system.A;b=system.b;C,f,d=equilibrate(A,b);stats={};coarse_setup=0.;coarse_dofs=0
    if method=='direct':lu=splu(C.tocsc());M=None
    elif method=='jacobi':M=jacobi(C)
    else:
        blocks=system.blocks('cbas' if method=='cbas' else 'overlap',width=width)
        policy={'progressive':'prob_energy','energy':'prob_energy','cbas':'fresh'}.get(method,method)
        builder=build_progressive_schwarz if method=='progressive' else build_schwarz
        M,cache,stats=builder(C,blocks,system.ids,mode=policy,cache=cache,tau=tau,step=step,changed_global_ids=system.changed_ids,probability_state=probability_state)
        stats['largest_block']=max(map(len,blocks));stats['block_occurrences']=len(blocks)
    if coarse_ratio and method!='direct':
        cstart=perf_counter();coarse,P,E=build_coarse(system,C,d,coarse_ratio);coarse_setup=perf_counter()-cstart;coarse_dofs=E.shape[0];M=M+coarse
    setup=perf_counter()-start;its=[0]
    def callback(y):its[0]+=1
    start=perf_counter()
    if method=='direct':y=lu.solve(f);info=0
    else:y,info=cg(C,f,x0=None if x0 is None else x0/d,M=M,rtol=1e-9,atol=0,maxiter=maxiter,callback=callback)
    elapsed=perf_counter()-start;x=d*y;r=b-A@x
    row=dict(method=method,step=step,setup=setup,solve=elapsed,linear=setup+elapsed,assembly=system.assembly_seconds,total=system.assembly_seconds+setup+elapsed,iterations=its[0],info=int(info),scaled_residual=float(np.linalg.norm(d*r)/np.linalg.norm(d*b)),residual=float(np.linalg.norm(r)/np.linalg.norm(b)),dofs=len(b),changed_cells=system.changed_cells,cached_cells=system.cached_cells,weak=len(system.weak_rows),minimum_fraction=float(system.fractions[system.fractions>0].min()),measure=system.measure,tau=tau,width=width,warm_start=x0 is not None,coarse_setup=coarse_setup,coarse_dofs=coarse_dofs,coarse_ratio=coarse_ratio,**{'stat_'+k:v for k,v in stats.items()})
    if reference is not None:
        e=x-reference;ae=A@e;value=float(e@ae);roundoff=64*np.finfo(float).eps*float(np.abs(e)@np.abs(ae))
        if value < -roundoff:raise FloatingPointError('Substantively negative error energy')
        row['energy_error']=float(np.sqrt(max(0,value)/(reference@(A@reference))))
    row['success']=bool(info==0 and np.isfinite(x).all() and row['scaled_residual']<=1e-8 and row['residual']<=1e-8 and row.get('energy_error',0)<=1e-6)
    return x,cache,row
