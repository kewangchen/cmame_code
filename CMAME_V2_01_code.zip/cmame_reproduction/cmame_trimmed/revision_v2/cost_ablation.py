"""Separate matched stopping-rule study; preserves the frozen campaign.

The extra policy was motivated by the first completed cubic repetition.
All four existing configurations and all three repetitions are kept. This
is a disclosed follow-up experiment, not part of the earlier preregistration.
Deterministic lookahead was added before this follow-up was frozen or run.
"""
import argparse,gc,hashlib,json,time,os,platform,sys
import scipy
from pathlib import Path
from types import FunctionType
import numpy as np
from .campaign import CASES,geometry,transfer,atomic,freeze
from .tensor_assembly import TensorAssembler
from .twolevel import solve_revised
from .screening import ProgressiveEnergyBudget
from .cost_screening import CostEnergyBudget,build_cost_schwarz
from .lookahead_screening import LookaheadEnergyBudget,build_lookahead_schwarz
from cmame_trimmed.src.preconditioners import EnergyBudget
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.solver import direct_reference
ROOT=Path(__file__).resolve().parent;METHODS=['energy','progressive','cost','lookahead']
namespace=dict(solve_revised.__globals__);namespace['build_progressive_schwarz']=build_cost_schwarz
_cost_solver=FunctionType(solve_revised.__code__,namespace,'cost_solver',solve_revised.__defaults__,solve_revised.__closure__)
lookahead_namespace=dict(solve_revised.__globals__);lookahead_namespace['build_progressive_schwarz']=build_lookahead_schwarz
_lookahead_solver=FunctionType(solve_revised.__code__,lookahead_namespace,'lookahead_solver',solve_revised.__defaults__,solve_revised.__closure__)

def solve_cost(system,**kwargs):
 x,cache,row=_cost_solver(system,'progressive',**kwargs);row['method']='cost';return x,cache,row

def solve_lookahead(system,**kwargs):
 x,cache,row=_lookahead_solver(system,'progressive',**kwargs);row['method']='lookahead';return x,cache,row

def anchor_digest(cache):
 """Hash memberships and represented anchors outside every method timer."""
 h=hashlib.sha256()
 for key,factor in sorted(cache.items()):
  a=np.ascontiguousarray(factor.anchor)
  h.update(json.dumps([list(key),list(a.shape),a.dtype.str],separators=(',',':')).encode())
  h.update(memoryview(a).cast('B'))
 return h.hexdigest()

def lookahead_audit(rep,k,cache,previous,states,rows):
 pair=all(bool(cache.get(m)) and previous.get(m) is not None and rows[m]['success'] for m in ('progressive','lookahead'))
 audit=dict(repeat=rep,step=k,pair_available=pair,progressive_anchor_sha256=None,lookahead_anchor_sha256=None,anchors_equal=None,solutions_equal=None,rng_states_equal=None,draw_counts_equal=None,factor_counts_equal=None)
 if pair:
  a=anchor_digest(cache['progressive']);b=anchor_digest(cache['lookahead'])
  audit.update(progressive_anchor_sha256=a,lookahead_anchor_sha256=b,anchors_equal=a==b,
   solutions_equal=bool(np.array_equal(previous['progressive'][0],previous['lookahead'][0]) and np.array_equal(previous['progressive'][1],previous['lookahead'][1])),
   rng_states_equal=states['progressive'].rng.bit_generator.state==states['lookahead'].rng.bit_generator.state,
   draw_counts_equal=states['progressive'].count==states['lookahead'].count,
   factor_counts_equal=all(rows['progressive']['stat_'+n]==rows['lookahead']['stat_'+n] for n in ('new','refreshed','reused_energy','reused_exact','reused_unchanged','retired')))
 return audit

def provenance():
 old=freeze();files=[Path(__file__).resolve(),ROOT/'cost_screening.py',ROOT/'lookahead_screening.py'];hashes={str(p.relative_to(ROOT.parent.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
 manifest=ROOT/'results/cost_ablation_manifest.json'
 data=dict(core_source_hashes=old['source_hashes'],added_source_hashes=hashes,cases=CASES,methods=METHODS,repeats=3,rho=.25,minimum_inconclusive_powers=2,seed_base=2026101700,motivation='Follow-up after first cubic repeat showed extra powers can raise total cost; deterministic lookahead added after a log-convexity derivation, before this follow-up was frozen or run. All original four configurations retained.',python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),threads={k:os.environ.get(k) for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']},created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
 if manifest.exists():
  prev=json.loads(manifest.read_text());assert prev['added_source_hashes']==hashes,'Ablation sources changed';return prev
 for p in files:
  target=ROOT/'results/cost_sources'/p.relative_to(ROOT.parent.parent);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
 atomic(manifest,data);return data

def run(name):
 manifest=provenance();cfg=CASES[name];path=ROOT/'results'/('cost_sequence_'+name+'.json');assert not path.exists(),'Refusing overwrite'
 data=dict(case=name,config=cfg,methods=METHODS,repeats=3,rows=[],references=[],lookahead_audits=[],manifest=manifest,complete=False)
 for rep in range(3):
  assembler=TensorAssembler(SplineGrid(tuple(cfg['cells']),cfg['degree']),physics='elasticity',quadrature=12);cache={};previous={}
  states={'energy':EnergyBudget(seed=2026101700+rep,min_dimension=288),'progressive':ProgressiveEnergyBudget(seed=2026101700+rep,probes=12,power=6,min_dimension=288,dimension_cost_cap=True),'cost':CostEnergyBudget(seed=2026101700+rep,probes=12,power=6,min_dimension=288,dimension_cost_cap=True,rho=.25),'lookahead':LookaheadEnergyBudget(seed=2026101700+rep,probes=12,power=6,min_dimension=288,dimension_cost_cap=True)}
  for k in range(cfg['queries']):
   system=assembler.assemble(geometry(cfg,k));reference,rt=direct_reference(system);data['references'].append(dict(repeat=rep,step=k,**rt));j=(rep+k)%len(METHODS);order=METHODS[j:]+METHODS[:j]
   for m in order:
    kw=dict(cache=cache.get(m),step=k,width=cfg['width'],reference=reference,probability_state=states[m],coarse_ratio=cfg['coarse_ratio'],x0=transfer(previous.get(m),system.ids))
    start=time.perf_counter()
    try:
     if m=='cost':x,c,row=solve_cost(system,**kw)
     elif m=='lookahead':x,c,row=solve_lookahead(system,**kw)
     else:x,c,row=solve_revised(system,m,**kw)
     cache[m]=c;previous[m]=(system.ids.copy(),x.copy()) if row['success'] else None
     del x,c
    except (np.linalg.LinAlgError,FloatingPointError,ArithmeticError,ValueError) as exc:
     row=dict(method=m,step=k,success=False,error=type(exc).__name__+': '+str(exc),attempt_seconds=time.perf_counter()-start,dofs=len(system.b));cache.pop(m,None);previous[m]=None
    row.update(case=name,repeat=rep,degree=cfg['degree']);data['rows'].append(row);atomic(path,data)
   data['lookahead_audits'].append(lookahead_audit(rep,k,cache,previous,states,{r['method']:r for r in data['rows'][-len(METHODS):]}));atomic(path,data)
   print(name,'rep',rep,'query',k,'linear',','.join(m+':'+format(data['rows'][-len(METHODS)+order.index(m)].get('linear',-1),'.3f') for m in METHODS),flush=True)
  del assembler,system,reference,cache,previous,states;gc.collect()
 data['complete']=True;atomic(path,data)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('case',choices=list(CASES)+['all']);args=p.parse_args()
 for name in (list(CASES) if args.case=='all' else [args.case]):run(name)
