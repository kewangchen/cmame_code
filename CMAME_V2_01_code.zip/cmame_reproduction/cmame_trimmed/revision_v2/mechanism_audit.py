"""Stable spline-mechanism formulas and a separate high-order quadrature audit.

Do not execute during formal timing campaigns. Run serially afterwards:
  python -m cmame_trimmed.revision_v2.mechanism_audit --mode mechanism
  python -m cmame_trimmed.revision_v2.mechanism_audit --mode quadrature

Mechanism mode uses Decimal/Fraction arithmetic only. Quadrature mode imports
NumPy/SciPy lazily after setting single-thread defaults; it compares independent
fresh TensorAssembler instances, not an independent quadrature implementation.
Neither mode is a probabilistic certificate or a performance measurement.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from fractions import Fraction
import gc
import hashlib
import json
from math import comb
import os
from pathlib import Path
import platform
import sys
import time

ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent.parent
DEFAULT_EPSILONS = ('0.1', '0.03', '0.01', '0.003', '0.001',
                    '0.0003', '0.0001', '0.00003', '0.00001',
                    '0.000003', '0.000001')
DECIMAL_PRECISION = 80
QUADRATURE_CASE = {'cells': [6, 6, 4], 'degree': 5, 'physics': 'elasticity',
                   'holes': [[.47, .51, .173]], 'top': 1.,
                   'comparison_orders': [12, 16, 20], 'reference_order': 24,
                   'boundary_condition': 'left', 'load': 'body'}
THREAD_VARIABLES = ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS',
                    'VECLIB_MAXIMUM_THREADS', 'MKL_NUM_THREADS')


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic_json(path, data):
    path = Path(path)
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')
    temporary.replace(path)


def snapshot_sources(files, project_root, destination):
    """Copy exactly the bytes whose hashes are reported; never replace a copy."""
    project_root, destination = Path(project_root), Path(destination)
    hashes = {}
    for source in files:
        source = Path(source)
        relative = source.relative_to(project_root)
        content = source.read_bytes()
        copied = destination/relative
        copied.parent.mkdir(parents=True, exist_ok=True)
        if copied.exists() and copied.read_bytes() != content:
            raise FileExistsError('Source snapshot differs: '+str(copied))
        if not copied.exists():
            copied.write_bytes(content)
        hashes[str(relative)] = hashlib.sha256(content).hexdigest()
    return hashes


def audit_sources():
    files = sorted((ROOT.parent/'src').glob('*.py'))
    files += [ROOT/'mechanism_audit.py', ROOT/'tensor_assembly.py',
              ROOT/'campaign.py', ROOT/'tests/test_mechanism_audit.py',
              ROOT/'docs/mechanism_audit_protocol.md']
    return files


def _decimal(value):
    return value if isinstance(value, Decimal) else Decimal(str(value))


def _pair_values(epsilon, family):
    """Raw high-precision values; caller owns the Decimal precision context."""
    e = _decimal(epsilon)
    if not Decimal(0) < e <= Decimal(1):
        raise ValueError('epsilon must lie in (0, 1]')
    if family == 'positive':
        b = 1-2*e+4*e*e/3
        F11, F12, F22 = 4*e*b, 2*e*e*(1-4*e/3), 4*e**3/3
        det_C = 1/(4*b)
    elif family == 'counterexample':
        a = 1-e+e*e/3
        b = 1-2*e+4*e*e/3
        c = 1-3*e/2+2*e*e/3
        F11, F12, F22 = 4*e*a, -4*e*c, 4*e*b
        det_C = e*e/(12*a*b)
    else:
        raise ValueError('unknown Bernstein family: '+str(family))
    rho = F12/(F11*F22).sqrt()
    lambda_max = 1+abs(rho)
    # Avoid subtracting two nearly equal values when |rho| approaches one.
    lambda_min = det_C/lambda_max
    condition = lambda_max/lambda_min
    return {'epsilon': e, 'stiffness': [[F11, F12], [F12, F22]],
            'correlation': rho, 'determinant_stiffness': 4*e**4/3,
            'determinant_normalized': det_C,
            'lambda_min_normalized': lambda_min,
            'lambda_max_normalized': lambda_max,
            'normalized_condition': condition,
            'epsilon_squared_condition': e*e*condition}


def _positive_constants(tau):
    t = _decimal(tau)
    if not 0 < t < 1:
        raise ValueError('tau must lie in (0, 1)')
    sqrt3 = Decimal(3).sqrt()
    b = 4/sqrt3
    kappa0 = 7+4*sqrt3
    r_max = t/(2*kappa0*(2+t)+t)
    # Solve 2*b*e+b^2*e^2=r_max without subtracting close square roots.
    radius = r_max/(b*((1+r_max).sqrt()+1))
    return {'tau': t, 'b': b, 'b_squared': Decimal(16)/3,
            'kappa0': kappa0, 'rho0': sqrt3/2,
            'sufficient_r_max': r_max, 'sufficient_epsilon_max': radius}


def _pack_decimal(values):
    out = {}
    for key, value in values.items():
        if isinstance(value, Decimal):
            out[key] = str(value)
        elif isinstance(value, list):
            out[key] = [[str(x) for x in row] for row in value]
        else:
            out[key] = value
    return out


def positive_constants(tau='0.2'):
    with localcontext() as ctx:
        ctx.prec = DECIMAL_PRECISION
        values = _positive_constants(tau)
        return {**{k: float(v) for k,v in values.items()},
                'decimal': _pack_decimal(values),
                'leading_gram_exact': [['4', '2'], ['2', '4/3']],
                'leading_gram_determinant_exact': '4/3',
                'b_exact': '4/sqrt(3)', 'kappa0_exact': '7+4*sqrt(3)'}


def bernstein_pair(epsilon, family, anchor_epsilon='0.0001', tau='0.2'):
    """Evaluate actual quadratic spline Grams; no eigenvalue subtraction."""
    with localcontext() as ctx:
        ctx.prec = DECIMAL_PRECISION
        values = _pair_values(epsilon, family)
        anchor = _pair_values(anchor_epsilon, family)
        e, rho = values['epsilon'], values['correlation']
        drift = abs(rho-anchor['correlation'])/anchor['lambda_min_normalized']
        values['anchor_epsilon'] = anchor['epsilon']
        values['anchor_relative_drift'] = drift
        row = {'family': family, 'leading_gram_spd': family == 'positive',
               'small_cut_theorem_applicable': False,
               'within_sufficient_pair_region': False,
               'small_cut_upper_bound': None,
               'limit_relative_drift': None}
        if family == 'positive':
            const = _positive_constants(tau)
            values['coupling_drift_from_limit'] = abs(rho-const['rho0'])
            values['limit_relative_drift'] = abs(rho-const['rho0'])/(1-const['rho0'])
            b = const['b']
            r = 2*b*e+b*b*e*e
            ea = anchor['epsilon']
            ra = 2*b*ea+b*b*ea*ea
            values['relative_gram_remainder_bound'] = r
            row['within_sufficient_pair_region'] = bool(
                max(e,ea) <= const['sufficient_epsilon_max'])
            if r < 1 and ra < 1:
                gamma = 2*const['kappa0']*r/(1-r)
                gamma_a = 2*const['kappa0']*ra/(1-ra)
                values['gamma_current'] = gamma
                values['gamma_anchor'] = gamma_a
                if gamma_a < 1:
                    row['small_cut_theorem_applicable'] = True
                    values['small_cut_upper_bound'] = (gamma+gamma_a)/(1-gamma_a)
        else:
            # The limiting normalized matrix is singular. A relative norm
            # against that limit is undefined and must never be reported.
            values['coupling_drift_from_limit'] = values['lambda_min_normalized']
        for key, value in values.items():
            if isinstance(value, Decimal):
                row[key] = float(value)
        row['decimal'] = _pack_decimal(values)
        return row


def _fraction_determinant(matrix):
    a = [[Fraction(x) for x in row] for row in matrix]
    result = Fraction(1)
    for k in range(len(a)):
        pivot = next((i for i in range(k, len(a)) if a[i][k]), None)
        if pivot is None:
            return Fraction(0)
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            result = -result
        diagonal = a[k][k]
        result *= diagonal
        for i in range(k+1, len(a)):
            ratio = a[i][k]/diagonal
            for j in range(k+1, len(a)):
                a[i][j] -= ratio*a[k][j]
            a[i][k] = Fraction(0)
    return result


def bernstein_leading_sets(degrees=(2,3,5)):
    records = []
    for p in degrees:
        if isinstance(p, bool) or not isinstance(p, int) or p < 1:
            raise ValueError('degrees must be positive integers')
        coefficients = [i*comb(p,i) for i in range(1,p+1)]
        gram = [[Fraction(coefficients[i]*coefficients[j],i+j+1)
                 for j in range(p)] for i in range(p)]
        minors = [_fraction_determinant([row[:k] for row in gram[:k]])
                  for k in range(1,p+1)]
        records.append({'degree': p, 'basis_indices': list(range(1,p+1)),
                        'leading_gradient_coefficients': coefficients,
                        'leading_gradient_orders': list(range(p)),
                        'leading_gram_exact': [[str(x) for x in row] for row in gram],
                        'leading_principal_minors': [str(x) for x in minors],
                        'leading_gram_spd': all(x>0 for x in minors)})
    return records


def mechanism_report(epsilons=DEFAULT_EPSILONS, anchor_epsilon='0.0001', tau='0.2'):
    if not epsilons:
        raise ValueError('at least one epsilon is required')
    rows = [bernstein_pair(e,family,anchor_epsilon,tau)
            for family in ('positive','counterexample') for e in epsilons]
    positive = [r for r in rows if r['family']=='positive']
    negative = [r for r in rows if r['family']=='counterexample']
    smallest = min(negative, key=lambda r: r['epsilon'])
    sets = bernstein_leading_sets()
    with localcontext() as ctx:
        ctx.prec = DECIMAL_PRECISION
        certified_rows = [r for r in positive if r['within_sufficient_pair_region']]
        checks = {
            'positive_exact_gram_sets_spd': all(r['leading_gram_spd'] for r in sets),
            'all_exact_pair_grams_spd': all(Decimal(r['decimal']['determinant_stiffness'])>0 for r in rows),
            'all_small_eigenvalues_positive': all(Decimal(r['decimal']['lambda_min_normalized'])>0 for r in rows),
            'available_positive_theory_bounds_hold': all(
                Decimal(r['decimal']['anchor_relative_drift']) <= Decimal(r['decimal']['small_cut_upper_bound'])
                for r in positive if r['small_cut_upper_bound'] is not None),
            'sufficient_region_tested': bool(certified_rows),
            'sufficient_region_pairs_meet_tau': all(
                Decimal(r['decimal']['anchor_relative_drift']) <= _decimal(tau)
                for r in certified_rows),
            'counterexample_has_no_small_cut_certificate': all(
                not r['small_cut_theorem_applicable'] and r['small_cut_upper_bound'] is None
                and r['limit_relative_drift'] is None for r in negative),
            'counterexample_scaled_condition_near_48': abs(
                Decimal(smallest['decimal']['epsilon_squared_condition'])-48)
                <= 200*Decimal(smallest['decimal']['epsilon']),
        }
    checks['all_passed'] = all(checks.values())
    return {'kind': 'exact_formula_evaluation', 'decimal_precision': DECIMAL_PRECISION,
            'epsilon_values': list(map(str, epsilons)), 'anchor_epsilon': str(anchor_epsilon),
            'tau': str(tau), 'positive_constants': positive_constants(tau),
            'leading_sets': sets, 'rows': rows, 'checks': checks,
            'formulas': {
                'positive_basis': ['2*x*(1-x)', 'x^2'],
                'negative_basis': ['(1-x)^2', '2*x*(1-x)'],
                'normalized_eigenvalue_min': 'det(C)/(1+abs(rho))',
                'normalized_condition': '(1+abs(rho))^2/det(C)',
                'positive_det_C': '1/[4*(1-2*epsilon+4*epsilon^2/3)]',
                'negative_det_C': 'epsilon^2/[12*(1-epsilon+epsilon^2/3)*(1-2*epsilon+4*epsilon^2/3)]',
                'anchor_relative_drift': 'abs(rho(epsilon)-rho(anchor))/(1-abs(rho(anchor)))',
                'positive_remainder': 'r(epsilon)=2*b*epsilon+b^2*epsilon^2, b=4/sqrt(3)',
                'positive_gamma': '2*kappa0*r/(1-r), kappa0=7+4*sqrt(3)',
                'negative_condition_limit': 'epsilon^2*kappa(C_epsilon) -> 48'},
            'scope': 'Decimal evaluations of exact spline formulas; no mesh or degree uniform claim, no acceptance-rate or performance claim, and no small-cut theorem assigned to the singular-leading-Gram counterexample.'}


def comparison_metrics(current, reference, solution, reference_solution):
    """Current-system residual and differences in the q_ref energy norm."""
    import numpy as np
    if not np.array_equal(current.ids, reference.ids):
        raise ValueError('Quadrature orders produced different active IDs')
    difference = (current.A-reference.A).tocsr()
    difference.sum_duplicates()
    matrix_error = np.linalg.norm(difference.data)/np.linalg.norm(reference.A.data)
    rhs_error = np.linalg.norm(current.b-reference.b)/np.linalg.norm(reference.b)
    error = solution-reference_solution
    applied = reference.A@error
    energy_squared = float(error@applied)
    rounding = 64*np.finfo(float).eps*float(np.abs(error)@np.abs(applied))
    if energy_squared < -rounding:
        raise FloatingPointError('Substantively negative reference error energy')
    reference_energy = float(reference_solution@(reference.A@reference_solution))
    if not np.isfinite(reference_energy) or reference_energy <= 0:
        raise FloatingPointError('Nonpositive or nonfinite reference energy')
    residual = current.b-current.A@solution
    scale = 1/np.sqrt(current.A.diagonal())
    values = dict(matrix_relative_frobenius=float(matrix_error),
                  rhs_relative_l2=float(rhs_error),
                  solution_relative_reference_energy=float(np.sqrt(max(0.,energy_squared)/reference_energy)),
                  solution_relative_l2=float(np.linalg.norm(error)/np.linalg.norm(reference_solution)),
                  current_residual_relative_l2=float(np.linalg.norm(residual)/np.linalg.norm(current.b)),
                  current_scaled_residual_relative_l2=float(np.linalg.norm(scale*residual)/np.linalg.norm(scale*current.b)),
                  identical_active_ids=True)
    if not all(np.isfinite(v) for v in values.values()):
        raise FloatingPointError('Nonfinite quadrature-comparison metric')
    return values


def _prepare_output(mode, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir/(mode+'_audit.json')
    if path.exists():
        raise FileExistsError('Refusing to overwrite audit data: '+str(path))
    files = audit_sources()
    hashes = snapshot_sources(files, PROJECT_ROOT, output_dir/(mode+'_audit_sources'))
    metadata = {'mode': mode, 'created_utc': utc_now(), 'complete': False,
                'source_hashes': hashes, 'source_snapshot': mode+'_audit_sources',
                'python': sys.version, 'platform': platform.platform(),
                'thread_environment': {k: os.environ.get(k) for k in THREAD_VARIABLES},
                'execution_policy': 'serial audit after the formal timing campaign; timings below are diagnostic only'}
    atomic_json(path, metadata)
    return path, metadata


def _check_source_consistency(data):
    return all(sha256(PROJECT_ROOT/relative)==digest
               for relative,digest in data['source_hashes'].items())


def run_mechanism(output_dir):
    path, data = _prepare_output('mechanism', output_dir)
    try:
        data.update(mechanism_report())
        data['checks']['sources_unchanged_during_audit'] = _check_source_consistency(data)
        data['checks']['all_passed'] = all(v for k,v in data['checks'].items() if k!='all_passed')
        data['complete'] = True
        data['status'] = 'passed' if data['checks']['all_passed'] else 'failed'
    except Exception as exc:
        data.update(status='failed', error=type(exc).__name__+': '+str(exc))
        atomic_json(path, data)
        raise
    data['finished_utc'] = utc_now()
    atomic_json(path, data)
    return data['status']=='passed'


def run_quadrature(output_dir, matrix_tolerance=1e-8, energy_tolerance=1e-6,
                   residual_tolerance=1e-8):
    # Called before importing numerical libraries when the CLI is used.
    for name in THREAD_VARIABLES:
        os.environ.setdefault(name, '1')
        if os.environ[name] != '1':
            raise ValueError(name+' must be 1 for this serial audit')
    import numpy as np
    import scipy
    from cmame_trimmed.src.geometry import TrimDomain
    from cmame_trimmed.src.space import SplineGrid
    from cmame_trimmed.src.solver import direct_reference
    from cmame_trimmed.revision_v2.tensor_assembly import TensorAssembler
    for value in (matrix_tolerance, energy_tolerance, residual_tolerance):
        if not np.isfinite(value) or value <= 0:
            raise ValueError('audit tolerances must be positive and finite')
    path, data = _prepare_output('quadrature', output_dir)
    data.update(config=QUADRATURE_CASE.copy(), numpy=np.__version__, scipy=scipy.__version__,
                thresholds=dict(matrix_relative_frobenius=matrix_tolerance,
                                solution_relative_reference_energy=energy_tolerance,
                                current_residual_relative_l2=residual_tolerance,
                                current_scaled_residual_relative_l2=residual_tolerance),
                rows=[], checks={},
                scope='Quadrature-order sensitivity with fresh TensorAssembler instances and direct algebraic solves. Order 24 is a numerical reference, not exact integration, an independent quadrature implementation, a continuum-error estimate or a theorem certificate.')
    atomic_json(path, data)
    geometry = TrimDomain(holes=tuple(tuple(h) for h in QUADRATURE_CASE['holes']))

    def assemble_at(order):
        grid = SplineGrid(tuple(QUADRATURE_CASE['cells']), QUADRATURE_CASE['degree'])
        assembler = TensorAssembler(grid, physics=QUADRATURE_CASE['physics'],
                                    quadrature=order, incremental=False)
        system = assembler.assemble(geometry)
        # Local element caches are not needed once this fresh matrix is built.
        del assembler
        gc.collect()
        return system

    try:
        reference = assemble_at(QUADRATURE_CASE['reference_order'])
        reference_solution, reference_times = direct_reference(reference)
        reference_metrics = comparison_metrics(reference, reference, reference_solution, reference_solution)
        data['reference'] = dict(order=QUADRATURE_CASE['reference_order'],
                                 dofs=len(reference.b), nonzeros=reference.A.nnz,
                                 assembly_seconds=reference.assembly_seconds,
                                 direct_solve_seconds=reference_times,
                                 measure=reference.measure, **reference_metrics)
        data['checks']['reference_residual_passed'] = all(
            reference_metrics[k] <= residual_tolerance for k in
            ('current_residual_relative_l2','current_scaled_residual_relative_l2'))
        atomic_json(path, data)
        for order in QUADRATURE_CASE['comparison_orders']:
            started = time.perf_counter()
            try:
                current = assemble_at(order)
                solution, solve_times = direct_reference(current)
                metrics = comparison_metrics(current, reference, solution, reference_solution)
                checks = {key: metrics[key] <= threshold
                          for key,threshold in data['thresholds'].items()}
                row = dict(order=order, dofs=len(current.b), nonzeros=current.A.nnz,
                           assembly_seconds=current.assembly_seconds,
                           direct_solve_seconds=solve_times, measure=current.measure,
                           **metrics, checks=checks, passed=all(checks.values()))
            except Exception as exc:
                row = dict(order=order, passed=False, error=type(exc).__name__+': '+str(exc))
            row['diagnostic_wall_seconds'] = time.perf_counter()-started
            data['rows'].append(row)
            atomic_json(path, data)
            print('quadrature order', order, 'passed', row['passed'],
                  'matrix', row.get('matrix_relative_frobenius'),
                  'energy', row.get('solution_relative_reference_energy'), flush=True)
            if 'current' in locals():
                del current
            if 'solution' in locals():
                del solution
            gc.collect()
        data['checks']['all_requested_orders_recorded'] = [r['order'] for r in data['rows']]==QUADRATURE_CASE['comparison_orders']
        data['checks']['all_order_thresholds_passed'] = all(r['passed'] for r in data['rows'])
        data['checks']['sources_unchanged_during_audit'] = _check_source_consistency(data)
        data['checks']['all_passed'] = all(data['checks'].values())
        data['complete'] = True
        data['status'] = 'passed' if data['checks']['all_passed'] else 'failed'
    except Exception as exc:
        data.update(status='failed', error=type(exc).__name__+': '+str(exc))
        atomic_json(path, data)
        raise
    data['finished_utc'] = utc_now()
    atomic_json(path, data)
    return data['status']=='passed'


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('mechanism','quadrature','all'), required=True)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'results')
    parser.add_argument('--matrix-tolerance', type=float, default=1e-8)
    parser.add_argument('--energy-tolerance', type=float, default=1e-6)
    parser.add_argument('--residual-tolerance', type=float, default=1e-8)
    args = parser.parse_args(argv)
    outcomes = []
    if args.mode in ('mechanism','all'):
        outcomes.append(run_mechanism(args.output_dir))
    if args.mode in ('quadrature','all'):
        outcomes.append(run_quadrature(args.output_dir, args.matrix_tolerance,
                                       args.energy_tolerance, args.residual_tolerance))
    return 0 if all(outcomes) else 1


if __name__ == '__main__':
    raise SystemExit(main())
