"""Predeclared serial 3D campaign. All policies share each current system.

Pilots are excluded. Every complete sequence includes its cold solve, rejected
screens and any unsuccessful attempt. Repetitions use different fresh probe
seeds; the method order rotates at each query. No rows are removed on failure.
"""
import argparse,gc,hashlib,json,platform,sys,time
from pathlib import Path
import numpy as np
import scipy
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.geometry import TrimDomain
from cmame_trimmed.src.solver import direct_reference
from cmame_trimmed.src.preconditioners import EnergyBudget
from .tensor_assembly import TensorAssembler
from .twolevel import solve_revised
from .screening import ProgressiveEnergyBudget
ROOT=Path(__file__).resolve().parent
METHODS=['fresh','exact_local','energy','progressive','stale','jacobi']
CASES={
 'cubic_long':dict(cells=[12,12,6],degree=3,width=6,coarse_ratio=2,queries=50,step_size=.0001,holes=1),
 'quartic_long':dict(cells=[8,8,4],degree=4,width=4,coarse_ratio=0,queries=50,step_size=.0001,holes=1),
 'quintic':dict(cells=[6,6,4],degree=5,width=3,coarse_ratio=0,queries=12,step_size=.0002,holes=1),
 'refined_cubic':dict(cells=[20,20,8],degree=3,width=5,coarse_ratio=4,queries=12,step_size=.0002,holes=2),
}

def atomic(path,data):
 p=path.with_suffix('.tmp');p.write_text(json.dumps(data,indent=2,allow_nan=False));p.replace(path)

def geometry(config,k):
 dx=k*config['step_size']
 return TrimDomain(holes=((.47+dx,.51,.173),) if config['holes']==1 else ((.34+dx,.38,.139),(.69,.64,.153)))

def source_hashes():
 files=list((ROOT.parent/'src').glob('*.py'))+[ROOT/n for n in ['screening.py','tensor_assembly.py','twolevel.py','campaign.py','kernel_study.py']]
 return {str(f.relative_to(ROOT.parent.parent)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}

def freeze():
 hashes=source_hashes();manifest=ROOT/'results/formal_manifest.json'
 data=dict(cases=CASES,methods=METHODS,repeats=3,quadrature=12,maxiter=2000,rtol=1e-9,tau=.2,delta_per_sequence=1e-8,probes=12,progressive_max_power=6,dimension_cost_cap=True,min_dimension=288,source_hashes=hashes,python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),timing='one process; BLAS threads one; method order rotated at each query; three full repetitions; assembly shared but charged equally; cold solve included',created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
 if manifest.exists():
  old=json.loads(manifest.read_text());assert old['source_hashes']==hashes,'Formal sources changed after freeze';assert old['cases']==CASES
  return old
 snapshot=ROOT/'results/formal_sources'
 for rel in hashes:
  dst=snapshot/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((ROOT.parent.parent/rel).read_bytes())
 atomic(manifest,data);return data

def transfer(previous,ids):
 if previous is None:return None
 old_ids,old_x=previous;common,a,b=np.intersect1d(ids,old_ids,assume_unique=True,return_indices=True)
 x=np.zeros(len(ids));x[a]=old_x[b];return x

def run(name):
 manifest=freeze();cfg=CASES[name];path=ROOT/'results'/('sequence_'+name+'.json')
 if path.exists():raise FileExistsError('Refusing to overwrite formal data: '+str(path))
 data=dict(case=name,config=cfg,methods=METHODS,repeats=3,rows=[],references=[],assembly_audits=[],source_hashes=manifest['source_hashes'],complete=False)
 for rep in range(3):
  assembler=TensorAssembler(SplineGrid(tuple(cfg['cells']),cfg['degree']),physics='elasticity',quadrature=12)
  caches={};previous={};budgets={m:(ProgressiveEnergyBudget(seed=2026101600+rep,probes=12,power=6,min_dimension=288,dimension_cost_cap=True) if m=='progressive' else EnergyBudget(seed=2026101600+rep,min_dimension=288)) for m in ['energy','progressive']}
  for k in range(cfg['queries']):
   system=assembler.assemble(geometry(cfg,k));reference,reference_time=direct_reference(system)
   data['references'].append(dict(repeat=rep,step=k,dofs=len(system.b),**reference_time))
   if rep==0 and k in [0,cfg['queries']//2,cfg['queries']-1]:
    other=TensorAssembler(SplineGrid(tuple(cfg['cells']),cfg['degree']),physics='elasticity',quadrature=12,incremental=False).assemble(geometry(cfg,k))
    diff=system.A-other.A;err=float(np.linalg.norm(diff.data)/np.linalg.norm(other.A.data));rhs=float(np.linalg.norm(system.b-other.b)/np.linalg.norm(other.b));ids=bool(np.array_equal(system.ids,other.ids))
    data['assembly_audits'].append(dict(step=k,matrix_relative_error=err,rhs_relative_error=rhs,identical_active_ids=ids));assert ids and err<2e-12 and rhs<2e-12
    del other,diff;gc.collect()
   shift=(rep+k)%len(METHODS);order=METHODS[shift:]+METHODS[:shift]
   for method in order:
    x0=transfer(previous.get(method),system.ids);t=time.perf_counter()
    try:
     x,cache,row=solve_revised(system,method,cache=caches.get(method),step=k,width=cfg['width'],reference=reference,probability_state=budgets.get(method),coarse_ratio=cfg['coarse_ratio'],x0=x0)
     if method!='fresh':caches[method]=cache
     previous[method]=(system.ids.copy(),x.copy()) if row['success'] else None
     del cache,x
    except (np.linalg.LinAlgError,FloatingPointError,ArithmeticError,ValueError) as exc:
     row=dict(method=method,step=k,success=False,error=type(exc).__name__+': '+str(exc),attempt_seconds=time.perf_counter()-t,dofs=len(system.b));caches.pop(method,None);previous[method]=None
    row.update(repeat=rep,case=name,degree=cfg['degree']);data['rows'].append(row)
    atomic(path,data)
   print(name,'rep',rep,'query',k,'n',len(system.b),'linear',','.join(m+':'+format(data['rows'][-6+order.index(m)].get('linear',-1),'.3f') for m in METHODS),flush=True)
  del assembler,system,reference,caches,previous,budgets;gc.collect()
 data['complete']=True;atomic(path,data)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('case',choices=list(CASES)+['freeze','all']);args=p.parse_args()
 if args.case=='freeze':print(json.dumps(freeze(),indent=2))
 elif args.case=='all':
  for case in CASES:run(case)
 else:run(args.case)
