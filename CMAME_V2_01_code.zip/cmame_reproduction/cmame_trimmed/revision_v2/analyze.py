"""Strict aggregation: failures remain visible and never become speedups."""
import json,hashlib
import math
from pathlib import Path
import numpy as np
from .campaign import CASES,METHODS
ROOT=Path(__file__).resolve().parent
LABELS={'cubic_long':'Cubic / 50 queries','quartic_long':'Quartic / 50 queries','quintic':'Quintic / 12 queries','refined_cubic':'Refined cubic / 12 queries'}

def audit_kernel():
 path=ROOT/'results/kernel_formal.json';d=json.loads(path.read_text());cfg=d['config'];rows=d['rows']
 manifest=json.loads((ROOT/'results/formal_manifest.json').read_text())
 assert d['source_hashes']==manifest['source_hashes']
 methods=['fresh','fixed12x2','adaptive8x3','adaptive4x6','adaptive12x2','progressive']
 expected={(n,dt,r,m) for n in cfg['sizes'] for dt in cfg['increments'] for r in range(cfg['repeats']) for m in methods}
 actual=[(r['size'],r['increment'],r['repeat'],r['method']) for r in rows]
 assert len(actual)==len(expected) and set(actual)==expected,'Incomplete or duplicate kernel coverage'
 for r in rows:
  assert math.isfinite(r['seconds']) and r['seconds']>0 and 0<=r['screen_seconds']<=r['seconds']
  assert math.isfinite(r['exact_drift']) and r['exact_drift']>=0
  if r['method']!='fresh':
   assert math.isfinite(r['bound']) and r['bound']>=0
   assert r['accepted']==(r['bound']<=cfg['tau'])
 checked=[r for r in rows if r['method']!='fresh'];accepted=[r for r in checked if r['accepted']]
 unsafe=[r for r in accepted if r['exact_drift']>cfg['tau']+1e-10]
 under=[r for r in checked if r['bound']+max(1e-13,1e-10*r['exact_drift'])<r['exact_drift']]
 facts=dict(complete=True,rows=len(rows),checks=len(checked),accepted=len(accepted),unsafe_acceptances=len(unsafe),underestimated_bounds=len(under),maximum_accepted_drift=max((r['exact_drift'] for r in accepted),default=None),sizes=cfg['sizes'],increments=cfg['increments'],sha256=hashlib.sha256(path.read_bytes()).hexdigest(),diagnostic_tolerance='1e-10 absolute for acceptance; max(1e-13,1e-10*drift) for estimate comparison',violations=unsafe,underestimates=under)
 (ROOT/'results/kernel_audit.json').write_text(json.dumps(facts,indent=2,allow_nan=False));return facts

def analyze():
 manifest=json.loads((ROOT/'results/formal_manifest.json').read_text());out=dict(cases={},source_hashes=manifest['source_hashes'])
 for name,cfg in CASES.items():
  data=json.loads((ROOT/'results'/('sequence_'+name+'.json')).read_text());assert data['complete'];assert data['config']==cfg
  assert len(data['rows'])==cfg['queries']*3*6
  assert data['source_hashes']==manifest['source_hashes']
  result=dict(config=cfg,methods={},assembly_audits=data['assembly_audits'])
  for m in METHODS:
   rows=[r for r in data['rows'] if r['method']==m];reps=[]
   for rep in range(3):
    rr=sorted([r for r in rows if r['repeat']==rep],key=lambda r:r['step']);assert [r['step'] for r in rr]==list(range(cfg['queries']))
    v=dict(repeat=rep,success=all(r['success'] for r in rr),failures=sum(not r['success'] for r in rr),attempt_work=sum(r.get('linear',r.get('attempt_seconds',0)) for r in rr))
    for key in ['setup','solve','linear','assembly','total','coarse_setup','iterations']:
     v[key]=sum(r[key] for r in rr) if all(key in r for r in rr) else None
    for key in ['factorization_time','randomized_time','extraction_time','randomized_checks','reused_energy','new','refreshed','retired','screen_action_batches','screen_column_actions','screen_early_accepts','screen_early_rejections','screen_lower_bound_rejections','screen_avoided_action_batches','screen_cost_capped_checks']:
     v[key]=sum(r.get('stat_'+key,0) for r in rr)
    v['factorizations']=v['new']+v['refreshed'];v['power_histogram']={str(q):sum(r.get('stat_screen_power_histogram',{}).get(str(q),0) for r in rr) for q in range(1,7)}
    reps.append(v)
   med={key:float(np.median([r[key] for r in reps])) if all(isinstance(r.get(key),(int,float)) for r in reps) else None for key in reps[0] if key not in ['repeat','success','power_histogram']}
   result['methods'][m]=dict(success=all(r['success'] for r in rows),failures=sum(not r['success'] for r in rows),repetitions=reps,median=med,max_iterations=max(r.get('iterations',0) for r in rows),max_residual=max(r.get('residual',0) for r in rows),max_scaled_residual=max(r.get('scaled_residual',0) for r in rows),max_energy_error=max(r.get('energy_error',0) for r in rows),largest_block=max(r.get('stat_largest_block',0) for r in rows),nmin=min(r['dofs'] for r in rows),nmax=max(r['dofs'] for r in rows),coarse_dofs=max(r.get('coarse_dofs',0) for r in rows))
  result['ratios']={}
  p=result['methods']['progressive']
  for m,v in result['methods'].items():
   if v['success'] and p['success']:
    result['ratios'][m]={}
    for metric in ['setup','linear','total']:
     ratios=[a[metric]/b[metric] for a,b in zip(v['repetitions'],p['repetitions'])]
     result['ratios'][m][metric]=dict(ratio_of_medians=v['median'][metric]/p['median'][metric],paired=ratios,minimum=min(ratios),maximum=max(ratios))
  out['cases'][name]=result
 out['geometric_mean']={m:{metric:float(np.exp(np.mean([np.log(v['ratios'][m][metric]['ratio_of_medians']) for v in out['cases'].values()]))) for metric in ['setup','linear','total']} for m in METHODS if all(m in v['ratios'] for v in out['cases'].values())}
 out['solves']=sum(c['queries']*3*6 for c in CASES.values());out['failures']=sum(v['failures'] for c in out['cases'].values() for v in c['methods'].values());out['max_dofs']=max(v['nmax'] for c in out['cases'].values() for v in c['methods'].values())
 out['record_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'results').glob('sequence_*.json')}
 (ROOT/'results/summary.json').write_text(json.dumps(out,indent=2,allow_nan=False));return out
if __name__=='__main__':
 s=analyze();print(json.dumps(dict(geometric_mean=s['geometric_mean'],solves=s['solves'],failures=s['failures'],max_dofs=s['max_dofs']),indent=2))
