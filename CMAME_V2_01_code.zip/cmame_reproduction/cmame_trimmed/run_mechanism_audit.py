"""Small-matrix verification of the conditional polynomial mechanism."""
from pathlib import Path
import json
import numpy as np
from scipy.linalg import eigvalsh
ROOT=Path(__file__).resolve().parent
R=ROOT/'results';R.mkdir(exist_ok=True)
b=4/np.sqrt(3);kappa0=7+4*np.sqrt(3)
G0=np.array([[1.,1.],[1.,4/3]])

def normalized(F):
    d=np.sqrt(F.diagonal());return F/d[:,None]/d[None,:]

def gram(e):return np.array([[e+2*e**2+4*e**3/3,e**2+4*e**3/3],[e**2+4*e**3/3,4*e**3/3]])

def gamma(e):
    r=2*b*e+b*b*e*e;a=np.sqrt(kappa0)*((1-r)**(-.5)-1)
    return r,2*r*kappa0/(1-r),(1+r)*(1+a)**2-1

C0=normalized(G0);ea=.001;Ca=normalized(gram(ea));ga=min(gamma(ea)[1:]);rows=[]
for e in np.geomspace(1e-6,.05,80):
    C=normalized(gram(e));r,g1,g2=gamma(e)
    actual=float(max(abs(eigvalsh(C-C0,C0))));anchor=float(max(abs(eigvalsh(C-Ca,Ca))))
    bound=(min(g1,g2)+ga)/(1-ga)
    raw=eigvalsh(gram(e),gram(ea));transport=eigvalsh(C,Ca)
    assert actual<=min(g1,g2)+1e-12 and anchor<=bound+1e-12
    rows.append(dict(epsilon=float(e),actual_drift=actual,simple_bound=g1,sharper_bound=g2,
                     anchor_drift=anchor,anchor_bound=bound,raw_condition=float(raw[-1]/raw[0]),
                     transported_condition=float(transport[-1]/transport[0])))
limit=1+2/np.sqrt(3)
assert abs(rows[0]['actual_drift']/rows[0]['epsilon']-limit)<1e-4
bad=[]
for e in np.geomspace(1e-4,.1,40):
    F=np.array([[e,e+e*e],[e+e*e,e+2*e*e+4*e**3/3]])
    ev=eigvalsh(normalized(F));bad.append(dict(epsilon=float(e),normalized_condition=float(ev[-1]/ev[0])))
out=dict(example='x+x^2, x^2',anchor_scale=ea,b=float(b),kappa0=float(kappa0),first_order_limit=float(limit),rows=rows,
         singular_leading_example='x, x+x^2',singular_leading_rows=bad,checks_passed=True)
(R/'mechanism_audit.json').write_text(json.dumps(out,indent=2))
print('80 current/anchor inequalities and first-order limit verified; singular-leading comparison retained.')
