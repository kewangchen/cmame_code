import numpy as np
from scipy import sparse
from scipy.sparse.linalg import LinearOperator
from cmame_trimmed.src.assembly import Assembler
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.geometry import TrimDomain
from cmame_trimmed.src.preconditioners import build_schwarz,EnergyBudget
from cmame_trimmed.src.solver import equilibrate,solve,direct_reference


def test_transport_removes_independent_temporal_amplitudes():
    C=np.array([[1.,.2,-.1],[.2,1.,.3],[-.1,.3,1.]])
    ids=np.arange(3);cache=None
    for diag in (np.ones(3),np.array([1e-9,3.,1e7]),np.array([1e4,.003,2.])):
        A=sparse.csr_matrix(diag[:,None]*C*diag[None,:])
        cn,_,d=equilibrate(A,np.ones(3))
        op,cache,stats=build_schwarz(cn,[ids],ids,mode='energy',cache=cache,tau=.2)
        physical=d[:,None]*(op@np.eye(3))*d[None,:]
        np.testing.assert_allclose(diag[:,None]*physical*diag[None,:],np.linalg.inv(C),rtol=2e-14,atol=2e-14)
        assert stats['refreshed']==0


def test_scaled_solver_matches_physical_reference_and_warm_start():
    assembler=Assembler(SplineGrid((7,7),2),quadrature=12)
    s=assembler.assemble(TrimDomain(holes=((.51,.48,.17),)))
    ref,_=direct_reference(s)
    for method in ('fresh','energy','energy_raw','cbas','deflation','jacobi'):
        budget=EnergyBudget()
        x,cache,row=solve(s,method,width=4,reference=ref,probability_state=budget)
        assert row['success'],row
        _,_,warm=solve(s,method,cache=cache,step=1,width=4,reference=ref,x0=x,probability_state=budget)
        assert warm['iterations']==0
