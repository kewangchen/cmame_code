"""Small dense oracles for the sparse preconditioner implementations."""
import unittest
from unittest import mock
import numpy as np
from scipy import linalg, sparse

from cmame_trimmed.src.preconditioners import build_schwarz, coordinate_deflation, jacobi
from cmame_trimmed.src import preconditioners as pc


def dense(operator):
    return operator @ np.eye(operator.shape[0])


def spd(n=6):
    rng = np.random.default_rng(42)
    q = rng.normal(size=(n, n))
    return q.T @ q + np.eye(n)


class PreconditionerTests(unittest.TestCase):
    def setUp(self):
        self.a = spd()
        self.blocks = [np.arange(4), np.arange(2, 6)]
        self.ids = np.arange(10, 16)

    def build(self, a=None, **kwargs):
        return build_schwarz(sparse.csr_matrix(self.a if a is None else a),
                             self.blocks, self.ids, **kwargs)

    def test_fresh_is_additive_inverse_action_and_spd(self):
        op, cache, stats = self.build()
        oracle = np.zeros_like(self.a)
        for b in self.blocks:
            oracle[np.ix_(b, b)] += np.linalg.inv(self.a[np.ix_(b, b)])
        np.testing.assert_allclose(dense(op), oracle, rtol=2e-14, atol=1e-14)
        self.assertGreater(np.linalg.eigvalsh(dense(op))[0], 0)
        self.assertEqual(stats['new'], 2)
        self.assertTrue(all(f.inverse_diagonal is None for f in cache.values()))
        self.assertGreaterEqual(stats['setup_time'], stats['factorization_time'])

    def test_exact_local_reuses_only_identical_anchor_and_retires_membership(self):
        _, cache, _ = self.build(mode='exact_local')
        _, c2, stats = self.build(mode='exact_local', cache=cache)
        self.assertEqual(stats['reused_exact'], 2)
        self.assertIs(c2[(10, 11, 12, 13)], cache[(10, 11, 12, 13)])
        a = self.a.copy()
        a[0, 0] += .1
        _, c3, stats = self.build(a, mode='exact_local', cache=c2)
        self.assertEqual((stats['refreshed'], stats['reused_exact']), (1, 1))
        _, c4, stats = build_schwarz(sparse.csr_matrix(a[:5, :5]),
                                    [np.arange(3), np.arange(2, 5)], self.ids[:5],
                                    mode='exact_local', cache=c3)
        self.assertEqual(stats['new'], 2)
        self.assertEqual(stats['retired'], 2)
        self.assertEqual(set(c4), {(10, 11, 12), (12, 13, 14)})

    def test_energy_anchor_prevents_accumulated_drift(self):
        a = np.eye(2)
        b = [np.arange(2)]
        _, cache, _ = build_schwarz(sparse.csr_matrix(a), b, np.arange(2), mode='energy')
        _, c2, s2 = build_schwarz(sparse.csr_matrix(1.15*a), b, np.arange(2), mode='energy', cache=cache)
        self.assertEqual(s2['reused_energy'], 1)
        np.testing.assert_array_equal(next(iter(c2.values())).anchor, a)
        _, c3, s3 = build_schwarz(sparse.csr_matrix(1.30*a), b, np.arange(2), mode='energy', cache=c2)
        self.assertEqual(s3['refreshed'], 1)
        np.testing.assert_array_equal(next(iter(c3.values())).anchor, 1.30*a)

    def test_support_spectral_check_accepts_when_first_bound_is_loose(self):
        a = np.eye(3)
        b = [np.arange(3)]
        _, cache, _ = build_schwarz(sparse.csr_matrix(a), b, np.arange(3), mode='energy')
        # Both cheap bounds exceed tau, while the star's exact spectral norm
        # is .12*sqrt(2), below tau.
        changed = a + np.array([[0., .12, .12], [.12, 0., 0.], [.12, 0., 0.]])
        op, _, stats = build_schwarz(sparse.csr_matrix(changed), b, np.arange(3), mode='energy', cache=cache)
        self.assertEqual(stats['first_checks'], 1)
        self.assertEqual(stats['spectral_checks'], 1)
        self.assertEqual(stats['peak_rank'], 3)
        self.assertEqual(stats['reused_energy'], 1)
        np.testing.assert_allclose(dense(op), a)

    def test_large_contraction_refreshes_instead_of_one_sided_acceptance(self):
        a = np.eye(3)
        b = [np.arange(3)]
        _, cache, _ = build_schwarz(sparse.csr_matrix(a), b, np.arange(3), mode='energy')
        op, _, stats = build_schwarz(sparse.csr_matrix(.05*a), b, np.arange(3), mode='energy', cache=cache)
        self.assertEqual(stats['refreshed'], 1)
        np.testing.assert_allclose(dense(op), 20*a)

    def test_energy_reuse_has_loewner_and_condition_inflation_bounds(self):
        _, cache, _ = self.build(mode='energy')
        a = 1.03*self.a
        reuse, _, stats = self.build(a, mode='energy', cache=cache, tau=.2)
        fresh, _, _ = self.build(a)
        br, bf = dense(reuse), dense(fresh)
        comparison = linalg.eigvalsh(br, bf)
        self.assertGreaterEqual(comparison.min(), .8-1e-12)
        self.assertLessEqual(comparison.max(), 1.2+1e-12)
        def condition(b):
            l = linalg.cholesky(b, lower=True)
            e = linalg.eigvalsh(l.T @ a @ l)
            return e[-1]/e[0]
        self.assertLessEqual(condition(br)/condition(bf), 1.2/.8+1e-12)
        self.assertEqual(stats['reused_energy'], 2)

    def test_energy_screen_and_inverse_are_invariant_to_scaled_basis(self):
        a = spd(4)
        changed = a.copy()
        changed[0, 0] += .015
        scale = np.array([1e-70, -1e-20, 1e20, 1e70])
        b = [np.arange(4)]
        _, cache, _ = build_schwarz(sparse.csr_matrix(a), b, np.arange(4), mode='energy')
        op, _, stats = build_schwarz(sparse.csr_matrix(changed), b, np.arange(4), mode='energy', cache=cache)
        _, scaled_cache, _ = build_schwarz(sparse.csr_matrix(scale[:, None]*a*scale[None, :]), b, np.arange(4), mode='energy')
        scaled_op, _, ss = build_schwarz(sparse.csr_matrix(scale[:, None]*changed*scale[None, :]), b, np.arange(4), mode='energy', cache=scaled_cache)
        self.assertEqual(stats['reused_energy'], ss['reused_energy'])
        np.testing.assert_allclose(scale[:, None]*dense(scaled_op)*scale[None, :], dense(op), rtol=1e-12, atol=1e-13)
        self.assertIsNone(ss['max_factor_residual'])

    def test_stale_periodic_and_missing_row_fallback(self):
        a = sparse.diags([2., 3., 4.]).tocsr()
        b = [np.array([0, 1])]
        op, cache, st = build_schwarz(a, b, np.arange(3), mode='stale')
        self.assertEqual(st['uncovered_rows'], 1)
        np.testing.assert_allclose(dense(op), np.diag([.5, 1/3, .25]))
        stale, cache, st = build_schwarz(2*a, b, np.arange(3), mode='stale', cache=cache)
        np.testing.assert_allclose(dense(stale), dense(op))
        self.assertEqual(st['reused_stale'], 2)
        periodic, _, st = build_schwarz(2*a, b, np.arange(3), mode='periodic', cache=cache, step=5, period=5)
        np.testing.assert_allclose(dense(periodic), .5*dense(op))
        self.assertEqual(st['refreshed'], 2)

    def test_jacobi_and_balanced_coordinate_deflation_dense_oracles(self):
        np.testing.assert_allclose(dense(jacobi(sparse.csr_matrix(self.a))), np.diag(1/np.diag(self.a)))
        k = np.array([1, 4])
        z = np.eye(6)[:, k]
        q = z @ np.linalg.solve(z.T @ self.a @ z, z.T)
        oracle = q + (np.eye(6)-q@self.a) @ np.diag(1/np.diag(self.a)) @ (np.eye(6)-self.a@q)
        actual = dense(coordinate_deflation(sparse.csr_matrix(self.a), k))
        np.testing.assert_allclose(actual, oracle, atol=2e-14)
        self.assertGreater(np.linalg.eigvalsh(actual)[0], 0)
        np.testing.assert_allclose(actual @ self.a @ z, z, atol=2e-14)

    def test_invalid_local_system_is_explicit(self):
        with self.assertRaises(np.linalg.LinAlgError):
            build_schwarz(sparse.csr_matrix([[1., 2.], [2., 1.]]), [np.arange(2)], np.arange(2))
        with self.assertRaises(ValueError):
            build_schwarz(sparse.eye(2).tocsr(), [np.arange(2)], np.array([0, 0]))
        with self.assertRaises(ValueError):
            build_schwarz(sparse.eye(2).tocsr(), [np.arange(2)], np.arange(2), tau=1.)
        with self.assertRaises(ValueError):
            jacobi(sparse.diags([0., 1.]).tocsr())

    def test_compressed_spectrum_matches_independent_generalized_eigenvalues(self):
        a = spd(8)
        perturbation = np.zeros((8, 8))
        k = np.array([1, 4, 7])
        perturbation[np.ix_(k, k)] = np.array([[.1, -.04, .02], [-.04, -.08, .03], [.02, .03, .05]])
        b = [np.arange(8)]
        _, cache, _ = build_schwarz(sparse.csr_matrix(a), b, np.arange(8), mode='energy', tau=.01)
        _, _, stats = build_schwarz(sparse.csr_matrix(a+perturbation), b, np.arange(8), mode='energy', cache=cache, tau=.01)
        exact = np.max(np.abs(linalg.eigvalsh(perturbation, a)))
        self.assertEqual(stats['spectral_checks'], 1)
        self.assertAlmostEqual(stats['max_spectral_norm'], exact, places=14)
        self.assertGreaterEqual(stats['max_first_bound']+1e-14, exact)

    def test_large_support_cannot_bypass_failed_first_bound(self):
        a = sparse.eye(33).tocsr()
        b = [np.arange(33)]
        _, cache, _ = build_schwarz(a, b, np.arange(33), mode='energy')
        _, _, stats = build_schwarz(1.3*a, b, np.arange(33), mode='energy', cache=cache)
        self.assertEqual(stats['first_checks'], 1)
        self.assertEqual(stats['spectral_checks'], 0)
        self.assertEqual(stats['refreshed'], 1)
        self.assertEqual(stats['peak_rank'], 33)

    def test_global_sparse_matrix_is_never_converted_to_dense(self):
        class SparseOnly(sparse.csr_matrix):
            def toarray(self, *args, **kwargs):
                if self.shape == (100, 100):
                    raise AssertionError('global matrix was densified')
                return super().toarray(*args, **kwargs)
        a = SparseOnly(sparse.diags([2.]*100))
        op, _, _ = build_schwarz(a, [np.arange(i, i+2) for i in range(0, 100, 2)], np.arange(100))
        np.testing.assert_allclose(op @ np.ones(100), .5*np.ones(100))

    def test_nonfinite_inverse_energy_data_is_rejected_explicitly(self):
        # A positive factor with an overflowing inverse remains usable only if
        # the caller does not request unrepresentable inverse diagnostics.
        with self.assertRaises(FloatingPointError):
            build_schwarz(sparse.csr_matrix([[1e-320]]), [np.array([0])], np.array([0]), mode='energy')

    def test_energy_preparation_records_inverse_residual(self):
        _, cache, cold = self.build(mode='energy', diagnostics=True)
        self.assertTrue(all(f.inverse_diagonal is None for f in cache.values()))
        _, cache, stats = self.build(1.001*self.a, mode='energy', cache=cache, diagnostics=True)
        for factor in cache.values():
            exact = np.diag(np.linalg.inv(factor.anchor))
            np.testing.assert_allclose(factor.inverse_diagonal, exact, rtol=1e-14)
            self.assertLess(factor.inverse_residual, 1e-13)
        self.assertLess(stats['max_inverse_residual'], 1e-13)

    def test_singletons_are_batched_and_keep_additive_overlap_weight(self):
        a = spd(4)
        blocks = [np.array([0]), np.array([1]), np.array([0, 1, 2])]
        op, cache, stats = build_schwarz(sparse.csr_matrix(a), blocks, np.arange(4), mode='energy')
        oracle = np.diag([1/a[0, 0], 1/a[1, 1], 0., 1/a[3, 3]])
        oracle[:3, :3] += np.linalg.inv(a[:3, :3])
        original = type(next(iter(cache.values()))).solve
        def no_singleton_solves(factor, rhs):
            self.assertGreater(len(factor.scale), 1)
            return original(factor, rhs)
        with mock.patch.object(type(next(iter(cache.values()))), 'solve', no_singleton_solves):
            np.testing.assert_allclose(dense(op), oracle, rtol=1e-13, atol=1e-14)
        self.assertEqual(stats['singleton_blocks'], 3)
        self.assertEqual(stats['new'], 4)

    def test_diagnostics_are_opt_in_and_can_audit_existing_cache(self):
        _, cache, stats = self.build(mode='energy')
        self.assertIsNone(stats['max_factor_residual'])
        self.assertIsNone(stats['max_inverse_residual'])
        self.assertTrue(all(f.factor_residual is None and f.inverse_residual is None for f in cache.values()))
        _, cache, _ = self.build(1.001*self.a, mode='energy', cache=cache)
        _, _, audit = self.build(1.001*self.a, mode='energy', cache=cache, diagnostics=True)
        self.assertLess(audit['max_factor_residual'], 1e-13)
        self.assertLess(audit['max_inverse_residual'], 1e-13)

    def test_changed_closure_skips_extraction_after_accepted_anchor_drift(self):
        a = sparse.eye(3).tocsr()
        blocks = [np.arange(3)]
        ids = np.array([10, 20, 30])
        _, cache, _ = build_schwarz(a, blocks, ids, mode='energy')
        _, drift, stats = build_schwarz(1.1*a, blocks, ids, mode='energy', cache=cache, changed_global_ids=ids)
        self.assertEqual(stats['reused_energy'], 1)
        with mock.patch.object(sparse.csr_matrix, 'toarray', side_effect=AssertionError('untouched block extracted')):
            op, same, stats = build_schwarz(1.1*a, blocks, ids, mode='energy', cache=drift, changed_global_ids=[])
        self.assertEqual(stats['reused_unchanged'], 1)
        self.assertAlmostEqual(stats['max_accepted_bound'], .1)
        np.testing.assert_array_equal(next(iter(same.values())).anchor, np.eye(3))
        np.testing.assert_allclose(dense(op), np.eye(3))
        _, refreshed, stats = build_schwarz(1.3*a, blocks, ids, mode='energy', cache=same, changed_global_ids=ids)
        self.assertEqual(stats['refreshed'], 1)
        np.testing.assert_array_equal(next(iter(refreshed.values())).anchor, 1.3*np.eye(3))

    def test_changed_closure_respects_stricter_tau_and_stale_anchor(self):
        a = sparse.eye(2).tocsr()
        blocks = [np.arange(2)]
        ids = np.arange(2)
        _, cache, _ = build_schwarz(a, blocks, ids, mode='energy')
        _, drift, _ = build_schwarz(1.1*a, blocks, ids, mode='energy', cache=cache)
        _, _, stats = build_schwarz(1.1*a, blocks, ids, mode='energy', cache=drift, tau=.05, changed_global_ids=[])
        self.assertEqual(stats['refreshed'], 1)
        _, stale, _ = build_schwarz(2*a, blocks, ids, mode='stale', cache=cache)
        _, _, stats = build_schwarz(2*a, blocks, ids, mode='energy', cache=stale, changed_global_ids=[])
        self.assertEqual(stats['refreshed'], 1)
        _, _, stats = build_schwarz(2*a, blocks, ids, mode='periodic', cache=stale, step=5, changed_global_ids=[])
        self.assertEqual(stats['refreshed'], 1)

    def test_changed_closure_uses_stable_ids_across_row_permutation(self):
        a = np.diag([2., 3., 4.])
        ids = np.array([10, 20, 30])
        _, cache, _ = build_schwarz(sparse.csr_matrix(a), [np.array([0, 1]), np.array([2])], ids, mode='exact_local')
        permutation = np.array([2, 0, 1])
        with mock.patch.object(sparse.csr_matrix, '__getitem__', side_effect=AssertionError('untouched block extracted')):
            op, _, stats = build_schwarz(sparse.csr_matrix(a[np.ix_(permutation, permutation)]),
                                        [np.array([1, 2]), np.array([0])], ids[permutation],
                                        mode='exact_local', cache=cache, changed_global_ids=[])
        self.assertEqual(stats['reused_unchanged'], 2)
        np.testing.assert_allclose(dense(op), np.diag([.25, .5, 1/3]))

    def test_energy_inverse_preparation_is_lazy_and_refresh_resets_it(self):
        a = sparse.eye(3).tocsr()
        blocks = [np.arange(3)]
        ids = np.arange(3)
        _, cache, cold = build_schwarz(a, blocks, ids, mode='energy')
        self.assertIsNone(next(iter(cache.values())).inverse_diagonal)
        self.assertEqual(cold['energy_preparation_time'], 0.)
        _, same, stats = build_schwarz(a, blocks, ids, mode='energy', cache=cache)
        self.assertIsNone(next(iter(same.values())).inverse_diagonal)
        self.assertEqual(stats['energy_preparation_time'], 0.)
        _, drift, _ = build_schwarz(1.01*a, blocks, ids, mode='energy', cache=same)
        self.assertIsNotNone(next(iter(drift.values())).inverse_diagonal)
        _, fresh, _ = build_schwarz(1.5*a, blocks, ids, mode='energy', cache=drift)
        self.assertIsNone(next(iter(fresh.values())).inverse_diagonal)

    def test_configurable_spectral_cap_preserves_exact_spectral_decision(self):
        a = sparse.eye(33).tocsr()
        blocks = [np.arange(33)]
        ids = np.arange(33)
        _, cache, _ = build_schwarz(a, blocks, ids, mode='energy')
        star = np.zeros((33, 33))
        star[0, 1:] = .02
        star[1:, 0] = .02
        _, _, stats = build_schwarz(a+sparse.csr_matrix(star), blocks, ids,
                                    mode='energy', cache=cache, spectral_cap=64)
        self.assertEqual(stats['spectral_checks'], 1)
        self.assertEqual(stats['reused_energy'], 1)
        self.assertAlmostEqual(stats['max_spectral_norm'], .02*np.sqrt(32))

    def test_singleton_setup_has_no_individual_factor_or_solve_calls(self):
        a = sparse.diags([2., 3., 4., 5.]).tocsr()
        with mock.patch('cmame_trimmed.src.preconditioners.linalg.cholesky', side_effect=AssertionError('scalar Cholesky')):
            with mock.patch('cmame_trimmed.src.preconditioners.linalg.cho_solve', side_effect=AssertionError('scalar solve')):
                op, cache, stats = build_schwarz(a, [np.array([0])], np.arange(4), mode='energy')
                np.testing.assert_allclose(dense(op), np.diag([.5, 1/3, .25, .2]))
        self.assertTrue(all(f.inverse_diagonal is None for f in cache.values()))
        self.assertEqual(stats['energy_preparation_time'], 0.)

    def test_duplicate_blocks_preserve_multiplicity_with_one_factor_each(self):
        a = spd(4)
        blocks = [np.array([0, 1]), np.array([0, 1]), np.array([1, 2]),
                  np.array([2]), np.array([2])]
        oracle = np.zeros((4, 4))
        for rows in blocks+[np.array([3])]:
            oracle[np.ix_(rows, rows)] += np.linalg.inv(a[np.ix_(rows, rows)])
        op, cache, stats = build_schwarz(sparse.csr_matrix(a), blocks, np.arange(4), mode='energy')
        np.testing.assert_allclose(dense(op), oracle, rtol=1e-13, atol=1e-14)
        self.assertEqual(stats['blocks'], 6)
        self.assertEqual(stats['unique_blocks'], 4)
        self.assertEqual(stats['new'], 4)
        self.assertEqual(stats['singleton_blocks'], 3)
        self.assertEqual(stats['unique_singleton_blocks'], 2)
        self.assertEqual(len(cache), 4)
        op, _, stats = build_schwarz(sparse.csr_matrix(a), blocks, np.arange(4),
                                     mode='energy', cache=cache, changed_global_ids=[])
        self.assertEqual(stats['reused_unchanged'], 4)
        np.testing.assert_allclose(dense(op), oracle, rtol=1e-13, atol=1e-14)

    def test_operator_first_bound_accepts_broad_change_without_spectral_solve(self):
        a = sparse.eye(40).tocsr()
        blocks = [np.arange(40)]
        _, cache, _ = build_schwarz(a, blocks, np.arange(40), mode='energy')
        _, _, stats = build_schwarz(1.01*a, blocks, np.arange(40), mode='energy', cache=cache)
        self.assertAlmostEqual(stats['first_coordinate_bound'], .4)
        self.assertAlmostEqual(stats['first_operator_bound'], .01)
        self.assertEqual(stats['operator_only_accepts'], 1)
        self.assertEqual(stats['reused_energy'], 1)
        self.assertEqual(stats['spectral_checks'], 0)

    def test_first_bounds_dominate_dense_eigen_oracle_under_scaled_basis(self):
        a = spd(7)
        delta = .003*np.diag([1., -1., 2., -2., 3., -3., 1.])
        exact = np.max(np.abs(linalg.eigvalsh(delta, a)))
        b = [np.arange(7)]
        records = []
        for scale in (np.ones(7), np.array([1e-70, -1e-40, 1e-10, -1., 1e10, -1e40, 1e70])):
            h = scale[:, None]*a*scale[None, :]
            current = scale[:, None]*(a+delta)*scale[None, :]
            _, cache, _ = build_schwarz(sparse.csr_matrix(h), b, np.arange(7), mode='energy')
            _, cache, stats = build_schwarz(sparse.csr_matrix(current), b, np.arange(7), mode='energy', cache=cache)
            factor = next(iter(cache.values()))
            c = factor.anchor/factor.scale[:, None]/factor.scale[None, :]
            self.assertGreaterEqual(factor.inverse_factor_norm_bound+1e-12,
                                    linalg.eigvalsh(np.linalg.inv(c))[-1])
            self.assertGreaterEqual(stats['first_coordinate_bound']+1e-13, exact)
            self.assertGreaterEqual(stats['first_operator_bound']+1e-13, exact)
            self.assertAlmostEqual(stats['max_first_bound'], min(stats['first_coordinate_bound'], stats['first_operator_bound']))
            records.append([stats['first_coordinate_bound'], stats['first_operator_bound']])
        np.testing.assert_allclose(records[0], records[1], rtol=1e-11, atol=1e-13)

    def test_random_energy_actions_match_independent_dense_operator(self):
        a = spd(6)
        delta = .001*np.diag([1., -2., 3., -1., 2., -3.])
        state = pc.EnergyBudget(seed=123, delta_total=1e-8, probes=24, power=1)
        rows = [np.arange(6)]
        _, cache, cold = build_schwarz(sparse.csr_matrix(a), rows, np.arange(6),
                                      mode='prob_energy', probability_state=state)
        self.assertEqual(state.count, 0)
        with mock.patch.object(pc.LocalFactor, 'prepare_energy', side_effect=AssertionError('inverse prepared')):
            op, cache, stats = build_schwarz(sparse.csr_matrix(a+delta), rows, np.arange(6),
                                            mode='prob_energy', probability_state=state, cache=cache)
        scale = np.sqrt(np.diag(a))
        c = a/scale[:, None]/scale[None, :]
        e = delta/scale[:, None]/scale[None, :]
        lower = np.linalg.cholesky(c)
        k = np.linalg.solve(lower, np.linalg.solve(lower, e).T).T
        omega = np.random.default_rng(123).standard_normal((6, 24))
        allocation = 6e-8/np.pi**2
        alpha = np.sqrt(2/np.pi)*allocation**(-1/24)
        beta = alpha*np.linalg.norm(k@omega, axis=0).max()
        self.assertAlmostEqual(stats['max_randomized_bound'], beta, places=13)
        self.assertGreaterEqual(beta, np.max(np.abs(linalg.eigvalsh(delta, a))))
        self.assertEqual(stats['randomized_checks'], 1)
        self.assertEqual(stats['reused_energy'], 1)
        self.assertEqual(stats['cumulative_checks'], 1)
        self.assertEqual(stats['energy_preparation_time'], 0.)
        self.assertTrue(all(f.inverse_diagonal is None for f in cache.values()))
        before = repr(state.rng.bit_generator.state)
        np.testing.assert_allclose(dense(op), np.linalg.inv(a), atol=1e-13)
        self.assertEqual(before, repr(state.rng.bit_generator.state))
        state = pc.EnergyBudget(seed=123, delta_total=1e-8, probes=12, power=2)
        _, cache, _ = build_schwarz(sparse.csr_matrix(a), rows, np.arange(6),
                                   mode='prob_energy', probability_state=state)
        _, _, stats = build_schwarz(sparse.csr_matrix(a+delta), rows, np.arange(6),
                                    mode='prob_energy', probability_state=state, cache=cache)
        omega = np.random.default_rng(123).standard_normal((6, 12))
        alpha = np.sqrt(2/np.pi)*allocation**(-1/12)
        expected = np.sqrt(alpha*np.linalg.norm(k@k@omega, axis=0).max())
        self.assertAlmostEqual(stats['max_randomized_bound'], expected, places=13)

    def test_random_energy_replay_budget_sum_and_cumulative_drift(self):
        a = sparse.eye(4).tocsr()
        rows = [np.arange(4)]
        def sequence():
            state = pc.EnergyBudget(seed=77)
            cache = None
            records = []
            for amplitude in (1., 1.001, 1.002, 1.003, 1.5):
                _, cache, stats = build_schwarz(amplitude*a, rows, np.arange(4), mode='prob_energy',
                                                cache=cache, probability_state=state)
                records.append((stats['max_randomized_bound'], stats['reused_energy'], stats['refreshed']))
            return state, cache, records
        state, cache, record = sequence()
        other, _, replay = sequence()
        self.assertEqual(record, replay)
        self.assertEqual(state.count, 4)
        self.assertAlmostEqual(state.spent_failure_budget,
                               6*state.delta_total/np.pi**2*sum(1/j**2 for j in range(1, 5)), places=22)
        self.assertLessEqual(state.spent_failure_budget, state.delta_total)
        self.assertEqual(record[-1][2], 1)
        np.testing.assert_array_equal(next(iter(cache.values())).anchor, 1.5*np.eye(4))
        self.assertIsNone(next(iter(cache.values())).inverse_diagonal)

    def test_random_certificate_provenance_and_unchanged_skip(self):
        a = sparse.eye(3).tocsr()
        rows = [np.arange(3)]
        state = pc.EnergyBudget(seed=12)
        _, cache, _ = build_schwarz(a, rows, np.arange(3), mode='prob_energy', probability_state=state)
        _, drift, _ = build_schwarz(1.001*a, rows, np.arange(3), mode='prob_energy', probability_state=state, cache=cache)
        with mock.patch.object(sparse.csr_matrix, 'toarray', side_effect=AssertionError('unchanged randomized block extracted')):
            _, _, stats = build_schwarz(1.001*a, rows, np.arange(3), mode='prob_energy', probability_state=state,
                                        cache=drift, changed_global_ids=[])
        self.assertEqual(stats['reused_unchanged'], 1)
        self.assertEqual(state.count, 1)
        new_state = pc.EnergyBudget(seed=12)
        _, _, stats = build_schwarz(1.001*a, rows, np.arange(3), mode='prob_energy', probability_state=new_state,
                                    cache=drift, changed_global_ids=[])
        self.assertEqual(stats['randomized_checks'], 1)
        _, _, stats = build_schwarz(1.001*a, rows, np.arange(3), mode='energy', cache=drift, changed_global_ids=[])
        self.assertEqual(stats['reused_unchanged'], 0)
        self.assertEqual(stats['first_checks'], 1)

    def test_random_bound_scaling_and_temporal_diagonal_transport(self):
        a = spd(5)
        changed = a + .0001*np.diag([1., -1., 2., -2., 1.])
        betas = []
        for scale in (np.ones(5), np.array([1e-60, 1e-20, 1., 1e20, 1e60]),
                      np.array([1e-60, -1e-20, 1., -1e20, 1e60])):
            state = pc.EnergyBudget(seed=444)
            h = scale[:, None]*a*scale[None, :]
            current = scale[:, None]*changed*scale[None, :]
            _, cache, _ = build_schwarz(sparse.csr_matrix(h), [np.arange(5)], np.arange(5), mode='prob_energy', probability_state=state)
            _, _, stats = build_schwarz(sparse.csr_matrix(current), [np.arange(5)], np.arange(5), mode='prob_energy', probability_state=state, cache=cache)
            betas.append(stats['max_randomized_bound'])
            self.assertGreaterEqual(stats['max_randomized_bound'], np.max(np.abs(linalg.eigvalsh(changed-a, a))))
            self.assertEqual(stats['reused_energy'], 1)
        np.testing.assert_allclose(betas[0], betas[1], rtol=1e-10, atol=1e-13)
        def normalized(a):
            d = np.sqrt(np.diag(a))
            return a/d[:, None]/d[None, :]
        state = pc.EnergyBudget(seed=44)
        c = normalized(a)
        temporal = np.array([.1, 2., 3., 5., 10.])
        ct = normalized(temporal[:, None]*a*temporal[None, :])
        _, cache, _ = build_schwarz(sparse.csr_matrix(c), [np.arange(5)], np.arange(5), mode='prob_energy', probability_state=state)
        _, _, stats = build_schwarz(sparse.csr_matrix(ct), [np.arange(5)], np.arange(5), mode='prob_energy', probability_state=state, cache=cache)
        self.assertLess(stats['max_randomized_bound'], 1e-12)
        self.assertEqual(stats['refreshed'], 0)

    def test_random_energy_invalid_budget_inputs(self):
        a = sparse.eye(2).tocsr()
        args = (a, [np.arange(2)], np.arange(2))
        with self.assertRaises(ValueError):
            build_schwarz(*args, mode='prob_energy')
        with self.assertRaises(TypeError):
            build_schwarz(*args, mode='prob_energy', probability_state=object())
        for failure in (0., -1., 1., np.inf, np.nan):
            with self.assertRaises(ValueError):
                pc.EnergyBudget(delta_total=failure)
        for probes in (0, -1, 1.5):
            with self.assertRaises(ValueError):
                pc.EnergyBudget(probes=probes)
        for power in (0, -1, 1.5):
            with self.assertRaises(ValueError):
                pc.EnergyBudget(power=power)
        with self.assertRaises(ValueError):
            pc.EnergyBudget(seed=-1)

    def test_random_power_action_avoids_naive_underflow(self):
        state = pc.EnergyBudget(seed=999, power=2, probes=12)
        a = np.eye(3)
        shape = np.array([[0., 1., 0.], [1., 0., 0.], [0., 0., 0.]])
        _, cache, _ = build_schwarz(sparse.csr_matrix(a), [np.arange(3)], np.arange(3),
                                   mode='prob_energy', probability_state=state)
        _, _, stats = build_schwarz(sparse.csr_matrix(a+1e-200*shape), [np.arange(3)], np.arange(3),
                                    mode='prob_energy', probability_state=state, cache=cache)
        omega = np.random.default_rng(999).standard_normal((3, 12))
        alpha = np.sqrt(2/np.pi)*(6e-8/np.pi**2)**(-1/12)
        expected = 1e-200*np.sqrt(alpha*np.linalg.norm(shape@shape@omega, axis=0).max())
        self.assertGreater(stats['max_randomized_bound'], 0.)
        self.assertAlmostEqual(stats['max_randomized_bound']/expected, 1., places=12)

    def test_random_small_block_bypass_refreshes_without_spending_budget(self):
        a = sparse.eye(2).tocsr()
        state = pc.EnergyBudget(seed=45, min_dimension=2)
        rows = [np.arange(2)]
        _, cache, _ = build_schwarz(a, rows, np.arange(2), mode='prob_energy', probability_state=state)
        _, same, exact = build_schwarz(a, rows, np.arange(2), mode='prob_energy', probability_state=state, cache=cache)
        self.assertEqual(exact['reused_exact'], 1)
        self.assertEqual(exact['skipped_small_blocks'], 0)
        before = repr(state.rng.bit_generator.state)
        op, refreshed, stats = build_schwarz(1.001*a, rows, np.arange(2), mode='prob_energy',
                                            probability_state=state, cache=same)
        self.assertEqual(stats['skipped_small_blocks'], 1)
        self.assertEqual(stats['refreshed'], 1)
        self.assertEqual(stats['randomized_checks'], 0)
        self.assertEqual(stats['energy_preparation_time'], 0.)
        self.assertEqual(state.count, 0)
        self.assertEqual(state.spent_failure_budget, 0.)
        self.assertEqual(before, repr(state.rng.bit_generator.state))
        self.assertIsNone(next(iter(refreshed.values())).inverse_diagonal)
        np.testing.assert_allclose(dense(op), np.eye(2)/1.001)

    def test_random_large_block_remains_eligible_and_threshold_validates(self):
        a = sparse.eye(3).tocsr()
        state = pc.EnergyBudget(seed=45, min_dimension=2)
        _, cache, _ = build_schwarz(a, [np.arange(3)], np.arange(3), mode='prob_energy', probability_state=state)
        _, _, stats = build_schwarz(1.001*a, [np.arange(3)], np.arange(3), mode='prob_energy',
                                    probability_state=state, cache=cache)
        self.assertEqual(stats['skipped_small_blocks'], 0)
        self.assertEqual(stats['randomized_checks'], 1)
        self.assertEqual(stats['reused_energy'], 1)
        self.assertEqual(state.count, 1)
        for threshold in (-1, 1.5, True):
            with self.assertRaises(ValueError):
                pc.EnergyBudget(min_dimension=threshold)


if __name__ == '__main__':
    unittest.main()
