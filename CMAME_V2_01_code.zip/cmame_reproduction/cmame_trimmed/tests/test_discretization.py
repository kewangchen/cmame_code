import numpy as np
from scipy.sparse.linalg import spsolve
from cmame_trimmed.src.geometry import TrimDomain, cut_quadrature
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.assembly import Assembler


def test_rectangle_and_tiny_strip_moments():
    for top in (0.83, 1e-8):
        points,w=cut_quadrature((0.,1.,0.,1.),TrimDomain(top=top),6)
        assert np.isclose(w.sum(),top,rtol=1e-13,atol=0.)
        assert np.isclose(w@points[:,1]**3,top**4/4,rtol=1e-12,atol=0.)


def test_circle_area_resolves_cut_geometry():
    geometry=TrimDomain(holes=((.5,.5,.21),))
    measures=[]
    for q in (8,16,32):
        total=0.
        for i in range(8):
            for j in range(8):
                _,w=cut_quadrature((i/8,(i+1)/8,j/8,(j+1)/8),geometry,q)
                total+=w.sum()
        measures.append(total)
    exact=1-np.pi*.21**2
    assert abs(measures[-1]-exact)<2e-8
    assert abs(measures[-1]-exact)<abs(measures[0]-exact)


def test_partition_unity_and_gradient():
    grid=SplineGrid((5,4),3)
    q=np.array([[.43,.31],[.58,.48]])
    ids,N,G=grid.local((2,1),q)
    np.testing.assert_allclose(N.sum(1),1,atol=2e-15)
    np.testing.assert_allclose(G.sum(1),0,atol=3e-14)
    x=grid.greville()[ids]
    np.testing.assert_allclose(N@x,q,atol=3e-15)
    np.testing.assert_allclose(np.einsum('qia,ib->qab',G,x),np.broadcast_to(np.eye(2),(2,2,2)),atol=2e-14)


def test_affine_patch_and_symmetric_spd():
    grid=SplineGrid((6,5),2)
    assembler=Assembler(grid,quadrature=10,load='affine')
    sys=assembler.assemble(TrimDomain(holes=((.51,.48,.19),)))
    u=spsolve(sys.A,sys.b)
    expected=grid.greville()[sys.ids,0]
    np.testing.assert_allclose(u,expected,atol=2e-9,rtol=2e-9)
    np.testing.assert_allclose(sys.A.toarray(),sys.A.T.toarray(),atol=1e-14)
    assert np.linalg.eigvalsh(sys.A.toarray())[0]>0


def test_edit_support_closure_and_exact_cached_cells():
    grid=SplineGrid((10,10),2)
    assembler=Assembler(grid,quadrature=8)
    first=assembler.assemble(TrimDomain(holes=((.51,.48,.17),)))
    second=assembler.assemble(TrimDomain(holes=((.52,.48,.17),)))
    diff=(second.A_full-first.A_full).tocoo()
    affected=set(second.changed_ids)
    assert all(int(i) in affected and int(j) in affected for i,j in zip(diff.row,diff.col))
    assert 0<second.changed_cells<100
    assert second.cached_cells>0


def test_linear_elasticity_affine_patch():
    grid=SplineGrid((4,4),2)
    assembler=Assembler(grid,physics='elasticity',quadrature=8,load='affine')
    sys=assembler.assemble(TrimDomain(holes=((.5,.5,.18),)))
    u=spsolve(sys.A,sys.b)
    coords=grid.greville()
    expected=np.column_stack((coords[:,0],.2*coords[:,0])).ravel()[sys.ids]
    np.testing.assert_allclose(u,expected,rtol=1e-8,atol=1e-8)


def test_extruded_volume_and_free_dofs():
    grid=SplineGrid((3,3,2),2)
    assembler=Assembler(grid,quadrature=6,load='affine')
    sys=assembler.assemble(TrimDomain(top=.81))
    assert np.isclose(sys.measure,.81,rtol=2e-13)
    u=spsolve(sys.A,sys.b)
    np.testing.assert_allclose(u,grid.greville()[sys.ids,0],rtol=1e-8,atol=1e-8)


def test_manufactured_error_decreases():
    errors=[]
    for n in (4,8):
        a=Assembler(SplineGrid((n,n),2),quadrature=12,load='manufactured',bc='outer')
        s=a.assemble(TrimDomain(holes=((.51,.48,.16),)))
        u=spsolve(s.A,s.b)
        errors.append(a.errors(s,u,quadrature=18)['H1_seminorm'])
    assert errors[0]/errors[1]>3.0


def test_irrelevant_hole_does_not_change_local_quadrature():
    cell=(.3,.4,.3,.4)
    a=TrimDomain(holes=((.5,.5,.22),(.31,.8,.04)))
    b=TrimDomain(holes=((.5,.5,.22),(.33,.8,.04)))
    assert a.signature(cell)==b.signature(cell)
    qa,wa=cut_quadrature(cell,a,7);qb,wb=cut_quadrature(cell,b,7)
    np.testing.assert_array_equal(qa,qb)
    np.testing.assert_array_equal(wa,wb)


def test_cached_and_fresh_assembly_match_after_local_edit():
    grid=SplineGrid((14,14),3)
    a=Assembler(grid,quadrature=8)
    a.assemble(TrimDomain(holes=((.28,.28,.12),(.72,.72,.12))))
    geo=TrimDomain(holes=((.28,.28,.1201),(.72,.72,.12)))
    s=a.assemble(geo);fresh=Assembler(grid,quadrature=8).assemble(geo)
    np.testing.assert_array_equal(s.ids,fresh.ids)
    np.testing.assert_allclose(s.A.toarray(),fresh.A.toarray(),rtol=0,atol=0)
    np.testing.assert_allclose(s.b,fresh.b,rtol=0,atol=0)


def test_roof_top_intersection_is_integrated_exactly():
    points,w=cut_quadrature((0.,1.,0.,1.),TrimDomain(top=.3,roof=((0.,0.),(1.,1.))),4)
    assert abs(w.sum()-.255)<2e-14
