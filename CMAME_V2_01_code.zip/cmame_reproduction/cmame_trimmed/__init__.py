"""Experiments on preconditioner reuse for evolving trimmed spline domains."""
