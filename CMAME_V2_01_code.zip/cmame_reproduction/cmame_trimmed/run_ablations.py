"""Serial equal-work screening and block-size ablations, after run_all.py."""
import json,time,hashlib,shutil
from cmame_trimmed.experiments import specs,save,RESULTS,ROOT
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.assembly import Assembler
from cmame_trimmed.src.geometry import TrimDomain
from cmame_trimmed.src.solver import solve,direct_reference
from cmame_trimmed.src.preconditioners import EnergyBudget
import numpy as np


def run_group(group,case,configs,steps=8,repeats=3):
    cells,p,physics,width,geos=specs(case,steps);rows=[];failures=[]
    for rep in range(repeats):
        a=Assembler(SplineGrid(cells,p),physics=physics,quadrature=max(12,p+6));caches={};previous={}
        budgets={k:EnergyBudget(seed=20262016+rep,probes=c.get('probes',12),power=c.get('power',2),delta_total=c.get('risk',1e-8),min_dimension=c.get('min_dimension',12*c.get('probes',12)*c.get('power',2))) for k,c in configs.items()}
        for t,g in enumerate(geos):
            system=a.assemble(g);reference,_=direct_reference(system)
            keys=list(configs);keys=keys[(rep+t)%len(keys):]+keys[:(rep+t)%len(keys)]
            for key in keys:
                config=configs[key];guess=None
                if key in previous:
                    ids,oldx=previous[key];guess=np.zeros(len(system.ids));_,new,old=np.intersect1d(system.ids,ids,return_indices=True);guess[new]=oldx[old]
                attempt=time.perf_counter()
                try:
                    x,c,r=solve(system,config.get('method','energy'),cache=caches.get(key),step=t,width=config.get('width',width),tau=config.get('tau',.2),reference=reference,x0=guess,probability_state=budgets[key])
                    caches[key]=c
                    if r['success']:previous[key]=(system.ids,x)
                    r.update(configuration=key,repeat=rep,case=case);rows.append(r)
                except (np.linalg.LinAlgError,FloatingPointError,ValueError,RuntimeError) as e:
                    failures.append(dict(configuration=key,repeat=rep,step=t,error=repr(e),attempt_seconds=time.perf_counter()-attempt))
                    caches.pop(key,None);previous.pop(key,None)
            save('ablation_'+group,dict(configurations=configs,case=case,steps=steps,repeats=repeats,rows=rows,failures=failures))
            print(group,rep,t,flush=True)


def update_sensitivity():
    """Longer sequences and larger edits; each method owns its warm start."""
    methods=['fresh','exact_local','energy','stale','jacobi']
    rows=[];failures=[];steps=24;repeats=3;multipliers=[.25,1.,5.,20.]
    for multiplier in multipliers:
        for rep in range(repeats):
            a=Assembler(SplineGrid((32,32),3),physics='elasticity',quadrature=12)
            caches={};previous={};budget=EnergyBudget(seed=20263016+rep,min_dimension=288)
            for t in range(steps):
                g=TrimDomain(holes=((.35+.00012*multiplier*t,.48,.16),(.74,.6,.1)))
                system=a.assemble(g);reference,_=direct_reference(system)
                order=methods[(rep+t)%len(methods):]+methods[:(rep+t)%len(methods)]
                for method in order:
                    try:
                        guess=None
                        if method in previous:
                            ids,oldx=previous[method];guess=np.zeros(len(system.ids))
                            _,new,old=np.intersect1d(system.ids,ids,return_indices=True);guess[new]=oldx[old]
                        x,c,r=solve(system,method,cache=caches.get(method),step=t,width=12,tau=.2,reference=reference,x0=guess,probability_state=budget if method=='energy' else None)
                        caches[method]=c
                        if r['success']:previous[method]=(system.ids,x)
                        r.update(multiplier=multiplier,repeat=rep);rows.append(r)
                    except (np.linalg.LinAlgError,FloatingPointError,ValueError,RuntimeError) as e:
                        failures.append(dict(multiplier=multiplier,repeat=rep,step=t,method=method,error=repr(e)))
                        caches.pop(method,None);previous.pop(method,None)
                save('update_sensitivity',dict(steps=steps,repeats=repeats,multipliers=multipliers,methods=methods,rows=rows,failures=failures,
                     config=dict(cells=[32,32],degree=3,physics='elasticity',width=12,tau=.2,risk_budget=1e-8,probes=12,power=2,min_screen_dimension=288,base_step=.00012,seed_base=20263016)))
                print('update_sensitivity',multiplier,rep,t,flush=True)


if __name__=='__main__':
    files=sorted((ROOT/'src').glob('*.py'))+[ROOT/'experiments.py',ROOT/'run_ablations.py']
    manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    save('ablation_source_hashes',manifest)
    for relative in manifest:
        target=RESULTS/'ablation_sources'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/relative,target)
    run_group('screening','elastic_plate',{
        'q1_s24':dict(power=1,probes=24),'q2_s12':dict(power=2,probes=12),'q4_s6':dict(power=4,probes=6),
        'tau005':dict(tau=.05),'tau05':dict(tau=.5),'risk1e4':dict(risk=1e-4),'risk1e12':dict(risk=1e-12),
        'no_size_guard':dict(min_dimension=0)})
    configs={f'w{w}_{m}':dict(width=w,method=m) for w in (4,8,12,16) for m in ('fresh','exact_local','energy')}
    run_group('block_size','moving_hole',configs)
    update_sensitivity()
    save('ablations_complete',dict(completed=time.strftime('%Y-%m-%d %H:%M:%S %z')))
