"""Serial, deterministic numerical experiments. Run from the repository root."""
import argparse, json, os, platform, time, sys
from pathlib import Path
import numpy as np
from scipy import sparse,linalg
from cmame_trimmed.src.space import SplineGrid
from cmame_trimmed.src.geometry import TrimDomain
from cmame_trimmed.src.assembly import Assembler
from cmame_trimmed.src.solver import solve,direct_reference,equilibrate
from cmame_trimmed.src.preconditioners import build_schwarz,EnergyBudget
ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results';RESULTS.mkdir(exist_ok=True)


def save(name, data):
    target=RESULTS/(name+'.json');temporary=target.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,indent=2,allow_nan=False));temporary.replace(target)


def specs(name,steps=16):
    if name=='moving_hole':
        return (48,48),3,'poisson',12,[TrimDomain(holes=((.472+.0002*t,.51,.183),)) for t in range(steps)]
    if name=='local_plate':
        return (64,64),3,'poisson',16,[TrimDomain(holes=((.28,.28,.12+.00008*t),(.72,.28,.12),(.28,.72,.12),(.72,.72,.12))) for t in range(steps)]
    if name=='active_crossing':
        return (32,32),3,'poisson',8,[TrimDomain(top=.699+.002*t,holes=((.46,.35,.142),)) for t in range(steps)]
    if name=='elastic_plate':
        return (32,32),3,'elasticity',12,[TrimDomain(holes=((.35+.00012*t,.48,.16),(.74,.6,.1))) for t in range(steps)]
    if name=='elastic_solid':
        return (12,12,6),2,'elasticity',4,[TrimDomain(holes=((.47+.00005*t,.51,.173),)) for t in range(steps)]
    if name=='large_plate':
        return (96,96),3,'poisson',16,[TrimDomain(holes=((.28,.28,.12+.00008*t),(.72,.28,.12),(.28,.72,.12),(.72,.72,.12))) for t in range(steps)]
    if name=='ridge':
        return (32,32),3,'poisson',8,[TrimDomain(roof=((0,.62),(.3,.62),(.42,.012),(.5,.69+.0002*t),(.58,.012),(.7,.62),(1,.62))) for t in range(steps)]
    raise ValueError(name)


def sequence(name,repeats=3,steps=16,methods=None,tau=.2,output_name=None,warmstart=True):
    cells,p,physics,width,geometries=specs(name,steps)
    methods=methods or ['fresh','exact_local','energy','energy_deterministic','energy_raw','stale','periodic','jacobi','cbas','deflation','direct']
    rows=[];failures=[]
    for rep in range(repeats):
        assembler=Assembler(SplineGrid(cells,p),physics=physics,quadrature=max(12,p+6))
        caches={};previous={};budgets={m:EnergyBudget(seed=20261016+rep,min_dimension=288) for m in ('energy','energy_raw')}
        for t,geometry in enumerate(geometries):
            try:
                system=assembler.assemble(geometry)
                ref,refcost=direct_reference(system)
            except Exception as e:
                failures.append(dict(case=name,repeat=rep,step=t,method='assembly_or_reference',error=repr(e)))
                save(output_name or 'sequence_'+name,dict(rows=rows,failures=failures))
                raise
            # Rotate deterministic method order to reduce order/temperature bias.
            order=methods[(rep+t)%len(methods):]+methods[:(rep+t)%len(methods)]
            for method in order:
                try:
                    guess=None
                    if warmstart and method in previous:
                        ids,values=previous[method];guess=np.zeros(len(system.ids))
                        _,new,old=np.intersect1d(system.ids,ids,return_indices=True)
                        guess[new]=values[old]
                    x,c,row=solve(system,method,cache=caches.get(method),step=t,tau=tau,width=width,reference=ref,x0=guess,probability_state=budgets.get(method))
                    if row['success']:previous[method]=(system.ids,x)
                    caches[method]=c;row.update(case=name,repeat=rep,physics=physics,degree=p,cells=list(cells))
                    rows.append(row)
                except (np.linalg.LinAlgError,FloatingPointError,ValueError,RuntimeError) as e:
                    failures.append(dict(case=name,repeat=rep,step=t,method=method,error=repr(e)))
                    # The next changed-element list covers only one step. A cache
                    # from an older query cannot use that list as a skip proof.
                    caches.pop(method,None);previous.pop(method,None)
            if rep==0 and t in (0,len(geometries)-1):
                np.savez_compressed(RESULTS/(name+f'_state_{t:02d}.npz'),ids=system.ids,solution=ref,cells=cells,degree=p,components=system.components,
                                    holes=np.array(geometry.holes).reshape(-1,3),top=geometry.top,roof=np.array(geometry.roof).reshape(-1,2))
            save(output_name or 'sequence_'+name,dict(config=dict(cells=cells,degree=p,physics=physics,width=width,steps=steps,repeats=repeats,tau=tau,methods=methods,warmstart=warmstart,seed_base=20261016,risk_budget=1e-8,probes=12,power=2,min_screen_dimension=288,quadrature=max(12,p+6)),rows=rows,failures=failures))
            energy=[r for r in rows if r['repeat']==rep and r['step']==t and r['method']=='energy']
            print(name,rep,t,'dofs',len(system.b),'energy',[(round(r['linear'],3),r.get('stat_reused_energy'),r.get('stat_refreshed')) for r in energy],flush=True)
    return rows


def accuracy():
    rows=[]
    for p in (1,2,3,4):
        for n in (4,8,16,32):
            a=Assembler(SplineGrid((n,n),p),load='manufactured',bc='outer',quadrature=p+9)
            s=a.assemble(TrimDomain(holes=((.51,.48,.17),)));x,cost=direct_reference(s)
            row=dict(degree=p,n=n,dofs=len(x),**a.errors(s,x,quadrature=p+14));rows.append(row)
            print('accuracy',row,flush=True)
    quads=[];systems=[]
    for q in (6,8,12,16,24):
        a=Assembler(SplineGrid((16,16),3),quadrature=q);s=a.assemble(TrimDomain(holes=((.51,.48,.17),)))
        x,_=direct_reference(s);systems.append((q,s,x))
    qr,sr,xr=systems[-1]
    for q,s,x in systems:
        e=x-xr
        quads.append(dict(order=q,matrix_relative_frobenius=float(sparse.linalg.norm(s.A-sr.A)/sparse.linalg.norm(sr.A)),
                          energy_difference=float(np.sqrt(max(0,e@(sr.A@e))/(xr@(sr.A@xr)))),area_error=abs(s.measure-(1-np.pi*.17**2))))
    save('accuracy',dict(convergence=rows,quadrature=quads))


def cut_study():
    rows=[];failures=[]
    for geometry_type in ('fixed_domain_sliver','thin_domain'):
        for p in (2,3,4):
            for eta in (1.,.1,.01,.001,.0001,.00001):
                a=Assembler(SplineGrid((12,12),p),quadrature=p+4)
                top=(7+eta)/12 if geometry_type=='fixed_domain_sliver' else eta/12
                s=a.assemble(TrimDomain(top=top));ref,_=direct_reference(s)
                for method in ['jacobi','cbas','deflation','fresh','direct']:
                    try:
                        x,c,r=solve(s,method,width=4,reference=ref,maxiter=3000)
                        r.update(degree=p,cut=eta,geometry_type=geometry_type);rows.append(r)
                    except Exception as e:failures.append(dict(degree=p,cut=eta,geometry_type=geometry_type,method=method,error=repr(e)))
                print('cut',geometry_type,p,eta,flush=True)
    save('cut_study',dict(rows=rows,failures=failures))


def spectral_audit():
    rows=[];a=Assembler(SplineGrid((8,8),3),quadrature=12);cache=None;budget=EnergyBudget()
    for t in range(14):
        s=a.assemble(TrimDomain(holes=((.49+.0005*t,.51,.18),)));blocks=s.blocks(width=4)
        C,_,_=equilibrate(s.A,s.b)
        fresh,_,_=build_schwarz(C,blocks,s.ids)
        reuse,cache,stats=build_schwarz(C,blocks,s.ids,mode='prob_energy',cache=cache,tau=.2,step=t,probability_state=budget)
        eye=np.eye(len(s.b));F=fresh@eye;B=reuse@eye
        eig=linalg.eigvalsh((B+B.T)/2,(F+F.T)/2)
        la=linalg.cholesky(C.toarray(),lower=True)
        ef=linalg.eigvalsh(la.T@F@la);er=linalg.eigvalsh(la.T@B@la)
        drifts=[];majorants=[];sizes=[]
        for block in blocks:
            h=cache[tuple(s.ids[block])];current=C[block,:][:,block].toarray();delta=current-h.anchor
            de=linalg.eigvalsh(delta/h.scale[:,None]/h.scale[None,:],h.anchor/h.scale[:,None]/h.scale[None,:])
            h.prepare_energy();d=np.sqrt(h.inverse_diagonal)
            drifts.append(float(np.max(np.abs(de))));majorants.append(float(d@np.abs(delta)@d));sizes.append(len(block))
        rows.append(dict(step=t,lower=float(eig[0]),upper=float(eig[-1]),fresh_condition=float(ef[-1]/ef[0]),reuse_condition=float(er[-1]/er[0]),max_exact_drift=max(drifts),drifts=drifts,majorants=majorants,sizes=sizes,**stats))
    save('spectral_audit',dict(tau=.2,min_screen_dimension=0,rows=rows))


def ablation():
    for tau in (.05,.1,.4,.7):
        sequence('local_plate',repeats=2,steps=12,methods=['energy'],tau=tau,output_name='ablation_tau_'+str(tau))


def metadata():
    import scipy,matplotlib,subprocess
    info=dict(date=time.strftime('%Y-%m-%d %H:%M:%S %z'),python=sys.version,numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,platform=platform.platform(),processor=platform.processor(),threads={k:os.getenv(k) for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']})
    try:info['cpu']=subprocess.check_output(['/usr/sbin/sysctl','-n','machdep.cpu.brand_string']).decode().strip()
    except Exception:pass
    save('environment',info)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('task');parser.add_argument('--repeats',type=int,default=3);parser.add_argument('--steps',type=int,default=16);args=parser.parse_args()
    metadata()
    if args.task in ('accuracy','cut_study','spectral_audit','ablation'):globals()[args.task]()
    else:sequence(args.task,args.repeats,args.steps)
